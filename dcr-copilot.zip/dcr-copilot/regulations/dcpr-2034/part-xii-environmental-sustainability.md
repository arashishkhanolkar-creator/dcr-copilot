# Part XII: Environmental Sustainability

61. Public Sanitary Convenience (PSC) Blocks/Toilets
With the approval of the Commissioner, PSC blocks may be constructed, maintained and
made available for general public use on Municipal/Govt. plots, which are
reserved/designated existing amenity for public purpose in the following manner:
i) The location of PSC blocks shall be such that the same are accessible for general public
use.
ii) The toilets shall be maintained by the user of the plot or as decided by the
Commissioner.
iii) On plots having non-buildable/POS reservation/designation existing amenity and having
area more than 4,000 sq. m, 2 toilets and 2 urinals each for ladies and gents may be
constructed and preferably one toilet for differently abled persons and one urinal for
children shall be constructed.
iv) On plots having non-buildable/POS reservation/designation existing amenity and having
area less than 4,000 sq. m, 1 toilet and 2 urinals each for ladies and gents may be
constructed.
v) On plots having buildable reservation/designation existing amenity and having area
more than 4,000 2000 sq. m and abutting to Public Street, 1 toilet and 2 urinals each for
ladies and gents may be constructed and preferably one toilet for differently abled
persons and one urinal for children shall be constructed while developing the plot. On plots
having buildable designation existing amenity and having area more than 2000 sq. m, 1
toilet and 2 urinals each for ladies and gents and preferably one toilet for differently abled
persons and one urinal for children may be constructed. The PSC so proposed preferably
shall have access directly from the public street and shall be located in such a way that, it
shall not cause nuisance to the occupants of the plot and same shall have to be maintained
as decided by the Commissioner in hygienic condition. The BUA of toilet block shall be
counted in BUA of the reservation to be handed over to Appropriate Authority. Efforts shall
be made to construct PSC blocks at a distance of every 3 km. especially near the bus stop
along highway/major roads taking in to consideration other requirements for provision of
PSC block.
(EP-157)
vi) Construction of such PSC may be allowed touching the plot boundary and accessible
from Public Street. The joint open space between the structure of primary user and the
structure for PSC shall not be less than required front open space for structure of primary
user or 3 m whichever is higher.
vii) The PSC to the extent specified shall be permissible free of FSI.
viii) Availability of PSC shall be displayed in such a way that it is clearly seen from Public
Street.
ix) Substation can be provided above PSC as per the requirement of Electric Supply
Company subject to NOC from CFO.
62. Rain Water Harvesting (RWH)
General: The Rain Water Harvesting (RWH) arrangement shall be provided in case of
Development /Redevelopment of plots having area of 500 sq. m and more. It shall have
one or more RWH structures having a minimum total capacity as detailed in schedule
below;
Provided that the professional on record shall certify that the RWH System /Structures
have been constructed as per the specification or of specifications different from those in
Schedule, subject to the minimum capacity of RWH System being ensured in each case.
The owner/society of every building shall ensure that the RWH structure/system is
maintained in good condition for storage of water for non-potable purposes or recharge of
ground water at all times.
The Authority may impose a levy of not exceeding Rs.1000/- per annum for every 100
Sq.Mt. of built-up area for the failure of the owner of any building mentioned in the (a)
above to provide or to maintain Rain Water Harvesting structures as required under these
byelaws.
(EP-158)
SCHEDULE
RWH in a building site includes storage or recharging into ground of rain water falling on
the terrace or on any paved or unpaved surface within the building site.
1. The following systems may be adopted for harvesting the rain water drawn from
terrace and the paved surface.
(i) Open well of a minimum diameter of 1 m and minimum depth of 6 m OR open well of a
minimum diameter of 0.3 m and minimum depth of 2 m at every 6 m in the Storm
Water Drain, into which rain water may be channeled, after filtration for removing silt
and floating material. The well shall be provided with ventilating covers. The water
from the open well may be used for non-potable domestic purposes such as washing,
flushing and for watering the garden.
(ii) RWH for recharge of ground water may be done through a bore well around which a pit
of one meter width may be excavated up to a depth of at least 3 m and refilled with
stone aggregate and sand. The filtered rain water may be channeled to the refilled pit
for recharging the bore well.
(iii) An impervious surface/underground storage tank of required capacity may be
constructed in the open space and the rain water may be channeled to the storage
tank. The storage tank shall always be provided with ventilating covers and shall have
drawn-off taps suitably placed so that the rain water may be drawn off for domestic
washing, gardening and such other purposes. The storage tanks shall be provided with
an overflow.
(iv) The surplus rain water after storage may be recharged into ground through percolation
pits or trenches or combination of pits and trenches. Depending on the
geomorphological and topographical condition, the pits may be of the size of 1.20 m
width x 1.20 m length x 2.00 m to 2.50 m depth. The trenches can be of 0.60 m width x
2.00 to 6.00 m length x 1.50 to 2.00 m depth. Terrace water shall be channeled to pits
or trenches. Such pits or trenches shall be back filled with filter media comprising the
following materials.
a) 40 mm stone aggregate as bottom layer up to 50% of the depth;
b) 20 mm stone aggregate as lower middle layer up to 20% of the depth;
c) Coarse sand as upper middle layer up to 20% of the depth;
d) A thin layer of fine sand as top layer;
e) Top 10% of the pits/ trenches will be empty and a splash is to be provided in this
portion in such a way that roof top water falls on the splash pad.
f) Brick masonry wall is to be constructed on the exposed surface of pits/ trenches and
the cement mortar plastered.
The depth of wall below ground shall be such that the wall prevents lose soil entering
into pits/trenches. The projection of the wall above ground shall be at least 15 cm.
g) Perforated concrete slabs shall be provided on the pits/trenches.
(v) If the open space surrounding the building is not paved, the top layer up to a sufficient
depth shall be removed and refilled with course sand to allow percolation of rain water
into ground.
(vi) For effective drainage of rain water, the roof of building shall be so constructed or
framed as to permit effective drainage of the rain water there from by means of rain
water pipes. Such pipes shall be so arranged, joined and fixed so as to ensure that the
rain water is carried away from the building without causing dampness in any part of
the walls or foundation of the building or those of adjacent buildings.
2. The terrace shall be connected to the open well/bore well/storage tank/recharge pit/
trench by means of HDPE/PVC pipes through filter media. A valve system shall be
provided to enable drain away the first washings from roof or terrace catchment, as
they would contain undesirable dirt. The mouths of all pipes and openings shall be
covered with mosquito (insect) proof wire net. For the efficient discharge of rain
water, there shall be at least two rain water pipes of 100 mm dia. for a roof area of 100
sq. m.
3. RWH structures shall be so sited as not to endanger the stability of building or
earthwork. The structures shall be designed such that no dampness is caused in any
part of the walls or foundation of the building or those of an adjacent building.
4. The water so collected/ recharged shall as far as possible be used for non-
drinking and non-cooking purpose.
Provided that when the rain water in exceptional circumstances will be utilised
for drinking and/ or cooking purpose, it shall be ensured that proper filter
arrangement and the separate outlet for by passing the first rain-water has
been provided.
Provided further that it will be ensured that for such use, proper disinfectants
and the water purification arrangement have been made.
(EP-159)
63. Special Provisions; for installation of Solar Water Heating (SWH) Systems.
Solar Water Heating (SWH) Systems shall be installed in the buildings for Hospitals,
Hotels, Guest Houses, Police/Army Barracks, Canteens, Laboratories and Research
Institutions, Hostels of Schools and Colleges and other Institutions.
1. The SWH systems shall be mandatory in hospitals and hotels, where the hot
water requirement is of continuous nature. In these buildings, the system shall
be provided with auxiliary electrical back-up.
2. The use of SWH system is recommended in the following type of buildings in
Govt/Semi–Govt and Institutional buildings where the hot water requirement
may not be continuous/permanent:
1) Guest House
2) Police/Army barracks
3) Canteens
4) Laboratory and Research Institutions where hot water is needed
5) Hostels of Schools and Colleges and other Institutes.
3. The use of SWH system may be allowed in any other building.
The installation of the electrical backup in all such water heating systems shall
be optional depending on the nature of requirement of hot water.
It is suggested that SWH systems of the capacity of about 100 liters per day on
thermosyphon with necessary electrical back-up be installed at residential
buildings like hostels.
In order to facilitate the installation of the SWH systems, the new buildings of
aforesaid types shall have the following provisions.
1) All such buildings where SWH systems are to be installed will have open
sunny roof area available for installation of SWH system.
2) The roof loading adopted in the design of such building should be at least
50 kg/sq. m for the installation of SWH system.
3) SWH systems can also be integrated with the building design. These can
either be put on the parapet or could be integrated with the south facing,
vertical wall of the building. The best inclination of the solar energy
collector for regular use throughout the year is equal to the local Latitude
of the place. The solar energy collector should be facing south. However,
for only winter use, the optimum inclination of the solar energy collector
would be Latitude+15 degrees of the south.
4) All the new buildings of aforesaid types to be constructed shall have an
installed hot water line from the roof top and also insulated distribution
pipelines to each of the points where hot water is required in the building.
5) The capacity of the SWH system to be installed on the building shall be
decided on the basis of the average occupancy of the buildings. The norms
for hospitals, hotels and other buildings are given below:
Sr. No. Type of Building Per capita capacity
recommended (litres per
day).
1 Hospitals 100
2 Hotels 150
3 Hostels & other such buildings 25
4 Canteen As required
5 Laboratory & Research Institutions As required.
6 Other buildings As required.
6) An open area of 3 sq. m would be required for installation of a solar energy
collector which supplies about 100 liters of water per day. At least 60 per cent of
the roof area may be utilised for installation of the system.
7) The specification for the SWH system laid down by the Ministry of Non-
Conventional Energy Sources can be followed. Flat plate Collector conforming to IS
12933 shall be used in all such solar water heating systems.
Note: 1. The Commissioner may add to the list of buildings mentioned above on
which installation of SWH systems can be made mandatory.
2. The Commissioner may insist on installation of solar energy collectors on
the terraces of the buildings for harnessing solar energy for purposes
other than water heating as well.
3. The construction of SWH system shall be in conformity with IS 12976.
64. Waste (Grey) Water Recycling and Reuse
(1) Development/redevelopment of the plots which attract requirements/provisions of
Notifications of Ministry of Environment and Forest (MoEF), Government of India, issued
from time to time shall have the provision for recycling and reuse of waste water.
Provision of recycling and reuse of waste water system may also be permissible in any
development other than mentioned above. The professional on record shall certify the
detailed scheme for the recycle and reuse of waste water.
The Waste Water Recycling System shall include the following:
i) Waste water other than from water closet, laundries, and hospitals shall be recycled.
ii) The system shall not constitute a nuisance of foul gases and/or cause public hazard
due to its installation and operation.
iii) The waste water recycling system shall be designed considering the anticipated
occupancy load and seasonal fluctuations in discharge.
iv) Separating of Waste Water:
(a) The waste water shall be recycled by installing recycling plant.
(b) Separate plumbing network shall be installed to collect waste water from kitchens,
bath rooms, washing machines and dish washers leading to recycling plant with
separate underground and overhead tanks provided for this purpose.
(c) The entire connecting network shall be painted in purple blue color.
(d) Recycled Waste Water system shall be maintained in good condition and shall
comply with the requirements of Maharashtra Pollution Control Board (MPCB), if any.
(2) Reuse of Waste Water:
i) The treated waste water shall be used only for gardening, toilet flushing, landscape,
irrigation, cooling towers, car washing, etc. and in no case for drinking, bathing, or washing
clothes and utensils.
ii) The output water quality shall conform to the standards of non-potable water as may be
prescribed by the MPCB.
iii) A clause must be included by the owner/developer in the purchase agreement with the
purchaser, owner of the premises/organization or society of the occupiers or the society of
purchasers stating that recycled waste water system has been provided in the
development and shall have to be maintained in good condition as per the requirements of
MPCB, if any.
65. Sewage Treatment Plant (STP) & Disposal
Development/redevelopment of the plots which attract requirements/provisions of
relevant Notification of Ministry of Environment and Forest (MoEF), Government of India
issued from time to time shall be provided with Sewage Treatment Plant (STP) and disposal
system.
Provision of STP and disposal system may also be permissible in any development other
than mentioned above. The professional on record shall certify the detailed scheme for the
STP and disposal system.
STP shall comply with the following:
a) STP structure shall be of compact design & completely covered, above ground, open to
sky and shall not be constructed in the basement for residential building. Aeration
tank/secondary treatment units shall not be closed from the top and it shall be treated
with tertiary treatment including disinfection.
In case of buildings other than residential buildings where space is a constraint and STP
need to be planned in first basement and can be permitted only if advanced technologies
such as membrane technologies with full automation are used. In no case the STP with
aeration tanks/Moving Bed Bio Reactor (MBBR)/Sequencing Batch Reactor (SBR) or other
attached growth process shall be allowed in basement.
(EP-160)
b) There shall not be any foul odour around the STP area or in the ambient environment.
c) STP shall not require continuous monitoring and operation and shall work well with
inconsistent inflow.
d) Treated water quality shall be of non-potable standards and can be reused for
gardening, toilet flushing, landscape, irrigation, cooling towers, car washing, etc. but in no
case for drinking, bathing, or washing clothes and utensils.
e) Treated water shall be environmentally safe to dispose of in Land or Water.
f) A clause must be included by the owner/developer in the purchase agreement with the
purchaser, owner of the premises/organization or society of the occupiers or the society of
purchasers stating that, STP has been provided in the development and shall have to be
maintained in good condition as per the requirement of the Maharashtra Pollution Control
Board (MPCB).
66. Solid Waste Segregation
All buildings shall be provided with separate coloured bins to collect dry waste (paper,
plastic, metal, glass, etc.) and wet waste (organic waste). Dedicated space shall be
allocated for collecting waste before transferring waste for recycling/disposal separately.
Separate bins shall be provided for safe disposal of hazardous waste (batteries, e-waste,
lamps, medical waste, etc.) as provided in hazardous waste management guidelines
prescribed by the Ministry of Environment and Forest (MoEF), Government of India.
Provision for treating the wet waste in situ will have to be made and a clause must be
included by the owner/developer in the purchase agreement with the purchaser, owner of
the premises/organization or society of the occupiers or the society of purchasers stating
that, wet waste will be treated in situ and shall have to be maintained in operational
condition as per the requirement of MCGM if any.
The planning design, construction and installation of Solid Waste Management System
shall be as per the National Building Code of India, Part 9 Plumbing Services, Section 1-
Water Supply, Drainage and Sanitation (Including Solid Waste Management) Paragraph 6.
On the plots having total construction area 20,000 Sq.mt & above Bio-degradable
Waste Treatment Plant of required capacity shall be provided and maintained.
The area under construction of Solid Waste Management System /Bio-degradable
waste treatment plant shall be free of FSI.
The Completion Certificate for the Solid Waste Management System /Bio-
degradable Waste Treatment Plant issued by Environmental Consultant shall be submitted
before asking for Occupation Certificate/Building Completion Certificate.”
(EP-161)
67. Tree Plantation Provisions for Landscaping Enhancing/Conserving/
Preserving Biodiversity
i) The development in any plot of land shall be such as to preserve, as far as practicable,
the existing trees. Where trees are required to be felled, twice the number of indigenous
trees shall be planted for every tree to be felled.
ii) Every plot of land shall have at least
(a) at the rate of 5 indigenous trees per 100 sq. m or part thereof of the said
recreational space, to be grown within the entire plot.
(b) at the rate of 1 indigenous tree per 80 sq. m or part thereof to be grown in a
plot for which a sub-division or layout is not necessary.
iii) Trees shall be planted taking care that they shall not obstruct the maneuvering of
firefighting vehicles during an emergency.
iv) In between the indigenous trees planted along the boundary of plot, shrubs with grass
shall be planted.
v) The native species which have the capacity to attract birds for nesting shall be preferably
selected.
Note: - Indigenous trees are naturally growing trees available locally like mango, neem,
jackfruit, banyan, pipal etc.
68. Coastal Regulation Zone (CRZ)
Notwithstanding anything contained in these Regulations, any development within CRZ
areas shall be governed by the amended Coastal Regulation Zone Notification No.S.O.19
(E), dated 6th Jan, 2011 Ministry of Environment and Forest (MoEF), Government of India
as amended from time to time, wherever applicable. Lands shown as Natural Area in DP
and situated on the seaward side of High Tide Line, if after modification to High Tide Line,
falls on the landward side of modified High Tide Line, then in such case the said land will be
deemed to have been situated in the zone of adjoining land unless, said land is forest/salt
pan land/occupied by mangroves/mud flats.
(EP-162)
69. Environment Impact Assessment (EIA)
This Regulation shall be applicable to developments as specified in provisions of amended
Environmental Impact Assessment Notification No.S.O.1533 dated 14.09.2006 as amended
from time to time. The compliance of conditions of NOC/Remarks shall be the
responsibility of the owner/developer/project proponent. At the same time MCGM shall
carry out detailed risk analysis within a time bound manner.
MCGM shall also prepare comprehensive Environment Impact Assessment plans for the
Jurisdiction of MCGM.
70. Energy Efficient Buildings
Owner/Developer/Project proponent at his option may opt for the certification of Indian
Green Building code (IGBC)/Energy Conservation Building Conservation Code (ECBC). The
provisions of appliances/fitting as per IGBC/ECBC shall be as per direction of GOI/GOM if
any from time to time. Owner/Developer/Project proponent will be eligible for the
additional fungible compensatory area over and above than that permissible as per the
Regulation No 31(3) to the extent of 5%, if he submits certification from Competent
Authority.
APPENDICES AND ANNEXURES
APPENDIX- I
(Regulation 47)
Additional Fire Protection Requirements for High Rise and special Building: -
1. General
In addition to the provisions of fire Protection, National Building code of India, the
Chief Fire Officer may insist on suitable provisions in, high rise and special buildings or
premises from the fire safety and fire-fighting point of view depending on their
occupancy and height.
2. Construction: -
(1) Building materials: -
(i) Load bearing elements of construction and elements of construction for which
the required fire resistance is one hour or more shall be of non-combustible
material. Interior finish materials (wall paneling, floor coverings etc.) may be
permitted of materials having their rating for flame spread and smoke developed
not exceeding a very low flame spread limit in accordance with IS: 1642,1960
(Class I) Ceiling linings shall be non-combustible or of plasterboard.
(ii) Stairways and corridors shall not contain combustible materials.
(2) Structural members such as supports and load bearing walls shall have fire
resistance rating of 3 hour, transoms and ceilings at least 2 hours.
(3) Internal walls and partitions separating corridors from areas on floors that are used
for any purpose other than circulation shall have a fire resistance of not less than
one hour. There shall be no openings in such walls other than for doors or delivery
hatches with fire resistance not less than half an hour. Fire sections (fire walls) sub-
dividing the building to prevent fire spread, shall have a fire resistance, rating not
less than two hours.
(4) Facades excluding windows and doors shall consist of non-combustible building
materials. The minimum distance between the top of the opening on a lower floor
and the sill of that on the floor above it shall be 0.9 m., so that the fire would have
to travel at least 0.9 m. between storeys.
3. Staircase enclosures: -
(1) The internal enclosing walls of staircase shall be of brick or R.C.C. construction
with a fire resistance of not less than two hours. All enclosed staircases shall be
reached via a ventilated lobby and shall have access through self-closing doors of
at least half an hour fire resistance. These shall be single swing doors opening in
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
the direction of the escape. The door shall be fitted with check section door
closers. The floor landing of staircases shall not form part of common corridor.
(2) The staircase enclosures on the external wall of a building shall be ventilated to
the atmosphere at each landing or mid-landing.
(3) A permanent vent at the top equal to 5 per cent of the cross-sectional area of the
enclosure and open able sashes at each landing level with area not less than 0.5
sq. m. on the external wall shall be provided. The roof of the shaft shall be at
least 1 m. above the surrounding roof. There shall be no glazing or glass bricks in
any internal enclosing wall of a staircase. If the staircase is in the core of the
building and cannot be ventilated at each landing, a positive pressure of 5 mm.
water gauge by an electrically operated blower shall be maintained.
(4) The mechanism for pressuring the staircase shaft shall be so installed that it
operates automatically and also manually when the automatic fire alarm
operates.
4. Lift enclosures: -
(1) The walls enclosing the lift shafts shall have a fire resistance of not less than two
hours. Shafts shall have permanent vents at the top not less than 1800 m. m. (0.2
sq. m.) in clear area. Lifts motor rooms should preferably be sited at the top of
the shaft and shall be separated from lift shafts by the enclosing wall of the shaft
or by the floor of the motor rooms.
(2) Landing doors in lift enclosures shall open into the ventilated or pressurised
corridor/lobby and shall have fire resistance of not less than one hour.
(3) The number of lifts in one lift bank shall not exceed four. The shaft for the fire
lift in a lift bank shall be separated from each other by a brick masonry or R.C.C.
wall of fire resistance of not less than two hours. Lift car doors shall have fire
resistance of not less than one hour.
(4) If the lift shaft and lift lobby are in the core of the building, a positive pressure of
not less than 2.5 mm. and not more than 3 mm. water gauge by an electrically
operated bower shall be maintained in the lift lobby and positive pressure of not
less than 5 mm. water gauge shall be maintained in the lift shaft. The mechanism
for pressuring the lift shaft and lift lobby shall be so installed that they shall
operate automatically and also manually when the detector & automatic fire
alarm operates. The mechanism shall have facilities to operate manually.
(5) Exit from the lift lobby, if located in the core of the building, shall be through a
self-closing smoke stop door of a half-hour fire resistance.
(6) The lift machine room shall be separate and no other machinery shall be installed
therein.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
(7) Lifts shall not normally communicate with the basement. However, one of the
lifts may be permitted to reach the basement level provided the lift lobby at each
basement level is shall be pressurized and separated from the rest of the
basement areas, by a smoke-actuated fire resisting door of two hours’ fire
resistance. These doors can also be kept in hold-open position by an electro-
magnetic device to be linked with a smoke detector.
5. External windows.
The area of the open able external windows on a floor shall be not less than 2 1/2 per
cent of the floor area. The locks for these windows shall be fitted with budget lock of
the carriage key type (which can be opened with the point of a fireman's' axe).
6. Fire lifts
The following provisions shall be made for a fire lift. -
(a) To enable fire services personnel to reach the upper floors with minimum delay,
one or more of the lifts shall be so designed as to be available for the exclusive
use of such personnel in an emergency and be directly accessible to every
dwelling/lettable floor space of each floor.
(b) The lift shall have a floor area of not less than 1.4 sq. m. with a minimum
dimension of 1.12 m. It shall have a loading capacity of not less than 545 kg. (8
persons lift) with automatic closing doors.
(c) There shall be an alternate electric supply from a generator of an adequate
capacity apart from the electric supply in the building and the cables shall run in a
route safe from fire, i.e. within the lift shaft. In case of failure of normal electric
supply, it shall automatically trip over to alternate supply. For apartment
buildings, this change over of supply could be done through a manually operated
change-over switch.
(d) The operation of a fire lift shall be by a simple toggle or two button switch
situated in a glass fronted box adjacent to the lift at the entrance level. When the
switch is on, landing call-points will become inoperative and the lift will be on
care control only or on priority control device. When the switch is off, the lift will
return to normal working. This lift can be used by the occupants in normal times.
(e) The words 'FIRE LIFT' shall be conspicuously displayed in fluorescent paint on the
lift landing doors at each floor level.
(f) Collapsible gates shall not be permitted for lifts; the lifts shall have solid doors
with fire resistance of at least one hour.
(g) The speed of the fire lift shall be such that it can reach the top floor from ground
level within one minute.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
7. Basements: -
(1) Each basement shall be separately ventilated. Vents with cross, sectional area
(aggregate) not less than 2.5 percent of the floor area spread evenly around the
perimeter of the basement shall be provided in the form of grills or breakable
stall boards lights or pavement lights or by way of shafts. Alternatively, a system
of air inlets shall be provided at basement floor level and smoke outlets at
basement ceiling level. Inlets and outlets may be terminated at ground level with
stall boards or pavement lights as before but ducts to convey fresh air to the
basement floor level shall have to be laid. Stall boards and pavement lights
should be in position easily accessible to the Fire Brigade personal and rescue
teams and clearly marked 'SMOKE OUTLET' or AIR INLET' with an indication of
area served at or near the opening.
(2) The staircase of basements shall (a) be of enclosed type having fire resistance of
not less than two hours; (b) be situated at periphery of the basement to be
entered at ground level only from the open air and in such a, position that smoke
from any fire in the basement shall not enter and exit serving the ground and
upper storeys of the building; and (c) communicate with basement though a lobby
provided with fire-resisting self-closing doors of one hour fire resistance. If the
travel distance exceeds 18.50m the values mentioned in Regulation No 47(3)(i) (I
&ii), additional staircases at proper places shall be provided.
(3) Intake ducts may serve al basement levels but each basement and basement
compartment shall have separate smoke outlet duct or ducts.
(4) Mechanical extractors for smoke-venting system from lower basement levels shall
also be provided. The system shall be of such design as to operate on actuation
of heat sensitive detectors or sprinklers if installed and shall have a considerably
higher performance than the standard units. The system should also have an
arrangement to start it manually and shall be designed to function at a
temperature not less than 5500C.
(5) Kitchens working or gas fuel shall not be permitted in basements.
8. Floor space division (fire sections)
The floor space division on floors and in basements shall be as per provisions of N.B.C.
9. Service ducts.
(1) Service ducts shall be enclosed by walls having a fire resistance of not less than
two hours. Doors for inspection or access shall also have a fire resistance of not
less than two hours.
(2) If the cross-sectional area of a duct exceeds 1 sq. m it shall be sealed where it
passes a floor with non-combustible light material. The seal within the duct
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
maybe pierced for any service pipe or ventilated trunk and shall fit as closely as
possible around any such pipe or trunk.
(3) A permanent vent shall be provided at the top of the service shaft of cross-
sectional area not less than 460 sq. cm or 6.25 cm. for each 900-sq. cm of the
area of the shaft, whichever is more.
10. Refuse chutes and refuse chambers.
(1) Hoppers under refuse chutes shall be situated in a well-ventilated position and the
chutes shall be continued upwards with an outlet above roof level and with an
enclosure wall of non-combustible material with fire resistance of not less than two
hours. The hoppers shall not be located within the staircase enclose.
(2) Inspection panels and hopper (charging station) opening shall be fitted with light
fitting, metal doors, covers, having a fire resistance of not less than one hour. Flap
doors/covers i.e. push-in or lift-up type shall not be permitted.
(3) Refuse chutes shall not be provided in staircase walls and air conditioning shafts,
etc.
(4) Refuse chambers shall have walls and floors or roofs constructed of non-
combustible and impervious material and shall have a fire resistance of not less than
two hours. They shall be located at a safe distance from exit routes.
11. Building services
(1) Electrical Services
(a) The electric distribution cables wiring shall be laid in a separate duct. The
duct shall be sealed at every floor with non-combustible materials having the
same fire resistance as that of the duct.
(b) Water mains, telephone lines, inter-com lines, gas pipes or any other service
line shall not be laid in the duct for electric cables.
(c) Separate circuits for water pumps, lifts, staircase and corridor lighting and
blowers for the pressurizing system shall be provided directly from the main
switch gear panel and these circuits shall be laid in separate conduit pipes so
that a fire in one circuit will not affect the others. Master switches
controlling essential services circuits shall be clearly labelled.
(d) The inspection panel doors and any other opening in the shaft shall be
provided with air-tight fire doors having a fire resistance of not less than two
hours.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
(e) High, Medium and low voltage wiring running in shafts, and within a false
ceiling, shall run in metal conduits.
(f) An independent and well ventilated service room shall be provided on the
ground floor with direct access from outside or from the corridor for the
purpose of termination of electric supply from the licensees' service and
alternative supply cables. The doors provided for the service room shall have
fire resistance of not less than two hours.
(g) If the licensees agree to provide meters on upper floors, the licensees' cables
shall be segregated from consumers' cables by a partition in the duct. Meter
rooms on upper floors shall not open into staircase enclosures and shall be
ventilated directly to open air outside.
(h) PVC cables should have an additional sheathing or protection provided by
compounds sprayed on after installation.
(2) Town gas/L.P. Gas supply pipes
These pipes shall be run in shafts exclusively for this purpose and shall be on
external walls, away from the staircases. There shall be no inter-connection
between these shafts and the rest of the floors, Gas meters shall be housed in a
suitable constructed metal cupboard located in a well-ventilated space at ground
level.
(3) Staircase and Corridor Lightings
(a) The staircase and corridor lighting shall be on separate circuits and shall be
independently connected so that they could be operated by one switch
installation on the ground floor easily accessible to fire-fighting staff at any
time irrespective of the position of individual control of light points, if any.
(b) Staircase and corridor lighting shall also be connected to alternate supply as
defined in sub-Regulations (4). However, for assembly and institutional
buildings less than 32 m. when the alternate source of supply may be
provided by battery continuously trickle-charged from the electric mains.
(c) Double throw switches should be installed to ensure that the lighting in the
staircase and the corridor do not get connected to two sources of supply
simultaneously. A double throw switch shall be installed in the service room
to terminate the stand-by-supply.
(d) Emergency lights shall be provided in the staircase/corridors for multistoried
high rise and special buildings.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
(4) Alternate source of electric supply
A stand-by electric generator shall be installed to supply power to staircase and
corridor lighting circuits, fire lifts, the stand-by fire pump, pressurization fans and
blowers, smoke extraction and damper systems in case of failure of normal
electric supply. The generator shall be capable of taking starting current of all the
machine and circuits stated above simultaneously. If the stand-by pumps are
driven by diesel engine, the generator supply need not be connected to the stand
by pump.
(5) Transformer
(a) If transformers are housed in basement, they shall be necessarily in the first
basement in a separate fire resisting room of four house rating, at the
periphery of the basement. The rooms shall be protected by carbon dioxide
or BCF fixed installation system to protect transformers. The entrance to the
room shall be provided with a steel doors of two hours’ fire rating. A curb
(sili) of a suitable height shall be provided with at the entrance in order to
prevent the flow of oil from a ruptured transformer into other parts of the
basement. Direct access to the transformer room shall be provided
preferably from outside. The switch gears shall be housed in a separate room
separated from the transformer bays by a fire resisting wall with fire
resistance of not less than four hours.
(b) If housed in basement, the transformer shall be protected by an automatic
high pressure water spray system (emulsifying).
(c) Transformers housed at ground floor level shall be cut-off from the other
portion of the premises by fire resisting walls of four hours' fire resistance.
(d) They shall not be housed on upper floors except stilt at upper level & podium
if dry type.
(e) A tank of RCC construction of capacity capable of accommodating the entire
oil of the transformers shall be provided at lower level, to collect the oil from
the catch-pit in an emergency. The pipe connecting the catch-pit to the tank
shall be of non-combustible construction and shall be provided with a flame-
arrester.
(6) Air-conditioning
(a) Escape routes like staircases, common corridors, lift lobbies etc. shall not be
used as return air passages.
(b) The ducting shall be constructed of substantial gauge metal in accordance
with IS-655-1963 Metal Air Ducts (Revised).
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
(c) Wherever the ducts pass through fire-walls or floors, the opening around the
ducts shall be sealed with fire-resisting materials such as asbestos rope or
verniculire concrete glass wool.
(d) As far as possible, metallic ducts shall be used even for the return air instead
of space above the false ceiling.
(e) The materials used for insulating the duct system (inside or outside) shall be
of non-combustible materials such as glass wool, spun glass with neoprene
facing.
(f) Area more than 750 sq. m on the individual floor shall be segregated by a
fire-wall and automatic fire dampers for isolation shall be provided where the
ducts pass through fire walls. The fire dampers shall be capable of operating
manually.
(g) Air ducts serving floor areas, corridor etc. shall not pass through the staircase
enclosure.
(h) The air handling units shall as far as possible be separate for each floor and
air ducts for every floor shall be separate and in no way interconnected with
the ducting of any other floors.
(i) Automatic fire dampers shall be provided at the inlet of the fresh air duct and
the re-turn air duct of each compartment on every floor. They shall be so
arranged as to close by gravity in the direction of the air movement and to
remain tightly closed upon operation of a smoke detector.
(j) If the air handling unit serves more than one floor, the requirements given
above shall be compiled with an addition to the conditions given below: -
(i) Proper arrangements by way of automatic fire dampers working on smoke
detectors for isolating all ducting at every floor from the main riser shall be
made.
(ii) When the automatic fire alarm operates, the respective air handling units
of the air-conditioning system shall automatically be switched off.
(k) The air filters of the air-handling units shall be of non-combustible materials.
(l) The air handling unit room shall not be used for storage of any combustible
materials.
(m) Inspection panels should be provided in main trunking to facilitate the
cleaning of the duct of accumulated dust and to obtain access for
maintenance of fire dampers.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
(n) No combustible material shall be fixed nearer than 15 cm. to any duct unless
such duct is properly enclosed and protected with non-combustible material
(glass wool) or spun glass with neoprene facing enclosed and wrapped with
aluminum sheeting) at least 3.2 mm. thick and which does not readily conduct
heat.
(o) Materials used for false ceilings, runners and suspenders shall be of non-
combustible type.
(7) Boiler room
Boiler and boiler rooms shall conform to the Indian Boilers Act. The following
additional aspects should be taken into account in the location of boiler/boiler
room:
(a) Boilers shall not be allowed in a lower basement but may be allowed in
basements at first level and away from the escape routes.
(b) The boilers shall be installed in a fire-resisting room of 4 hours' fire resistance
rating situated on the periphery of the basement. Catch-pitch shall be
provided at the low level.
(c) Entry to this room shall be provided with a composite door of two hours’ fire
resistance.
(d) The boiler room shall be provided with fresh air inlets and smoke exhausts
directly to the atmosphere.
(e) The furnace oil tank for the boiler, if located in the adjoining room, shall be
separated by-fire resisting walls 4 hours rating. The entrance to this room
shall be provided with double composite doors. A kerb of suitable height
shall be provided at the entrance in order to prevent the flow of oil into the
boiler room in case of tank rupture.
(f) Foam inlets shall be provided on the external walls of the building near the
ground level to enable the fire services to use foam in case of fire.
12. Provision of First Aid and Fire-fighting Appliances
(1) First-aid firefighting equipment shall be provided on all floors including
basements lift rooms, etc. in accordance with IS: 2217-1963 Recommendations for
providing First-Aid Fire Fighting Arrangements in Public Buildings.
(2) The firefighting appliances shall be distributed over the building in accordance
with IS: 2190-1971 Code of Practice for Selection, Installation and Maintenance of
Portable First-Aid Fire Appliances.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
13. Fixed Fire-Fighting Installations
(1) Buildings shall be protected by wet riser, wet riser-cum-down corner, automatic
sprinkler, installation, high pressure water spray or foam generating system as
prescribed in sub-Regulations (2) to (6) below: -
(2) The wet riser/riser-cum-down comers' installation with capacity of water storage
tanks and fire pumps shall conform to the requirements specified in Table
hereunder.
Table
Firefighting installation requirements: -
Requirements
Sr. Type of the Water Supply Pump Capacity
No. building
Undergro
occupancy
Type of und Terrace Near the
Installation Static Tank underground Terrace Level
Tank Static Tank
(1) (2) (3) (4) (5) (6) (7)
Residential
1 buildings below Nil Nil Nil Nil Nil
32 m. in height
Residential
buildings-
(a) Above 32 m. Wet riser- 50,000 30000 2400 litres per 900 litres per
and not cum-down litres litres minute giving minute giving a
exceeding 70 m.
comer. a pressure not pressure not less
(if plot area is
less than 600 sq.
less than 3.2 than 3.2 kg/cm2
m) with
kg/cm2 at the at the topmost
topmost hydrant.
shopping/comme
hydrant.
rcial up to two
2 upper floor
2,400 litres
(b) Above 32 m.
and not Wet riser 1,50,000 30,000 per minute
exceeding 70 m. cum-down litres litres giving a 900 litres per
(if plot area is comer. pressure not minute giving a
less than 3.2 pressure not less
more than 600
kg/cm2 at the than 3.2 kg/cm2
sq. m) with
topmost at the topmost
shopping/comme
rcial up to two
hydrant. hydrant.
upper floor
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
(c) Exceeding 70 Wet riser 3,00,000 50,000 2800 litres per
m. cum down litres litres minute giving 900 litres per
corner pressure not minute giving
less than 3.2 pressure not less
kg/cm 2 at the than 3.2 kg/cm2
top most at the top most
hydrant. hydrant.
Non-residential
/Special type
buildings-
(a) Up to 15 m. in Nil 50,000 Nil Nil
Nil
height. litres
900 litres per
1400 litres per
(b) Above 15 m. Wet riser- 1,00,000 20,000 minute giving a
minute giving
but not cum-down litres litres pressure not less
a pressure not
exceeding 32 m. corner.
less than 3.2
than 3.2 kg/cm2
in height except
kg/cm2 at the
at the top
educational hydrant.
e (c x ) c
b
e A b e
u
b u d
i
o
l
t
d
in v
i
n e
n
g o
g
3 7 t
s
2 0
.
m m . . c W u
c
m e
o
t -
r
d r
n
i o s
e
e w
r
r n - 1,0 lit 0 r , e 0 s 0 0 3 l 0 it , r 0 e 0 s 0
t
h
2 a m
o
y
4 p
p
d
i 0 n r
m
r
0 e u
a
s
o
l t
n
i s e
s
t
t
u r
t
g e r e i s v i n p n o e g t r p m r 9 e i 0 n s 0 s u u t l r i e t e r g e n i s v o i p t n e l g e r a s s
in height except less than 3.2 than 3.2 kg/cm2
(3) educational kg/cm2 at the at the top
buildings. (If area topmost hydrant.
of plot is less
hydrant.
than 600 sq. m)
(d) Above 32 m.
2400 litres per 900 litres per
but not 1,50,000 30,00
exceeding 70 m. Wet riser- litres litres minute giving minute giving a
(I
m
f a
o
r
r
e
e
a
t h
o
a
f
n
p l
o
t
is cu
c
m
or
-
n
d
e
o
r
w
.
n a
l e
p
s
r
s
e s
th
su
a
r
n
e
n
.2
o t p
th
re
a
s
n
s u
r
.2
e
k
n
g
o
/
t
c
l
m
es
s
kg/cm2 at the at the top
sq. m
topmost hydrant.
hydrant.
e
h
)
e
A
ig
b
h
o
t
v
b
e
u
il
d i
m
ng
.
s
in
. 3,00,000 50,000 2800 litres per 900 litres per
(If area of plot is Wet riser- litres. litres minute giving minute giving a
cum-down a pressure not pressure not less
more than 600
corner. less than 3.2 than 3.2 kg/cm2
sq. m)
kg/cm2 at the at the top
topmost hydrant.
hydrant.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
Note:
1. Any of the above categories may incorporate an automatic sprinkle/a drencher
system, if the risk is such that it requires such protective methods.
2. A minimum of two hydrants shall be provided within a courtyard.
3. Wet riser-cum-down corner is an arrangement for firefighting within the
building by means of vertical rising mains of not less than 10 cm. Internal dia,
with hydrant and hose reel on each floor landing connected to an overhead
water/storage tank for firefighting purpose through a booster pump, check
valve and a non-return valve near the tank end and a fire pump, gate and
non-return valve over the underground static tank. A fire service inlet at
ground level filled with a non-return valve shall also be provided to the rising
main for charging it by a fire service pump in case of failure of static fire
pumps over the underground static tanks.
4. The performance of pumps specified above shall be at R.P.M. not exceeding
2,000.
5. The above quantities of water shall be exclusively for firefighting and shall not
be utilised for domestic/or other use. The layout of underground static water
tank shall be as per the requirement of CFO/CFO manual.
6. The size of the riser in the non-residential buildings over 32 m. high shall be 15
cm. (internal dia.) with twin hydrant outlets and hose reel on each floor.
7. A facility to boost water pressure in the riser directly from the mobile pump
shall also be provided to the wet riser system with suitable fire service inlets
(collecting head with two 63 mm inlets for 10 cm rising main and four 63 mm
inlets with check valves for 15 cm. Dia rising main) and a non-return valve
and a gate valve.
8. Hose Reel-The Internal diameter of rubber hose for the hose reel shall be a
minimum of 19 mm. A shut-off branch with a nozzle of 4.8 mm. size shall be
provided.
(3) Wet Riser Installation
They shall conform to IS: 3644-1966 Code of Practice for Installations of Internal
Fire Hydrants in high-rise buildings. In addition, the wet-riser shall be designed for
zonal distribution ensuring that unduly high pressure does not develop in risers
and hose pipes.
In addition to wet-riser, wet riser-cum-down corner, first aid hose reels shall be
installed on the floors of buildings above 32 m. and shall conform to IS :884-1969
Specifications for First Aid Hose Reel for Fire Fighting (Fixed Installation). The first
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
aid hose reel shall be connected to one of the female couplings of twin couplings
of landing valves directly to the wet riser in the case of single outlet of the wet
riser installations by means of adapter: -
(i) Static Water Storage Tank: - A satisfactory supply of water for the purpose of
firefighting shall always be available in the form of an underground static
storage tank with capacity specified for each building with arrangements of
replenishment by main or alternative source of supply at 1,000 liters per
minute. The static storage water supply should easily be accessible to fire
engines. Provision of suitable number of manholes shall be made available
for immersion, repairs and inspection of suction hose etc. The covering slab
shall be able to withstand a vehicular load of 18 tonnes. The domestic suction
tank connected to the static water storage tank shall have an overflow
capable of discharging 2250 litres per minute to a visible drain point from
which by a separate conduit the overflow shall be conveyed to a storm water
drain.
(ii) To prevent stagnation of water in the static water storage tank, the suction
tank of the domestic water supply shall be fed only through an overflow
arrangement to maintain the level therein at the minimum specified capacity.
(iii) The static water storage tank shall be provided with a fire brigade collecting
breaching with four 63 mm. Dia. (two of 63 mm. dia. for pump with capacity
1,400 liters/minute) instantaneous male inlets arranged in a valve box at a
suitable point at street level and connected to the static tank by a suitable
fixed pipe of not less than 15 cm dia. to discharge water into the tank when
required at a rate of 2250 litres per minute.
(iv) Automatic Sprinklers: - Auto-sprinklers shall be installed in accordance with
provisions of NBC, amended up to date:
(a) in basements used as car parks except in apartment buildings and
residential hotels if the area exceeds 500 sq. m.
(b) in basements of high-rise buildings used as car parks and for permissible
essential services ancillary to a particular occupancy.
(c) In any rooms or other compartment of a building exceeding 500 sq. m.
(d) In department stores or shops in an area exceeding total of 750 sq. m.
(e) In all non-domestic floors of mixed occupancy considered to constitute a
hazard and not provided with staircase independent of the remainder of a
building;
(f) In godowns and warehouses as considered necessary;
(g) In dressing rooms, scenery decks, stages, and stage basements of theatres.
(4) Automatic High Pressure Water Spray (emulsifying): - This system shall be
provided for protection of indoor transformers of a substation in a basement area.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
(5) Foam Generating System: - This system shall be provided for protection of boiler
rooms with ancillary, storage of furnace oils in a basement.
(6) Carbon-dioxide (Co2) Fire Extinguishing System: - Fixed Co2 fire extinguishing
installation shall be provided as per IS: 6382-1971 Code of Practice for Design and
Installation of Fixed Co2 Fire Extinguishing System on premises where water or
foam cannot be used for extinguishing fire because of the special nature of the
contents of the buildings/areas to be protected. Where possible, BCF installation
may be provided instead of Co2 installation.
14. Fire Alarm System: -
All buildings mentioned below shall be equipped with fire alarm systems as given
below: -
(i) Special buildings above 15 m. in height and Business and Industrial
buildings above 32 m in height-
(a) Such buildings shall be equipped with a manually-operated electrical fire
alarm system with one or more call boxes located at each floor. The call
boxes shall be so located that one or other of them shall be accessible to all
occupants of the floor without having to travel more than 30 m.
(b) The call boxes shall be of the 'break-glass' type without any moving parts
where the call is transmitted automatically to the control room without any
other action on the part of the person operating the call box.
(c) All call boxes shall be wired in a closed circuit to a control panel in the
control room located as given in this rule so that the floor number where the
call box is actuated is clearly indicated on the control panel. The circuit shall
also include one or more batteries with a capacity of 48 hours normal
working at full load. The battery shall be arranged to be continuously trickle-
charged from the electric mains. The circuit may be connected to an
alternate source of electric supply.
(d) The call boxes shall be arranged to sound one or more sounders so as to
ensure that all the occupants of the building are warned whenever any call
box is actuated.
(e) The call boxes shall be so installed that they do not obstruct the exit-ways
and yet their location can easily be noticed from either direction. The base of
the call box be at a height of 1 m. from the floor level.
(ii) All other buildings exceeding 32 m. height excluding those mentioned in
clause (i) above: -
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
These buildings shall, in addition to the manually operated electrical fire
alarm system, be equipped with an automatic fire alarm system. The latter
shall be in addition to any automatic fire-extinguishing system installed in any
particular occupancy in accordance with these rules. The detectors for the
automatic fire alarm shall conform to the relevant IS Specification Heat Smoke
Sensitive Type Fire Detector and the system shall be installed in accordance
with IS: 2189-1976 Code of Practice for Automatic Fire Alarm System of any
other relevant Indian Standard, prescribed from time to time.
Provided that, no automatic detector shall be required in any room or portion
of a building which is equipped with an approved installation of automatic
sprinklers.
15. Lightning Protection of Buildings
The lightning protection systems for buildings shall be in accordance with the
provisions of Part III, National Building Code of India amended up to date.
16. Control Room
For all buildings mentioned in clause no 14 above except residential buildings, there
shall be a control room on the entrance floor of the building with communication
system (suitable public address system) to all floor planers along with the details of
firefighting equipment and installations shall be maintained in the control room. The
control room shall also have facilities to detect a fire on any floor through indicator
boards connecting fire detecting and alarm systems on all floors. The staff in-charge
of the control room shall be responsible for the maintenance of the various services
and firefighting equipment and installations. Control room shall be manned around
the clock.
17. Fire drills and fire orders
Fire notices/orders shall be prepared indicating the requirements of firefighting and
evacuation of the building in the event of fire or another emergency. Occupants shall
be thoroughly familiarised with their contents and action needed in the event of an
emergency. Such notices should be displayed prominently.
18. Location of Refuge Area: -
i) Manner of providing refuge area: -
a) The refuge area shall be so located that it shall preferably face the access road/s or
otherwise face the wider open space on the side of the building perpendicular to the
main access road.
b) The cantilevered Refuge area on cantilever will be permissible at the mid-landing of the
staircase only. All other refuge areas shall be within the building line only.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
c) The cantilevered refuge area shall necessarily be of RCC type.
d) The refuge area shall be provided with railing / parapet of 1.20 m.
e) R.C.C. covering shall be provided above the topmost cantilever refuge area.
f) The refuge area shall have a door which shall be painted or fixed with a sign in luminous
paint mentioning “REFUGE AREA”
g) The lift/s shall not be permitted to open into the refuge areas.
h) The refuge area provided within building line shall be accessible from common passage/
staircase.
ii) Use of refuge area: -
a) The refuge area shall be earmarked exclusively for the use of occupants as temporary
shelter and for the use of Fire Brigade Department or any other organization dealing
with fire or other emergencies when occur in the building and also for exercises/drills if
conducted by the Fire Brigade Department.
b) The refuge areas shall not be allowed to be used for any other purpose and it shall be
the responsibility of the owner/occupier to maintain the same clean and free of
encumbrances and encroachments at all times.
iii) Facilities to be provided at refuge area: -
a) Adequate emergency lighting facility shall be provided.
b) Toilet may be provided within refuge area.
c) Drinking water shall be provided.
iv) Terrace floor as a refuge floor: -
a) The necessary facilities such as emergency lighting, drinking water etc. shall be
provided.
b) The access door/s from the enclosed staircase/s to the terrace floor shall have louvers at
top half portion of the door. The entrance doors to the terrace shall be painted or fixed
with sign painted in luminous paint mentioning "REFUGE AREA”
19. Glass Façade
All the buildings having glass façade shall comply with fire safety requirements as per Model
Building Bye Laws/NBC
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
APPENDIX- II
[Regulations10.1, 10(3) (iii), (iv)]
Form of Notice and first Application for development Under Sections 44,45,58,69 of the
Maharashtra Regional and Town Planning Act 1966 and to erect a building under section 337/342
of the Mumbai Municipal Corporation Act, 1888.
To,
The ……………………..
Municipal Corporation of Greater Mumbai,
Mumbai.
Sir,
I intend to carry out development in the site/to erect, to re-erect/to make material alteration in
the building…………………….on/in plot No. C.S.No./C.T.S.
No………………………..of……………………..Division/village/Town Planning Scheme
No…………………………situated at Road/Street………………………
ward……………………….and in accordance with section 44,45, 58,69 of the Maharashtra Regional and
Town Planning Act, 1966/section 337, 342 of the Mumbai Municipal Corporation Act, 1888, and
the Maharashtra Development Plan Rules, 1970.
2. I enclose the following plans and statements (Items 1 to 6) wherever applicable, in
quadruplicate
, signed by (Name in block letter)……………………………………
Licensed surveyor/engineer/structural engineer/supervisor, License No………………
or architect, who has prepared the plans and designs on my behalf and copies of other
statements/documents as applicable (Items 7 to 14): -
1) Key Plan (Location Plan)
2) Site Plan
3) Sub-division/layout plan
4) Building Plan
5) Particulars of development in the form in Annexure-I
6) Ownership Title documents and ownership title submitted by Solicitor/Advocate
7) Attested copy of receipt for payment of building permit fee
8) Clearance certificate of municipal tax arrears Self certification from owner/developer
regarding municipal tax clearance.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
9) No objection certificate/s, where required.
10) Appointment letter in favour of licensed technical personnel or architect.
11) Supervision memorandum of licensed technical personnel or architect.
12) Property register card, and city survey plan for plot in original signed by the Competent
City Survey Authority not issued prior to 12 months,
13) Owners' affidavit regarding area of the plot.
14) Architect's certificate for plot area along with area calculations by triangulation method.
Please approve the proposed development/construction and permit me to execute the work.
Yours faithfully,
Date: ……………………. Signature of Owner -----------------------------------------------
Name of Owner ----------------------------- (in block letters)
Address of Owner ----------------------------------------------
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
Appendix III
Regulation NO 59
Table. List of special purpose NOCs.
Sr. Authority Location
No.
1 Airport For height of buildings as per the provisions of Regulation No 45(f)
2 Police For Construction of Religious Structures
3 Jail Authority Required by the Competent Authority and as notified by Urban
Development Department, GoM
4 Railway If situated within 30 m from Railway Land Track Boundary.
5 Defence Required by the Defence Authority around defence installation and
as notified by Urban Development Department, GoM
6 MHCC For development related to Heritage Structures and in Heritage
Precincts as specified in the Regulation No 52.
7 ASI (Archeological As notified by the Competent Authority
Survey of India)
8 MHADA /MBRR In case of development of lands belonging to MHADA /development
Board in MHADA layout, Cessed Buildings
9 MCZMA For development in areas affected by Coastal Regulation Zone
10 MoEF For development attracting the EIA Notification
11 Highway Plot abutting falling within highway buffer as shown on DP
12 MMRDA In influence zone of Metro/Monorail as may be notified by the
Competent Authority.
13 Estate Department Land of Improvement Trust
of MCGM
14 Collector Government land/ NA/ ULC wherever applicable
15 Director of As specified in these Regulations
Industries
 The above cited list shall stand amended through additions/deletions mandated by GoM
from time to time.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
Appendix IV
(Regulation 60)
Repairs to existing Building
(1) Repairs to be carried out can be categorized as detailed below:
Partial repairs- The repairs to the extent of 75% of BUA will be termed as partial repairs.
The partial repairs shall be allowed with the permission of the Commissioner.
Extensive repairs- The repairs beyond 75% of BUA will be termed as extensive repairs
which shall be allowed with the special permission of the Commissioner.
(2) Type of Repairs:
Category- I-The building neither affected by the road widening nor by DP Reservations.
Category-II-The buildings affected by the road widening or by reservations or by both
(3) Pre-requisites while submitting the proposal:
(i) Notice under section 342 of MMC Act and notice under section 44/69 of MR & TP Act
1966 duly signed by owner/NOC Holder.
(ii) NOC from M.B.R & R Board (if cessed building)
(iii) Structural audit report/Statutory Notice issued by MCGM/MHADA
(iv) Photographs showing condition of building as under:
a) Front roadside view from ground to top floor in one or more photographs as
possible.
b) Side view elevation photographs wherever possible.
c) Dangerous portions proposed for repairs
d) Type of existing material in mode of construction
e) Roof photographs.
(v) Plan showing block plan, location plan and all the details existing on site
(vi) List of all the existing tenants/occupants signed by NOC Holder and countersigned by
Architect, in case of non cessed building and list of all the existing tenants/occupants
signed by Ex. Engineer M.B. R. & R Board in case of cessed building.
(vii) Owner’s consent for the proposed repairs/authority under section 499 of MMC Act
where Owner’s consent for proposed repairs is not possible.
(viii) The onus of submitting authenticity of the structure for which repairs have been
proposed shall entirely vest with owner/NOC holder
(4) Guidelines
(1) The buildings which are in need of Extensive Repairs shall be preferably developed or
redeveloped under the provisions of these Regulations. However, if
development/redevelopment is not possible due to various reasons such as
size/shape of plot, disputes and other reasons, then Extensive Repair may be allowed.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
(2) Except those buildings affected by setback of important roads from the point of view
of their widening, in all other cases repairs will be allowed inclusive of setbacks, with
registered undertaking for not claiming any compensation on account of repairs for
the structure and shall handover the portion of road setback as per prevailing
policy/provision, when required by MCGM. The provision of Twin column
arrangement shall be insisted at the sanctioned R.L / D.P. Road so as to detach the
part of the building falling within the setback as and when required by MCGM for
widening of roads.
(3) When repairs are allowed in the setback/widening of the road portion only then,
Standing Committee shall be intimated as per the section 297(3) of MMC Act.
If a road is already widened on either side of the building which is to be taken up for
repairs, such building can be taken up for repairs in conformity with (2) and (3) above,
if it requires extensive repairs.
(4) Repairs may be allowed on sites under reservation, if the same is not under
acquisition.
In case of reserved sites which are under acquisition, the repairs may be allowed with
special permission of the Commissioner. In both the cases, registered undertaking
shall be insisted upon from the NOC holder/owner stating that no compensation will
be claimed on account of repairs for the structure as and when the property is
acquired, and grant of permission for repairs will not in any way affect the process of
acquisition and shall not be used as a tool to impede the process of acquisition.
(5) It shall be the responsibility of the owner/NOC holder to ensure that the existing
tenements/existing authorised uses are maintained.
(6) No repairs to the unauthorised structure/unauthorised part of structure shall be
allowed.
(7) In case of cessed properties MHADA/MBRRB may carry out repairs of buildings after
obtaining remarks from MCGM as per provisions of the MHADA Act. Remarks and
observations if any as stated in these guidelines shall be complied with during the
course of repairs.
Notes:
1. The repairs to the non-tallying portion which forms part of common amenities such as
toilet block, washing places, common passage, and staircase can be considered at Dy. Ch.
E (BP)'s level.
2. In case applicant submits documentary evidence from Government Authority to prove
the existence of non-tallying portion prior to 01/04/1962 for non-residential and
17/4/1964 for residential buildings, repairs can be allowed
3. In case of partial/extensive structural repairs of buildings owned by Government/Semi
Government organizations/Municipal Corporation/B.E.S.T. Undertaking/Government-
Semi Government Undertakings, approval of the Head of department/Competent
Authority of Concerned organization shall be sufficient. Structural Audit as per the
requirement of MCGM and compliance thereof shall have to be observed by the
concerned organization/Authority.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
APPENDIX- V
MUNICIPAL CORPORATION OF GREATER MUMBAI
No. Dy.Ch.E./BP/ of
Office of the:
Dy. Chief Engineer (B.P.)
ADVANCE POSSESSION RECEIPT
Sub: - Handing over and taking over the advance possession of plot/Area of D.P.
Road/Reservation/amenity area etc. as per provisions of DCR 2034 out of
Survey No./H.No. ................, CTS No. /C.S. No./ F.P. No.
.................................... of village /Division/ T.P. Scheme No. ...........................
in .......... Ward.
_________________ working as Assistant Engineer in the Office of Dy. Ch.E. (B.P.)........
and ....................................., the owner of the said plot of land have respectively taken over on
behalf of MCGM as per provisions of DCR and handed over the representative possession of the
above said land respectively. The possession of the land mentioned below has been taken as
required by the Deputy Superintendent Land Records as per Indian Registration Act, 1908, for the
rectification in the Land Record. This possession Receipt does not mean that MCGM have taken
final possession of the said land.
The final possession receipt shall be issued only after ascertaining the actual area as per
provisions of DCR & joint measurement plan and physically taken over the possession of plot by
MCGM and handed over by the owner. The cost of any transaction involved shall be borne by the
owner or lessee.
The particulars of land considered for initial stage of representative advance possession
receipt is as mentioned below-
Survey No. H.No. CTS No./ Village/Division/TPS Area in Sq. M.
C.S.No./F.P.No.
Conditions to be complied with before handing over final possession of the subject land.
 The construction of compound wall with gate wherever necessary.
 The necessary provision of storm water drain.
 Joint Measurement Survey with C.T.S.O
 The Title Clearance has been certified by Legal Department of MCGM Advocate/Solicitor
who has experience in this field of a minimum 10 years.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
 The owner/developer agreeing to rectify the defects in the works, if any, in terms of
Undertaking separately given by the owner.
 Any other conditions as may deem fit and proper in the interest of general public.
On............................................. Day of the month of ....................................
Handed over by Taken over by
OWNER
Sub Engineer/Assistant Engineer
Address :
Bldg. Proposal ( Ward)
Disclaimer: This advance possession receipt is issued on the request of applicant and as per
Provisions of Regulation No...........of DCR 2034. This advance possession receipt will not entail
land owner/lessee to serve Purchase Notice under Section 49/127 of M.R. & T.P. Act, 1966
amended up to date.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
APPENDIX- VI
(Final Possession Receipt from Owner to DP Department & DP Department to Estate
Department)
MUNICIPAL CORPORATION OF GREATER MUMBAI
No. Ch.E./DP/ of
OFFICE OF THE:
Chief Engineer (Development Plan)
Brihanmumbai Mahanagarpalika,
Municipal Head Office,
5th floor, Annexe Building,
Mahapalika Marg,
Fort, Mumbai-400 001.
FINAL POSSESSION RECEIPT
Sub:- Handing over and taking over of D.P. Road /Reservation/Amenity area out of
Survey No. /H .No. ................, CTS No. /C.S. No. / F.P. No.
.................................... of village /Division/ T.P. Scheme No. ...........................
in.......... Ward.
Ref:- 1) Advance possession Receipt No. Dy.Ch. E. /BP/........... dtd……………..
_________________ working as Assistant Engineer in the Office of Ch.E. (D.P.) and
....................................., the owner for the said plot of the land have respectively taken over and
handed over the possession of the above mentioned vacant land.
The particulars of land are as mentioned below-
Survey No. H. No. CTS No./ C.S. Village/Division Area in Sq. m.
No./F.P. No.
 The compound wall with gate wherever necessary is provided.
 The necessary provision of storm water drain is made.
 The area of the D P Road/Reserved land/Amenity area has been ascertained on the basis
of Joint Measurement Survey with SLR/C.S. Office under M.R. Plan No.
.................................................. dated ............................ with communication No.
................................ dated ......................... and as per the provisions of these
Regulations.
 The Title Clearance has been certified by Legal Department of MCGM Advocate/Solicitor
who has experience in this field of a minimum 10 years under no.
...................................... dated .................
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
 Any other conditions as may deem fit and proper in the interest of general public.
 The possession of above land is taken over subject to the owner/developer agreeing to
rectify the defects in the works and in terms of Undertaking separately given by the
owner.
 Ownership of land so handed over shall be transferred in the name of MCGM in land
revenue records. The cost of any transaction involved shall be borne by the owner or
lessee
NOTE:-In case of constructed built up amenity to be handed over along with plot as per
the provisions of these Regulations, then the details such as built up area of amenity,
number of tenements/non-residential galas, along with requirements like number of
parking with their earmarking on the occupation plans and details
Occupation/Completion Certificate shall be clearly mentioned in the possession receipt.
On ............................................. Day of the month of ....................................
Handed over by Taken over by
OWNER Sub/Asstt. Engineer Development Plan ( Ward)
Address:
MUNICIPAL CORPORATION OF GREATER MUMBAI
No. Ch.E. /DP/ of
FINAL POSSESSION RECEIPT
Sub:- Handing over and taking over possession of D.P.Road/Reservation/Amenity
out of Survey No./H.No. ................, CTS No. /C.S. No./ F.P. No.
.................................... of village /Division/ T.P.Scheme No. ...........................
in .......... Ward.
_________________ working as Assistant Engineer in the Office of Ch.E.(D.P.) and
....................................., working as Assistant Engineer in the Office of Assistant Commissioner
(Estates) / Ward for the said plot of the land have respectively handed over and taken over the
possession of the above mentioned vacant land.
The particulars of land is as mentioned below-
Survey No. H. No. CTS No./ C.S. Village/Division Area in Sq. m.
No./F.P. No.
 The compound wall with gate wherever applicable is provided.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
 The necessary provision of storm water drain is made.
 The area of the D P Road/Reserved land/Amenity area has been ascertained on the basis
of Joint Measurement Survey with SLR/C.S. Office under M.R. Plan No.
.................................................. dated ............................ with communication No.
................................ dated ......................... and as per the provisions of these
Regulations.
 The Title Clearance has been certified by Legal Department of MCGM Advocate/Solicitor
who has experience in this field of a minimum 10 years under no.
...................................... dated .................
 Any other conditions as may deem fit and proper in the interest of general public.
 The possession of above land is taken over subject to the owner/developer agreeing to
rectify the defects in the works and in terms of Undertaking separately given by the
owner.
 Ownership of land so handed over shall be transferred in the name of MCGM in land
revenue records. The cost of any transaction involved shall be borne by the owner or
lessee
NOTE:-In case of constructed built up amenity to be handed over along with plot as per
the provisions of these Regulations, then the details such as built up area of amenity,
number of tenements/non-residential galas, along with requirements like number of
parking with their earmarking on the occupation plans and details
Occupation/Completion Certificate shall be clearly mentioned in the possession receipt.
On ............................................. Day of the month of ....................................
Handed over by Taken over by
Sub/Assistant. Engineer Sub/Assistant Engineer
Development Plan ( Ward) Assistant Commissioner (Estates) / Ward
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
ANNEXURE - 1
(Part of Appendix II Item 10 5)
Particulars of Development
1) (a) (i) Applicant's Full Name ……………………………………………………
(in block letters) ……………………………………………………
(ii) Applicant's address ……………………………………………………………..
(a) Name and address of Licensed Surveyor/Engineer/Structural Engineer or Supervisor/Architect
employed/Professionals on Records ……………………………………………….
…………………………………………………………………………………………
(c) No. and date of issue of license ……………….. Valid up to ……………………
2) Is the plot affected by any reservation or road lines? If so, are these correctly and clearly marked
on the block plan?
3) *(a) What is the total area of the plot according to the document?
*(b) Does it tally with the Collector's record?
*(c) What is the actual area available on site measured by the licensed
surveyor/architect/engineer/supervisor or architect?
(d) If there is any deduction in the original area of the plot on account of road lines or
reservation? Please state the total area of such deductions.
(e) If so, what is the net area?
(f) Is the clearance under Urban Land (Ceiling and Regulations) Act, 1976 obtained? If so, what
is the area allowed for development? Clearance under Urban Land (Ceiling and
Regulations) Act, 1976 else an undertaking.
*Permission will be based on the minimum of areas in (a), (c) or (f) above.
Note. -INDICATE DETAILS ON THE SITE/BUILDING PLAN AS IN FORM 1.
4) Are all plans as required under Regulations 10(3) enclosed?
5) (a) Is the plot part of a city triangulation survey number, revenue survey number or hissa
number or a final plot number (city survey number) of a Town Planning Schemes or a part
of an approved layout?
(b) Please state sanction number and date of sub-division/layout.
6) (a) In what zone does the plot fall?
(b) What is the permissible Floor Space Index of the Zone?
(c) What is the number of tenements per net hectare permissible in the zone?
7 (a) Is the use of every room in the proposed work marked on the plans?
(b) Is it in accordance with the Regulations?
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
(c) Does the building fall in the category of-
(i) Special building as defined in Regulations 2(iv)(17)(n)
(ii) High rise building as defined in Regulations 2(iv)(17)(i) 76
8 If the work is in connection with an industry-
a) Please briefly describe the main and accessory processes.
b) Please state the maximum number of workmen and the total KW likely to be employed per
shift in the factory.
c) Under what industrial classification does it fall? (Reference to relevant Regulation should be
given).
d) Is the proposal for relocation of an existing industry? If so, give the name and address of the
existing industry.
Note. - The permission will be based on the area which is minimum.
e) If the proposal is for the establishment of a new industry or for the expansion of an existing
industry, is a copy of the "No Objection Certificate" from the Department of Industries
enclosed [see Regulations No. 18(k) wherever applicable?
f) Will the building be away from the boundary of a residential or commercial zone or as per
Table 18(B) in Regulations 41(4)?
g) Is the proposal for a service industrial estate on a plot reserved for service industries or in
industrial zone?
h) Nature and quantum of industrial waste/effluents and methods of disposal be stated.
9) (a) What is the average-
(i) Prescribed width and
(ii) Existing width of the street?
(If the plot abuts two or more streets, information for all streets should be given).
(b) What is the height of the building-?
(i) above the average ground level of the plot?
Does it comply with Regulations 43?
10) (a) If there are existing structures on the plot-
(i)Are they correctly marked and numbered on the site plan?
(ii) Are those proposed to be demolished immediately coloured yellow?
(iii) What is the plinth area and total floor area of all existing structures to be retained?
(Please indicate in the appended Statement 'A' with details)
(iv) What is the number of existing tenements in the structure(s) to be retained?
(b)What is the plinth area and total floor area of the proposed work or building?
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
(Please indicate in appended statement ’B’ with details
(c) What is the number of tenements proposed?
Note. - INDICATE DETAILS OF THE BUILDING PLAN AS IN FORM 1.
11) (a) Please state the plinth area and total floor area, existing and proposed (i.e. totals of items
10) a) (iii) and 10(b).
b) Please state the Development Rights, if any, proposed to be used and the floor space index
credit available there under.
c) Please state the overall floor space index [Item 11(a) divided by Item 3(e)] plus the floor
space index available due to Development Rights.
d) Does the work consume the full floor space index of the plot, as given in item 6(b)?
If not, why not?
e) Is the building proposed with setbacks on upper floors?
f) What is the total number of tenements [Item 10(a) (iv) plus Item 10(c)]?
Note. -INDICATE DETAILS ON THE BUILDING PLAN AS IN FORM 1.
12) (a) What is the width of the front open space? If the building abuts two or more streets, does
the front open space comply with Regulations 41(1)
(b) Please state which of the sub-Regulations of Regulations 41 and/or any other Regulations is
applicable for the open space?
13) Does the front open space comply with the Regulations?
14) (a) What is-
(i) the width of side open space (s)?
(ii) the width of rear open space (s)?
(iii) the distance between buildings?
(b) Do they comply with Regulations 41(2)(i)(a)?
Regulations 41(6)?
(c) Are there two or more wings to the buildings?
If so, are the open spaces separate or distinct for each wing as required by Regulations 41(1)(a)
15) If the plot is narrow, which clause under Regulations 41(7)(a) or Regulations 41(7)(b), do you
propose to take advantage of (whatever applicable)?
16) (a) What are the dimensions of the inner or outer chowk?
(b) (i) Does any room depend for its light and ventilation on the chowk? If so, are the
dimensions as required for each wing of the buildings?
(ii) If not, is the area at least equal to square of one-fifth of the height as per Regulations
41 (8)
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
(17) If the height of the building is greater than 16 m. above the average ground level, is provision
for lift (s) made?
If so, give the following details of the lift(s): -
(a) Details of lift
Type | Passenger Capacity |No. of lifts |Types of doors
(b) Details of fire lift.
Type | Passenger Capacity |No. of lifts |Types of doors
18) (a) Does the building fall under the purview of clause (i) 2(iv)76 or (n) of sub-Regulations (17),
Regulations 2?
(b) If so, do the proposed fire protection requirements conform to those in Appendix I?
(c) If not, give reasons.
19) (a) (i) What is the requirement of parking spaces under Regulation 44(2) and (3)?
(ii) How many are proposed?
(iii) How many lock-up garages are proposed?
(b) (i) Are parking spaces for transport vehicles provided (Regulations 36 44(5))?
(ii) If so, what is the requirement?
(iii) How many are proposed?
NOTE: - INDICATE DETAILS ON BUILDING PLAN AS IN FORM 1.
20) (a) (i) What are the maximum widths of balconies?
(ii) Will they reduce the required open space to less than the provisions of the Regulation?
(iii) Do they serve as a passage to any part of the building?
(iv) What is their total area?
(v) What is the maximum width of weather-frames, sun-shades (chajja), sun-breakers,
cornices, caves, or other projections?
(c) (i) Are any porches/canopies proposed?
(ii)Do they comply with requirements of Regulations 42?
21) (a) What is the width of the means of access?
(b) What is its clear height?
(c) Will it be paved, drained and kept free of encroachment?
22) Is the recreational or amenity open space provided as required under Regulations 27(I), 27(2)?
23) (a) Are any accessory buildings proposed? If so, for what purpose?
(b)What are their heights?
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
(c) Are the 7.5 meters away from the street or front plot boundary and if located within the
open spaces, 1.5 meters from any other boundary?
(d) Is their area calculated in floor space Index?
24) (a) what is the proposed height of the compound wall?
Is it at a junction?
(b) Does it comply with Regulations 37(2624)?
25) (a) (I) Is the proposal in the airport zone?
(b) (ii) Is a "No Objection Certificate" for height and character of smoke from chimneys
obtained from Civil Aviation Authorities (Attach copy).
(c) Does the proposal fall in the category of tower-like structure vide Regulation 2(iv)(113)124
and 41(2)(i)(c)? If so, does it comply with the requirement thereof?
26) Indicate provision for common conventional antenna for receipt of television transmission in
residential building with more than ten tenements (Regulations 42)
27) Does the proposal fall in any of the areas/zones such as those of the Mumbai Metropolitan
Region Development Authority/ Maharashtra Housing and Area Development
Authority/Railway/Highway/Slum Authorities/Power Transmission line/Coastal Area/No
Development Zone/Tourism Development Zone/Communication Authorities etc.?
28) (a) Does any natural water course pass through the land under development?
(b) Is the necessary set back provided according to Regulations 18(b)?
29) (a) Is the plinth level proposed to be above the level of the surrounding ground level?
(b) Will the proposed plinth level be above 27.55 m Town Hall Datum?
(c) Is the plot proposed to be filled up to the level of the abutting road or Reduced Level (R.L.)
27.55 m Town Hall Datum, whichever is more?
30) The details of the materials to be used in construction with specifications are as follows:
Roofs------------------------------------------------------------------------------------------------
Floors-----------------------------------------------------------------------------------------------
Walls------------------------------------------------------------------------------------------------
Columns---------------------------------------------------------------------------------------------
Beams------------------------------------------------------------------------------------------------
Any other Material---------------------------------------------------------------------------------
“Note:- Building material to be used in construction such as brick etc. shall contain the fly
ash. Fly ash shall also be used for construction and road/ maintenance as permissible as
per I.S. specification”
(EP-165)
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
31 The number of water closets, urinals, kitchens, and baths to be provided are as follows:
Water closets |Baths | Urinals |Kitchen
Existing------------------------------------------------------------------------------------------------
Proposed----------------------------------------------------------------------------------------------
32) Details of the source of water to be used in the construction.
33) Distance from the sewer.
34) How much municipal land, if any, will be used for stacking building material?
35) Please explain, in detail, in what respect the proposal does not comply with these Regulations
and the reasons therefore, attaching separate sheets for this information, if necessary.
I am the owner-lessee/mortgagee in possession/----------------------------------- of the plot on which
the work is proposed and that the statements made in this Form are true and correct.
Date:
Address: Signature of the applicant.
Form of certificate be signed by the Licensed Surveyor/Engineer/Structural
Engineer/Supervisor or Architect/ Professionals on Records employed by the Applicant
I (Name) -------------------------------------------------------------------------- have been employed by the
applicant as his Licensed Surveyor/Engineer/Structural Engineer/Supervisor or Architect. I have
carefully pursued his covenant or conveyance in respect of this plot and have examined the
boundaries and the area of the plot and I certify that I have personally verified all the statements
made by the applicant who is the owner/lessee/mortgage in possession of the plot & possess
ownership/absolute development rights as in the above Form and the attached Statements A and
B and found them to be correct.
Date:
Address
Signature of Licensed Surveyor/Architect
Engineer/Structural Engineer/Supervisor
Note: - INDICATE IN BUILDING PLAN AS IN FORM II.
STATEMENT 'A'
(Serial No. 10(a)(iii) in ANNEXURE 1)
Existing Building to be retained
Existing Building Floor Plinth Total floor area Use or
No. No. Area of the Existing Occupancy
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
(1) (2) (3) Building of floors
(4) (5)
STATEMENT 'B'
[Sr. No. 10(b) in ANNEXURE "1"]
Proposed Work/Buildings
Building No. Floor No. Area Total Floor Area Use or
of proposed work Occupancy of
Floors
FORM I
(Sr. No. 2, 9,10,11,19 in ANNEXURE "1")
(At right top corner of site/building plan at Ground Floor Level)
I. Area Statement Square meter
1. Gross Area of plot
a) Area of Reservation in plot
b) Area of Road Set back
c) Area of D P Road
2. Deductions for.
(A)For Reservation/Road Area
(a) Road set-back area to be handed over (100%) (Regulation No 16)
(b) Proposed D P road to be handed over (100%) (Regulation No 16)
(c) Reservation area (plot) to be handed over (Regulation No 17)
(B) For Amenity area
(a) Area of amenity plot/plots to be handed over as per DCR 14(A)
(b) Area of amenity plot/plots to be handed over as per DCR 14(B)
(c) Area of amenity plot/plots to be handed over as per DCR 15
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
(d) Area of amenity plot/plots to be handed over as per DCR 35
(C) Deductions for Existing Built up area to be retained if any
(a) Land component of Existing BUA as per regulation
under which the development was allowed.
3. Total deductions: [ 2(A) +2(B) +2(C)]
4. Balance area of plot (1 minus 3)
5. Gross Plot area under Development [4 + 2(A) +2(B)] {4 – (2(A) +2(B))}
6. Zonal (basic) FSI (1 or 1.33)
7. Permissible Built up Area as per Zonal(basic) FSI (5 * 6)
(In case of Mill land Permissible Built up Area shall be as per 4 of Regulation 30(A)
8. Additional Built up area equal to area of land handed over as per 3(a) of Regulation 30(A)
2(A)+{2(B) except (d)}
9. Built up Area In lieu of Cost of construction of built up amenity to be handed over
10. Built up area due to “Additional FSI on Payment of Premium” as per Table No 12 of
Regulation No 30(A) subject to Regulation No 30(A)3
11. Built up area due to admissible “TDR” as per Table No 12 of Regulation No 30(A) subject to
Regulation No 30(A)3
12. Permissible Built up Area (7+8+9+10 +11)
13. Proposed Built Up Area
14. TDR generated if any as per regulation 30 (A)
15. Fungible Built up Compensatory Area as per Regulation No 31(3)
a) i)Permissible Fungible Built up Compensatory area for Rehab component without
charging premium
ii) Fungible Built up Compensatory area availed for Rehab component without
charging premium
b) i) Permissible Fungible Built up Compensatory area by charging premium.
ii) Fungible Built up Compensatory area availed on payment of premium
16. Total Built up Area proposed including Fungible Built up Compensatory Area [13 +15(a)(ii)
+15(b)(ii)]
17. FSI consumed on Net Plot [13/ 4]
(EP-163)
(II) Other Requirements
(A) Reservation/Designation
a) Name of Reservation
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
b) Area of Reservation affecting the plot
c) Area of Reservation land to be handed/handed over as per Regulation No.17
d) Built up area of Amenity to be handed over as per Regulation No.17
e) Area/Built up Area of Designation
(B) Plot area/Built up Amenity to be Handed Over as per Regulation No
(i) 14(A)
(ii) 14(B)
(iii) 15
(C) Requirement of Recreational Open Space in Layout/Plot as per Regulation No.27
(D) Tenement Statement
(i) Proposed built up area (13 above)
(ii) Less deduction of Non-residential area (Shop etc.)
(iii) Area available for tenements [(i) minus (ii).]
(iv) Tenements permissible (Density of tenements/hectare)
(v) Total number of Tenements proposed on the plot
(E) Parking Statement
(i)_Parking required by Regulations for. -
Car
Scooter/Motor cycle
Outsiders (visitors)
(ii) Covered garage permissible
(iii) Covered garages proposed
Car
Scooter/Motor cycle
Outsider (Visitors)
(iv) Total parking provided
(D) Transport Vehicles Parking
(i) Spaces for transport vehicles parking required by Regulations
(ii) Total No. of transport vehicles parking spaces provided
Note – The Proforma is for an illustrative guideline only. The proforma may be modified to suit the
provisions of DCR under which the development is proposed.
FORM II
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
(At right bottom corner of plans/below Form I)
Contents of sheet
Stamp of date of receipt of plans
Stamp of approval of plans
Revision Description
Date Signature
Certificate of Area
Certified that I have surveyed the plot under reference on……….. and that the dimensions of the
sides, etc. of the plot stated on the plan are as measured on site and the area so worked out
is*…………………. square meters and tallies with the area stated in the document of ownership/Town
Planning Scheme records.
Signature of Licensed Surveyor/Architect/Engineer/Structural Engineer/Supervisor or Architect
Description of proposal and property
Name of owner
Job No. Drg no. Scale Checked by
Drawn by
North Line
Signature, Name (in block letters) and
Address of Licensed Surveyor /Engineer
/Structural Engineer /Supervisor or Architect.
*Area to be stated in figures and also in words
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
ERUXENNA
ANNEXURE 2
FORM OF SUPERVISION ACCEPTANCE
(By Architect/Licensed Surveyor for Building Permission)
To
The…………………………………………
Municipal Corporation of Greater
Mumbai, Mumbai
Subject: Acceptance of supervision of proposed development
Sir,
The development work of the
Full Particular of the work
On plot bearing C.S.No./C.T.S.No./F.P.No.
Of Division/village/T.P. Scheme No.
Type of Development
Road Name:
Ward
Name of Architect/Licensed Surveyor
will be carried out under my supervision. All the materials (type and grade) and the
workmanship of the work will generally tally with the general specifications submitted along
with the plans and the work will be carried out according to the sanctioned plans. I shall be
responsible for the execution of the work in all respects.
Yours faithfully,
Name of the Architect/Licensed Surveyor
License No.
APPENDICES AND ANNEXURES
Address:
Tel. No.:
Signature:
Date:
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
ANNEXURE 3
PLOT AREA CERTIFICATE
(On the letter head of Architect/Licensed Surveyor)
Date: _______________
To,
Executive Engineer,
Building Proposal_____ward, M.C.G.M.
Subject: Proposed development on plot
Full Particular of the work
On plot bearing C.S.No./C.T.S.No./F.P.No./
Of Division/village/T.P. Scheme No.
Ward
Name of Owner
Reference: Building Proposal File
No.___________________
Sir,
I have submitted a proposal on behalf of my/our client Shri/M/s. ____
______________________________for the proposed development on the above
referred plot. The area of the plot is__________sq. m as per the P.R. Cards
obtained from city Survey office dated________. In order to verify the plot
area, I/We have carried out the survey of the said plot through our staff to
ascertain correctness of the area mentioned in the Property Register Card. The
said survey has been carried out on the basis of the boundaries of the plot shown
by the Owner/client.
The said area as per the survey no works out to__________sq. m and FSI is claimed for the
plot area____________sq. m
Thanking you,
Yours faithfully
Name of the Architect/Licensed Surveyor
Registration No.:
Address:
Tel.No.:
Signature:
Date:
APPENDICES AND ANNEXURES
ERUXENNA
ANNEXURE 4
OWNER’S PLOT AREA AFFIDAVIT
(To be typed on stamp Paper of Requisite value)
To
The Executive Engineer,
B.P._____ward Mumbai.
Subject: Proposed development on property bearing C.S./C.T.S.No./ F.P.
No._________,Of Division/village/T.P. Scheme
No._______at_____________ Road in_________ward.
Reference: Building Proposal File No./Proposal No.
___________________
I______________, possessing the right of development by virtue
ofconveyance/Lease/DevelopmentAgreement/PowerofAttorneydated___________________
for the property bearing C.S./C.T.S.No./F.P.No._________,of Division/village/T.P. Scheme
No_______at
_____________Road in_________ward and having my residence/office at ________________
___________________________________solemnly affirm and say as under:
I have submitted the plans through my Architect/Licensed surveyor________________having Comment [W1]:
License No._________for development of the aforesaid property.
In order to verify the area, I have also carried out survey of the said plot through my Architect/
Licensed surveyor to ascertain the correctness of the area.
I say that my Architect/Licensed Surveyor has certified the said area on the basis of the
property register card duly certified by the Superintendent of Land Records and/or on the basis
survey carried out as per the boundaries of the property shown by me/us.
The said area works out to ___________ sq. m (in words__________________sq. m.
0and F.S.I is claimed for the plot area____________sq. m.
It may also be stated here that I/we do not hold /own any contiguous land with the subject
land.
SOLEMNLY AFFIRMED AT MUMBAI
DATED THIS____ DAY OF
(Name &Signature of Owner/C.A. to Owner)
BEFORE ME.
Note: To be submitted in original duly notarized.
APPENDICES AND ANNEXURES
ANNEXURE–5
SUPERVISION MEMO OF STRUCTURAL ENGINEER
(On the Letter Head of STRUCTURAL ENGINEER)
Name of Structural Engineer
License No.
Date:__________
To,
Executive Engineer,
Building Proposal_____ward, M.C.G.M.
Subject: Proposed development work of ………………………………
Building proposal No
Full Particular of the work
On plot bearing C.S.No./C.T.S.No./F.P.No./Of
Division/ village/ T.P. Scheme No
Type of development
Road Name
Ward
Name of Architect / Licensed Surveyor
Name of Owner
With reference to the letter of our appointment dated_____________addressed to you, by
the Owner, I hereby confirm that I have agreed to act as the Consulting Structural Engineer for
the above proposal.
I further confirm that the structural design and calculations shall be inconformity with the
pro- visions of IS Code nos. 1875,1893 &4326 taking into consideration the Seismic forces
etc.as required by the planning authority.
Thanking you,
Yours Faithfully
Name of the Consulting Structural Engineer
Registration No
Address:
Tel. No.:
Signature:
Date:
C.C.to: 1. Owner.
2.. Architect /Licensed Surveyor
APPENDICES AND ANNEXURES
XENNA
ANNEXURE 6
SUPERVISION MEMO OF LICENSED PLUMBER
(On the Letter Head of Licensed Plumber)
Name of Plumber
License No.
Date_________
To,
Executive Engineer,
Building Proposal_____ward,
M.C.G.M.
Subject: Drainage &Sanitation work of proposed development
Building proposal No
Full Particular of the work
Building comprising of (no of wings and floors)
On plot bearing C.S.No./C.T.S.No./F.P.No./ Of
Division/village/T.P. Scheme No
Type of development
Road Name:
Ward
Name of Architect / Licensed Surveyor
Name of Owner
This is in reference to the letter of appointment issued by the Owner/Developer, I hereby
confirm having agreed to act as Licensed Plumber for the above proposal.
Thanking you,
Yours faithfully,
Name of the Licensed Plumber
License No.
Address:
Tel.No.:
Signature:
Date:
Copies submitted to:
i) Architect/Licensed Surveyor
ii) Structural Engineer
iii) Owner/Developer
APPENDICES AND ANNEXURES
ANNEXURE 7
SUPERVISION MEMO OF LICENSED PLUMBER Site Supervisor
(On the Letter Head of Site Supervisor)
Name of Site Supervisor
License No.
Date
To,
Executive Engineer, Building Proposal
_____ward, M.C.G.M.
Dear Sir,
Subject: Proposed development work of
Building proposal No
Full Particular of the work
On plot bearing C.S.No./C.T.S.No./F.P.No./ Of
Division/village/T.P. Scheme No
Type of development
Road Name
Ward
Name of Architect/ Licensed Surveyor
Name of Owner
With reference to the letter of my appointment dated addressed to you, by the Owner, I hereby
confirm that I have agreed to act as the Site Supervisor for the above proposal.
I further confirm that the workmanship and material quality and material testing shall be in
conformity with the provisions of IS standards and the development work shall be as per
approved plans and the structural design etc.
Thanking you,
Yours Faithfully
Name of the Site Supervisor
Registration No
Address:
Tel.No.:
Signature:
Date:
C.C.to:1. Owner.
2.Architect /Licensed Surveyor
APPENDICES AND ANNEXURES
ERUXENNA
ANNEXURE 8
SUPERVISION MEMO OF OTHER PROFESSIONAL ON RECORD
(On the Letter Head of Professional)
Name of Professional
To, License No.
Executive Engineer, Date:_______________
Building Proposal
_____ward, M.C.G.M.
Dear Sir,
Subject: Proposed development work of
Building proposal No
Full Particular of the work
On plot bearing C.S. No./C.T.S .No./F.P. No./ Of
Division/village/T.P. Scheme No
Type of development
Road Name
Ward
Name of Architect /Licensed Surveyor
Name of Owner
With reference to the letter of my appointment dated addressed to you, by the Owner, I hereby
confirm that I have agreed to act as the for the above proposal.
I further reconfirm that the work will be carried out in conformity with the provisions of IS
standards and as per requirements of Regulations, Annexure for Duties and Responsibilities of
Professional on Record and the development work shall be as per approved plans and the
structural design etc.
Thanking you,
Yours Faithfully
Name of the Professional
Registration No
Address:
Tel.No.:
Signature:
Date:
C.C.to:
1.Owner.
2.Architect/Licensed-Surveyor
APPENDICES AND ANNEXURES
ANNEXURE 9
[Regulations 10 (3) (ix)]
Form for Supervision
To
The ……………………………………
Municipal Corporation of Greater Mumbai,
Mumbai.
Sir,
The development/erection/re-erection/demolition or material alteration of the
building ………………………….. on Plot No./C.S. No./C.T.S. No. …………………… of
Division/village/Town Planning Scheme No. …………………………………. situated at
Road/Street………………………………….ward……………………..will be carried out under my
supervision. All the materials (type and grade) and the workmanship of the work will
generally tally with the general specifications submitted along with the plans and the
work will be carried out according to the sanctioned plans. I shall be responsible for
the execution of the work in all respects.
Yours faithfully,
Signature of Licensed/ Surveyor/Engineer/
Structural Engineer/supervisor of Architect.
Name: …………………… (in block letters)
License No: ………………………..
Address: ………………………..
Date: ………………………
APPENDICES AND ANNEXURES
ANNEXURE–10
DETAILS OF THE QUALIFICATION, DUTIES, RESPONSIBILITIES AND REGISTRATION PROCESS
Sr. Profession Qualification Registration Duties Responsibilities
No als
1 Architect The Architect must have Registration To design and The Architect/
degree in architecture from with the carry outwork Licensed Surveyor
recognized college/ university Council of related to shall be
and minimum of two years of Architecture, development responsible for
experience in a practice of India, issued as permission as designing the
architecture. per the pro- given below building in
visions of the and to submit conformity with
Architects Act, these Regulations,
a) all plans/
1972 for authentication
documents/
of documents
information/ area
submitted except
certification &
other details
legal document
and for ensuring
as specified in that the
DCR connected development is
with carried out as per
development approved plans,
permission; else get amended
b) Work Start plans approved
Notice Certificate and intimating the
of plinth Authority.
completion.
Certificate of
supervision
completion
certificate for
building with
plans.
The registered Town Planner
2 Town The minimum qualification for a town planner
town planner shall responsible
Planner town planner shall be the shall be the
shall be for designing the
Associate Membership of the Associate
competent to building in
Institute of Town Planners or Membership of
carryout the conformity with
graduate or post graduate the Institute of
work related to these Regulations,
degree in town and country Town Planners
the development for authentication
planning. or graduate or
permit as given of documents
post graduate
below : submitted except
degree in town
a) Preparation of legal document
and country
plans for land and for ensuring
planning.
sub division / that the
layout and development is
related carried out as per
information approved plans,
connected with else get amended
development plans approved
permit for all and intimating the
areas. Authority.
APPENDICES AND ANNEXURES
Sr. Profession Qualification Registration Duties Responsibilities
No als
b) Issuing of
certificate of
supervision for
development of
land of all areas.
3 Licensed The “Licensed Surveyor”” shall Registration To design and The Architect/
Surveyor have diploma/ degree in with Municipal carry outwork Licensed Surveyor
Civil/Construction Engineering Corporation related to shall be
from recognized college/ with the valid development responsible for
board/University or Corporate license issued permission as designing the
memberships (civil) of the as per the given below building in
Institution of Engineers (India) procedure and to submit conformity with
and minimum of 2 years of adopted by these Regulations,
a) all plans/
experience in a practice of MCGM for authentication
documents/
architecture architectural of documents
information/ area
field. submitted except
certification &
legal document
other details
and for ensuring
as specified in that the
DCR connected development is
with carried out as per
development approved plans,
permission; else get amended
b) Work Start plans approved
Notice and intimating the
Certificate of Authority.
plinth
completion.
Certificate of
supervision
completion
certificate for
building with
plans.
4 Structural The minimum qualifications for Registration To carry out The structural
Engineer a Structural Engineer shall be with Municipal work related to engineer shall be
Graduate in Civil Engineering of Corporation development responsible for
recognized Indian or foreign with the valid permission as the structural
university or Associate license issued given below and safety and stability
Membership in Civil as per the to submit – of development
Engineering Division of procedure carried out on
a) All structural
Institution of Engineers (India) adopted by site. He shall
plans and related
and with minimum 3 years of MCGM ensure that the
information
experience in Structural development is as
connected with
Engineering Practice with per the structural
development
designing and field work. requirements
permission
given by him.
The 3 years of experience shall
b) structural Further, the
be relaxed to 2 years in the
details and structural design
case of post graduate degree
calculation of all given shall match
of recognized Indian or foreign
APPENDICES AND ANNEXURES
Sr. Profession Qualification Registration Duties Responsibilities
No als
university in the branch of parts of buildings with approved
Structural Engineering. In case plans. If he notices
c)certificate of
of Doctorate in Structural any difference he
plinth
Engineering, the experience shall be
completion
required would be 1 year responsible for
d) Certificate of intimating the
supervision and Authority.
completion
certificate for
building with
completion
plans.
5 Advocate The Advocate or Solicitor on Registration To render services Advocate or
or Solicitor Record must hold a valid with the Bar related to Solicitor shall be
on Record registration with the Bar Council of development responsible for
Council of India. India. permission and to certification of
submit- title of the land
The Advocate or Solicitor on
Record must have a minimum a) Title Clearance Certifying the
of three ten years of Certificate for the authentication of
experience in a practice of Land Land rights of the
related matters. underdevelopme owner/ developer
nt after exercising to carry out
the procedure of development on
search etc. at the the land
time of concerned.
submission of
proposal,
ownership for
each CTS No.
along with all
rights on
proposed
development at
the time of
Submission of
proposal.
b) Details of any
earlier court
matters related
to land at the
time of
submission of
proposal.
6 Site The “Site Supervisor” must Registered To carry out work The Site
Supervisor hold a diploma in Civil/ with the in accordance Supervisor shall be
Construction Engineering or Municipal with the responsible for the
any other qualification in the Corporation development workmanship and
field of Civil Engineering with the valid permission and material quality
recognized by the board / license issued approved plans and tests of
APPENDICES AND ANNEXURES
Sr. Profession Qualification Registration Duties Responsibilities
No als
universities in Maharashtra as per the and to submit- material required
procedure Certificate of in development
The “Site Supervisor” must
adopted by supervision of carried out on site.
have a minimum of two years
MCGM. buildings and to The failure of test
of experience in Supervision of
carry out results shall be
building works.
material testing intimated to
on site and MCGM. He shall
Note – Earlier registered site ensuring the ensure that the
supervisor Grade II and Grade quality of work development is as
III with MCGM may be as per the per the structural
continued. specifications, design and
NBC & relevant approved plans
Code of Practice. and If he notices
any deviation he
shall be
responsible for
intimating the
Authority.
7 Licensed The “Licensed Plumber” must Registered To carry out The Licensed
Plumber hold a diploma in Civil with Municipal plumbing work Plumber shall be
Engineering or any other Corporation related to responsible for the
qualification in the field of with the valid development workmanship and
Civil Engineering recognized license issued permission and material quality
by the board / universities in as per the approved plans and tests of
Maharashtra Licensed procedure and to submit- material required
Plumber must have a adopted by for plumbing and
a) Certificate of
minimum of two years of MCGM. water supply. The
supervision of
experience in Plumbing works. failure of test
buildings for
results shall be
Plumbing& water
intimated to
supply and to
MCGM. He shall
carry out details
ensure that the
and calculations
plumbing layout
of all parts of
proposed is as per
building w.r.t.
approved plans
Plumbing & bye
and If he notices
law 4(c)
any deviation he
according to
shall be
approved
responsible for
development
intimating the
permission and
Authority.
b) Drainage
Completion
Certificate along
with plans.
8 Consultant The Consultant for Rain Water To carry out The Consultants
for Rain Harvesting (RWH) must hold a work related to for Rain Water
Water Diploma/Degree in Civil Rain Water Harvesting shall
Harvesting Engineering. Harvesting and be responsible for
to submit- the work of Rain
The Consultant for Rain Water
APPENDICES AND ANNEXURES
Sr. Profession Qualification Registration Duties Responsibilities
No als
Harvesting on record must a) Certificate & all Water Harvesting
have a minimum of two years related carried out on site
of experience in the field information as per approval.
practice in RWH. connected with He shall ensure
development that the work is
permission for carried out as per
Rain Water approval and If he
Harvesting; notices any
deviation he shall
b) Details for Rain
be responsible for
Water Harvesting
intimating the
system with
Authority.
proposal/ plans.
c)Completion
Certificate with
respect to Rain
Water Harvesting
for
Building stating
that RWH system
has been
installed and
tested.
9 Consultant The Consultant for Grey Water To carry out work The Consultants
for Grey Recycle must hold a degree in related to Grey for Grey Water
Water Environmental/Public Health Water Recycle Recycle shall be
Recycle /Civil Engineering. and to submit- responsible for the
work of Grey
The Consultant for Grey a) certificate
Water Recycle
Water Recycle on record must &all related
carried out on site
have a minimum of two years information
as per approval.
of experience in a field connected with
He shall ensure
practice in gray water development
that the work is
recycling. permission for
carried out as per
Grey Water
approval
Recycling;
And If he notices
b) Details for
any deviation he
Grey Water
shall be
Recycling Plant
responsible for
with proposal /
intimating the
plans.
Authority.
c)Completion
Certificate with
respect to
completion
plan respect to
Grey water
10 Consultant The Consultant for a. To submit The Consultants
for Conservation of Energy must certificate &all for Conservation
APPENDICES AND ANNEXURES
Sr. Profession Qualification Registration Duties Responsibilities
No als
conservation hold any valid degree in related of Energy shall be
of Energy Electrical/Mechanical information responsible for
Engineering and must have a connected with the work of
minimum of two years of Conservation of Conservation of
experience in a field practice Energy; Energy carried out
in energy conservation. on site as per
b. To submit
approval and the
details for
ECBC codes. He
Conservation of
shall ensure that
Energy Plant
the work is
with proposal for
carried out as per
implement in.
approval and If he
c. To submit notices any
Completion deviation he shall
Certificate with be responsible for
completion plan intimating the
with respect to Authority
Conservation of
Energy for
building
11 Consultant Fire Protection Consultant Must be To carry out work The consultant for
for Fire shall be a licensed agency registered with related to fire protection shall
Safety under the Fire Prevention Director, development be responsible for
Measures Maharashtra permission with design and
& Fire Safety Measures Act,
Fire Services respect to Fire implementation of
2006.
Safety measures firefighting system
and to submit- and shall also
responsible for its
a) Certificate&
implementation on
all related
site in consultation
information
with fire
concerned with
department of
development
MCGM.
permission in
accordance with
requirement of
FireAct2008;
b) details for fire
safety measures
for all parts of
building
Completion
Certificate along
with plans for
building stating
all fire safety
measures as per
CFO NOC has
been installed
and tested with
APPENDICES AND ANNEXURES
Sr. Profession Qualification Registration Duties Responsibilities
No als
completion plans.
12 Consultant HVAC Consultant shall be a To carry out work The consultant for
for Heating/ graduate in Electrical related to HVAC HVA Can be
Ventilation Engineering and must system and to responsible for
and Air submit planning, designing
possess minimum two years
Condition and
of experience in installation a) Certificate &
(HVAC) implementation of
of HVAC all related
HVAC system as
information
per the NBC and
concerned with
relevant code of
HVAC;
practices.
b) details for
HVAC for
implementation.
Completion
Certificate along
with plans with
respect to HVAC
installation, their
testing and
proper
functioning.
13 Consultant SWM Consultant shall be a To carry out work The consultant for
for Solid graduate in related to SWM SWM shall be
Waste Civil/Environmental system and to responsible for
Managemen Engineering or Environ- submit- planning,
t(SWM) mental Planning and must designing and
a) Certificate & all
possess minimum two years implementation of
related
of experience in field of SWM system as
information
SWM. per the NBC and
concerned with
relevant code of
SWM;
practices.
b) Details for
SWM for
implementation
regarding waste
segregation,
onsite treatment
and disposal.
c) Completion
Certificate along
with plans with
respect to SWM
system
installation, their
testing and proper
functioning.
(EP-164)
APPENDICES AND ANNEXURES
Note-: Latent Defect Liability :—
(a) Any or all of the following shall be held liable for any structural flaws or defects in the building with BUA
750 sq.mt. and above for period of Ten (10) years after the date of grant of occupation cum building completion
certificate, except in case of natural calamities, damages, due to war, riots,
i. Architect/License Surveyor
ii. Structural Engineer
iii. Site Supervision/Site Engineer :
iv. Construction Company including contractor, sub-contractor
v. Consultants appointed for various activities involved in the construction work.
(b) The above mentioned professional and the Construction Company including contractor and sub-
contractor may take decennial professional liability insurance to cover such liability.
APPENDICES AND ANNEXURES
ANNEXURE 11
Regulation (10) (5)(i)
Form of sanction of development permission, building permission and Commencement
certificate.
To
…………………………………..
…………………………………..
…………………………………..
Sir,
With reference to your application No. …………..dated………….for Development Permission and
grant of Commencement Certificate under sections 44 and 69 of the Maharashtra Regional and
Town Planning Act, 1966, to carry out development and building permission under section 346 of
the Mumbai Municipal Corporation Act 1888,to erect/additions /alterations to building
……………………………….
On plot No./CS/C.T.S./F P No…………………………..Div./village/Town Planning Scheme
no…………………………………….situated at Road/street……………………….ward…………………….the
Commencement certificate/building permit is granted on the following conditions :-
1. The land vacated in consequence of the enforcement of the set-back line/road widening line
shall form part of the public street.
2. No new building or part thereof shall be occupied or allowed to be occupied or used or
permitted to be used by any person until occupancy permission has been granted.
3. The commencement certificate/development permission shall remain valid for one year
commencing from the date of its issue.
4. This permission does not entitle you to develop land which does not vest in you.
5…………………………………………………………………………………….
6…………………………………………………………………………………….
Yours faithfully,
Executive Engineer (Building Proposal) (………….Ward)
Municipal Corporation of Greater Mumbai.
Office No. ………………………….
Office Stamp ……………………………………..
Date ……………………………………………….
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
ANNEXURE 12
[Regulation 10(5) (i)]
Form of refusal of Development Permission, Building Permission and Commencement Certificate
To
…………………………………………….
…………………………………………….
……………………………………………
Sir,
With reference to your application
No……………………………..dated…………………………for the grant of sanction of the development works;
the erection of a building/execution of work for Building on ………………………..plot
No./C.S.No./C.T.S.No/F.P No .of………………………….Divn./Village/Town Planning Scheme
No…………………………….Situated at…………. Road/Street
………………………………..Ward…………………………………, I regret to inform you that the sanction is
refused on the following grounds under Section 346 of the Mumbai Municipal Corporation Act,
1888, and under Section 45/69 of the Maharashtra Regional and Town Planning Act, 1966.
1. …………………………………….
2 …………………………………….
3. …………………………………….
4. …………………………………….
5. …………………………………….
6. …………………………………….
Yours faithfully,
Executive Engineer, (Building Proposal) (……………Ward)
Municipal Corporation of Greater Mumbai.
Office No. …………………………
Office Stamp ……………………………..
Date ………………………
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
ANNEXURE 13
[Regulations No.11(2) and Section 347(i)(a) of the Mumbai
Municipal Corporation Act, 1888]
Form of Notice for Start of Work
To
The Executive Engineer
(Building Proposal),……………….Ward,
Municipal Corporation of Greater Mumbai,
Mumbai.
Sir,
The development work/erection/re-erection/demolition or material alteration in/of Building
No. ……………………….on/in Plot No./C.S. No./C.T.S.No/F.P No.
…………………………..Division/Village/Town Planning Scheme No.
………………………….situated at ………………………………Street/Road ……………………………Ward
……………………………….will start on ……………………………in accordance with your permission
No.
……………………………………date…………………………………….
Under the supervision of …………………………………….
Licensed Surveyor/ Engineer /Structural Engineer/ Supervisor, or Architect License No
…………………………………and in accordance with the plans sanctioned.
Yours faithfully,
Signature of Owner ………………………………
Name of the Owner ………………………………
In Block Letters ………………………………
Address of Owner ……………………………
Date: …………………………….
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
ANNEXURE 14
[Regulations No.11(4)]
Form of intimation of Completion of Work up to Plinth Level
To
The Executive Engineer
(Building Proposal) …………………….Ward,
Municipal Corporation of Greater Mumbai.
Sir,
The construction up to plinth/column up to plinth level has been completed in Building
No…………………on/in Plot No./C.S. No./ C.T.S.No/F.P No. ……………………………..
Division/Village/Town Planning Scheme No. …………………………….
Road/Street…………………………Ward…………………………………………………in accordance with your
permission No. ……………………………….dated ………………………………..under my supervision and in
accordance with the sanctioned plan.
Please check the completed work and permit me to proceed with the rest of the work.
Yours faithfully,
Signature of Licensed Surveyor/
Engineer/Structural Engineer/Supervisor or Architect
Name………………………(in block letters)
Address……………………………………………….
Date : …………………………………
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
ANNEXURE 15
[Regulations No.11(4)]
Form of Approval/Disapproval of Development Work up to Plinth Level
To
…………………………………………..
…………………………………………..
Sir,
Please refer to your intimation No. …………………….dated ……………………………..regarding the
completion of construction work up to plinth/columns up to plinth level in Building
No……………………………..on/in Plot No/C.S. No./C.T.S. No/F.P No.
………………………..Division/Village/Town Planning Scheme No. ……………………………..situated at
………………………..Road/Street …………………………………Ward …………………………………………You
may/may not proceed with the further work as per sanctioned plans/as the construction up to
plinth level does/does not conform to the sanctioned plans.
Yours faithfully,
Executive Engineer (Building Proposal (…………Ward)
Municipal Corporation of Greater Mumbai.
Office No. …………………………..
Office Stamp ……………………….
Date : ……………………………….
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
ANNEXURE 16
(Regulations No.11(6) & (7))
Form for Development completion certificate
To
The executive Engineer
(Building Proposal),……………………….Ward,
Municipal Corporation of Greater Mumbai,
Sir,
I certify that the erection/re-erection or part/full development work in/on building/part building
No. …………….on/in Plot No., C.S.No./C,T,S, No/F.P No. ……………
Division/Village/Town Planning Scheme No. …………………. Situated at……………
Road/Street………………………………………….Ward……………………………….
has been supervised by me and has been completed on……………………………according
to the plans sanctioned (office communication No. ………………………………………
dated……………………………). The work has been completed to my best satisfaction the workmanship
and all the materials (type and grade) have been used strictly in accordance with general and
detailed specifications. No provisions of the Act or Development Control Regulations or no
requisitions made, conditions prescribed or orders issued thereunder have been transgressed in
the course of the work. I am enclosing three copies of the completion plans, one of which is cloth
mounted. The building is fit for occupancy for which it has been erected/re-erected or altered,
constructed and enlarged.
I have to request you to arrange for the inspection and give permission for the occupation of
the building.
Yours faithfully,
Signature of Licensed surveyor/Engineer/Architect/
Structural Engineer/Site Supervisor/
Architect.
Name …………… (In Block letters)
Address ……………………………..
License No………………………………
Date : ………………………………
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
ANNEXURE 17
(Regulations No. 11(6))
(See sub-section (3) of section 259-A of the Mumbai Municipal Corporation Act, 1888)
Drainage Completion Certificate
To
Assistant Engineer……………………….
……………………….
Sir,
The following work …………
……………………………….(insert full particulars of the work) has been completed to my satisfaction;
the workmanship and the whole of the materials used are good; and no provision of the Act or
the Development control Regulations or building Bye-laws and no requisition made, condition
prescribed or order issued there under, has been transgressed in the course of the work,
Yours faithfully,
Signature of Licensed Plumber……………
Name (in Block letters) ………………….
Address ………………………………….
Licence No. ………………………
Date : ………
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
ANNEXURE 18
(Regulations No. 11(6))
(See sub-section (I) of section 353-A of the Mumbai Municipal Corporation Act, 1888)
Building completion Certificate
To
Executive Engineer……………………………..
Sir,
The following building work (insert full particulars of the work) has been supervised by me and
has been completed to my satisfaction; the workmanship’s and the whole of the materials used
are good; and no provision of the Act or the Regulations, Bye-laws and no requisitions made,
condition prescribed or order issued there under, has been transgressed in the course of the
work.
Yours faithfully,
Signature of Licensed Surveyor/
Engineer/Structural
Engineers/Supervisor or Architect,
Name (in block letters)_________
Address ………………………………………..
Date : ………………………….. License No. …………………………..
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
ANNEXURE 19
(Regulations 11(6) and11 (7)
Form of Acceptance of Drainage Completion Certificate
No…………………….of
To,
………………….
Subject :
Reference :
Sir,
The Completion certificate submitted by you on ………………………..for the above work is hereby
accepted
Yours faithfully)
Executive Engineer/Asst. Engineer…….Dn.
Zone ……………..
Date :
Office Stamp :
No. ……………………………of
Copy forwarded to
………………………………………Dn.
The Assistant Engineer/
Executive Engineer,
Development Plan/
Chief Engineer,
Vigilance,
……………………………………………………………………………..For information
Executive Engineer Zone……………………….
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
ANNEXURE 20
(Regulation 11(7))
Form for Occupancy certificate
To
……………………………
……………………………
……………………………
Sir,
The part/full development work/erection/re-erection or alteration in/of building/part building
No. ….........................................on/in Plot No. ……………………………….
Block No. ………………………………………situated at ……………………..Road/
Street ………………………………………………………….C.S No/C.T.S. No/F.P no. S. No. Division/Village/Town
Planning scheme No. ………………….Situated at……………
Road/Street………………………………………….Ward……………………………….
………………………………. completed under the supervision of …………………
Licensed surveyor/Engineer/Structural Engineer/Supervisor, Architect/License No……...
……………………..may be occupied on the following conditions:-
1)
2)
3)
4)…………………………
…………………………
A set of certified completion plans is returned herewith.
Yours faithfully,
Executive Engineer (Building Proposal) (…………Ward)
Municipal Corporation of Gr. Mumbai.
Office No. ………………………………..
Office Stamp……………………………...
Date ……………………………………
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
ANNEXURE 21
(Regulation 11(8)
Form of Indemnity for Part Occupancy Certificate
To
………………………………………..
Mumbai.
Subject:
Sir,
While thanking you for letting me occupy a portion of the above building before acceptance of
the Completion Certificate of the whole building for the plans approved in communication No.
…………………………………… dated ……………….. I, *indemnify the Municipal Corporation of Greater
Mumbai against any risk, damage and danger which may occur to occupants and users of the said
portion of the building and also undertake to take necessary security measures for their safety.
This undertaking will be binding on me/us, our heirs, administrators and our assignees.
Yours faithfully,
Signature of Owner …………………………
Name of the Owner ………………………….
(in block letters)
Witness
(Signature and name in block letters) ………………………………………
Address : ………………………………………………………………………
………………………………………………………………..
Date : ……………………………………………………………………….
*of such value as decided by the Commissioner.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
ANNEXURE 22
(Regulations 11(6)
Form of Acceptance of Completion Certificate
No…………………….of
To
………………….
Subject:
Reference:
Sir,
The Completion certificate submitted by you on ………………………..for the above work is hereby
accepted and the premises may be occupied.
Yours faithfully,
Executive Engineer/Asst. Engineer…….Dn.
Zone ……………..
Date :
Office Stamp:
No. ……………………………of
Copy forwarded to
………………………………………Dn.
The Assistant Engineer/
Executive Engineer,
Development Plan/
Chief Engineer,
Vigilance,
……………………………………………………………………………..For information
Executive Engineer Zone………………………..
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
ANNEXURE 23
Sketches
Sketch No 1
Sketch No.2
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
Sketch No. 3
Sketch No. 4
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
Sketch No 5
Sketch No. 6
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
Fig 7- Illustrative example:
Note – Sketches not to scale
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
Annexure 24
Appropriate Authority
Sr. No Reservation Reservation Sub Category Appropriate Authority
main Category
Code Name
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
noitacudE
RE1.1 Municipal School MCGM
Primary and Secondary MCGM / School Education & Sports
2 RE1.2
School Department, GOM
Social Justice & Special Assistance
3 RE1.3 Special School
Department, GOM
Higher & Technical Education
4 RE2.1 Higher Education
Department, GOM
Higher & Technical Education
Department, GOM
5 RE3.1 Other Education (In case of Medical College -
Medical Education & Drug
Department, GOM)
Higher & Technical Education
6 RE 4.1 Urban Planning Institute
Department, GOM
MCGM/Medical Education & Drug
7 RE 4.2 Medical Institute
Department, GOM
Higher & Technical Education
8 RE 4.3 Financial Institute
Department, GOM
Higher & Technical Education
9 RE 4.4 Other Institutes
Department, GOM
htlaeH
RH1.1 Municipal Dispensary/
MCGM
Health Post
MCGM/ Medical Education &
RH1.2
11 Hospital Drug Department, GOM / Public
Health Department, GOM
RH1.3 Municipal Maternity
12 MCGM
Home
MCGM/ Social Justice and Special
13 RH3.1 Rehabilitation Centre
Assistance Department, GOM
RH3.4 MCGM / Agriculture, Animal
14 Veterinary Hospital
Husbandry Department, GOM
APPENDICES AND ANNEXURES
Sr. No Reservation Reservation Sub Category Appropriate Authority
main Category
Code Name
15 RMS1.1 Road Depot MCGM
16 RMS1.2 Municipal Chowky MCGM
17 RMS1.3 Municipal Facilities MCGM
18 RMS2.1 Transport Garage MCGM
Solid Waste Management
19 RMS3.1 Facilities and Allied MCGM
Activity
20 RMS3.2 Land Fill Site MCGM
21 RMS3.3 Scrap Yard MCGM
Sewage Treatment
22 MCGM
RMS4.1
Plant/Facilities
23 RMS4.3 Sewage Pumping Station MCGM
24 RMS5.1 Reservoir MCGM
Municipal
25 Services RMS5.2 Water Pumping Stations MCGM
26 Water Treatment Plant MCGM
RMS5.3
Hydraulic Engineering
27 RMS5.5 MCGM
Store/Office
Storm Water Pumping
28 RMS6.1 MCGM
Station
29 RO1.3 Municipal Office MCGM
Public RO2.1 Concerned Department of
30 Government Office
State/Central Govt.
Offices
Disaster Management
31 RO3.1 MCGM
Facility
32 ROS1.2 Promenades MCGM
33 ROS1.4 Play Ground MCGM
34 ROS 1.5 Garden/ Park MCGM
Club/
35 Public Open ROS2.1 MCGM
Gymkhana
Spaces
36 ROS2.3 Zoo MCGM
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
Sr. No Reservation Reservation Sub Category Appropriate Authority
main Category
Code Name
ROS2.4
37 Municipal Sports Complex MCGM
MCGM / School Education &
38 ROS2.5 Sports Complex/ Stadium
Sports Department GOM
39 ROS2.8 Botanical Garden MCGM
40 RP1.1 Fish & Net Drying yards Fisheries Department, GOM
Primary Activity
41 RP2.1 Dhobi Ghat MCGM
42 RPU 1.1 Fire Station MCGM
Ministry of Petroleum, GOI /Fuel
43 RPU2.1 Fuel Station Supply Companiesrecognized by
Ministry of petroleum
Home Department, GOM
44 RPU 3.1 Police Station
45 RPU 3.2 Police Chowky Home Department, GOM
46 RPU3.3 Correction Facilities Home Department, GOM
47 Public Utilities RPU3.4 Police Facilities Home Department, GOM
& Facilities.
Law & Judiciary Department,
48 RPU 3.5 Courts
GOM
Post & Telegraph Department of
49 RPU4.1 Post &Telegraphic Office
GOI.
Energy Department, GOM/
Electricity Transmission Authorized Electric Supply
50 RPU5.2
&Distribution Facility Provider like MSEB / BEST/
Reliance Energy / Tata etc.
51 RPU 6.1 Service Industrial Estate MCGM
52 RR1.1 Municipal Staff Quarters MCGM
RR1.2
53 Police Staff Quarters Home Department, GOM
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
Sr. No Reservation Reservation Sub Category Appropriate Authority
main Category
Code Name
RR1.3 Concerned Department of
54 Government Staff Quarters
State/Central Govt
RR 1.5 Municipal Housing MCGM
Housing
56 RR1.6 Police Housing Home Department, GOM.
Concerned Department of
57 RR1.7 Government Housing
State/Central Govt
Rehabilitation &
58 RR2.1 MCGM
Resettlement
59 RR2.2 Social Housing MCGM
60 RR3.1 Koli Housing MCGM
Municipal Market with
61 RSA1.1 MCGM
Vending Zone
Retail Market with
62 RSA1.2 MCGM
Vending Zone
Multi-Purpose
63 RSA2.1 MCGM.
Community Centre
MCGM / Social Justice and Special
Assistance Department,
RSA2.7 Students Hostel GOM/Women & Child Welfare
Department, GOM
65 RSA2.9 Homeless Shelter MCGM
Cultural Centre/ Drama MCGM /Tourism &Cultural Affairs,
RSA3.3 Theatre/Theater GOM
Social
MCGM /Tourism &Cultural Affairs,
67 Amenities RSA3.5 Museum
GOM
MCGM /Tourism &Cultural Affairs,
68 RSA3.6 Art Gallery
GOM
69 RSA3.7 Leisure Park MCGM
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
Sr. No Reservation Reservation Sub Category Appropriate Authority
main Category
Code Name
70 RSA4.8 Cemetery MCGM
71 RSA4.9 Old Age Home MCGM
Multi-Purpose housing for Women & Child Welfare
72 RSA5.2
working Women Department, GOM
73 RSA6.1 Care Centre MCGM
Adhar Kendra with skill MCGM / Skill Development
74 RSA6.2
development centre Department, GOM
75 RSA6.3 Public Convenience MCGM
Tourism & cultural Affair
76 RSA 7.1 Film Studio/ TV Studio
Department, GOM
RSA 8.1 Animal shelter Agriculture, Animal Husbandry
Department, GOM
MCGM/Transport Department,
78 RT1.1 Truck Terminus
GOM
79 RT1.2 State Transport Depot Transport Department GOM
BEST Bus
80 RT1.4 BEST
Facilities
81 RT1.6 Parking Lot MCGM
Port and Transport Department,
RT2.1 Water Transport Terminal
82 GOM
83 Port and Transport Department,
Jetty
Transport RT2.2 GOM
Metro/Mono Rail Car Urban Development Department,
84 RT3.1
shed GOM
85 RAM Reservation Amenity MCGM
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
APPENDICES AND ANNEXURES
ANNEXURE 25
Abbreviation of criteria (classification) for heritage listing
(a) Value for architectural historical or cultural reasons .. A
-- architectural .. A(arc)
-- historical .. A(his)
-- cultural .. A(cul)
(b) The date and / or design and / or unique use of the building or artefact .. B
-- period .. B(per)
-- design .. B(des)
-- use .. B(uu)
(c) Relevance to social or economic history .. C(seh)
(d) Association with well-known persons or events .. D(bio)
(e) A building or groups of buildings and / or areas of a distinct architectural
design and / or style historic period or way of life having sociological
interest and / or community value. E
-- style
-- historical
(f) The unique value of a building or architectural features or artefact and / or being F
part of a chain of architectural development that would be broken if it were lost.
(g) Its value as a part of a group of buildings .. G(grp)
(h) Representing forms of technological development .. H(tec)
(i) Vistas of natural / scenic beauty or interest, including water-front areas,
Distinctive and / or planned lines of sight, street line, skyline or topographical. .. I(sce)
(j) Open spaces sometimes integrally planned with their associated areas having
a distinctive way of life and for which are and have the potential to be areas
of recreation. J
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai