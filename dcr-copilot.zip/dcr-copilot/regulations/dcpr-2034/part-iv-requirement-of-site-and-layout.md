# Part IV: Requirement of Site and Layout

PART – IV REQUIREMENT OF SITE AND LAYOUT
18. Requirement of Site
No land shall be used as a site for the construction of building –
(a) if the Commissioner considers that the site is insanitary or that it is dangerous
to construct a building on it or no water supply is likely to be available within a
reasonable period of time;
(b) if the site is within 6.0 m from the edge of the water mark of a minor water
course, or 15m from the edge of the water mark of a major water course,
unless arrangements to the satisfaction of the Commissioner are made to drain
the flow of the water course;
Provided that where a water course passes through low-lying land without well-
defined banks, the Commissioner may, as determined by him, permit the owner of
the property to restrict or divert the water course to an alignment and cross
section.
Provided that, in case of trained nallah 6.0m marginal open space shall have to be
maintained
(EP-42)
(c) if the building is proposed on any area filled up with carcasses, excreta, and
filthy and offensive matter, till the production of a certificate from the
Commissioner to the effect that it is hygienically fit to be built upon;
(d) if the use of the said site is for a purpose which, in the Commissioner's opinion,
may be a source of danger to the health and safety of the inhabitants of the
neighborhood;
(e) if the level of the site is lower than the Datum Level prescribed by the
Commissioner depending on topography and drainage aspects. This shall not be
less than reduced level of 27.55m of the Town Hall Datum;
(f) if situated within the funnel of vision marked on DP plan of D Ward;
(g) if the building is nearer than 24.5 m in the case of residential buildings and
36.5 m in the case of other buildings from the centre line of a National
Highway, State Highway or Major District Road;
(h) if it is situated-
(i) within 2438 m from an international civil airport unless the application for
development permission is accompanied by a certificate of consent from the
Civil Aviation Authorities,
(ii) with in 1829 m from any other civil airport unless the application for
development permission is accompanied by a certificate of consent from the
Civil Aviation Authorities.
(i) for places of public worship unless the site has been previously approved by
the Commissioner and the Commissioner of Police;
(j) Unless it derives access from an authorized street/means of access
described in these Regulations;
(k) for industrial use, other than a service industry unless the application is
accompanied by NOC from the appropriate officer of the Industries Department
of the Govt. according to the prevailing Industrial Location policy;
(l) if the proposed development is likely to involve damage to or have
deleterious impact on or is against urban aesthetics of environment or ecology
and/or on historical/architectural/aesthetical buildings and precincts unless
and otherwise specified in these Regulations.
19. Public Street and Means of Access
(1) Every site to have access free of encroachment: Every site proposed to be developed
or redeveloped shall have access from a public street/road as required in these
Regulations. Such access shall be kept free of encroachment.
(2) High Rise and Special Buildings: The Commissioner may permit access to such
buildings from any street as stated below in the Table No6
Table No 6
Building type Height of Building Minimum road width
required in Metres (m)
High Rise Above 32 m up to 70 m 9.0
High Rise Above 70 m up to 120 m 12.0
High Rise Above 120 m 18.0
Special/Assembly For Height up to 32 m 12.0
Building
Special/Assembly For Height above 32 m 18.0
Building
And one end of street shall join another street of width as specified above or greater
width.
Development on plot along the road with width less than that specified in the above
Table shall be allowed if along the entire stretch of a road, the plot owners/owner
handover the land required for widening of road as required for the proposed development
on plot, provided further that the width of the stretch proposed to be widened will not be
more than the width of the road to which it connects.
Provided further that the Commissioner may allow access to building with height up
to 70 m
(a) through the existing 6.0 m wide road which is proposed to be widened to 9.0 m or
more, either in DP or by a sanctioned prescribed regular line under the MMC Act,
1888 provided that road is not dead end road and if the total width of 9.0 m including
width of the road and front open space of the building is made available without
construction of the compound wall for the movement of Fire engine.
(b)Through two numbers of existing roads each having minimum width of 6.0 m.
c) Provided further that in case of redevelopment under Regulation No 33(5), 33(6),
33(7), 33(7)(A),33(7)(B),33(10),33(10) (A),33(15),33(20) (A) width of Road 9 m shall be deemed
to be adequate for any height for the development up to the FSI permissible under that
regulation.
(d) The Municipal Commissioner shall constitute a High-Rise Committee to advise on issues
related to high-rise building having height more than 120 m. in which followings persons shall
be included:
1) Practicing structural Engineer- Member
2) Teaching structural Engineer-Member
3) Chief Fire Officer, MCGM- Member
4) Or any other member
Subject to prior permission of H’ble Supreme court.
(EP-43)
NOTE: - 1. Wherever feasible, the MCGM shall strive to widen all roads having width
below 9 m to a minimum 9 m, after a comprehensive traffic study and due
implementation analysis and sanction as per MMC Act 1888. MCGM shall convert all
roads of width less than 9 m to 9 m and above as per site condition through MR &TP
Act or MMC Act.
2. Roads excluding existing public road/Municipal road, reflected in DP shall not be
treated as public Road, unless and until declared under appropriate section of MMC
Act & shall not be subjected to mechanical acquisition.
(EP-44)
(3) Other buildings:
(a) The Commissioner shall permit access from streets having width of not less than
6.0 m over which the public have a customary right of access or have used it or
passed over it uninterruptedly for a period of 12 years.
(b) The Commissioner may permit access from
(i) any street 6.0 m wide or more (including streets in a gaothan which give access to
other properties outside the gaothan),
(ii) any existing street not less than 3.6 m wide which is proposed to be widened
either in DP or by sanctioned regular line of street under the MMC Act, 1888,
(iii) any street less than 3.6 m wide in a gaothan/Koliwada/Adivasipada if the plot
boundary is shifted 2.25m from the central line of the street. Provided that
shifting of plot boundary to 2.25 m from central line of the street will be insisted
upon only in respect of identified streets forming part of Traffic Circulation
System in gaothan/Koliwada/Adivasipada. Such streets will be identified with
specific approval of the Municipal Commissioner. In all other cases, existing
access will be considered as adequate in gaothan/Koliwada/Adivasipada areas,
subject to the physical verification on site,
(iv) any street or road more than 52.0 m in width specifically identified in the DP for
giving direct access except where NOC has been granted by the appropriate road
authorities,
(c) In case of TP schemes access provided in TP scheme shall be considered adequate.
Provided further that, in case where it is not feasible/possible to provide 6.0 m
wide access (except T P Scheme), the Commissioner, by special permission, may
consider access up to 3.6 m for the proposed building not exceeding 32m in
height. For greater height provision of sub-Regulation (2) of this regulation shall
apply.
Provided further that where any road is proposed to be widened in the DP for
which a regular line of street has been prescribed under the MMC Act, 1888, the
resulting proposed width shall be reckoned in dealing with a request for
development permission. Provided further that a high-rise building shall require
actual access as described in Sub-Regulation (2) of this regulation shall apply.
Regular line of street prescribed under the MMC Act, 1888 shall prevail as per
Regulation No 20, even if it is not reflected in DP.
(EP-45)
(4) Plots/Buildings abutting or fronting a means of Access:
Where a plot or building abuts/fronts a means of access; the width of the access
shall be as specified in Regulation No 23.
20. Alignment & Intersection of Roads
(a)Where there is any conflict between the width provided in the DP and the width
resulting from the prescription of a Regular Line of a street under the MMC Act,
1888, the larger of the two shall prevail. Further, if there is variation in the
alignment of DP Road and sanctioned Regular Line under the MMC Act, 1888 of
same width, the alignment as per the Regular Line shall prevail.
For intersection of roads, the rounding off, cut-off or splay or similar treatment
shall be done to the satisfaction of the Commissioner depending upon the widths
of the roads, the traffic generated, the sighting angle, etc. to provide clear side
distance.
The alignment of road sand their junctions shall be subject to actual demarcation
on site by the Commissioner.
(b) Access to plot at the Carriage Entrance-The sloping portion for deriving
vehicular access from the carriage-way to the plot shall be provided with in the
plot boundary.
21. Highway and wider Roads
No site excepting one proposed to be used for highway amenities like petrol
pumps or motels or hospitals shall have direct access from a highway or specified
road 52m or more in width, unless the same is permitted by Appropriate
Authority.
Provided that this shall not apply to any lawful development along the highways
and other specified roads which have existed before these Regulations have come
into force and alternative measures are provided for their continuance.
22. Access to land-locked plot.
In the case of a plot, surrounded on all sides by other plots, i.e. a land-locked plot
which has no access to any street or road, the Commissioner may require access
through an adjoining plot or plots which shall, as far as possible, be nearest to the
public street. The cost of land acquisition and development of such access shall be
borne by the owner of land-locked plot and subject to other conditions prescribed
by the Commissioner. Alternatively, if the owner of the adjoining plot, which is
accessible from a public street, is willing to provide right of access to such land-
locked plot then the same may be permitted from the required marginal side open
space of the building on such adjoining plots.
Notwithstanding anything contained in these Regulations, additional FSI equal to
Zonal (basic) FSI of area of access provided to land locked plot shall be granted to
plot owner who is providing the access to such land locked property subject to
condition that such access handed over to MCGM. In SDZ II if such right of way is
provided then, additional FSI equal to Zonal (basic) FSI prevailing in adjoining
zone, for area of access provided to land locked plot shall be granted to plot
owner who is providing the access to such land locked property subject to
condition that such access being handed over to MCGM.
(EP-46)
23. Internal means of access
(1) Minimum road width vis-à-vis the area served- Plots which do not abut on a
street shall abut/front on a means of access, the width and other requirements of
which shall be as given in Table No 7 hereunder for residential and commercial
zones and as given in Table No 8 hereunder for an industrial zone.
TABLE No 7
Width of access for Residential and Commercial Zones for plot area to be served
Access Area served (sq. m)
length in meters
(m)
Less than More than1500 More than More than
1500 & up to 4,000 4000 & up 10,000
to10,000
Width in meters (m)
(1) (2) (3) (4) (5)
Less than 75 6 7.5 9 12
More than 75 7.5 7.5 9 12
& upto150
More than 9 9 9 12
150 & up to 300
Over 300 12 12 12 12
Provided that in residential layouts, straight cul-de-sacs up to 150 m long roads are
permissible. An additional length up to 125m will be permissible, if an additional turning
space is provided at 150 m. The turning space, in each case, should not be less than
81sq.min area, no dimension being less than 9 m.
Provided that in residential layouts, straight cul-de-sacs upto 150 m. long roads are
permissible. An additional length upto 125m. will be permissible, if an additional turning
space is provided at 150 m. The dead end shall be at a level higher than the main road
from where the cul-de-sac road takes off. The turning space, in each case, should not be
less than 81sq.m. in area, no dimension being less than 9 m.
(EP-47)
TABLE No 8
Width of access for industrial zones for plot area to be served
Access length in meters Width of means of
(m) access in meter (m)
(1) (2)
Up to 100 9.0
Above 100 up to 300 12.0
Above 300 15.0
(2) Access for residential, commercial and industrial zones- as in table No 7 and
8 above-
(a) shall be clear of marginal open spaces but not less than 3m from the building
line;
(b) may be reduced by 1 m from the prescribed widths if the plots are on only
one side to the access;
(c) shall be measured in length from the point of its origin to the next wider
public street it meets.
(3) Larger width of Means of Access-
In the interest of the general development of any area, the Commissioner
may require the means of access to be of larger width than that required
under these Regulations.
(4) Access in Partially Built up Plots:
Notwithstanding the above, in partially built-up plots where the area still to be
built upon does not exceed 5,000 sq. m an access of 3.6m width may be
considered adequate. If such an access is through a built over arch, this access
shall have a height of not less than 4.5m.
24. Minimum Width of Pathways
The approach to a building from a road/street/internal means of access shall be
through a paved pathway of width specified in Table 9 here-under, the length of
pathway being determined by the distance from the farthest plot or building to
the internal road proposed under Regulation No 23 or to an existing road from
which it takes off.
TABLE No 9
WIDTHS OF PATHWAYS
Types of Development Length of Pathway Width
(1) in meters (m) in meters (m)
(2) (3)
Up to 50 3.0
(i)Residential building Up to 40 2.5
Up to 30 2.0
Up to 20 1.5
(ii) Non-residential building Up to 20 1.5
more than and up to 50 3.0
25. Means of Access to be Constructed & Maintained
(1) General: Means of access shall be levelled, metalled, tarred, flagged, paved,
sewered, drained, channelled, provided with lights and water supply line and
with trees for shade to the satisfaction of the Commissioner. They shall be free
of encroachment by any structure or fixture that may reduce their width below
the minimum required by Regulation No 23 and shall be maintained in
condition considered satisfactory by the Commissioner.
(2) Private Street: If any private street or other means of access is not constructed
or maintained as specified in sub-regulation (1) above, or if structures or
fixtures arise thereon in contravention of that sub-rule, the Commissioner may,
by written notice, direct the owner or owners of the several premises fronting
or adjoining the said street or other means of access or abutting thereon or to
which access is obtained through such street or other means of access or which
shall benefit by works executed, to carry out any or all of the aforesaid
requirements in such manner and within such time as he shall direct. If the
owner or owners fail to comply with this direction, the Commissioner may
arrange for its execution and recover the expenses incurred from the owner or
owners.
(3) How to measure the length of access-ways- The length of main means of access
shall be determined by the distance from the farthest plot or building plot and
the main street. The length of a subsidiary access-way shall be measured from
the point of its origin and the next wider road it meets.
26. Layout/amalgamation/subdivision of plot
(1) Circumstances warranting preparation of a layout or sub-division
/amalgamation: A layout or subdivision/amalgamation shall be submitted for
the following:
(a) when more than one building (except for building accessory to the main
building) is proposed on any land;
(b) when development or redevelopment of any tract of land includes its division
or sub-division/amalgamation of plots;
(c) when the land under development admeasures 2000 sq. m or more in any
zone. in ‘R’, ‘C’ & ‘I’ Zone, except ‘G’ & ‘N.A.’ Zone, where the development is
permissible.
(EP-48)
(2) Contents: Every sub-division/amalgamation/ layout shall contain sub-plots
being formed after sub-division, access thereto, ROS LOS, if any, required
under Regulation No 23 and 27, spaces for other ancillary uses if any required
under Regulation No. 24 and 28 also all the reservations, designations,
allocations, road or road widening proposals of the DP and the regular lines of
streets prescribed under the MMC Act, 1888.
Provided that the Commissioner may, without any reduction in area, allow
adjustment in the boundaries of DP Roads/reserved /allocated sites within the
same holding and conforming to the zoning provisions to suit the development.
In doing so, he will ensure that the shapes of altered, allocated/reserved sites
are such that they can be developed in conformity with these Regulations.
(3) Minimum plot areas: The minimum plot areas permissible for different
categories of use types of development permissible and the minimum
dimension shall be as in Tables No 10 here under:
TABLE No 10
Minimum Plot areas for various Uses
Sr. Land use Plot area (sq. m) Type of
No Development
(1) (2) (3) (4)
1 Residential and Commercial (i)25 and above but less than 40 Row
(except those in 2,3 and 4 below)
(ii)40 and above but less than 125 Row/semi-
detached.
(iii)125 and above with no dimension Row/semi-
less than 9.0 m detached/
detached.
2 Plots in Rehabilitation and 21 with minimum width of 3.0 m Row.
Resettlement/Slum up-
gradation/Reconstruction scheme.
3. Petrol filling Station -
(a) without service bay 545 (with one dimension not less Detached
than 16.75 m).and for filling stations of
only compressed Natural Gas minimum
area of plot shall be 300 sq. m.
(b) with service bay 1100 (with one dimension not less Detached
than 30.5 m).
4 Cinema theatre, assembly hall 3 sq. m per seat including parking
requirements
5 Mangal Karyalaya/ Public Hall 1000
6 Industrial (I) 300 (with width not less than 15m) Detached
Note: - If DP Road/RL is prescribed in already approved layout, then imbalance of
FSI in subdivided plots because of new DP Road/RL shall be allowed. If layout is
amended subsequently, then the benefit of imbalance of FSI will not be allowed
prospectively.
(EP-49)
27. Layout/Plot Recreational Ground/Open Spaces (ROS) (LOS) in Layout/Plot
(1) ROS LOS in residential and commercial layouts:
(a) Extent: In any layout or sub-division/amalgamation/ for the development of
individual plots with single building in a residential and commercial zone, ROS
LOS shall be provided as under.
(i) Area from 1001 sq. m to 2500 sq. m. 15 per cent
(ii) Area from 2501 sq. m to 10,000 sq. m 20 per cent
(iii) Area above 10,000 sq. m 25 per cent
These ROS LOS shall be exclusive of areas of accesses/internal
roads/designations or reservations, DP roads and areas for road-widening and
shall as far as possible be provided in one place. Where however, the area of
the layout or sub-division/amalgamated/plot area is more than 5000 sq. m,
ROS LOS may be provided in more than one place, but at least one of such
places shall be not less than 1000 sq. m in size. Such ROS LOS will not be
necessary in the case of land used for educational institutions with attached
independent playgrounds.
In case of provisions of Regulation No 33 the ROS LOS shall be as stipulated in
the relevant regulations if specified separately, or else the ROS LOS as
specified above shall be provided.
Provided further that the provisions of ROS LOS in case of the redevelopment
schemes under the regulation no 33(5),33(7),33(8),33(10),33(15) and 33(20) (A)
may be reduced due to planning constraints, minimum of at least 8% 10%shall
be maintained. Provided further that in case of redevelopment proposal under
Regulation No 33(5), the existing area of ROS LOS shall be maintained if it is
more than 8 % of the layout.
(EP-50)
(b) Minimum area: No such ROS LOS shall measure less than 125 sq. m.
(c) Minimum dimensions: The minimum dimension of such ROS LOS shall not be
less than 7.5 m, and if the average width of such ROS LOS is less than 16.6 m,
the length thereof shall not exceed 2 1/2 times the average width.
(d) Access: Every plot meant for a ROS LOS shall have an independent means of
access, unless it is approachable directly from every building in the layout.
(e) Ownership: The ownership of such ROS LOS shall vest by provision, in a deed of
conveyance, in all the property owners on account of whose holdings the ROS
LOS is assigned.
(f) Tree growth: Excepting for the area covered by the permissible structures
mentioned under (g) below, the ROS LOS shall be kept permanently open to the
sky and accessible to all owners and occupants as a garden or a playground etc.
LOS and indigenous trees shall be grown as under: -
(a) at the rate of 5 indigenous trees per 100 sq. m or part thereof of the said ROS
LOS to be grown within the entire plot
(b) at the rate of 1 indigenous tree per 100 sq. m or part thereof to be grown in a
plot for which ROS LOS is not necessary
(c) In between the indigenous trees planted along the boundary of plot shrubs with grass
shall be planted.
(d)The native species which have the capacity to attract birds for nesting shall be
preferably selected.
Note: - Indigenous trees are naturally growing trees available locally like mango, neem,
jackfruit, banyan, piple etc.
(EP-51)
(g) Structures/uses permitted in ROS LOS:
(i) In a ROS LOS exceeding 400 sq. m in area (in one piece),
elevated/underground water reservoirs/tanks, electric sub-stations, pump
houses, facility for treatment of wet waste in situ may be built and shall not
utilize more than 10 per cent of the ROS LOS in which they are located.
(ii) In a ROS LOS of 1000 sq. m or more in area (in one piece and in one place),
structures for pavilions, gymnasia, club houses, swimming pools and other
structures for the purpose of sports and recreation activities may be permitted
with BUA not exceeding 15 per cent of the total required ROS LOS, in one
place. The area of the plinth of such a structure shall be restricted to 10 per
cent of the area of the total required ROS LOS in these regulations. The total
height of any such structure, which may be Ground + one storey shall not
exceed 8 m. The height may be increased to 13 m to accommodate badminton
court/squash court. Where club house is proposed in ROS LOS, then provision
for gymnasium/fitness centre/yogalaya in club house shall be insisted upon.
Structures for such sports and recreation activities shall conform to the
following requirements: -
(a) The ownership of such structures and other appurtenant users shall vest, by
provision in a deed of conveyance, in all the owners on account of whose
cumulative holdings the ROS LOS is required to be kept as ROS LOS or ground
viz 'R.G', in the layout or sub-division/amalgamation/plot of the land.
(b) The proposal for construction of such structure should come as a proposal
from the owner/owners/society/societies or federation of societies shall be
meant for the beneficial use of the owner/owners/members of such
society/societies/federation of societies.
(c) Such structures shall not be used for any other purpose, except for
recreational activities.
(d) The remaining area of the ROS LOS shall be kept open to sky and accessible
to all members as a place of recreation, garden or a playground.
(e) The owner/owners/or society or societies or federation of the societies
shall submit to the Commissioner a registered undertaking agreeing to the
conditions in (a) to (d) above.
(f) LOS in a private layout shall be for the exclusive use of the residents of such
private layout only and shall not be subjected to acquisition by
MCGM/Appropriate Authority. Further in such cases area of existing
Recreational Open Space shall have to be maintained by residents of such
private layout.
(h) Unpaved strip: The area of 1.5 m. wide strip within the plot boundary shall be kept
unpaved for ground water recharge and plantation of trees and it shall not be counted
in required LOS:
(EP-52)
(i) Structures/Uses permitted in recreational open spaces
“Construction of Solid Waste Management System as per the National
Building Code of India, Part 9 Plumbing Services, Section 1-Water Supply,
Drainage & Sanitation (including Solid Waste Management) paragraph 6 /bio
degradable waste treatment plant, in the layout RG, having plot area 2000
Sq.mt. & above within 10% of the plot area.”
(EP-53)
(2) ROS LOS in industrial plots/layout of industrial plots in any industrial plot
admeasuring 1000 sq. m or more in area, 15 per cent of the total area shall
be provided as ROS LOS subject to:
(i.) such ROS LOS shall have proper means of access and shall be so located that it
can be conveniently utilised by the persons working in the industry;
(ii.) such ROS LOS shall be kept permanently open to sky and accessible to all the
owners and occupants and indigenous trees shall be grown therein at the rate
of 5 trees for every 100 sq. m of the said open space or at the rate of 1 tree
for every 100 sq. m in other cases. In between the indigenous trees planted
along the boundary of plot, shrubs with grass shall be planted. The native
species which have the capacity to attract birds for nesting shall be preferably
selected.
Note:
1. The above area of ROS LOS shall be calculated on the area excluding the
areas under DP road/ setback/ reservations area to be handed over to
appropriate authority
2. The minimum 60% of the required ROS LOS shall be provided exclusively on
the ground and at least 50% of this shall be provided on mother earth to
facilitate the percolation of water and balance 40% of required ROS LOS may
be provided on podium area extending beyond the building line. The ROS LOS
on mother earth shall not be paved and all ROS LOS shall be accessible to all
the occupants of the plot/layout. Rest of the compound pavement other than
stated above shall be paved with perforated paving having adequate strength,
in order to facilitate percolation of rain water into the ground.
The entire LOS may be provided on top most podium subject to condition that 1.5 m.
unpaved distance shall be kept for planting of trees and thereafter marginal open
space required as per Regulation 47(1) for the maneuvering of fire fighting engine ( &
other equipments) on site from where light & ventilation is derived shall be provided
on two sides.
(EP-54)
3. Recreational Open Space of private layout which is reflected in DP as
reservation of POS or designated existing POS shall remain as layout open space
only and shall not be subjected to acquisition. Further in such cases area of
existing Layout Recreational Open Space shall have to be maintained by the
owner/Co Op Hsg. So/federation etc. as the case may be.
28. Substation
(A) Electrical Consumer Substation (CSS)/Distribution Substation (DSS):
In case of development/redevelopment of any land, building or premises,
provision for electric sub-stations may be permitted as under
Table No.11.
Requirements of plot area for Consumer Substation (CSS).
Sr. No Plot Area (Sq. m) Maximum area of land for CSS/DSS in sq.
m
1 Up to 1000 Nil
2 Above 1000 & up to 2000 40.00 (single Transformer of 8.0 X 5.0)
3 Above 2000& up to 4000 66.00 (single Transformer of 12.0 X 5.5)
4 Above 4000 & up to 20000 143.00 (Two nos of Transformers with each
size 13.0 X 5.5)
5 Above 20000 & up to 40000 720
Note:
(a) If the CSS is forming a part of a building, it shall comply with all the safety precautions
insisted upon by the concerned Electricity Distribution Company and the requirements of
Chief Fire Officer.
(b) Such allotted public spaces shall be developed and maintained by the concerned
Electricity Distribution Company at its own cost, as directed by the Commissioner.
(c) For installation of above, the height as required by the technical requirements of such
installations and the ancillary installations necessary for effective functioning of the
system shall be permitted without taking into account the height parameter in FSI.
(d)The provision for CSS shall not be made mandatory by the Electricity Distribution
Company in each development. The experts in Electricity Distribution Company shall
assess the requirement of CSS considering the existing facilities available in the
neighborhood.
(e) CSS/DSS may be permitted to be constructed in ROS LOS in such a way that area shall
not exceed the limit prescribed in the Regulation No.27.
(f) Ownership of the space/land, where substation is proposed shall vest with concerned
owner/society/association or the person deriving the title, and easement rights will vest
with concerned Electric Authority till CSS/DSS remain inexistence and functional.
(g) The sub-station proposed to be constructed in open space shall be in such a manner that
it is away from the main building at a distance of at least 3 m and in general does not affect
the required side margin open spaces or prescribed width or internal access or larger open
space. The substation can be provided in stilt/podium/within building line subject to
compliance of fire safety requirements, or as may be decided by the Commissioner.
(B) Requirements of plot area for Distribution Substation/Receiving
Substation/Extra High Voltage Receiving Station (DSS/RSS/EHVRS).
Sr. No Plot Area (sq. m) Maximum area of land for DSS/RSS/
EHVRS in sq. m
1 Above 20,000 & up to 40,000 721 to 1200 (maximum) for DSS/RSS as per
the requirements of concerned Electric
Authority
2 Above 40,000 3,500 (maximum) DSS/RSS as per the
requirements of concerned Electric
Authority
3 Extra High Voltage Receiving The construction of EHVRS as per the
Station (EHVRS) requirements of electric distribution
company in their premises shall be
permissible.
Note-
a) The height as required by the technical requirements of such installations and the
ancillary installations necessary for effective functioning of the system shall be
permitted without taking into account the height parameter in FSI.
b) DSS/RSS/EHVRS may be permitted to be constructed below the POS in such way that
the effective area occupied by DSS/RSS/EHVRS shall not exceed the 20% of developed
area of such POS. However, in exceptional cases the said limit may be allowed to be
exceeded with special permission of the Commissioner. Specific permission of Municipal
Corporation shall be obtained for constructing underground DSS/RSS/EHVRS and shall
be subject to terms and conditions and applicable payment. Such allotted POS shall be
developed and maintained by the concerned Electric Distribution Company at its own
cost and will have to be kept open for the use of general public except minimum area
required for ingress and egress.
c) DSS/RSS/EHVRS can be provided on the land of electric supply company or the
requirement of land as specified above and such land will have to be acquired/obtained
as per the policy of Govt. by concerned electric supply company.
d) It shall comply with all the safety precautions insisted upon by the concerned
Electricity Distribution Company and the requirements of Chief Fire Officer.
29. Additional facilities in the Development in Large Holding/layout
(A) In layouts or sub-divisions/amalgamation of area in excess of 2 ha in residential
and commercial zones, plots may be provided for shopping centers/departmental
stores. Such centers/stores may have an aggregate BUA up to 5 per cent of the
Zonal (basic) FSI of the plot. The conditions governing the layout of such a
centre/store shall be as under:
(i) The centre/store may be at one place or may be distributed within the layout to
make it accessible from the different parts of layout;
(ii) These centers/stores shall not abut any roads more than 31 m wide
(iii) A shopping centre may be provided exclusively within the building towers with no
access or frontage on any public road
(iv) Within a layout, the centers/stores may be provided on the ground and upper
floors or on the ground floor and the upper floors may be used for residential
purposes and conveniences like banks or places for medical or dental
practitioners.
(v) Uses shall be as defined in clause (3031) of Regulation No.2, provided further that
restaurant/eating house shall not be permissible in a residential building.
Additional uses may include:
Stores or shops for the conduct of retail business. There will, however, be no
storage or sale of combustible material except with the Commissioner's
permission.
(a.) Personal services establishments only.
(b.) Frozen food stores.
(c.) Cleaning and pressing establishments for clothes, each occupying floor area not
more than 200 sq. m and not employing solvents with a flash point lower than
590C, machines with dry load capacity exceeding 30 kg and employing not more
than 9 persons, with a total power requirements of not more than 4 KW
(d.) Shops for goldsmiths, lock-smiths, watch and clock shops and their repairs, bicycle
shops and their rental and repairs, optician’s shops and optical glass grinding and
repairs shops, musical instruments shops and their repairs, picture framing, radio,
television and household appliance shops and their repairs, umbrella shops and
their repairs and upholstery work, each employing not more than 9 persons.
(e.) Coffee selling shops and grinding establishments, each with electric motive power
not exceeding 0.75 KW (0.025 KW individual motor each);
(f.) Bakeries with no floor above, not occupying for production an area in excess of 75
sq. m and not employing more than 9 persons, if the power requirement does not
exceed 4 KW, where only electrical ovens are used and additional heating load up
to 12 KW permitted
(g.) Confectioneries and establishments for the preparation and sale of eatables not
occupying for production, an area in excess of 75 sq. m per establishment and not
employing more than 9 persons or motive power exceeding 1.12 KW, as well as
sugarcane and fruit crushers, each not employing more than 6 persons with
motive power not exceeding 1.12 KW, in an area not more than 25 sq. m.
(h.) Vegetable, fruit, flower shops
(i.) Photographic studios with laboratories, photocopying, video and videotaping
establishments, etc. and their laboratories, each with an area not exceeding 50 sq.
m, and not employing more than 9 persons and not using power more than 3.75
KW
(j.) Data processing unit with use of computers
(k.) Travel agencies
With the special permission, the Commissioner may from time to time add to,
alter or amend the above list
(B) If a public amenity like a kindergarten school, milk Centre, electric sub-station, bus
shelter, is provided within the project, the area of such facility not exceeding 5
percent of the total plot area shall be allowed free of FSI.