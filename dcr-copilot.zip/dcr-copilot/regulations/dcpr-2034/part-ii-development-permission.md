# Part II: Development Permission

9. Development permission and commencement certificate
(1) Necessity of obtaining permission: No person shall erect or re-erect a building or
alter any building or carry out any development or redevelopment, on any plot of
land or cause the same to be done without obtaining development permission and
a commencement certificate from the Commissioner.
(2) Items of operational construction by some authorities excluded: Construction for
operational purposes, including maintenance of operational structures,
emergency/essential staff quarters by the following organizations, authorities or
departments, whether temporary or permanent, may be exempted by special
permission of the Commissioner in each case from the purview of these
Regulations, except those relating to floor space index and fire precautions:
i. Railways;
ii. National Highways;
iii. National Waterways;
iv. Major ports;
v. Aerodromes and Airports;
vi. Posts and Telegraphs, Telephones, Television, Wireless, Broadcasting
authorities and the authorities of other similar forms of communication;
vii. Regional grids, towers, gantries, switchyards, control room, Relay room for
transmission, distribution, etc. of electricity;
viii. Defence Authorities;
ix. Any other essential public services as may be notified by the State
Government.
x. Metrorail Administration(MRA)/Project Implementing Agency designated by
the Government for the Metro Rail and Monorail/Light Rail Transit (LRT)
Projects.
xi. Facilities & services of Municipal Corporation of Greater Mumbai such as
Roads, Water Supply, Sewerage, Storm Water Disposal and any other
essential public services as decided by the Municipal Commissioner.
All such constructions shall, however, conform to the prescribed requirement for
the provision of essential services, water supply connections, drains, etc. to the
satisfaction of the Commissioner.
(3) Operational constructions excluded: The following constructions for operational
purposes of the organizations, authorities or departments listed above are
exempted from the purview of these Regulations except those relating to floor
space index and fire precautions:
(i) Repairs and renovation of existing installations of buildings used for
operational purposes alone and which do not involve addition to or
increase of built-up areas.
(ii) In the case of the Railways/Metro Rail and Monorail/LRT Authority:
a) repairs and renovation of existing railway tracks, including culverts,
over bridges, under-passes or bridges, tunnels and side drains;
b) platforms, goods sheds and offices, parcel offices, sub-stations, foot-
over bridges turn-tables, lifting towers, gantries, signal and signal
boxes or control cabins in hump yards;
c) running (loco) sheds, carriage and wagon depots, carriage washing
places, overhead or ground level water tanks, pipelines and pumping
station; running rooms, train examiners' offices, yard depots,
permanent way inspectors' and signal inspectors' stores in railway
yards and all overhead electric equipment for traction.
d) Operational Control Centre, Playback Training Room, Stabling Yards,
Maintenance Workshop, Auto wash plant, Auxiliary Rail Vehicle
Building, Under Floor Wheel Lathe & Blow Down Plant, Cooling Tower,
Generator Area, Auxiliary Substation, Traction Substation, Transformer
Area, Water Treatment Plant, Wastewater Treatment Plant, Depot,
Control Centre, Sump Area, Parking Check post, Loading & Unloading
Areas, Fouling Points, DG Set Rooms, Metro& Mono
Stations(Underground& Elevated),Viaduct & Tunnel, Ventilation Shaft,
Entry/Exit Block, Passages, Underground Passages to Station Box, Lift/
Staircases, Escalators ,Air Handling Unit.
(iii) Store sheds, when ancillary to operational requirement only;
Provided that, for the construction of new railway lines or tracks the approval of
the State Government shall be necessary. For construction of new buildings, goods
stores, sheds or platforms, parcel offices and workshops or for purposes of major
remodeling, the approval of the Commissioner shall be necessary.
Further provided that, the following constructions by the organizations,
authorities or departments listed in sub-Regulation (2) herein shall not be deemed
to be operational for the purpose of exemption under the said Regulations,
namely: -
(i) Residential buildings, commercial buildings, office buildings and industrial
buildings (other than gate lodges, essential operational staff quarters and the
like), roads and drains, hospitals, clubs, institutes and schools in residential,
commercial or industrial areas of the colonies of such organizations,
authorities or departments.
(ii) Construction, installation or any extension of any building in the case of any
service other than those mentioned in this Regulation.
(4) Exclusion from requirement of permissions: -No permission shall be required to
carry out tenantable repair works to existing buildings, which have been
constructed with the approval from the competent authority or are in existence
since prior to 17.04.1964 in respect of residential structures and 01.04.1962 in
respect of non-residential structures, as described under section 342 of MMC Act
1888.
No permission shall be required for provision of safety grills to window/ventilator.
No permission shall be required for repairs to the Existing
Consumer/Distribution/Receiving Substation of the BEST/Electric Supply Company.
However, no addition/alteration shall be permissible without the approval of the
Commissioner.
No permission shall be required for providing fencing, construction of compound
wall along CTS/CS boundaries of land under his ownership, installation of Solar
Panels having base of solar panel at height 1.8m from terrace, ensuring structural
stability from the Licensed Structural Engineer.
(EP-10)
No permission shall be required for internal light weight partitions/cabins up to
height of 2.2 in the commercial building/establishment subject to structural
stability from the Licensed Structural Engineer.
(5) Validity of development permission: The development permission granted in the
past shall be governed by the provision of section 48 of the MR&TP Act, 1966.
Where development has commenced as per the development permission/ IOD
issued prior to publication of these Regulations, the CC shall be issued or
revalidated till completion of development in accordance with the
plans/concessions approved for full permissible FSI, in respect of the said IOD as
per the then Regulations.
(EP-11)
(6) Applicability to partially completed works:
(a) For works where development permission IOD/IOA/LOI has been issued or for
partially completed works, started with due permission before these Regulations
have come into force, the developer/owner may continue to complete the said
works in accordance with the conditions under which permission stood granted.
However, the period of the development permission granted shall not exceed that
specified in section 48 of the MR&TP Act, 1966 or at the option of
owner/developer, the proposal can be converted as per DCPR-2034 in toto.
(EP-12)
(b) In case of such plots or layouts that started with due permission before these
Regulations have come into force, where part development is completed and full
Occupation Certificate or Building Completion Certificate is granted or
building/buildings stand assessed to the Municipal taxes, and if the owner
/developer thereafter seeks further development of plot/layout as per these
Regulations, then the provision of these Regulations shall apply to land excluding
the land component of such buildings.
Provided further that in case of building/buildings where development permission
is granted but full occupation or completion certificate is not granted or are not
assessed to the Municipal taxes and if owner/developer seeks further development
under these Regulations, then the entire development shall have to be brought in
conformity with these Regulations.
(b) In case of such plots or layouts that started with due permission before DCPR 2034 have
come into force, where part development is completed and part or full Occupation
Certificate or Building Completion Certificate is granted or building/buildings stand
assessed to the Municipal taxes, and if the owner /developer, at his option, thereafter
seeks further development of plot/layout/buildings as per DCPR 2034, then the provision
of DCPR 2034 shall apply to the further development. The development potential of the
entire plot shall be computed as per DCPR 2034 from which the sanctioned FSI as per the
approved plans in respect of building(s) having part and / or full Occupation Certificate or
Building Completion Certificate or building/buildings stand assessed to the Municipal taxes
shall be deducted to arrive at the balance development potential of the plot.
(EP-13)
(7) The reservations in the DP-2034 is kept for private persons/institutions then such
reservation will laps and development on such plots will be allowed as per the
adjoining zone of the said land as per DCPR-2034.
(EP-14)
Provided further that in case of building/buildings where development permission
is granted but full occupation or completion certificate is not granted or are not
assessed to the Municipal taxes and if owner/developer seeks further development
under these Regulations, then the entire development shall have to be brought in
conformity with these Regulations
10. Procedure for obtaining Development Permission and Commencement
Certificate.
(1) Notice of intention: Every person who intends to carry out development or
redevelopment, erect or re-erect a building or alter any building or part of a building
shall give notice in writing to the Commissioner of his said intention in the form in
Appendix II and such notice shall be accompanied by plans and statements with
sufficient number of copies, as required by sub-Regulations (2) and (3) hereunder.
The plans may be ordinary prints. One set of such plans shall be retained in the office
of the Commissioner for record after the issue of permission or refusal. The
Commissioner may set a date after which all submissions, approvals and
communication in regard to development permission shall be on line.
(2) Copies of plans and statements:
(i) Notice: The notice referred to in sub Regulations (2) of Regulation No 11 shall be
accompanied by as many copies of plans as the Commissioner may prescribe after
taking into consideration the clearances required from other agencies.
(ii) Size: The size of drawing sheets shall be any of those specified in Table 1
hereunder.
TABLE 1 Drawing sheet sizes
Serial No.1 Designation Trimmed Size (mm)
(1) (2) (3)
1 A0 841-1189
2 A1 594-841
3 A2 420-594
4 A3 297-420
5 A4 210-297
If necessary, submission of plans on sheets bigger than A0 size is also permissible.
(iii) Colouring notations for plans: The plans shall be coloured as specified in Table 2
hereunder. The prints of the plans shall be on one side of the paper only.
TABLE 2
Colouring of Plans
Sr. Item Site Plan Building
No. Plan
(2) (3)
(1) (4)
1. Plot Lines ----------- Thick Black-----------
2. Existing Street Green -------------
---
3. Future Street Green Dotted -------------
---
4. Permissible Building Thick Dotted -------------
---
Black
5. Open Spaces ----------------- No Color-----------------
6. Work proposed to be ---------------- Yellow hatched ----------
demolished
7. Proposed work ---------------- Red filled in ------------
8. Drainage and Sewerage ---------------- Red Dotted -------------
work
9. Water Supply Work ------------------- Blue Dotted thin ---------
-
10. Deviations ------------ ------ Red Hatched --------------
11. Recreation Ground ------------------- Green Wash -------------
12. Roads and Set backs ------------------- Burnt sienna ------------
13. Reservation -------------------- Appropriate colour
code -------------
Note. - (i) Site plans/building plans may be submitted in the form of Ammonia prints/Blue
prints or White plans.
(ii) Existing work to be hatched black; for land development/sub-division/lay-out,
suitable colouring notations shall be used duly indexed.
(3) Information accompanying notice:
(i) Key plan, site plan, etc. to accompany notice. The notice shall be
accompanied by the key plan (location plan), a site plan, sub-division/lay
out plan, building plan, specifications and certificate of supervision,
ownership, title, etc. as prescribed in clauses (ii) to (xiii) below.
(ii) Ownership title and area. -Every application for development permission
and commencement certificate shall be accompanied by a copy of
certificate of the title of the land under development, obtained from an
Advocate who has experience in this field of a minimum 10 years. In case
the application for Development Permission or Commencement Certificate
is submitted by the holder of power of attorney, then a certificate from an
Advocate certifying that the power of attorney in favour of the applicant is
valid and subsisting shall be accompanied. In addition to above the
certificate, the following documents for verifying the area of the land shall
be submitted, accompanied by an Indemnity Bond indemnifying MCGM and
its officer against legal consequences on account of ownership disputes, if
any. of the following documents for verifying the ownership and area
etc. of the land:-
a) Attested copy or original sale/lease deed/power of attorney/enabling
ownership documents wherever applicable;
b) Title clearance certificate with title search from Solicitors/Advocate on
record;
(EP-15)
a) Property register card of a date not earlier than twelve months prior to the
date of submission of the development proposal;
b) Statement of area of the holding by triangulation method from a licensed
surveyor or architect with an affidavit from the owner as certifying the
boundaries of the plot and area well as from licensed surveyor or architect
in regard to the area in the form prescribed by the Commissioner;
c) Affidavit from the owner regarding non-holding of contiguous land to the
site under development.
d) CTS/CS plan in original. If there is any sub-division due to ownership,
documents related to sub-division.
e) In case of property owned by more than one owner, certificate from an
advocate who has experience in this field of a minimum 10 years, certifying
that all co-owners have consented for development.
f) In case of tenanted properties to be developed under Reg. No. 33(7), 33(9),
certificate from MHADA/Land owning public authority, certifying that at
least 70% 51% of the certified and eligible tenants of the property/each
building have granted irrevocable consent for development in favour of
owner/developer & in case of tenanted properties to be developed under
Reg. No. 33(9) certificate from MHADA/Land owning public authority,
certifying that at least 51% of the certified and eligible tenants of the
property/each building & overall 70% eligible tenants have granted
irrevocable consent for development in favour of owner/developer.
(EP-16)
g) In case of properties owned by co-operative societies, certificate from an
Advocate who has experience, in this field, of a minimum 10 years,
confirming that the registered society/society on the plot of development
have entered into registered agreement with the developer wherein it has
granted permission for development of the project and at least 70% of
member of the society present in a Special General Body Meeting convened
for the purpose, have approved development and have consented in favour
of the development by the applicant.
h) In case of properties situated in the layout and owned by MHADA/Land
owning public authority, a certificate from MHADA or land owning public
authority certifying that minimum 70% 51% of the certified and legal
occupants of the property have granted consent in favour of
owner/developer.
(EP-17)
i) In the case of land leased by the Government or local authorities, clearance
of Government or such authorities regarding observance of the lease
conditions shall be obtained and attached to the application for
development permission in respect of such land.
j) Any other documents as may be prescribed by the Commissioner;
k) Declaration cum affidavit from the owner/developer/applicant stating
therein that construction materials like sand/aggregate will be obtained
from the authorized quarry.
(iii) Key plan or location plan-A Key plan drawn to a scale of not less than 1:
4000 shall be submitted along with the application in Appendix II for
development permission and commencement certificate showing the
boundary, locations of the site with respect to neighborhood land-marks.
(iv) Site plan-The site plan sent with an application for permission drawn to a
scale of 1:500 shall be duly signed by the Owner & licensed Surveyor or
architect showing in addition to the details in Form-II of Annexure I the
following: -
a) The boundaries of the site and of any contiguous land belonging to the
owner of the site;
b) The position of the site in relation to neighboring streets;
c) The names of the streets on which the building is proposed to be situated
if any;
d) All existing buildings contained in the site with their names (where the
buildings are given names) and their numbers;
e) The position of the building and of other buildings, if any, which the
applicant intends to erect upon his contiguous land referred to in (iv)(a)
above in relation to-
i. the boundaries of the site and in a case where the site has been
partitioned, the boundaries of the portions owned by others;
ii. all adjacent streets, buildings (with number of stories and height) and
premises within a distance of 12 m of the work site and of the
contiguous land(if any) referred to in (iv)(a); and
iii. if there is no street within a distance of 12m of the site, the nearest
existing street with its name;
f) The means of access from the street to the building, and to all other
buildings (if any) which the applicant intends to erect upon his contiguous
land referred to in (iv)(a) above;
g) The space to be left around the building to secure free circulation of air,
admission of light and access for service purposes;
h) The width of the street (if any) in front and of the street (if any) at the side
or near the building;
i) The direction of the north line relative to the plan of the building;
j) Any existing physical features, such as wells, tanks, drains or trees;
k) The ground area of the whole property and the back-up of the covered
area on each floor with the calculations;
l) Overhead electric supply lines including space for electrical transformer
sub-station according to the requirements of the electric distribution
licenses, water supply and drainage line;
m) Such other particulars as may be prescribed by the Commissioner.
(v) Sub-division/Lay-out Plan -Where development is proposed in a sub-division
or involves a layout plan, the notice shall be accompanied by a key-plan
showing the location of the plot in the ward at a scale of not less than 1:4000
and a sub-division layout plan to a scale of not less than 1:500, which shall be
duly signed by the Owner & licensed surveyor or architect containing the
following: -
a) Scale used and the direction of the north line relative to the plan of
the building;
b) The location of all proposed and existing roads with their names,
existing/proposed/prescribed width within the land;
c) dimensions of the plot along with the building lines showing the set-
backs with dimensions of each plot;
d) The location of drains, sewers, STP, tanks, wells, trees, public
facilities and services, electric lines, etc.;
e) A table indicating the size, area and use of all the plots in the sub-
division/lay-out plan;
f) A statement indicating the total area of the site, area utilized under
roads, open spaces for parks, playgrounds, recreation spaces and
development plan designations, reservations and allocations,
amenity space, school, shopping and other public places along with
their percentage with reference to the total area of the site;
g) In the case of plots which are sub-divided in built-up areas, in
addition to the above, the means of access to the sub-division from
existing streets and in addition, in the case of plots which are sub-
divided in built up area, the means of access to each sub-plot from
existing streets.
h) Contour plan of site, wherever necessary.
(vi) Building Plan -The plans of the building with elevations and section
accompanying the notice shall be drawn to a scale of 1:100 and shall-
a. Include floor plans of all floors together with the covered area clearly
indicating the size of the rooms, the positions and width of staircases,
ramps and other exit ways, lift wells, lift machine rooms and lift pit details,
meter room and electric sub-station. It shall also include the ground floor
plan as well as the basement plan and shall indicate the details of parking
spaces, loading and un-loading spaces, if required to be provided around
and within the building, as also the access ways and appurtenant open
spaces with projections in dotted lines, the distance from any building
existing on the plot in figured dimensions along with the accessory building.
These plans will also contain the details of FSI calculations.
b. Show the use or occupancy of all parts of the buildings;
c. Show the exact location of essential services, e.g. water closet (WC), sink,
bath,
d. Include sectional drawing showing clearly the sizes of the footings,
thickness of basement wall, wall construction, size and spacing of framing
members, floor slabs and roof slabs with their materials. The section shall
indicate the heights of the building and rooms and also the height of the
parapet and the drainage and the slope of the roof. At least one section
should be taken through the staircase &Lift well. The certified structural
plan by Structural Engineer/Consultant giving details of all structural
elements and materials used along with structural calculations can be
submitted separately, but under any circumstances, before the issue of the
development permission/commencement certificate;
e. Show relative levels of streets;
f. Give dimensions of the portions projecting beyond the permissible building
line;
g. Include a terrace plan indicating the drainage and the slope of the roof;
h. Indicate the north line relative to the plans;
i. Give a schedule of doors, windows and ventilators;
j. Show the pump rooms, Rain Water Harvesting System, Sewage Treatment
Plant, if any.
k. Provide such other particulars as may be prescribed by the Commissioner;
Provided that with the building plans for high rise or special buildings, the
following additional information shall be furnished or indicated on the
building plans;
l. Access to fire appliances/vehicles with details of vehicular turning circle and
clear motorable access way around the building;
m. Size (width) of main and alternate staircases along with the balcony
approach, corridor, ventilated lobby approach;
n. Location and details of lift enclosures;
o. Location and size of fire lift;
p. Smoke stop lobby door/Fire resistant door, where provided;
q. Refuse chutes, refuse chamber, service duct, etc.
r. Vehicular loading and unloading and parking spaces;
s. Refuse area if any;
t. Details of air-conditioning system with position of fire dampers, mechanical
ventilation system, electrical services (with dimensions of electrical
transforming sub-stations etc.) boilers, gas pipes, meter rooms etc.;
u. Details of exits, including ramps, etc. for hospitals and special risks;
v. Location of generator, transformer and switch gear room;
w. Smoke exhaust systems, if any;
x. Details of fire alarm system;
y. Location of centralized control, connecting all fire alarms, built-in fire
protection arrangements and public address system, etc.; location and
dimensions of static water storage tank and pump room along with fire
service inlets for mobile pump and water storage tank;
z. Location and details of fixed fire protection installation such as sprinklers,
wet hose reels, drenchers, carbon-dioxide (CO ) installations, etc.; and.
aa. Location and details of first aid and firefighting equipment/installations.
(vii) Service plan - Plan and sectional elevations of private water supply, sewage
disposal system and details of building services, where required by the
Commissioner, shall be made available on a scale of not less than 1:100 before
undertaking such work.
(viii) Specifications. - General specifications of the proposed construction, giving the
type and grade of materials to be used in the form in Annexure 2 to 9 signed by a
licensed surveyor/engineer/structural engineer, supervisor, or architect, town
planner or qualified professional as the case may be, shall accompany the notice.
It shall be ensured that the construction materials to be used shall be in
accordance with the relevant I S Codes, by the developer/owner.
(ix) Supervision Certificate. - The notice shall be further accompanied by a certificate
of supervision in the form in Annexure 2 to 8 by the licensed
surveyor/engineer/structural engineer/supervisor or architect/Professional on
Record as the case may be. If the said licensed technical person or architect
ceases to be employed for the development work, further development shall be
suspended till a new licensed technical person or architect is appointed and his
certificate of supervision along with a certificate for the previous work erected, if
any, is accepted by the Commissioner.
(x) Development permission fee receipt - The notice shall be accompanied by an
attested copy of the receipt of payment of the development permission
application fee.
(xi) Security deposit - To ensure compliance with these Regulations and the directions
given in the sanctioned plan and other conditions, a security deposit, shall be
charged at rates specified by the Commissioner. It shall be returned to the owner
one year immediately after the issue of the full occupancy certificate after the
Commissioner is satisfied with the compliance with various conditions stipulated
in the said full occupancy certificate.
(xii) Clearance certificate for tax arrears - The notice shall also be accompanied by an
attested copy of a clearance certificate from the Assessment Department of the
Corporation for payment of tax up-to-date self-certification by the
owner/developer regarding payment of tax up to date with certified copies latest
payment receipt.
(xiii) No objection certificate - For occupancies requiring clearance from authorities like
the Civil Aviation Department, Directorate of Industries, Maharashtra Pollution
Control Board, Inspectorate of Boilers and Smoke Nuisances, electrical distribution
licensers regarding requirements of electrical transforming stations, the no
objection certificate from these authorities, applicable to the occupancy, shall also
accompany the notice.
(xiv) Other facilities to be provided during construction. - The notice shall also be
accompanied by an undertaking from the owner/developer/contractor to the
effect that during the period of construction facilities will be made available for
day-care centre, crèche, adult-literacy and non-formal education programs for the
construction workers, directly by him or through a voluntary agency.
(4) Signing of plans by owners and licensed personnel/architect:
(i) Signing of Plans - All the plans shall be signed by the owner and the licensed
surveyor/engineer/structural engineer/supervisor or architect or any Professional
on Record as the case may be, and shall indicate their names in block capital
letters, addresses and license numbers when so licensed, allotted by the
Commissioner. The list of Professionals on Record is as per Annexure 10.
(ii)Qualification and competence of the licensed surveyor/engineer/structural
engineer/supervisor/Professional on Record - The Commissioner shall grant license
to surveyors, engineers, structural engineers and supervisors with the
qualifications listed in Annexure 10 to perform the tasks mentioned in that
Annexure.
(5) Processing of the development permission application:
(i) Grant of permission or refusal. - The Commissioner may either sanction or
refuse to sanction the plans and specifications or may sanction them with such
modifications or directions as he may deem necessary, and thereupon, he shall
communicate his decision accordingly to the person giving the notice in the
formats specified in Annexure 11 and 12
(ii) Fire brigade scrutiny. -The plans for all high rise and special buildings shall also
be subject to the scrutiny of the Chief Fire Officer, and development permission
shall be given by the Commissioner only after clearance by the Chief Fire Officer.
(iii) Deemed permission.-If within sixty days of the receipt of the notice under sub-
Regulations (1) of Regulations 10, the Commissioner fails to intimate in writing to
the person who has given the notice, his refusal or sanction, or sanction with
modifications or directions, the notice with its plans and statements shall be
deemed to have been sanctioned, provided that this shall not be construed to
authorize any person to do anything on the site of the work in contravention of or
against the terms of lease or titles of the land, development plan, these
Regulations or any law in force.
(iv)Revised plans. - Once the plans have been scrutinized and objections have been
pointed out, the owner giving notice shall modify the plans to comply with the
objections raised and resubmit them. The plans submitted for final approval shall
not contain superimposed corrections. The Commissioner shall scrutinize the
revised plans and shall grant or refuse development permission/commencement
certificate within sixty days from the date of resubmission.
(6) Commencement of work:
A development permission/commencement certificate shall remain valid for four
years in the aggregate, but shall have to be renewed before the expiry of one year
from the date of its issue. The application for renewal shall be made before expiry
of one year, if the work has not already commenced. Such renewal can be done for
three consecutive terms of one year each, after which proposals shall have to be
submitted to obtain development permission afresh.
For the purpose of this Regulation, `Commencement` shall mean as under: -
(a) For a building work including Completion of foundation work
additions and alterations such as pile foundation, casting
of raft or raft for basement,
casting of footing of open
foundation. This shall not
include the sheet
piling/diaphragm wall/touch
piles/retaining wall for
protection of site/neighborhood.
Upto plinth level or where there
is no plinth, upto upper level of
basement or stilt, as the case
may be.
(b) For bridges and overhead Foundation and Construction
Tanks work up to the base Floor.
(c) For Underground works Foundation and Construction
work up to floor of underground
Floor.
(d) For lay-out, sub-division and Final demarcation and provisions
amalgamation proposals of infrastructure and services up
to the following stages:
(i) Roads: Water bound
macadam complete.
(ii) Sewerage, Drainage and
water supply excavation and
base concreting complete.
(7) Payments of the development charges/ premium/ development cess/off-site
infrastructure charges/fees:
Development permission/ Commencement certificate shall be granted only on
payment of the requisite fees, development charges, premiums, Development
cess/off-site infrastructure charges, as applicable for the proposal. The
development shall be considered unauthorized if carried out without requisite
payments to the Government/MCGM/Planning Authority.
NOTE: The Municipal Commissioner with special permission may decide the
modalities of procedure for Development Permission, including online approval
process, from the point of view of Ease of Doing Business time to time.
11. Procedure during Construction
(1) Construction to be in conformity with Regulations: Owner`s liability-Neither the
grant of permission nor approval of the drawing and specifications nor inspections by
the Commissioner during erection of the building, shall in any way relieve the owner
of such building from full responsibility for carrying out the work in accordance with
these Regulations.
While allowing development, the Commissioner shall ensure that relevant provisions
of The Noise Pollution (Regulation and Control), Rules 2000 be adhered to in letter
and spirit.
(EP-18)
(2) Notice to start of work: The owner shall give notice to the Commissioner of his
intention to start work on the building site in the format given in Annexure 13 The
owner may start the work after 7 days have elapsed from the date of the service of
such notice to the Commissioner or earlier, if so permitted.
(3) Documents at site:
(i) Results of tests- Where tests of any material are made to ensure conformity
with the requirements of these Regulations, record of the test data shall be kept
available for inspection during the construction of the building and for such period
thereafter as required by the Commissioner.
(ii) Development permission - The person to whom development permission is
issued shall during construction, keep-
(a) posted in a conspicuous place, on the site for which permission has
been issued, a copy of the development permission/commencement
certificates; and
(b) a copy of the approved drawings and specifications referred to in
Regulations 10 on the site for which the permission was issued.
(c) list of Professionals on Record with their contact details.
(d) copies of various remarks obtained from various departments related
to the development.
(4) Checking of plinth columns up to plinth level: The owner through his licensed
surveyor, or his architect shall give notice in the form given at Annexure 14 to the
Commissioner on completion of work up to plinth level to enable the Commissioner to
ensure that the work conforms to the sanctioned plans. The Commissioner may
inspect the work jointly with the licensed technical personal or architect within
fifteen days from the receipt of such notice and either give or refuse permission for
further construction as per the sanctioned plans in the form given at Annexure 15. If
within this period, the permission is not refused, it shall be deemed to have been
given provided the work is carried out according to the sanctioned plans.
(5) Deviation during constructions: If during the construction of a building, any
departure of a substantial nature from the sanctioned plans is intended by way of
internal or external additions, prior sanction of the Commissioner shall be mandatory.
A revised plan showing the deviations shall be submitted and the procedure laid down
for the original plans here to shall apply to all such amended plans. Any work done in
contravention of the sanctioned plans, without prior approval of the Commissioner,
shall be deemed as unauthorized. Any work done in contravention of the approved
plan but within the sanctioned FSI, shall be deemed to be departure not of a
substantial nature.
(6) Completion certificate: The owner, through his licensed plumber, shall furnish a
drainage completion certificate to the Commissioner in the form given at Annexure
17. The owner through his licensed surveyor/engineer/structural engineer/supervisor
or his architect, or any professional on record, who has supervised the construction,
shall furnish a building completion certificate to the Commissioner in the form given
at Annexure 18. These certificates shall be accompanied by three sets of plans of the
completed development. The Commissioner shall inspect the work and, after
satisfying himself that there is no deviation from the approved plans, issue a
certificate of acceptance of the completion of the work in the form given at Annexure
19. Further on receipt of development completion certificate for entire development
in the form of Annexure 16, and after satisfying himself that there is no deviation
from the sanctioned plans, may issue Building Completion certificate in the form given
at Annexure 22 or refuse the Building Completion Certificate within 21 days from the
date of receipt of the request for the said Building completion certificate. Deviation in
outer dimension to the extent of 25 mm shall be tolerated subject to condition that
carpet area shall remain unchanged.
(7) Occupancy certificate: On receipt of the acceptance of completion certificate in
the form given at Annexure 19, the owner, through his licensed surveyor or his
architect shall submit to the Commissioner a development completion certificate in
the form given at Annexure 16 with three copies of the completion plan, one of which
shall be cloth mounted for record. The Commissioner may inspect the work and after
satisfying himself that there is no deviation from the sanctioned plans, issue an
occupancy certificate in the form given at Annexure 20 or refuse to sanction the
occupancy certificate within 21 days from the date of receipt of the said completion
certificate, falling which the work shall be deemed to have been approved for
occupation, provided the construction conforms to the sanctioned plans. One set of
plans, certified by the Commissioner as the completed plans, shall be returned to the
owner along with the occupancy certificate. Where the occupancy certificate is
refused, or rejected, the reasons for refusal or rejection shall be communicated to the
owner in writing.
(8) Part occupancy certificate /part building completion certificate: When requested
by the owner, the Commissioner may issue a part occupancy certificate /accept part
building completion certificate for a building or part thereof, before completion of the
entire work as per the development permission, provided sufficient precautionary
measures are taken by the holder to ensure public safety and health. The part
occupancy certificate/part building completion certificate shall be subject to the
owner's indemnifying the Commissioner in the format given at Annexure-21
12. Inspection –
(1) Inspection at various stages: The Commissioner may at any time during erection
of a building or the execution of any work or development, make an inspection
thereof without giving previous notice of his intention so to do.
(2) Inspection by Fire Departmental: For all high-rise and special buildings, the work
shall also be subject to inspection by the Chief Fire Officer, and the Commissioner
shall issue the occupancy certificate/accept building completion certificate only after
clearance by the said Chief Fire Officer.
(3) Unsafe building: All unsafe buildings shall be considered to constitute danger to
public safety, hygiene and sanitation and shall be restored by repairs or demolished
or as otherwise directed by the Commissioner.
(4) Unauthorized development:
(a) In case of unauthorized development, the Commissioner shall take suitable action
which may include demolition of unauthorized works as provided in section 53 of
the Maharashtra Regional and Town Planning Act, 1966 and the relevant
provisions of the Mumbai Municipal Corporation Act, 1888.
(b) It will be the responsibility of the Architect/Licensed Surveyor on Record, to
inform the Commissioner, immediately, regarding any unauthorized work/
development and also to inform the owner/developer, in writing, to stop the
work, failing which suitable action against Architect/ licensed surveyor will be
taken. take suitable action against the licensed surveyor or the architect, site
supervisor, professional on record and persons who are directly are indirectly
responsible for such unauthorized development as provided under section 52 and
53 of the Maharashtra Regional and Town Planning Act, 1966.
(5) Safety Precautions: It shall be responsibility of the Owner/Developer and the
respective professionals on record appointed by Owner/Developer, to ensure all the
necessary safety measures are taken on site and its immediate surroundings,
especially in regard to workmen engaged, as directed in part -7, Constructional
Practices & Safety, National Building Code of India, as amended to date.
Grant of IOD/C.C/O.C. or issuance of any written instructions to ensure public safety
or reduce nuisance/inconvenience does not render MCGM liable for any injury,
damages or loss whatsoever that may be caused to anyone in and around the
construction area/site.
(6) Revocation of permission:
(i) Without prejudice to the powers of revocation conferred by Section 51 of
the Maharashtra Regional and Town Planning Act, 1966,Municipal
commissioner may, after giving the opportunity of being heard, revoke any
development permission issued under these regulations where it is noticed
by him that there had been any false statement or any misrepresentation
of material fact in the application on the basis of which the development
permission was issued and there upon such work carried out in pursuance
of such permission shall be treated as unauthorized.
(ii) In the case of revocation of permission under sub-regulation (i) above, no
compensation shall be paid.