# DCPR-2034 Reference Index

Source: DCPR-2034 (Development Control and Promotion Regulations for Greater Mumbai), sanctioned Gazette text, as uploaded by user (Notification set dated 8 May 2018 with subsequent corrigenda through Sept-Nov 2018).

> NOTE: verify this reflects the latest amendments before shipping — DCPR-2034 has seen amendments since 2018 (e.g. redevelopment/TDR policy changes). Cross-check against MCGM/Directorate of Town Planning for anything more recent.

## Parts

- **Part I: Administration** -> `part-i-administration.md` (57681 chars)
- **Part II: Development Permission** -> `part-ii-development-permission.md` (44203 chars)
- **Part III: Land Uses and Manner of Development** -> `part-iii-land-uses-and-manner-of-development.md` (119260 chars)
- **Part IV: Requirement of Site and Layout** -> `part-iv-requirement-of-site-and-layout.md` (38249 chars)
- **Part V: Floor Space Index** -> `part-v-floor-space-index.md` (82857 chars)
- **Part VI: Additional Floor Space Index** -> `part-vi-additional-floor-space-index.md` (341754 chars)
- **Part VII: Land Use Classification and Uses Permitted** -> `part-vii-land-use-classification-and-uses-permitted.md` (123678 chars)
- **Part VIII: General Building Requirements** -> `part-viii-general-building-requirements.md` (121197 chars)
- **Part IX: Urban Safety Requirements** -> `part-ix-urban-safety-requirements.md` (24167 chars)
- **Part X: Special Provisions** -> `part-x-special-provisions.md` (30893 chars)
- **Part XI: Miscellaneous Provisions** -> `part-xi-miscellaneous-provisions.md` (14097 chars)
- **Part XII: Environmental Sustainability** -> `part-xii-environmental-sustainability.md` (143833 chars)