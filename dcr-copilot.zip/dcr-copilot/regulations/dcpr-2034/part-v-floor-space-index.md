# Part V: Floor Space Index

PART V - FLOOR SPACE INDEX
30. Floor Space Indices & Floor space / Built-Up Area (BUA) computation,
Tenement Density and Protected Development
(A) Floor Space Indices & Floor space /BUA computation
1 The total area of a plot shall be reckoned in FSI/BUA calculations applicable
only to new development to be undertaken hereafter as under: -
TABLE 12
Floor Space Indices in Residential, Commercial and Industrial Zones
Sr Areas Zone Road width Zonal Addition Admi Permis
No (Basic) al FSI on ssible sible
payment TDR FSI
of (4+5+
Premium 6)
1 2 3 3 4 5 6 7
1 2
I Island City Reside up to 9m 1.33 - - 1.33
ntial/C More than 1.33 0.34 0.33 2.0
ommer 9m up to 0.5 0.17
cial 12.20m
More than 1.33 0.62 0.45 2.4
12.20 m up
to 18.3m
More than 1.33 0.73 0.64 2.7
18.3 m up
to 30m
more than 1.33 0.84 0.83 3.0
30m
II Suburbs and Extended Suburbs
i The area earmarked for Reside 0.75 - - 0.75
BARC from M Ward and the ntial/C
areas comprised in N Ward ommer
bounded on the west by the cial
Eastern Express Highway, on
the north by the northern
boundary of the N ward, on
the east by the Thane creek
and on the south by the
southern boundary of N
Sr Areas Zone Road width Zonal Addition Admi Permis
No (Basic) al FSI on ssible sible
payment TDR FSI
of (4+5+
Premium 6)
ward.
ii Areas of the village of Akse, Reside 0.5 - - 0.50
Marve and CRZ affected ntial/C
areas of Erangal in P/North ommer
Ward and Gorai and cial
Manoriin the R Ward
excepting gaothan proper.
iii Reside up to 9m 1.0 - - 1.0
The remaining area in ntial/C More than 1.0 0.5 0.5 2.0
Suburbs and Extended ommer 9m up to
Suburbs cial 12.20m
More than 1.0 0.5 0.7 2.2
12.20 m up
to 18.3m
More than 1.0 0.5 0.9 2.4
18.3 m up
to 30m
more than 1.0 0.5 1.0 2.5
30m
III Island City Indust 1.0 0.5 0.5 1.0
rial - - 2.0*
IV Suburbs and Extended Indust 1.0 0.5 0.5 1.0
Suburbs rial - - 2.0*
*Utilization of TDR in I Zone for the uses permissible only in I Zone except for the
hazardous activities, as per Table No C, of Regulation No 34.3 will be allowed.
Condition:- TDR & paid Ratio can be change from time to time keeping the total Cap as it is.
(EP-55)
2 The permissible FSI shall be on gross plot area including excluding area under DP
roads/roads for which sanctioned Regular line as per MMC Act is prescribed, and DP
Reservation, and where also excluding the land is to be surrendered to
MCGM/Appropriate Authority under Regulation no 14 (amenity plots), 15 (inclusive
housing), 16, and 17.
(EP-56)
3 In case of Sr. No. 2 above;
a) Additional BUA as per regulation 32(1) Table 12(A) equal to area of land so surrendered
to MCGM/Appropriate Authority shall be allowed to be consumed over and above the
permissible BUA (as per column no 7 of Table no 12 above) on the remainder/balance
plot or may be availed in the form of TDR as per these Regulations.
b) It shall be permissible to utilize BUA equal to area of land so surrendered to
MCGM/Appropriate Authority even before availing the additional FSI on payment of
premium/TDR.
c) BUA in lieu of cost of construction of built up amenity to be handed over as per the
provisions of Regulation number 17(1) note 1(d) shall be permissible over and above
permissible BUA or owner may avail the TDR thereof if not consumed on the remainder
land.
d) If owner/developer is unable to consume even Zonal (basic) FSI due to planning
constraints, he shall be entitled for TDR for the unconsumed BUA thereof including a &
c above.
In such cases, no additional FSI on payment of premium/TDR shall be allowed to be
utilized on remainder /balance plot.
(EP-57)
4 The permissible FSI shall be on gross plot area including areas to be surrendered to
MCGM/Appropriate Authority under Regulation no 14 (amenity plots), 15 (inclusive
housing) and 35 (development of cotton textile mills).
Provided further that BUA in lieu of cost of construction of built up amenity required to
be handed over to MCGM under Regulation Nos 15, if any, shall be permissible over
and above permissible BUA (as per column no 7 of Table No 12 above) or owner may
avail the TDR thereof, if not consumed on the balance plot.
(EP-58)
5. BUA so arrived shall be allowed to be consumed on the balance plot after handing over
of Reservation/Amenity/Plot/DP road/roads for which sanctioned Regular line is
prescribed as per MMC Act to MCGM.
6. Premium shall be charged for ‘additional FSI on payment of premium’ (as per column
no 5 of table no 12) for BUA at the rate of 60% of the land rates as per ASR (for FSI 1) of
the year in which such FSI is granted. Premium so recovered shall be shared between
the State Govt. and MCGM on 50:50 basis. The MCGM shall utilize the premium for
implementation of D P.
Provided further that utilization of ‘additional FSI on payment of Premium’ and TDR is
optional and can be utilized in any combination subject to limit prescribed in column
no 7 of Table No 12 above & shall be non-transferable. ‘Additional FSI on payment of
Premium’ is to be granted on application and payment of premium & shall be used on
the same plot only.
Provided further that of the admissible TDR as per column 6 of the Table 12 of this
regulation, utilization of minimum 20% of admissible TDR generated from slum
redevelopment scheme, shall be compulsory, but shall not exceed 50% of the
admissible TDR as per column 6.
(EP-59)
7. A Development Surcharge cess up to at the rate of 100% of Development charge, for
BUA over and above the Zonal (basic) FSI (including excluding fungible compensatory
area BUA) in accordance with the Time Schedule for such payment as may be laid down
by the Commissioner, MCGM shall be paid. This Surcharge development cess shall not
be applicable to BUA to be handed over to MCGM/Appropriate authority & BUA which
are excluded from FSI computation. This Development Surcharge cess shall be in
addition to development charges levied as per section 124 of MR&TP Act 1966. This
Surcharge development cess shall not be applicable for proposals of Govt. /MCGM
executed departmentally.
The payment of Development Surcharge cess as detailed above will not be payable in
cases where development cess is proposed under Regulation no 33(3), 33(5), 33(7),
33(7)(A),33(8), 33(9), 33(9)(B),33(10), 33(11) and for development where the payment
of off-site infrastructure charges/development cess is applicable and for these
Regulations development cess/off-site infrastructure charges shall be payable as
described in the concerned Regulations.
8 The owner shall give advance possession of the land to be handed over to
MCGM/MHADA/Appropriate Authority, wherever applicable, at the time of seeking
permission for development of plot. It shall be the responsibility of the land owner to
clear off all encumbrances and complete the formalities towards transferring the land
in the name of MCGM/MHADA/Appropriate Authority in Land Revenue Record.
9 The aforesaid plot, free of encumbrances, shall be handed over to
MCGM/MHADA/Appropriate Authority within twelve months from the date of
approval of building plans/approval of the layout. The FSI of such plot can be utilized
on remainder plot only after handing over of such plot to MCGM or before availing
Zonal (basic) FSI beyond 50% 75% of gross plot area or granting Occupation Certificate
to any of the buildings, whichever is earlier. The ownership of such plot shall be
transferred in the name of MCGM/ MHADA/Appropriate Authority in Land Revenue
Records before seeking occupation to last 25% of admissible FSI in any of the buildings
in the layout other than amenity.
10 The area of built up amenity shall be counted in FSI initially and after handing over of
said built up amenity, the area of built up amenity shall be allowed free of FSI.
Commencement Certificate in respect of BUA in lieu of the built-up amenity to be
handed over to MCGM under AR can be granted only after handing over of such built
up amenity or before availing Zonal (basic) FSI beyond 75% of gross plot area or before
seeking Occupation Certificate to any part of building/buildings beyond 50% of
permissible BUA as per Zonal (basic) FSI, other than the built up amenity.
11 Fungible FSI Compensatory Area/BUA shall be permissible over and above permissible
FSI as per column no 7 of Table No.12 above and as per the provisions of Regulation no
31(3).
(EP-60)
12 The Development of plots under combination of various regulations shall be
permissible, but the maximum permissible FSI on gross plot shall not exceed the
permissible FSI limit prescribed in respective any of the applicable regulations.
13 TDR in lieu of balance BUA after loading of “additional FSI on payment of premium &
Admissible TDR’’ as per table 12 above shall not be permissible.
14 In case of development as per this regulation and/or under the provisions of 33(2),
33(3), 33(3) (A), 33(3) (B), 33(8) (B), 33(11), 33(20) (A) the premium shall be applicable
all the Central Govt. and their statutory bodies/Central Govt. undertaking/State Govt.
undertaking etc. except State Govt. and MCGM itself.
(EP-61)
Note: (1) Area of recreational open spaces as required under Regulation No 27 shall
not be deducted for the computation of BUA/FSI.
(2) In case of new Development/Redevelopment proposal under this Regulation,
where the plot is affected by Road line/DP Road/Reservation and where the
land affected by Road line/DP Road/Reservation is either merged or handed
over to MCGM/Appropriate Authority & where FSI benefit of the same had
already been taken in the earlier development proposal as per then prevailing
Regulation or monetary compensation had been claimed in the past, but
ownership has not been transferred in the name of MCGM/Appropriate
Authority, in such cases the gross plot area shall be reckoned after deduction of
such areas.
(3) The Occupation Certificate for buildings constructed out of last 25% of
admissible FSI for residential/commercial use shall be granted by the
Commissioner only after recreational area is developed and structure for
recreational activities are actually provided on site. Provided further that in case
of layout having 2 or more buildings, development of proportionate recreational
area may be permitted subject to completion of entire recreational area &
structure thereon for recreational activities prior to seeking occupation of last
buildings.
(4) In case of Government/Semi-Government Department and
Organizations/Public Sector Authorities/Undertakings such as the Atomic Energy
Department, the Civil Aviation Department, International Airport Authority of
India, Defence authorities, Railway authorities and the Mumbai Port Trust, for
computing the available FSI, the area of lands not designated/reserved but
shown as such in the DP for the following purpose shall be excluded:
(a) Playgrounds, stadia, golf courses;
(b) Parade grounds, training grounds, firing ranges;
(c) Green areas within their complexes;
(d) Lands kept open for operational purposes;
(e) Lands under major internal roads;
(f) Railway tracks and yards;
(g) Lands unauthorizedly reclaimed;
(h) Lands of air-fields and air-strips.
(B) Tenement Density
1. Maximum tenement density shall be 450 per ha for FSI 1.00 and shall be appropriately
increased/reduced proportionate to FSI 1.00.
2. Minimum tenement density shall be 200 per ha for FSI 1.00 and shall be appropriately
increased/reduced proportionate to FSI 1.00, applicable only to plots of 1 ha and above
and sub-divided plots each of 1 ha and above from larger layouts or sub-divisions.
3. Minimum tenement density for Rehabilitation and Resettlement/ affordable housing
plots/shall be 325 per ha for FSI 1.00 and shall be appropriately increased/reduced
proportionate to FSI 1.00.
(EP-62)
(C) Protected Development
(a) The FSI permitted as per Table No. 12 will be allowed to be exceeded for
redevelopment of existing authorized building to the extent of existing authorized
development rights/BUA and shall be also entitled for the additional FSI as per
relevant regulations.
(EP-63)
Provided further that in cases where benefit of additional FSI as per the then
prevailing regulations was availed for the purpose of educational, medical, starred
category hotels, religious development and Information Technology
establishments and if redevelopment is proposed by discontinuing such users,
then such additional BUA will not be protected. The development shall have to be
in consonance with the provisions of these Regulations. The premium paid in past
for such user will not be adjusted.
(b) In cases where development is not completed, it shall be permissible to avail the
balance development rights as permissible under these Regulations by utilizing the
TDR or additional FSI on payment of Premium by adjusting the payments made
earlier for availing FSI if any, or payments made for grants of any concessions,
condonations etc. but no refund shall be permissible.
However, such additional utilization of the development right in the plot/layout,
shall be permissible on the plot area beyond the land component of the buildings
for which occupation is granted/existing building as specified in Regulation No 9 as
per the then prevailing Regulation under which the development was approved.
Provided that if the development is proposed to the extent of protected built-up area
only as per a) and b) above, 9 m. road width shall consider adequate. However, if
development is proposed with more area than protected as per regulation then, the
restrictions as per regulation 19(2) shall be applicable.
(EP-64)
31. Exempted from FSI /to be counted in FSI / Fungible Compensatory Area
(Fungible) Floor Space Index (FSI):
(1) Exemption from FSI
The following shall not be counted in FSI
(i) Areas of structures permitted in ROSLOS under clause (g) of sub-Regulation (1) of
Regulation No 27.
(ii) Areas covered by features permitted in open spaces as listed in Regulation No.42
except for Regulation 42(i) (b), 42(ii)(d),42(ii) (e) (ii)&(iii), and 42(ii) (f) (ii)&(iii) and
42(ii)(g).
(iii) Areas covered by staircase rooms, lift machine rooms above topmost storey,
staircase/lift wells and passages in stilt, basement and floors exclusively used for
parking and other ancillary uses as permitted in this Regulation No.31(1)
(iv) Areas covered by staircases/lift wells including lobbies as specified, excluding those
covered under DC Regulation No.31 (1) (iii) with special written permission of the
Commissioner subject to payment of premium.
Such exclusion from FSI computation shall not be applicable in case of existing buildings.
Provided further that where the permissible FSI has not been exhausted in the case of
existing buildings and cases decided by the Corporation prior to coming into force of
these Regulations, the exclusion from FSI computation as in these Regulations will be
available for construction of balance potential,
Provided further that for the reconstruction scheme under Regulation No. 33(6) such
exclusion will be permissible as per guidelines hereunder: -
i. While working out total existing BUA, the BUA of existing staircase will not be taken
into account.
ii. Premium for the area of the staircase and lift-well will be recovered after working
out the area of the staircase and lift-well in the proposed building minus area of the
existing staircase, lift-well etc., if any
(v) Area of the basement used exclusively for parking and other ancillary uses as
permitted in Regulation No. 37(97) (iv) (b, c, d, e & j).
(vi) Area of covered parking spaces as provided in sub-Regulation (6) (a) of
Regulation No. 44
Provided, however, that additional parking to the extent of 25% 50% of the
required parking may be permitted without payment of premium.
Provided further that in non-residential building, where entire parking is
proposed by mechanical/ automatic means, additional parking to the extent of
10% 20% of the required parking shall be permitted free of FSI as vehicle holding
area.
(EP-65)
(vii) Area of one office room as provided in sub-Regulation (119) of Regulation 37
(viii) Lofts [vide sub-Regulation 4 of Regulation 37]
(ix) Porches [vide sub-Regulation (20 18) of Regulation 37].
(x) Canopy [vide sub-Regulation (2119) of Regulation 37].
(xi) Area of structures for an effluent treatment plant, Water Treatment Plant,
Sewerage Treatment Plant as required to be provided, as per the
requirements of the MPCB or other relevant authorities:
Provided, however, in the case of an existing industry, if no vacant land is
available the Commissioner may permit structures with dimensions to be
approved by him for such effluent treatment plant on 15 per cent amenity open
space.
(xii) A chajja, cornice, weather shade, sun-breaker, vertical fins (excluding column);
at lintel level, only; projecting not more than 1.2 m. from the face of the building
as provided in sub regulation no. 42 (ii) (e)(i).
Further chajja, Cornice, Weather Shade, sun breaker or other ornamental
projections etc. shall be permissible up to 0.3 m. in Gaothan area for the plots
admeasuring up to 250 sq. m
(xiii) A chajja, cornice, weather shade, sun-breaker over a balcony or gallery, as
provided in sub regulation no. 42(ii)(f)(i)
(xiv) Area covered by elevated/underground water reservoirs/tanks, electric
sub-stations, Distribution Sub Station, pump houses, facility for treatment
of wet waste in situ.
(xv) Area covered by new lift and passage thereto in an existing building with a
height up to 16m. in the Island City [vide clause (ii) (f) of sub-Regulation (1917)
of Regulations 37]
(xvi) Area of a covered passage of clear width not more than 1.52m (5ft.) leading
from a lift exit at terrace level to the existing staircase so as to enable descent to
lower floor in a building to reach tenements not having direct access to a new
lift in a building without an existing lift.
(xvii) Area of one fitness centre /Yogalaya for a Co-Op. Housing Society or Apartment
Owners Association as provided in sub-regulation 37(3028).
(xviii) The fire chutes as provided under DC Regulation No. 48(9)
(xix) The refuge areas subject to DC Regulation No. 48(8)
(xx) Service Floor of height not exceeding 1.8 m or as stated in Regulation No.
37(3432).
(xxi) Entrance lobbies in stilted portion, height not exceeding 7.2 m. or height
equivalent to two floor or height of stilt whichever is more.
(xxii) Open to sky swimming pool at the terrace above the top most storey or on the
top most podium only.
(xxiii) Area of the service ducts abutting Sanitary Block, kitchen not exceeding 1.2 m. in
width depth. In case of high rise buildings higher width/size as per requirement
and design approved by Commissioner but not exceeding 2.0 m.
(xxiv) Ornamental projection of cladding/glass façade/glazing not exceeding 0.30 0.60
m from building line for non-residential building.
(xxv) Area covered by chimney, elevated tanks (provided its height below the tank
from the floor does not exceed 1.5 m)
(xxvi) Area of sanitary block for use of domestic servants engaged in the premises, not
exceeding 2.2 sq. m at staircase mid-landing level and at stilt level, area of
sanitary block for use of drivers engaged by the car owners not exceeding 2.2 sq.
m at each of the parking floor level. In case number of car parks exceeds 200 per
parking floor level, additional sanitary block for every 200 cars or part there of
shall be allowed.
(EP-66)
(xxvii) Letter boxes as specified in Regulation No 37(1210) (b)
(xxviii) Parking floors as specified in Regulation No 37(3230)
(xxix) Area of DG set at stilt and podium level as specified in Regulation No 37(3331)
(xxx) Area of DG set, electric sub-station with protective walls having voids/perforated
walls above 1 m height, at stilt and podium level or in side and rear marginal open
space, or in a separate independent structure specified in Regulation No 37(3331)
(EP-67)
(xxxi) Electrical Duct/ fire duct of clear width not more than 0.45 m and not abutting to
any habitable room.
(xxxii) Area of electric meter/service utility room/rooms having area of 10 sq. m per 50
tenements at Basement /Ground/Stilt/Podium. In case of High Rise building the
meter room may be allowed as per the specific requirements of Electric Supply
Company.
(xxxiii) Refuse Chute/Garbage Shaft as specified in Regulation No.37(1412)
(xxxiv) Elevation feature or dome like structure above water tank/lift machine
room/staircase room up to 2 m for building with height beyond 32 m & up to 70
m, 6 m for the building height beyond 70 m and up to 120 m and up to 9 m for
building with height beyond 120 m with 60% voids in surface area/profile may
be allowed.
(xxxv) Area required for Rain Water Harvesting Arrangement, Non-conventional Energy
System as per these Regulations.
(xxxvi) Advertisements and sky signs, covered areas required on topmost terrace for
antenna/dish antenna/communication tower used for Telecom not exceeding
20 sq. m.
(xxxvii) Area required for Cooling Towers/Chilling Plants (open to sky) only beyond the
required marginal open spaces or on terrace floor.
(xxxxviii) Area for Laundry, Boiler Room for Hotels, Hospitals & Hostels as specified in
Regulation No.37(7).
(xxxix) Room with maximum size 5 sq. m, for Battery back-up for solar water heater
and/or for common lighting in basement or on terrace.
(xxxx) Entry gate over Arch.
Note:
i. Areas covered by the projections exceeding those specified in clauses xii, xiii,
xxiii, xxiv and xxxiii above shall be counted in FSI.
ii. Open to sky swimming pool at any level other than (xxii) above, excluding at
ground level as provided in Regulation No 42 (ii)(a), shall be counted in FSI.
iii. Any passage by whatever name not covered under DCR 31(1) shall be counted in
FSI.
(2) The following shall be counted in FSI.
(i) Covered parking spaces/Garage as provided under Regulation No. 44 (6)(d)
(ii) Area of fire escape balcony as provided in Regulation No 48(6)
(iii) Area of Sanitary block for the use of domestic servants engaged in the premises,
other than as provided as per Regulation No 31(1) ((XXVI) at staircase mid-
landing level, stilt level, parking level.
(iv) Part/Pocket/Covered terraces, for whatever purpose, except open terrace above
the top most storey and the part terrace at top most storey due to planning
constraints but accessible from common staircase, terraces created due to
restriction imposed by the Railway Authority and above shopping/Non-
residential/Industrial area at one level only with a slope of 1:5, in case of
residential/Non-residential/Industrial development on upper floors.
(v) Area below open to sky swimming pool, clearance exceeding 1.5 m. from floor
level.
(vi) Air conditioning plant room/Air handling unit room, D.G. set room except
provided in basement.
(vii) Service floor of height exceeding 1.8 m as per Regulation No.37(32).
(viii) Area of balconies as provided in sub regulation 22 20 of Regulation No 37.
(ix) Niches below window sill.
(x) Area of one public telephone booth and one telephone exchange (PBX) room
per building.
(xi) The ornamental projection, including the voids, flower beds, etc. projecting from
the face of the building except at the terrace level other than allowed as per
Regulation No 31(1) (ii).
(xii) Ornamental projection, flower bed etc. over a balcony or gallery other than
allowed as per Regulation No 31(1) (ii).
(xiii) Area of one room for installation of telephone concentrators as per
requirements of Mahanagar Telephone Nigam limited.
(xiv) Letter box room as specified in Regulation No 37(12 10) (a).
(xv) Covered areas required on top terrace for antenna/dish
antenna/communication tower used for Telecom (basic cellular or satellite
telephone) or ITE purposes, V-Sat, Routes, Transponders or similar IT related
structure or equipment, in excess of 20.00 sq. m.
(xvi) The parking floor in excess of required parking under these regulation [31(1)(vi)]
and for which the premium has been paid. Deck parking inclusive of car lifts and
passages thereto on habitable floors.
(xvii) Driver’s room/sanitary block on podium and or parking floor other than
mentioned in Regulation No.31(1)(xxvi).
(xviii) Covered swimming pool.
(xix) Area of DG set room at stilt and podium level other than mentioned in
Regulation No 31(1)(xxx)
3. Fungible Compensatory (Fungible) Floor Space Index (FSI) Area: -
Notwithstanding anything contained in the D. C. Regulations 30, 32 & 33, the
Commissioner may, by special permission, permit fungible compensatory FSI area, not
exceeding 35% for residential/ development, and 20% for Industrial/Commercial
development, over and above admissible FSI/BUA, by charging a premium at the rate of
60% for Residential and 80% for Industrial and Commercial development of ASR (for
FSI 1), which is to be shared between MCGM, State Govt. and MSRDC (for Sea Link) in
50%, 30% and 20% respectively.
Provided further that in case of entirely commercial building, mall/multiplex, additional
fungible BUA maximum to the extent of 10% of BUA, only for more width of
corridors/passages than required under these Regulations may be allowed by charging
a premium at the rate of 80% of ASR (for FSI 1).
Provided that in case of redevelopment under regulation
33(5),33(6),33(7),33(7)(A),33(7)(B),33(8),33(9), 33(9)(B),33(20), and 33(10) excluding
clause No.3.11 of the Regulation the fungible compensatory FSI area admissible on
rehabilitation component shall be granted without charging premium.
In case of redevelopment under regulation 33(5), 33(6) & 33(7)(B) of the Regulation
the fungible compensatory FSI area admissible on existing BUA shall be granted
without charging premium.
Provided further that redevelopment under Regulation No. 33(5) and for
redevelopment proposal of existing buildings in suburbs and extended suburbs by
availing TDR/Additional FSI on payment of Premium, the fungible compensatory FSI
area admissible on FSI consumed in existing structure shall be granted without charging
premium.
Provided further that such fungible compensatory FSI area for rehabilitation
component shall not be used for free sale component and shall be used to give
additional area over and above eligible area to the existing tenants/occupants. Fungible
compensatory area admissible to one rehabilitation tenement cannot be utilized for
another rehabilitation tenement.
Provided that, this Regulation shall be applicable only in respect of the buildings to be
constructed or reconstructed.
Provided also that in case of development under Regulation No. 33(15), the fungible
compensatory FSI area shall be admissible without charging premium.
“Provided that in case of development under Regulation No. 33(2) excluding buildings
of private medical institutions under Regulation No. 33(2)(A), the fungible
compensatory FSI area shall be admissible on 50 % rebate in premium to be charged as
per this regulation and the development under Regulation No 33(3) shall be admissible
without charging premium for fungible compensatory area FSI.
(EP-68)
Explanatory Note: -
(i) Where IOD/IOA has been granted but the building is not complete then this
Regulation shall apply, only at the option of the owner/developer,
(ii) For plots/layouts, where IOD is granted for partial development, this Regulation will
apply for the balance potential of the plot,
(iii)The fungible compensatory area FSI is useable as regular FSI,
Note:
(a)The premium paid for fungible compensatory area BUA prior to coming into force of
this Regulation particularly in case of Commercial/Industrial development will not be
adjusted ; for grant of additional fungible compensatory area BUA under this regulation,
and premium if any, premium as per this Regulation shall have to be paid. Fungible
Compensatory F.S.I. granted under Regulation 35(4) of DCR 1991 shall be continued as
Fungible Compensatory Area under Regulation 31(3) of DCPR 2034 & no premium shall
be demanded or refunded or adjusted.
(b)The premium amount collected shall be kept in a separate Account to be utilized for
infrastructure development.
(c) The deficiency in open space created due to utilization of fungible compensatory
area shall be condoned by charging premium at 25% of normal premium.
(EP-69)
32 Transfer of Development Rights (TDR)
In certain circumstances the development potential of a plot of land may be separated
from the land itself and may be made available to the owner of the land in the form of
Transferable Development Rights (TDR). These Rights may be made available and be
subject to the Regulations as detailed below.
TDRs as per provision of this regulation shall be applicable only to prospective
development: -
1. TDR in lieu of handing over of areas affecting reservations including DP road:
The land reserved for public purposes in the DP can be compulsorily acquired, according to
the provisions of Section 125, and clauses (a) and (c) of Sub-section (1) of Section 126 of
the MR&TP Act.
Alternatively, owner of the land reserved for public purposes can be granted “Transferable
Development Rights” (TDR) in lieu of the monetary compensation as provided under Sub
Clause (b) of Sub-section (1) of Section 126 of the MR&TP Act. The grant of Development
Right will be governed by the following:
Owner of the land reserved for any public purpose desirous of availing the TDR may apply
to the Commissioner in prescribed form, expressing his willingness to surrender the land so
reserved, free of cost and free of all encumbrances to MCGM or as described below. The
cases in which TDR will be offered are further defined below.
Provided also that Additional/incentive Transferable Development Rights (TDR) to the
extent of 20 %, 15%, 10% and 5% of the surrendered land area shall also be allowed to the
land owners who submit the proposal for grant of Transferable Development Rights (TDR)
within 1, 2 ,3 and 5 years respectively from sanction of this Regulation.
Table No 12(A)
Instances in which TDR can be availed.
Sr Instances Extent of TDR Remarks/conditions
No
1 a) If entire plot of land reserved BUA as per the Zonal a) Where land is not
for public purpose in the DP and (basic) FSI of land so handed over yet and
land is surrendered to transferred surrendered transferred + FSI benefit is not
in the name of BUA equal to plot area of approved in the
MCGM/Appropriate Authority. land so surrendered development proposal
transferred on remainder plot & no
TDR/monitory
compensation is
availed.
b) award is not
declared under Section
11 23 of Right to Fair
Compensation and
Transparency in Land
Acquisition
Rehabilitation and
Resettlement L.A. Act
2013 or any
compensation has not
been paid
b) Plot of land of IH as per BUA as per the Zonal Only where land is not
Regulation No. 15/AOS as per (basic) FSI of land so handed over and FSI
Regulation No. 14/ Development surrendered transferred. benefit is not approved
of lands of cotton textile mill in the development
under the provision of Regulation proposal and not
No. 35 in lieu of land to be proposed to be utilized
surrendered transferred to in the on remainder plot nor
name of MCGM/MHADA/ TDR is availed, then
Appropriate Authority TDR of unutilized BUA.
c) DP Roads/RL under MMC BUA as per the Zonal Only if FSI benefit is
Act/land under River widening, (basic) FSI of land so not approved in the
major Nalla widening surrendered surrendered transferred + development proposal/
transferred to in the name of BUA equal to plot area of availed and not
MCGM land so surrendered proposed to be utilized
transferred on remainder plot nor
TDR is availed
d) Setback due to Subsequent BUA as per the Zonal
Road widening/Proposed DP (basic) FSI of land so
Road/Right of way to land locked surrendered transferred.
Sr Instances Extent of TDR Remarks/conditions
No
plot as per Regulation No.22, in In case of SDZ-II, BUA
case where development of equal to Zonal (basic)
plot/layout is completed in all FSI prevailing in
respect/where no development is adjoining zone of land
proposed/is in progress at the so surrendered.
time of handing over of such area
to MCGM.
2 If owner/developer develops the If no BUA is availed in the Due to planning
reservation under provisions of AR form of FSI or such constraints.
and is unable to consume even unutilized BUA on the
Zonal (basic) FSI, BUA equal to plot balance plot.
area of land so surrendered
transferred to in the name of
MCGM/Appropriate Authority and
BUA in lieu of cost of construction
of built up amenity to be handed
over to MCGM/Appropriate
Authority.
3 BUA in lieu of cost of construction If no BUA is availed in the Due to planning
of BUA built up amenity to be form of FSI or such constraints.
handed over to unutilized BUA on the
MCGM/Appropriate Authority as balance plot.
per the Regulation No. 14,15 &17
4 In case of redevelopment of As prescribed under the
Cessed buildings 33(7), 33(7)(B), relevant provision of DCPR
33(8), Urban renewal schemes
Cluster Development Scheme 33(9)
and slum redevelopment scheme
33(10), Permanent transit
tenements in the form of
permanent structures for Slum
Rehabilitation Scheme/Rental
housing under Regulation
No.33(11),
5 BUA of Affordable Housing/Rental As prescribed under the
Housing constructed on under the provision of
unreserved private land and corresponding regulation
handing over of entire plot along
with constructed tenements to
Sr Instances Extent of TDR Remarks/conditions
No
MCGM free of cost as per the
Regulation No. 33(20).
6 Heritage buildings {BUA as per Zonal (basic) Where the
FSI+ area of plot on which Development of
Heritage Structure is building is not
existing} – BUA consumed permissible as per
by Heritage building provision of Regulation
No 52 and with the
permission of
Municipal
Commissioner in
consultation with & on
recommendation of
MHCC
The potential of the
plot shall be
perpetually reduced to
the extent of Existing
BUA of the Structure.
7 Encumbered plots which are Project Implementing
required for implementation of authority shall
public project on very urgent basis separately certify the
To the extent of 50%of area of land which was
a. In case of land which are fully
BUA as per Zonal (basic) vacant and the area of
encumbered and where
FSI of the plot area. land under
encumbrances had/have to be
encumbrance along
removed and rehabilitated
with details as per the
elsewhere by the project
joint measurement
implementing authority,
(i)For the portion of land survey carried out in
b. which are partly encumbered
which is/was vacant as this respect with the
and where encumbrance
per serial no 1(a) of this City Survey Officer. The
are/were removed and
table area of vacant land and
rehabilitated elsewhere by the
land under
Project Implementing authority, (ii) For the portion of land
encumbrance shall be
which is/was encumbered
clearly distinguished
to the extent of 50% of
and demarcated,
BUA as per Zonal (basic)
otherwise the land
FSI of the vacant plot area.
under part
encumbrance shall be
treated as fully
Sr Instances Extent of TDR Remarks/conditions
No
encumbered land.
The owner has to
follow the procedure
laid down by the
MCGM for availing the
DRC.
8 Unreserved accessible plot not BUA as per the Zonal If owner willingly offers
falling in N SDZ/NA (basic) FSI of land so the land and the
surrendered transferred Municipal
+ BUA equal to plot area Commissioner, MCGM
of land so surrendered requires the land for
transferred public purpose such as
POS/SWM facility/
Municipal Chowky/ PSC
blocks.
9 Reserved Land of for D. P. BUA equal to 0.8 times of
Road/public purpose in N SDZ-II land area so surrendered
area accessible from existing Road. BUA as per the Zonal
(basic) FSI prevailing in
the adjoining Zone of land
so transferred + BUA
equal to plot area of land
so transferred
10 Roads/uninterrupted access to BUA equal to area of land
SH/POS/OA to be handed over to so surrendered/
MCGM in proposed development transferred
under Regulation No 33(8)
NOTE: - Even if plot is affected by River widening, major Nalla widening and ownership of
portion of plot affected by River widening, major Nalla widening has been transferred in
the name of MCGM, the plot on which development has been proposed shall not be
treated as sub divided plot under these Regulations.
2. Utilization of TDR
Development Right Certificates (DRCs) can be used in entirety or in parts at any location,
except mentioned in Sr No 3. (A) (8) below, in any land use zone within the limits of FSI
prescribed in Table No. 12 above. The TDR at the receiving plots shall be governed by the
following
TDRr = TDRo x (RRLo/RRLr)
Where:
TDRr = Transferable Development Rights on the receiving plot.
TDRo= Transferable Development Rights on the originating plot
RRLo =Land rates of Annual Statement of Rates (ASR) of the originating plot
RRLr =Land rates of Annual Statement of Rates (ASR) of the receiving plot
Note: Land rates of ASR of both RRLo & RRLr shall be of the relevant year in which scrutiny
fees for utilization of TDR is paid. In case there are more than one land rate applicable to
different parts of the plot under development, a weighted average of all the applicable
rates shall be taken for calculation.
Transferable Development Rights (TDRr) and the corresponding Transferable Development
Rights (TDRo) shall be clearly indicated on the Development Rights Certificate that are
used.
Note: 1. Utilisation of TDR generated as per Table No 12(A) or as provided under these
Regulations shall be dealt at par.
2. Utilization of DRC/DRC’s issued prior to coming into force of these Regulations shall be
dealt with as per the then prevailing Regulations/policy only.
3. (A) Regulations for the grant of Transferable Development Rights (TDRs) to owners/
developers and conditions for grant of such Rights:
1. The owner (or lessee on submission of NOC from lessor) of a plot of land which is
reserved for a public purpose in the DP and for additional amenities deemed to be
reservations provided in accordance with these Regulations, excepting in the case of an
existing or retention user or any required compulsory or ROSLOS, shall be eligible for
the award of TDR in the form of FSI to the extent as described in the table no 12(A)
above and on the conditions set out below. Such award will entitle the owner of the
land FSI in the form of DRC which he may use himself or transfer to any other person.
2. Subject to the Regulation 1 above, where a plot of land is reserved for any purpose
specified in section 22 of MR & TP Act, 1966, the owner will be eligible for
Development Rights (DR's) to the extent stipulated as described in the table no 12,
after the said land is surrendered free of cost as stipulated in this Regulation and after
completion of the development or construction as in Regulation if he undertakes the
same
3. DRs will be granted to an owner or a lessee only for reserved lands which are
retainable/non-retainable under the Urban Land (Ceiling and Regulations) Act, 1976,
and in respect of all other reserved lands to which the provisions of the aforesaid Act
do not apply, and on production of a certificate to this effect from the Competent
Authority under that Act before a DR is granted. In the case of non-retainable lands,
the grant of DRs shall be to such extent and subject to such conditions as Govt may
specify. DRs are available only in cases where development of a reservation has not
been implemented i.e. TDRs will be available only for prospective development of
reservations.
4. DRCs will be issued by the Commissioner himself. They will state, in figures and in
words, the FSI credit of BUA in square meters of the BUA to which the owner or lessee
of the said reserved plot is entitled, the place and village/TP Scheme/Division, CS
No/CTS No/FP No from where it is generated, year of issue of DRC and Ward in which
the DRs are earned.
5. A DRC will be issued only on the satisfactory compliance with the conditions prescribed
in this Regulation.
6. If a holder of a DRC intends to transfer it to any other person, he will submit the DRC to
the Commissioner with an appropriate application along with registered agreement
with new holder for an endorsement of the new holder's name, i.e. transferee on the
said Certificate. Without such an endorsement by the Commissioner himself, the
transfer shall not be valid and the Certificate will be available for use only by the earlier
original holder.
7. A holder of a DRC who desires to use the FSI credit certified therein on a particular plot
of land shall attach to his application for development permission valid DRCs to the
extent required
8. A DRC shall not be valid for use on receivable plots in the areas listed below:
a. Coastal areas and areas in NDZ SDZ, TDAs, Green Zone and areas where SPA appointed
as notified under section 40 of MR&TP Act 1966 viz MMRDA, MIDC or MHADA.
b. On plots for housing schemes of slum dwellers/cessed buildings for which additional
FSI is permissible under sub-regulation (7) (9), (10) of Regulation 33. However, in cases
where non-slum plot/non-cessed plot where eligible structures as stipulated in the
relevant provisions are not existing and is amalgamated with the slum plot/cessed plot
with the approval of CEO SRA/Commissioner on receipt of NOC from MHADA
authorities, for the purpose of better planning etc. then DRC will be receivable on the
non-slum plot/non-cessed plot. In such cases utilization of DRC shall be governed as
per procedure and provisions stipulated in this regulation.
c. In proposal where additional FSI is proposed to be utilized as per special FSI provisions
of these Regulations unless otherwise specified therein.
d. Areas where the permissible FSI is less than 1.0.
e. In Industrial Zone, wherein only hazardous industrial activity has been proposed.
However, on conversion of Industrial Zone to Residential/Commercial Zone as per
provision of these regulations, then utilization of TDR as provided in this regulation
shall be permissible.
f. Heritage buildings and precincts notified under Regulation No. 52. However, in any
Heritage Precinct with the prior approval of the MHCC and subject to compliance with
the regulations of the particular precincts may be allowed.
9. DRCs may be used on one or more vacant plots of land or in case of already developed
plot of land, on the balance/remainder plot of land after deduction of the land
component of existing development, as per then prevailing regulations under which
development was allowed as specified in Regulation No. 9. The development shall be in
conformity with these Regulations.
10. DRs will be granted and DRCs issued only after the reserved land is surrendered to the
Corporation, where it is Appropriate Authority, otherwise to the State Government as
the case may be, free of cost and free of encumbrances, after the owner or lessee has
levelled the land to the surrendering ground level and after he has constructed a 1.5 m
high compound wall (or at a height stipulated by the Commissioner) with a gate at the
cost of the owner, and to the satisfaction of the Commissioner, or the State
Government (where the Corporation is not the Appropriate Authority). The cost of
any transaction involved shall be borne by the owner or lessee.
11. With an application for development permission, where an owner seeks utilization of
DRs, he shall submit the DRC to the Commissioner who shall endorse thereon the
writing in figures and words, the quantum of the DRC proposed to be utilized before
granting development permission as per these regulations and, the Commissioner shall
endorse in the DRC in writing, in figures and words, the quantum of DR's actually
utilized/and the balance remaining thereafter, if any.
12. A DRC shall be issued by the Commissioner himself as a certificate printed on bond
paper in an appropriate form prescribed by Commissioner. Such a certificate will be a
transferable "negotiable instrument" after due authentication by the Commissioner.
The Commissioner shall maintain a register in a form considered appropriate by him of
all transactions, etc. relating to grant of utilization of DRs.
13. The surrendered reserved land for which a DRC is to be issued shall vest in the
Corporation or the State Government, if the Appropriate Authority is other than the
Corporation, and such land shall be transferred in the Revenue Records in the name of
the Corporation or the State Government, as the case may be, and shall vest absolutely
in the Corporation or the State Government. The surrendered land, so transferred to
the State Government in respect of which the Corporation is not the Appropriate
Authority, may, on application, thereafter be allotted by the State Government in
favour of the concerned authority which may be a State or Central Government
Department, authority or organization, or another public authority or organization on
appropriate terms as may be decided by the State Government.
14. The Commissioner/Appropriate Authority shall draw up in advance and make public
from time to time a phased annual programme (allowing a 10 per cent variation to deal
with emergency development) for utililsation of TDRs in the form of DRs, prioritizing DP
reservations to be allowed to be surrendered and indicating the areas for their
utilization on receiving plots. Notwithstanding this, in urgent cases the
Commissioner/Appropriate Authority, may for reasons to be recorded in writing, grant
DRs, as and when considered appropriate and necessary.
15. DRC shall state the Development Rights credit in square meters in figures and in
words along with the details of place i.e. village, Ready Reckoner Zone Number, year
of issue of DRC and Ward in which the Development Rights are earned.
16. The Municipal Commissioner may reject the application for transfer/utilization of
DRC, if
a. Any dues are payable by the owner of the land on which DRC is proposed to be
utilized.
b. Under direction from the Competent Court to the State Government/MCGM
17. The Commissioner shall reserve the rights for granting permission to utilize/transfer
the DRC and/or forfeiting DRC, if the property so handed over to MCGM/other
appropriate authority is by fraudulent means and/or dues payable to the State
Government/MCGM are not paid.
18. DRC shall remain valid till DR available under DRC is fully utilized.
1.0 TRANSFERABLE DEVELOPMENT RIGHTS -
Transferable Development Rights (TDR) is compensation in the form of Floor Space Index (FSI) or
Development Rights which shall entitle the owner for construction of built-up area subject to
provisions in this regulation. This FSI credit shall be issued in a certificate which shall be called as
Development Right Certificate (DRC).
Development Rights Certificate (DRC) shall be issued by Municipal Commissioner under his
signature and endorse thereon in writing in figures and in words, the FSI credit in square meters of
the built-up area to which the owner or lessee is entitled, the place from where it is generated and
the rate of that plot as prescribed in the Annual Statement of Rates issued by the Registration
Department for the concerned year.
2.0 CASES ELIGIBLE FOR TRANSFERABLE DEVELOPMENT RIGHTS (TDR):-
Compensation in terms of Transferable Development Rights (TDR) shall be permissible for-
i) lands under various reservations for public purposes, new roads, road widening etc. which are
subjected to acquisition, proposed in Draft or Final Development Plan, prepared under the
provisions of the Maharashtra Regional and Town Planning Act,1966;
ii) lands under any deemed reservations according to any regulations prepared as per the
provisions of Maharashtra Regional & Town Planning Act, 1966;
iii) lands under any new road or road widening proposed under the provisions of Mumbai
Municipal Corporation Act, 1888;
iv) development or construction of the amenity on the reserved land;
v) unutilized FSI of any structure or precinct which is declared as Heritage structure or Precinct
under the provisions of Development Control Regulations, due to restrictions imposed in that
regulation;
vi) in lieu of constructing housing for slum-dwellers according to regulations prepared under the
Maharashtra Regional & Town Planning Act, 1966;
vii) the purposes as may be notified by the Government from time to time, by way of, modification
to, new addition of, any of the provisions of sanctioned Development Control Regulations.
viii) Unreserved accessible plot not falling in NDZ/NA and if owner willing to offer the land and the
Municipal Commissioner, MCGM needed the said land for public purpose shall be deemed to be a
reservation and eligible for TDR under this regulation.
ix) The TDR of lands owned by Central Govt. and it’s undertakings under reservations shall be
granted to the Central Govt. and it’s undertakings. However, it will not be eligible to the lands
under reservations which are granted on lease at concessional rates by the Central Govt. and State
Govt.
3.0 CASES NOT ELIGIBLE FOR TRANSFERABLE DEVELOPMENT RIGHTS ( TDR ):-
It shall not be permissible to grant Transferable Development Rights (TDR) in the following
circumstances:-
i) For earlier land acquisition or development for which compensation has been already paid
partly or fully by any means;
ii) Where award of land has already been declared and which is valid under the Land Acquisition
Act, 1894 or the Right to Fair Compensation & Transparency in Land Acquisition, Rehabilitation
and Resettlement Act, 2013 unless lands are withdrawn from the award by the Appropriate
Authority according to the provisions of the relevant Acts.
iii) In cases where layout has already been sanctioned and layout roads are incorporated as
Development Plan roads prior to these regulations.
iv) In cases where layout is submitted along with proposed Development Plan Road, in such cases
TDR shall not be permissible for the width of road that would be necessary according to the
length as per Development Control Regulations;
v) If the compensation in the form of FSI / or by any means has already been granted to the
owner.
vi) Where lawful possession including by mutual agreement /or contract has been taken.
vii) For an existing user or retention user or any required compulsory open space or recreational
open space or recreational ground, in any layout.
viii) For any designation, allocation of the use or zone which is not subjected to acquisition.
ix) The incentive TDR will not be applicable to deemed reservations.
4.0 GENERATION OF THE TRANSFERABLE DEVELOPMENT RIGHTS ( TDR ) –
4.1 Transferable Development Rights (TDR ) against surrender of land :-
4.1.1 For Surrender of the gross area of the land which is subjected to acquisition, free of cost and
free from all encumbrances, the owner shall be entitled for TDR or DR irrespective of the FSI
permissible or development potential of the very said land to be surrender and also that of land
surrounding to such land at the rate as given below:-
Sr Instances Extent of TDR Remarks/conditions
No
1 a) If entire plot of land reserved a) Where land is not
Area under Entitlement
for public purpose in the DP handed over yet and
reservation for TDR/DR
and land is transferred in the FSI benefit is not
name of MCGM/Appropriate Mumbai 2.5 times the approved in the
City area area of
Authority. development proposal
(island City) surrendered
on remainder plot & no
land.
(Maximum TDR/monitory
2.5) compensation is
availed.
Mumbai 2 times the
Suburban/ area of
b) award is not
Extended surrendered
declared under Section
Suburban land.
(Maximum 23 of Right to Fair
2.00 ) Compensation and
Transparency in Land
Sr Instances Extent of TDR Remarks/conditions
No
Acquisition
Rehabilitation and
Resettlement L.A. Act
2013 or any
compensation has not
been paid
b) Development of lands of cotton BUA as per the Zonal Only where land is not
textile mill under the provision of (basic) FSI of land so handed over and FSI
Regulation No. 35 in lieu of land transferred. benefit is not approved
to be transferred in the name of in the development
MCGM/MHADA/ Appropriate proposal and not
Authority proposed to be utilized
on remainder plot nor
TDR is availed, then
TDR of unutilized BUA.
c) DP Roads/RL under MMC Only if FSI benefit is
Area under Entitlement
Act/land under River widening, not approved in the
reservation for TDR/DR
major Nalla widening transferred development proposal/
to in the name of MCGM Mumbai 2.5 times the availed and not
City area area of
proposed to be utilized
(island City) surrendered
on remainder plot nor
land.
(Maximum TDR is availed
2.5)
Mumbai 2 times the
Suburban/ area of
Extended surrendered
Suburban land.
(Maximum
2.00 )
d) Setback due to Subsequent BUA as per the Zonal
Road widening/Proposed DP (basic) FSI of land so
Road/Right of way to land locked transferred. In case of
plot as per Regulation No.22, in SDZ, BUA equal to Zonal
case where development of (basic) FSI prevailing in
plot/layout is completed in all adjoining zone of land
respect/where no development is so surrendered.
proposed/is in progress at the
time of handing over of such area
to MCGM.
2 If owner/developer develops the If no BUA is availed in the Due to planning
Sr Instances Extent of TDR Remarks/conditions
No
reservation under provisions of AR form of FSI or such constraints.
and is unable to consume even unutilized BUA on the
Zonal (basic) FSI, BUA equal to plot balance plot.
area of land so transferred in the
name of MCGM/Appropriate
Authority and BUA in lieu of cost of
construction of built up amenity to
be handed over to
MCGM/Appropriate Authority.
3 BUA in lieu of cost of construction If no BUA is availed in the Due to planning
of built up amenity to be handed form of FSI or such constraints.
over to MCGM/Appropriate unutilized BUA on the
Authority as per the Regulation No. balance plot.
14,15 &17
4 In case of redevelopment of As prescribed under the
Cessed buildings 33(7), 33(7)(B), relevant provision of DCPR
33(8), Cluster Development
Scheme 33(9) and slum
redevelopment scheme 33(10),
Permanent transit tenements for
Slum Rehabilitation Scheme under
Regulation No.33(11),
5 BUA of Affordable Housing As prescribed under the
constructed on unreserved private under the provision of
land and handing over of entire corresponding regulation
plot along with constructed
tenements to MCGM free of cost
as per the Regulation No. 33(20).
6 Heritage buildings {BUA as per Zonal (basic) Where the
FSI+ area of plot on which Development of
Heritage Structure is building is not
existing} – BUA consumed permissible as per
by Heritage building provision of Regulation
No 52 and with the
permission of
Municipal
Commissioner in
consultation with & on
recommendation of
Sr Instances Extent of TDR Remarks/conditions
No
MHCC
The potential of the
plot shall be
perpetually reduced to
the extent of Existing
BUA of the Structure.
7 Encumbered plots which are To the extent of 50%of Project Implementing
required for implementation of BUA as per Zonal (basic) authority shall
public project on very urgent basis FSI of the plot area. separately certify the
area of land which was
a. In case of land which are fully (i)For the portion of land
vacant and the area of
encumbered and where which is/was vacant as
land under
encumbrances had/have to be per serial no 1(a) of this
encumbrance along
removed and rehabilitated table
with details as per the
elsewhere by the project
(ii) For the portion of land
joint measurement
implementing authority,
which is/was encumbered
survey carried out in
b. which are partly encumbered
to the extent of 50% of
this respect with the
and where encumbrance
BUA as per Zonal (basic)
City Survey Officer. The
are/were removed and
FSI of the vacant plot area.
area of vacant land and
rehabilitated elsewhere by the
land under
Project Implementing authority,
encumbrance shall be
clearly distinguished
and demarcated,
otherwise the land
under part
encumbrance shall be
treated as fully
encumbered land.
The owner has to
follow the procedure
laid down by the
MCGM for availing the
DRC.
8 Unreserved accessible plot not If owner willingly offers
Area under Entitlement
falling in SDZ/NA the land and the
reservation for TDR/DR
Municipal
Mumbai 2.5 times the Commissioner, MCGM
City area area of requires the land for
(island City) surrendered
public purpose such as
land.
(Maximum POS/SWM facility/
Sr Instances Extent of TDR Remarks/conditions
No
2.5) Municipal Chowky/ PSC
blocks.
Mumbai 2 times the
Suburban/ area of
Extended surrendered
Suburban land.
(Maximum
2.00 )
9 Reserved Land for D. P.
Area under Entitlement
Road/public purpose in SDZ area
reservation for TDR/DR
accessible from existing Road.
Mumbai 2.5 times the
City area area of
(island City) surrendered
land.
(Maximum
2.5)
Mumbai 2 times the
Suburban/ area of
Extended surrendered
Suburban land.
(Maximum
2.00 )
10 Roads/uninterrupted access to BUA equal to area of land
AH/POS/OA to be handed over to so transferred
MCGM in proposed development
under Regulation No 33(8)
(Explanation: Above entitlement may also be applicable to the compensation paid in the form of
FSI to the owner to be utilised on unaffected part of same land parcel and in such cases the
procedure of DRC shall not be insisted.)
Provided that, if leveling of land and construction/erection of the compound wall / fencing as per
Clause No. 4.1.2 to the land under surrender is not permissible as per the prevailing Development
Control Regulations, the quantum of TDR shall be reduced to 1:2.35 and 1:1.85 in Mumbai City
area ( island city) and Mumbai Suburban /Extended Suburban area respectively.
Provided also that Additional / incentive Transferable Development Rights (TDR) to the extent of
20 %, 15 % , 10 % and 5% of the surrendered land area shall also be allowed to the land owners
who submit the proposal for grant of Transferable Development Rights (TDR ) within 1, 2 ,3 and
5 years from this notification respectively.
Provided that the quantum of Transferable Development Rights (TDR) generated for D.P. Road/
reservation in CRZ/BDP/HTHS/Low Density Zone/ Hazardous Zone/ Special Development Zone
areas or in areas which have some natural or legal constraint on development etc. shall be as
decided by the Government separately.
Provided further that in case of Govt. land which are fully encumbered then the TDR of such
encumbered plot shall be granted as per the clarifications given by the Govt. from time to time.
4.1.2 DRC shall be issued only after the land is transferred to the Municipal Corporation, only
after compliance of conditions stipulated in these regulations and after handing over and taking over
possession of the reserved land for which TDR is sought at free of cost and free from encumbrances
and after leveling the land to the surrounding ground level and after constructing / erecting a 1.5 m.
high compound wall / fencing i.e. brick/stone wall up to 0.60 mt above ground level and fencing
above that up to remaining height with a gate, at the cost of the owner and to the satisfaction of the
Municipal Commissioner. Provided that, if on certain lands such construction / erection of
compound wall / fencing is prohibited or restricted by any regulation, then quantum of
Transferable Development Rights (TDR ) shall be reduced as prescribed in proviso to Clause 4.1.1.
Provided further that such construction/erection of compound wall/fencing shall not be
necessary for area under Development Plan roads. In such cases TDR equivalent to entitlement as
mentioned in regulation no 4.1.1 shall be granted without any reduction.
4.1.3 If any contiguous land of the same owner/developer, in addition to the land under
surrender for which Transferable Development Rights (TDR) is to be granted, remains
unbuildable, the Municipal Commissioner may grant Transferable Development Rights (TDR)
for such remaining unbuildable land also if the owner / developer hands it over free of cost
and free from all encumbrance and encroachment. If such land is from the proposed roads
then such land shall be utilized for road side parking, garden, open space or road side
amenities including bus bays, public toilets or any compatible user as the Commissioner may
decide and if the such land is from the proposed reservation then same shall be included in
such proposed reservation and shall be developed for the same purpose. The Municipal
Commissioner shall quarterly report such cases to Government.
4.1.4 In case of lessee, the award of Transferable Development Rights (TDR ) shall be subject
to lessee paying the lessor or depositing with the Planning Authority for payment to the lessor,
an amount equivalent to the value of the lessors’ interest to be determined by the Planning
Authority on the basis of Land Acquisition Act, 1894 or the Right to Fair Compensation and
Transparency in Land Acquisition, Rehabilitation and Resettlement Act, 2013 against the area
of land surrendered free of cost and free from all encumbrances.
4.2 Transferable Development Rights (TDR ) against Construction of Amenity-
When an owner or lessee with prior approval of Municipal Commissioner, may develop or
construct the amenity on the surrendered plot or on the land which is already vested in the
Planning Authority, at his own cost subject to such stipulations as may be prescribed and to
the satisfaction of the Municipal Commissioner and hands over the said
developed/constructed amenity free of cost to the Municipal Commissioner then he may be
granted a Transferable Development Rights (TDR ) in the form of FSI as per the following
formula:-
Construction Amenity TDR in sq.m. = A/B * 1.25
Where,
A= cost of construction of amenity in rupees as per the rates of construction mentioned in
Annual Statement of Rates (ASR) prepared by the Inspector General of Registration for the
year in which construction of amenity is commenced.
B = land rate per sq.m. as per the Annual Statement of Rates (ASR) prepared by the Inspector
General of Registration for the year in which construction of amenity is commenced.
5.0 UTILISATION TRANSFERABLE DEVELOPMENT RIGHTS ( TDR ):--
5.1 A holder of DRC who desires to use FSI credit therein on a particular plot of land shall
attach valid DRCs to the extent required with his application for development permission.
Proposal for Transferable Development Rights (TDR) utilisation shall be submitted alongwith
the documents as may be prescribed by the Commissioner or by the Government from time to
time.
5.2 With an application for development permission, where an owner seeks utilisation of DRC,
he shall submit the DRC to the Municipal Commissioner who shall endorse thereon in writing
in figures and words, the quantum of the TDR proposed to be utilised, before granting
development permission. Before issuance of Occupation Certificate, the Commissioner shall
endorse on the DRC, in writing in figures and words, the quantum of TDR/DRs actually used
and the balance remaining if any.
5.3 The Transferable Development Rights (TDR) generated from any land use zone shall be
utilised on any receiving plot irrespective of the land use zone and anywhere in Mumbai City
area ( island city) and Mumbai Suburban /Extended Suburban area. The equivalent quantum
of Transferable Development Rights (TDR ) to be permitted on receiving plot shall be
governed by the formula given below:-
Formula: X = (Rg / Rr) x Y
Where, X = Permissible Utilisation of TDR/DR in sqm on receiving plot
Rg = Rate for land in Rs. per sq.m. as per ASR of generating plots in generating year
Rr = Rate for land in Rs. per sq.m. as per ASR of receiving plot in generating year
Y = TDR debited from DRC in sq.m.
Note:- All TDR including slum and heritage TDR shall be utilized as per this regulation only.
5.4 Utilization of Transferable Development Rights (TDR ) and Road Width Relation will
be govern by regulation 30 (A) subject to following notes:-
Note:-
i) Municipal Corporation of Greater Mumbai shall convert all roads of width less than 9.00m.
to 9.00m. and above as per site conditions through MR & TP. Act or MMC Act provisions.
ii) The maximum permissible TDR that can be utilised on any plot. Provided that specific area
based restriction where TDR utilisation is not permissible by earlier Regulations shall remain in
force except for Gaothan/ congested areas.
Provided also that the above utilisation of TDR would be available to an existing road
width of 9 mt and above so marked under the relevant Municipal Corporation Act.
iii) Maximum permissible TDR loading as mentioned above on any plot shall be exclusive of FSI
allowed for inclusive housing if any.
iv) The priority and quantum of maximum permissible TDR loading mentioned above shall
include slum TDR atleast 20 % and maximum to the extent of 50% of column no. 6 of Table No.
12 regulation 30(A). slum TDR (wherever applicable) as per this regulation and DRC generated
from the vary said land and/or DRC generated from other location up to the permissible limit
mention above .
v) If a plot is situated on internal road having dead end within 50 mt. from the main road,
having minimum width of 9m or more then such plot shall be treated as fronting on main road
for the purpose of utilisation of TDR. Similarly if the plot derives from 9m wide internal road
then such plots also eligible for the purpose for utilisation of TDR.
vi) The relaxation premium for the use of slum TDR i.e. 10% of normal premium shall be
charged while condoning deficiencies in open spaces.
5.4.2 Provided that, the restrictions of total maximum permissible built up area in terms of FSI
with respect to road width mentioned above shall not be applicable in cases where, the
permissible FSI is more than the basic FSI in various schemes, like Slum Rehabilitation Scheme,
Redevelopment of cess buildings, redevelopment of dangerous buildings, Urban Renewal
Scheme, Redevelopment of MHADA buildings/Colonies, Metro Influence Zone, BRTs, TODs
etc. where specific provisions which are sanctioned by the Government shall apply.
5.4.3. Provided that, the additional FSI permissible in certain categories of buildings such as,
Educational building, Registered Charitable Institutional/ Medical / Hospital Building, Star
Category Hotel, Religious Building etc. as per prevailing Development Control Regulations, if
any, can be availed either by full or part utilization of TDR or full or part utilization of
additional FSI at the option of owner. However, the restriction of road width mentioned as
above shall not be applicable when the owner exercises his option of availing utilization of
additional FSI and in such cases limitation of maximum building potential as mentioned in
regulation no 5.4.1 shall not be applicable.
5.4.4 The utilisation of Transferable Development Rights (TDR) shall be permissible by
considering Gross Plot Area excluding area affected by reservations or deemed reservation, if
any. This principle shall also be applicable to the reservations to be developed under the
provisions of Accommodation Reservation, by considering the total area of such reservation
before surrender.
5.4.5 Areas Restricted from Utilisation of Transferable Development Rights (TDR ) :-
Utilisation of Transferable Development Rights (TDR) shall not be permitted in following
areas:-
DRC shall not be valid for use on receivable plots in the areas listed below:-
(a) Coastal areas and areas in Special Development Zones and areas for which the Mumbai
Metropolitan Region Development Authority or Maharashtra Housing and Area
Development Authority or Maharashtra Industrial Development Corporation is the
Special Planning Authority;
(b) On plots for housing schemes of slum dwellers for which additional FSI is permissible
under sub-regulation (7), (9) & (10) of Regulation 33;
On plots for housing schemes of slum dwellers for which additional FSI is permissible
under sub-regulation (10) of Regulation 33. However, in cases where non-slum plot is
amalgamated with the slum plot for the purpose of better planning etc. then DRC will be
receivable on the non-slum plot/ non-cessed plot. In such cases utilization of DCR shall
be governed as per procedure and provisions stipulated in this Regulation and sub clause
(B).
(c) Areas where the permissible FSI is less than 1.0.
(d) Coastal regulation zone, except in cases where it is permissible to Utilised TDR as per CRZ
Notification 2011 and subsequent amendment from time to time’.
e) Area having developmental prohibition or restrictions imposed by any notification issued
under the provisions of any Central/State Act (like CRZ regulations, Defense restriction
areas, etc.) or under these regulations.
6.0 GENERAL STIPULATION:-
6.1 Development Rights (DRs) will be granted to an owner or lessee, only for reserved lands
which are retainable and not vested or handed over to the Government /Urban Local Bodies
and not exempted under section 20 or 21 of the then Urban Land (Ceiling and Regulations)
Act, 1976 and undertaking to that effect shall be obtained, before a Development Right is
granted. In the case of schemes sanctioned under section 20 or 21 of the said Act, the grant of
Development Rights (DRs) shall be to such extent and subject to the conditions mentioned in
section-20 scheme and such conditions as the Government may prescribed. In case of non-
retainable land, the grant of Development Rights shall be to such extent and subject to such
conditions as the Government may specify. The provisions of this Regulation shall be subject
to the orders issued by the Government from time to time in this regard.
Provided that, in case of lands having tenure other than Class-I, like Inam lands, tribal
lands etc., N.O.C. from Competent Authority, mentioning i)share of Government and land
holder ii)transfer of such land in the name of Planning / Appropriate Authority, shall be
produced by the land holder at the time of submission of application for grant of TDR.
6.2 DRC shall be issued by the Municipal Commissioner as a certificate printed on bond paper
in an appropriate form prescribed by him. Such a certificate shall be a “transferable and
negotiable instrument” after the authentication by the Municipal Commissioner. The
Municipal Commissioner shall maintain a register in a form considered appropriate by him of
all transactions, etc. relating to grant of, or utilisation of, DRC.
6.3 The Commissioner shall issue DRC within 180 days from the date of application or reply
from the applicant in respect of any requisition made by him, whichever is later.
6.4 Transfer of DRC-
6.4.1 The Commissioner shall allow transfer of DRC in the following manner -
i) In case of death of holder of DRC, the DRC shall be transferred only on production of the
documents as may be prescribed by him from time to time, after due verification and
satisfaction regarding title and legal successor.
ii) If a holder of DRC intends to transfer it to any other person, he shall submit the original
DRC to the Commissioner with an application alongwith relevant documents as may be
prescribed by the Commissioner and a registered agreement which is duly signed by
Transferor and Transferee, for seeking endorsement of the new holders name, i.e., the
transferee, on the said certificate. The transfer shall not be valid without endorsement by the
Commissioner and in such circumstances the Certificate shall be available for use only to the
holder / transferor.
6.4.2 The utilisation of TDR from certificate under transfer procedure shall not be permissible,
during transfer procedure.
6.5 The Commissioner may refrain the DRC holder from utilizing the DRC in the following
circumstances:-
i. Under direction from a competent Court.
ii. Where the Commissioner has reason to believe that the DRC is obtained a) by producing
fraudulent documents b) by misrepresentation,
6.6 Any DRC may be utilised on one or more plots or lands whether vacant, or already
developed fully or partly by erection of additional storeys, or in any other manner consistent
with the prevailing Development Control Regulations,
6.7 DRC may be used on plots/land having Development Plan reservations of buildable
nature, whether vacant or already developed for the same purpose, or on the lands under
deemed reservations, if any, as per prevailing Regulations.
6.8 DRC may be used on plots/land available with the owner after surrendering the required
land and construction to the Planning Authority under the provisions of Accommodation
Reservation. In such circumstances, for the purpose of deciding Transferable Development
Rights (TDR) receiving potential, the total area of the reservation before surrender, shall be
considered.
6.9 Infrastructure Improvement Charges-
The utilizer shall pay to the Planning Authority, an infrastructure improvement charges, for a
proposed quantum of TDR to be utilised, at the rate of 5% of construction cost as per the
prevailing Annual Statement of Rates.
7.0 VESTING OF LAND :-
7.1 The Commissioner, before issuing DRC, shall verify and satisfy himself that the ownership
and title of the land proposed for surrender is with the applicant, and get the Record of Right
to be corrected in the name of Planning Authority.
7.2 In case the Appropriate Authority for reservation is other than Planning Authority, it shall
be permissible for the Commissioner on the request of such authority to grant TDR under this
regulation and hold such possession as a facilitator. Provided that, the Municipal
Commissioner shall handover the possession of such land to concerned Appropriate Authority,
after receipt of value of land, from such Appropriate Authority as per Annual Statement of
Rates prevailing at the time of handing over possession of land under reservation.
Provided also that, if such Appropriate Authority is the State Government Department,
the Municipal Commissioner shall handover the possession of such land to the concerned
Department free of cost.
8.0 EFFECT OF THIS REGULATION:-
Provision of Generation of TDR from these regulations shall not be applicable where DRC
has been issued prior to publication of these regulations. "However DRCs issued under
the old Regulations shall be allowed to be utilised as per TDR zones of old Regulations
without indexation but subject to all other conditions of these Regulations. Such
utilisation shall be allowed for one year only.
Provided also that old TDR purchased for utilisation on a specific plot with registered
documents of sale and/or specific proposal for utilisation of such TDR pending in the ULBs
prior to these regulations shall be allowed completely as per the old regulations".
(EP-70)
(B) Additional Regulations for the grant of TDR to the Developers/Co-operative Housing
Societies/NGOs in respect of slum rehabilitation scheme vide DCR 33(10) and DCR
33(11)
1. The developer/society/NGO on a plot of land for which the Slum Rehabilitation
Project is sanctioned under these Regulations shall be eligible for the award of TDR for
the FSI, if any, in excess of 3.0 or as may be specifically permitted by the CEO, Slum
Rehabilitation Authority (SRA) difference between sanctioned FSI and FSI that can be
utilized in-situ.
The developer/society/NGO on a plot of land for which the Slum Rehabilitation Project
is sanctioned under these Regulations shall be eligible for the award of TDR for the FSI,
if any,
2. DRC for the TDR will be issued by the Commissioner, MCGM himself on
recommendation by CEO (SRA). DRC shall state the DRs credit of BUA in square
meters in figures and in words along with the details of place i.e. village/TP
Scheme/Division, CS No/CTS No/FP No from where it is generated, year of issue of
DRC and Ward in which the DRs are earned.
3. The BUA for the grant of DRC shall be equal to BUA of the sanctioned Slum
Rehabilitation Project allowed to be taken in the form of TDR & as approved by CEO
SRA.
4. When a buildable amenity on the reserved plot for which slum rehabilitation project
is sanctioned, is handed over free of cost to the MCGM, the Commissioner may grant a
further TDR due for the construction of the said amenity, as per Sr. No 3 of the table. A
DRC will be issued only on the satisfactory compliance with the conditions prescribed
in this Regulation.
5. A register, in a form considered appropriate by the Commissioner, shall be
maintained of all transactions relating to grant or utilization of DRCs arising out of slum
rehab projects.
(C) Additional regulations for the grant of TDR to owners/lessees of heritage
buildings/heritage precincts and conditions for grant of such rights
1 As provided in Regulation No. 52 DRs of the owner/lessee of any Heritage building
who suffers loss of DRs due to any restrictions imposed by the Commissioner or
Government under Regulations No 52 shall be eligible for award of TDR in the form
of FSI to the extent and on the conditions set out below at 2. Such award will entitle
the owner of the Heritage Building to FSI in the form of a DRC which he may use
himself or transfer to any other person.
2 For generating TDR, agreement with MCGM shall be executed stating that the
heritage structure will be maintained by the Owner as decided by the Commissioner
along with a clause of penalty for breach of conditions of agreement as may be
decided by Commissioner and potential of the plot shall be perpetually reduced to
the extent of existing BUA of the structure.