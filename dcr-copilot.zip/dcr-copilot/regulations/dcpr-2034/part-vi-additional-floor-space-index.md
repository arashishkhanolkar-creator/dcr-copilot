# Part VI: Additional Floor Space Index

33. Additional Floor Space Index (FSI) which may be allowed to certain
categories:
33 (1) Additional FSI to Religious building:
The Municipal Commissioner may permit 0.5 FSI in addition to the Zonal (basic)
FSI in respect of buildings of Registered Public Trust subject to following terms
and conditions:
i.NOC shall be obtained from Police Authority and Collector before applying for
permission.
ii.Additional FSI shall be used for religious purpose alone. However, without taking
into account the additional FSI, ancillary residential/commercial uses will be
permissible up to 10% of Zonal (basic) FSI.
iii.Additional FSI shall be permissible to existing authorized religious user subject to
structural stability.
iv.Additional FSI shall be permissible subject to payment of 25 % premium as per
ASR of the year in which such FSI is granted and shall be equally shared between
GoM & MCGM.
v.The minimum area of plot shall be 250 sq. m.
33 (2) Buildings of Medical and Educational Institutions and Other
Institutional Buildings covered under Regulation (2) (IV) (16 17) (g): -
The Municipal Commissioner, by special permission, may permit up to FSI
5 for medical Institutions and FSI up to 4 for educational & other
Institutional buildings including the Zonal (basic) FSI specified in Table No
12 in respect of buildings on independent plots of educational/medical
institutions and institutional buildings of Govt./MCGM or public
authorities or of registered public charitable trusts or of medical institutions
run on cooperative basis established for charitable purposes and registered under
the provisions of Income Tax Act or Maharashtra Cooperative Societies Act
subject to terms and conditions he may specify subject to minimum width
of 13.40m except educational institutions;
Provided that in the case of additional FSI allowed to the above cited
institutions, except institutional buildings of State Govt. / & MCGM,
premium for BUA, at the rate of 10% of the land rates as per ASR (for FSI 1) for
educational institutions, at the rate of 10% of the land rates as per ASR (for FSI
1) for medical institutions, at the rate of 20% of the land rates as per ASR (for
FSI 1) for the private hospitals and at the rate of 30% of the land rates as per
ASR (for FSI 1) for other institutional buildings shall have to be paid, if any,
beyond Zonal (basic) FSI, or as fixed by Govt. from time to time shall be
equally shared between Govt. and MCGM.
Out of the additional FSI beyond Zonal (basic) FSI, 50% may be availed by
utilizing TDR (without payment of premium), provided that the utilization
of such TDR will be allowed as per the option of the owner/developer only
after availing the remaining additional FSI.
In regard to other Institutional Buildings covered under Regulation (2) (IV)
(16 17) (g), Govt. /Municipal Commissioner may from time to time specify
terms and conditions.
(EP-71)
(A) Terms and Conditions for Medical Institutions and Institutional Building
(a)Additional BUA beyond Zonal (basic) FSI shall be utilized for bonafide
medical purpose only.
(b) 20% of the total beds and free treatment shall be given to EWS/persons
below poverty line. In addition, 10% of the total number of patients in
OPD shall be provided treatment at rates charged in Govt. hospitals. Such
facility, proportionate to cited percentages, shall be in separate
building/wing, or if not possible, on separate floor.
(c)The Director of Health Services, GoM shall be the competent authority for
observance of (a) & (b) above, including determination of penalties for
breach of conditions.
(d)The Medical Institution shall maintain records of free/concessional
medical treatment, furnish such records periodically and make them
available to the Director of Health Services on demand.
(e)The Medical Institution shall file an undertaking to abide by the cited
terms and conditions before allowing utilization of 50% of additional
permissible FSI beyond Zonal (basic) FSI.
(B) Terms and Conditions for Educational Institution or Institutional
Buildings
(a) Additional BUA beyond Zonal (basic) FSI shall be utilized for bonafide
educational purpose only.
(b) Such Institutions shall make available some rooms to Govt as and when
required.
(c) 10% of the total seat capacity shall be reserved for Govt nominees on
recommendation by the Department of Education/Higher and Technical
Education, GoM.
(d) The Directors of School Education/Higher and Technical Education, GoM
shall be the competent authority for observance of (a), (b) & (c) above,
including determination of penalties for breach of conditions.
(e) The Educational Institution shall maintain records of free/concessional
education, furnish such records periodically and make them available to
the Directors of School Education/Higher & Technical Education, GoM on
demand.
(f) The Educational Institution shall file an undertaking to abide by the cited
terms and conditions before allowing utilization of 50% of additional
permissible FSI beyond Zonal (basic) FSI.
(C) Terms and Conditions for Buildings of Private Medical & Educational
Institutions
(a) Such additional FSI (except the TDR component) will be permissible
subject to the payment of premium as decided by Govt. from time to
time, to be shared equally between GoM and MCGM.
(b) Conditions stipulated in (A) & (B) above shall be adhered to.
The Municipal Corporation shall intimate the concerned appropriate
implementing authority regarding grant of building permission / occupation
certificate to enable such authority to comply with the aforesaid conditions
mentioned in (A), (B) & (C).
(EP-72)
33(3) Buildings of Government/MCGM/Statutory Bodies, Semi-Government
and PSU Offices:
The Commissioner, by special permission, may permit FSI up to 5 including
Zonal (basic) FSI specified in Table No 12 for office use & other allied
purposes except residential use considering the specific requirement of
Govt./MCGM and their Statutory Bodies, Semi Govt. and PSUs as detailed
below:
Sr No Plot area Minimum Road Maximum
Width Permissible FSI
1 Up to 2000 sq. m 12m Up to 3
Above 2000 and up to 18m
2 Up to 4
3000 sq. m
3 Above 3000 Sq. m 30m Up to 5
Provided further that in case of Public Sector Undertaking the premium
for FSI beyond Zonal (basic) FSI shall be payable as decided by Govt. from
time to time.
Premium shall be applicable for additional FSI except for the development
by State Government & MCGM as decided by the Government from time
to time.
(EP-73)
33(3) (A) Development/Redevelopment for construction of staff quarters of Govt. or
its statutory bodies (including CISF) or MCGM or its statutory bodies, on lands
belonging to such Public Authorities:
1.The Commissioner may permit FSI up to 4 including Zonal (basic) FSI
specified in Table No 12 on the gross plot area, abutting a road having
minimum width of 12 m, solely for the project of construction of staff
quarters (hereinafter referred to as “staff quarters project”) for the
employees of the Govt./MCGM, or their statutory bodies (hereinafter
collectively referred to as “User Authority”) on land belonging to such
User Authority, by the Public Works Department of the GoM or MHADA or
Maharashtra Police Housing Corporation or MCGM or its statutory bodies
or Private Public Partnership (PPP) project or any other Public Agency
nominated by the Govt. for this purpose which would also include any
Special Purpose Vehicle, wherein the Govt. or a fully owned Company of
the Govt. holds at least 51% equity share (hereinafter collectively referred
to as “Implementing Public Authority”).
Premium shall be applicable for additional FSI except for the development
by State Government & MCGM as decided by the Government from time
to time.
2. The total permissible FSI under this Regulation shall be utilized for
construction of staff quarters for the User Authority subject to the
following:
(i) The area of staff quarters/free sale component for various categories
of employees shall be as per the norms prescribed by the concerned User
Authority.
(ii) (a) Commissioner may also permit up to 1/3rd of the total permissible
FSI under this Regulation for construction of free sale area (hereinafter
referred to as “free sale component”) to be disposed of by the
Implementing Public Authority to recover the cost of project
implementation as provided herein.
The free sale component shall preferably be constructed in a separate
block. Sub-division of plots shall be permissible on the basis of equitable
distribution of FSI, in case construction of free sale component is
permitted by Commissioner.
(b) If the User Authority requires construction of staff quarters to the
extent of full permissible FSI of 3.0 / 4.0, then the User Authority shall
pay full cost of construction to the Implementing Public Authority, in lieu
of the free sale component.
(c) The flats constructed under the free sale component shall be first
offered to the Central Govt, its statutory bodies, Central/ State PSUs for
purchase as staff quarters and if the Central Govt. or its statutory Bodies
or Central/ State PSUs do not indicate willingness to purchase the same
within the prescribed time limit, such flats shall be sold in open market.
(b) The flats constructed under the free sale component shall be first
offered to Govt/MCGM or their statutory bodies. If no willingness is
forthcoming or their demand falls short of total stock, the same may be
off loaded in the open market.
3.An infrastructure charge Development cess at 7% of the Land Rate for
the BUA as per ASR (for FSI 1) of the year of approval beyond Zonal (basic)
FSI (including excluding fungible FSI compensatory area) shall be paid to
MCGM. These The infrastructure charges Development cess shall be in
addition to development charges levied as per section 124 of MR&TP Act
4. (i) No premium shall be charged for fungible FSI compensatory area
admissible as per DCR 31(3) for construction of staff quarters of
MCGM & State Government.
(ii)No premium shall be payable for stair case, lift and lift lobby for the
construction of staff quarters of MCGM & State Government.
(iii) Open space deficiency shall be charged at the rate of 2.5% of the
land rate of ASR (for FSI 1).
(iv) Provisions of IH shall not be applicable for development under this
Regulation.
5. For any staff quarters project under this Regulation, a Development
Agreement shall be executed between the User Authority and
Implementing Public Authority authorizing the Implementing Authority
to dispose of the flats constructed under the free sale component of
the project wherever applicable.
(EP-74)
33(3) (B) Development/Redevelopment for construction of staff quarters of Govt. or
its statutory bodies (including CISF) or Municipal Corporation of Greater
Mumbai or its statutory bodies on private lands.
1. The Commissioner may permit construction of staff quarters for the
employees of Govt. /MCGM/their statutory bodies (hereinafter
referred to as “User Authority’’) on private plots of lands, having
minimum area of 2000 sq. m and abutting a road having minimum
width of 12 m and grant incentive FSI, as provided herein below, in
lieu of BUA of staff quarters created and handed over free of cost to
the User Authority, subject to payment of premium as decided by the
Government from time to time except for the buildings of State
Government & MCGM and the following provisions:
(i)The area of staff quarters for various categories of employees shall
be as per the norms prescribed by the concerned User Authority and in
no case, shall the area of Staff Quarters exceed the maximum limit of
carpet area as prescribed therein.
(ii)Incentive FSI shall be admissible against the FSI required for
construction of Staff Quarters as per following table: -
Table A
Location of project Incentive (As% of required
BUA of staff Quarters)
(i)
Island city 40%
Sub urbs & Extended 80%
Suburbs
(iii)FSI including Zonal (basic)/permissible FSI shall be used on the same
plot and as stated in the Table below.
Plot Area Minimum Maximum
Road Width permissible FSI
2000 sq. m or more 12m 3.00
but less than 4000
sq. m
4000 sq. m or more 18m 4.00
(iv) (a) No premium shall be charged for features permitted as per DCR 31
(1) and 31(3), for the construction of staff quarters to be handed over to
MCGM/Appropriate Authority.
(b) Open space deficiency shall be charged at 2.5% of the land rate of ASR
(for FSI 1).
(c)The provision of IH shall not be applicable for development under this
Regulation.
i. An infrastructure charge Development cess at 7% of the Land Rate for
the BUA as per ASR (for FSI 1) of the year of approval beyond Zonal
(basic) FSI (including excluding fungible FSI compensatory area) shall be
paid to MCGM. These infrastructural charges Development cess shall be
in addition to development charges levied as per section 124 of MR&TP
Act 1966.
ii. Development/redevelopment of a vacant plot belonging to a private
landholder for constructing staff quarters for a user Authority shall be
permitted by the Municipal Commissioner with prior approval of the
location and requirement of such Staff Quarters by the Committee
formed for this purpose by GoM.
iii. In case of flats proposed for conservancy staff quarters under this
Regulation, a percentage of flats as decided by GoM shall be available
on ownership basis under Shram Saphalya scheme.
(EP-75)
33(4) Building of Residential Hotels on independent plot:
Subject to payment of premium for BUA at the rate of 30% of the land rates as
per ASR (for FSI 1) or as decided by Govt. from time to time or else as per
the provision of Regulation No 33(19), equally to be shared between
Govt. & MCGM, and subject to other terms and conditions, the
maximum permissible FSI [including Zonal (basic) FSI] shall be as below
for all residential hotels on independent plots and satisfies other related
provisions of these Regulations and under one establishment.
Sr No Plot area excluding area Minimum Maximum
covered under to be handed Road Permissible FSI
over in lieu of Reservation/ Width
Designation in the DP except
affected by proposed DP
roads/Sanctioned RL under
MMC Act
1 Up to 2000 sq. m 12m Up to 3
Above 2000 and up to 3000 18m
2 Up to 4
sq. m
3 Above 3000 Sq. m 30m Up to 5
Conditions:
(1) 5% of total rooms shall be reserved for total 30 days in a year for
Govt./MCGM free of cost (only room charges) & it may be monitored by the
MTDC and Protocol Department.
(2) An infrastructure charge Development cess at 7% of the Land Rate for
the BUA as per ASR (for FSI 1) of the year of approval beyond Zonal (basic) FSI
(including excluding fungible FSI compensatory area) shall be paid to MCGM.
These infrastructural charges Development cess shall be in addition to
development charges levied as per section 124 of MR&TP Act 1966.
(3) Commercial uses up to 20% of Zonal (basic) FSI, in addition to uses
permissible in hotel i.e. banquet hall, conference hall and meeting room etc.
shall be permissible.
Note: Out of the additional FSI beyond Zonal (basic) FSI, 50% may be availed
by utilizing TDR (without payment of premium), provided that the utilization
of such TDR will be allowed only after availing of the remaining additional
FSI.
(EP-76)
33(5) Development/Redevelopment of Housing Schemes of Maharashtra
Housing & Area Development Authority (MHADA)
1) FSI for a new scheme of Low Cost Housing, implemented by MHADA
departmentally on vacant lands for EWS, LIG and MIG categories (as
stipulated by Govt. from time to time) shall be 4.0 on the gross plot
area (excluding Fungible FSI). 70 % BUA of such schemes shall be
for EWS, LIG and MIG. FSI 4 will not be applicable to HIG.
2) The above cited condition would also apply to redevelopment of
existing housing schemes of MHADA.
2.1 Where redevelopment of buildings in existing housing schemes of
MHADA is undertaken by the housing co-operative societies or the
occupiers of such buildings or by the lessees of MHADA, the
Rehabilitation Area Entitlement, Incentive FSI and sharing of balance
FSI shall be as follows: -
A) Rehabilitation Area Entitlement:
(a) Carpet area of existing tenement plus 35% thereof, subject to a
minimum carpet area of 35 sq. m, an additional carpet area, in
accordance with the Table-A below:
Table-A
Area of the Plot under Additional Carpet Area on the
Redevelopment Existing Carpet Area of Tenement
Above 4000 sq. m to 2 ha 15%
Above 2 ha to 5 ha 25%
Above 5 ha to 10 ha 35%
Above 10 ha 45%
Explanation: Plot under redevelopment means land demarcated by
MHADA for redevelopment.
Provided that the maximum rehabilitation area shall in no case exceed the
maximum limit of carpet area prescribed for MIG category by Govt. as
applicable on the date of approval of the redevelopment project.
Under redevelopment of buildings in existing housing schemes of MHADA,
rehabilitation area of any existing non-residential/amenity unit in Residential
Housing Scheme shall be equal to carpet area of the existing unit plus 20%
thereof.
B) Incentive FSI: Incentive FSI admissible against the FSI required for
rehabilitation, as calculated in (A) above, shall be based on the ratio
(hereinafter referred to as Basic Ratio) of Land Rate (LR) and Rate of
Construction (RC)* and shall be as given in the Table B below: -
Provided that the above incentive will be subject to availability of FSI on the
Plot under redevelopment and its distribution by MHADA.
Table B
Incentive (As % of Admissible
Basic Ratio (LR/RC)
Rehabilitation Area)
Above 6.00 40%
Above 4.00 and up to 6.00 50%
Above 2.00 and up to 4.00 60%
Up to 2.00 70%
Explanation
Land Rate (LR)*—Rate of Open Land for FSI 1in Rs/sq. m of the plot under
redevelopment &
* Rate of Construction (RC) --- Rate in Rs/ sq. m applicable to the area of RCC
construction as per ASR
Provided further that the Land Rate (LR) and the Rate of Construction (RC)
for calculation of the Basic Ratio shall be taken for the year in which the
redevelopment project is approved by the Competent Authority. Provided
further that in case there is more than one land rate applicable to different
parts of the plot under redevelopment, a weighted average of all the
applicable rates shall be taken for calculating the Average Land Rate for
deriving the Basic Ratio.
C) Sharing of the Balance FSI:
The balance remaining FSI/BUA after providing for rehabilitation and the
incentive components, calculated as per Table (A) and (B) above respectively,
shall be shared between the Cooperative Housing Society and MHADA in the
form of BUA, as given in Table (C) below. The share of MHADA shall be
handed over to MHADA free of cost.
Table C
Sharing of Balance FSI
Basic Ratio (LR/RC) Cooperative Society
MHADA Share
Share
Above 6.00 30% 70%
Above 4.00 and up to 6.00 35% 65%
Above 2.00 and up to 4.00 40% 60%
Up to 2.00 45% 55%
2.2 Where redevelopment of buildings in the existing housing schemes of
MHADA is undertaken by MHADA or jointly by MHADA along with the
housing societies or the occupiers of such building or by the lessees of
MHADA, the Rehabilitation Area, incentive FSI and sharing of balance FSI
shall be as follows:
A) Rehabilitation Area: The Rehabilitation Area shall be increased by 15% of
the existing carpet area, over and above the Rehabilitation Area
calculated in (A) of 2.1 above, subject to the maximum of the size of MIG
prescribed by the Government.
B) Incentive FSI: Incentive FSI shall be the same as in (B) of 2.1
C) Sharing of the balance FSI: Sharing of the balance FSI shall be the same
as in (C) of 2.1
Note: Fungible FSI as applicable on the surplus area to be handed over to
MHADA shall not be allowed to be utilized on sale component. No
premium shall be charged on the fungible FSI, in respect of area to be
handed over to MHADA and surplus area to be handed over to MHADA
shall be exclusive of the Fungible BUA if availed.
3) For the purpose of calculating FSI, the entire area of the layout including
DP roads and internal roads but excluding the land under the reservation
of public amenities shall be considered. Sub-division of plots shall be
permissible on the basis of the compulsory open spaces as in these
Regulations.
4)a) An infrastructure charge at 7% of the Land Rate for the BUA as per ASR
(for FSI 1) of the year of approval beyond Zonal (basic) FSI (including
fungible FSI ) shall be paid to MCGM. 75 % of the Infrastructure Charge
levied and collected by MHADA shall be transferred to MCGM for
developing necessary offsite infrastructure. These infrastructural charges
shall be in addition to development charges levied as per section 124 of
MR&TP Act 1966.
b) No premium shall be charged under Regulation 31(1) & 31 (3) for
construction of EWS/LIG/MIG tenements by MHADA on a vacant plot, in a
redevelopment project for EWS/LIG/MIG tenements towards the share of
MHADA and for rehabilitation component (existing BUA in old building)
of a redevelopment project.
5) Notwithstanding anything contained in these Regulations, the other
relaxation incorporated in Regulation No. 33(10) of these Regulations
except clause 6.18 shall apply to the housing schemes under this
Regulation for construction of tenements under EWS/LIG/MIG categories.
However, the front open space shall not be less than 3.0 m.
6) a) In any Redevelopment Scheme where the Co-operative Housing
Society/Developer appointed by the Co-operative Housing Society has
obtained NOC from MHADA/Mumbai Board, thereby sanctioning
additional balance FSI with the consent of 70% of its members and
where such NOC holder has made provision for alternative
accommodation in the proposed building (including transit
accommodation), then it shall be obligatory for all the
occupiers/members to participate in the Redevelopment Scheme and
vacate the existing tenements for the purpose of redevelopment. In
case of failure to vacate the existing tenements, the provisions of
section 95 A of MHAD Act mutatis mutandis shall apply for the purpose
of getting the tenements vacated from the non-co-operative members.
b) For redevelopment of buildings in any existing housing scheme of
MHADA under clause 2.2 hereinabove, by MHADA, the consent of the
Cooperative Housing Society in the form of a valid Resolution as per the
Co-operative Societies Act, 1960 will be sufficient. In respect of
members not co-operating as per approval of the redevelopment
project, action under section 95(A) of the MHAD Act, 1976 may be taken
by MHADA.
7. A corpus fund, as may be decided by MHADA, shall be created by the
Developer which shall remain with the Co-operative Housing Societies
for the maintenance of new buildings under the Rehabilitation
Component.
8. Redevelopment proposals where NOC has been issued by Mumbai
Board or Offer Letter has already been issued prior to the date of
coming into force of this Regulation (hereinafter referred to as the
"appointed date") and which is valid as on the appointed date, shall
continue to be governed by the applicable prior to this Regulation.
9. Convenience Shopping shall be permitted along layout roads with 12 m
to 18m width.
1) The FSI for a new scheme of Housing, implemented by MHADA on
MHADA lands for Economically Weaker Sections (EWS), Low Income Group
(LIG) and Middle Income Group (MIG) categories shall be 3.0 on the gross
plot area (exclusive of the Fungible Compensatory Area) and at least 60%
BUA in such scheme shall be in the form of tenements under the EWS, LIG
and MIG categories, as defined by the Government in Housing Department
from time to time.
Provided that the Floor Space Indices above may be permitted to be
exceeded up to 4.00 FSI in case of plots, having area of 4000 sq. m or
above which front on roads having width of 18.00 m or more.
2) For redevelopment of existing housing schemes of MHADA, containing
(i)EWS/LIG and/or(ii)MIG and/or (iii) HIG houses with carpet area less than
the maximum carpet area prescribed for MIG, the total permissible FSI
shall be 3.0 on the gross plot area (exclusive of the Fungible Compensatory
Area).
Provided that the Floor Space Indices above may be permitted to be
exceeded up to 4.00 FSI in case of plots, having area of 4000 sq. m or
above which front on roads having width of 18.00 m or more.
2.1 Where redevelopment of buildings in existing housing schemes of
MHADA is undertaken by the housing co-operative societies or the
occupiers of such buildings or by the lessees of MHADA, the Rehabilitation
Area Entitlement, Incentive FSI and sharing of balance FSI shall be as
follows:-
A) Rehabilitation Area Entitlement:
i) Under redevelopment of buildings in existing Housing Schemes of
MHADA, the entitlement of rehabilitation area for an existing residential
tenement shall be equal to sum total of
(a) a basic entitlement equivalent to the carpet area of the existing
tenement plus 35% thereof, subject to a minimum carpet area of 35 sq. m,
and
(b) an additional entitlement, governed by the size of the plot under
redevelopment, in accordance with the Table-A below: -
Table-A
Area of the Plot under Additional Carpet Area on the Existing
Redevelopment Carpet Area of Tenement
Above 4000 sq. m to 2 ha 15%
Above 2 ha to 5 ha 25%
Above 5 ha to 10 ha 35%
Above 10 ha 45%
Explanation: The plot under redevelopment means the land demarcated by
MHADA for redevelopment.
Provided that the maximum entitlement of rehabilitation area shall in no
case exceed the maximum limit of carpet area prescribed for MIG category
by the Govt, as applicable on the date of approval of the redevelopment
project.
ii) Under redevelopment of buildings in existing Housing Schemes of
MHADA, the entitlement of rehabilitation area of any existing commercial
/amenity unit in the Residential Housing Scheme shall be equal to the
carpet area of the existing unit plus 20% thereof.
B) Incentive FSI: Incentive FSI admissible against the FSI required for
rehabilitation, as calculated in (A) above, shall be based on the ratio
(hereinafter referred to as Basic Ratio) of Land Rate (LR) in Rs/sq. m. of the
plot under redevelopment as per the Annual Schedule of Rates (ASR) and
Rate of Construction (RC)* in Rs/sq. m applicable to the area as per the
ASR and shall be as given in the Table B below:-
Table B
Incentive (As % of Admissible
Basic Ratio (LR/RC)
Rehabilitation Area)
Above 6.00 40%
Above 4.00 and up to 6.00 50%
Above 2.00 and up to 4.00 60%
Up to 2.00 70%
Provided that the above incentive will be subject to the availability of the
FSI on the Plot under redevelopment and its distribution by MHADA.
Provided further that in case there are more than one land rate applicable
to different parts of the plot under redevelopment, a weighted average of
all the applicable rates shall be taken for calculating the Average Land Rate
and the Basic Ratio. Provided further that the Land Rate (LR) and the Rate
of Construction (RC) for calculation of the Basic Ratio shall be taken for the
year in which the redevelopment project is approved by the Competent
Authority.
C) Sharing of the Balance FSI:
The FSI remaining in balance after providing for the rehabilitation and the
incentive components, calculated as per (A) and (B) above respectively,
shall be shared between the Cooperative Housing Society and MHADA in
the form of BUA, as given in Table C below and the share of MHADA shall
be handed over to MHADA free of cost.
Table C
Sharing of Balance FSI
Basic Ratio (LR/RC) Cooperative Society
MHADA Share
Share
Above 6.00 30% 70%
Above 4.00 and up to 6.00 35% 65%
Above 2.00 and up to 4.00 40% 60%
Up to 2.00 45% 55%
Explanation
* RC is the rate of construction in respect of R.C.C. Construction, as
published by the Chief Controlling Revenue Authority & Inspector General
of Registration, Maharashtra State in the Annual Schedule of Rates.
Provided that in case of plots up to 2000 sq. m, MHADA without insisting
MHADA’s Share in the form of BUA, may allow additional BUA over and
above existing BUA up to 3.00 FSI by charging premium at the percentage
rate of ASR defined in table C1 below:-
Table C1
LR/RC Ratio EWS/LIG MIG HIG
0 to 2 40% 60% 80%
2 to 4 45% 65% 85%
4 to 6 50% 70% 90%
above 6 55% 75% 95%
Note: - The above percentage may change with prior approval of the Govt.
from time to time.
Provided further that in case of plots having area of 4000 sq. m or above
which front on roads having width of 18.00 m or more, the FSI 1.00 over
and above 3.00 shall be permissible in the form of Social Housing stock as
decided by MHADA in the ratio of 1 MHADA: 0.5 Cooperative Society and it
shall be handed over to MHADA on payment of cost of construction as per
ASR free of cost & without any compensation.
Provided that at the option of or with the approval of MHADA, the tenements
coming to the share of MHADA can also be provided by the Promoter/Developer
elsewhere within the same or adjoining Municipal Ward. Provided that the BUA
area to be handed over to MHADA shall be as per equivalent value of BUA as per
the market value (as per ASR of that year)
Provided that in case of plots having plot area between 2000 to 4000 sq. m may
allow additional BUA over and above existing BUA up to 3.00 FSI, however for this
plot area over and above 2000 sq. m to 4000 sq. m the social housing stock as per
above Table C shall be handed over to MHADA. In this case the Social Housing
Stock in situ will have to be handed over to MHADA.
2.2 Where redevelopment of buildings in the existing Housing Schemes of
MHADA is undertaken by MHADA or jointly by MHADA along with the
housing societies or the occupiers of such building or by the lessees of
MHADA, the Rehabilitation Area Entitlement, incentive FSI and sharing of
balance FSI shall be as follows:
A) Rehabilitation Area Entitlement:
The Rehabilitation Area Entitlement shall be increased by 15% of the
existing carpet area, over and above the Rehabilitation Area Entitlement
calculated in (A) of 2.1 above, subject to the maximum of the size of MIG
prescribed by the Government in the Housing Department.
B) Incentive FSI: Incentive FSI shall be the same as in (B) of 2.1
C) Sharing of the balance FSI: Sharing of the balance FSI shall be the same
as in (C) of 2.1
Note: Fungible compensatory area as applicable on the surplus area to be
handed over to MHADA shall not be allowed to be utilized on sale
component. No premium shall be charged on the fungible compensatory
area, in respect of area to be handed over to MHADA and surplus area to
be handed over to MHADA shall be exclusive of the Fungible compensatory
BUA if availed
3) For the purpose of calculating the FSI, the entire area of the layout
including Development Plan roads and internal roads but excluding the
land under the reservation of public amenities shall be considered. Sub-
division of plots shall be permissible on the basis of the compulsory open
spaces as in these Regulations.
The reservations in the MHADA layout may be developed as per the
provisions of Regulation No. 17(1).
Provided that there shall be no restriction on the utilization of the FSI
permissible under this Regulation except for the restrictions under any
law, rule or regulation.
4) For the purpose of this Regulation, the carpet areas for EWS, LIG or MIG
tenements shall be as determined by the Government from time to time.
5) a) For providing the requisite infrastructure for the increased population,
Development Cess at the rate of 7% of the Land Rate as per the ASR of the
year of approval of the redevelopment project shall be chargeable for the
extra FSI (excluding the fungible compensatory area) granted over and
above the normal FSI for the redevelopment schemes. 5/7th part of the
Development Cess levied and collected by MHADA shall be transferred to
the Municipal Corporation of Greater Mumbai for developing necessary
offsite infrastructure. Development cess shall be in addition to
development charges levied as per section 124 of MR&TP Act 1966.
b) No premium shall be charged under Regulation No 31(1) and 31(3) (for
the fungible compensatory area) for
(i) Construction of EWS/LIG and MIG tenements by MHADA on a MHADA
plot or
(ii) in a redevelopment project for the construction of EWS/LIG and MIG
tenements towards the share of MHADA, or
(iii) for rehabilitation component of a redevelopment project.
6) Notwithstanding anything contained in these Regulations, the other
relaxation incorporated in Regulation No. 33(10) of these Regulations
except clause 6.11, 6.15, 6.16 & 6.18 shall apply. The payment of premium
or at the rate of 25% of normal premium or at the rate of 6.25% of the land
rates as per ASR (for FSI 1), whichever is more shall apply to the Housing
Schemes under this Regulation for construction of tenements under
EWS/LIG/MIG categories. However, the front open space shall not be less
than 3.0 m.
7) a) In any Redevelopment Scheme where the Co-operative Housing
Society/Developer appointed by the Co-operative Housing Society has
obtained NOC from the MHADA/Mumbai Board, thereby sanctioning
additional balance FSI with the consent of 51% 70% of its members and
where such NOC holder has made provision for alternative permanent
accommodation in the proposed building (including transit
accommodation/Rent Compensation), then it shall be obligatory for all
the occupiers/members to participate in the Redevelopment Scheme and
vacate the existing tenements for the purpose of redevelopment. In case
of failure to vacate the existing tenements, the provisions of section 95 A
of the MHAD Act. mutatis mutandis shall apply for the purpose of getting
the tenements vacated from the non-co-operative members.
b) For redevelopment of buildings in any existing Housing Scheme of
MHADA under clause 2.2 hereinabove, by MHADA, the consent of the
Cooperative Housing Society in the form of a valid Resolution as per the
Co-operative Societies Act, 1960 will be sufficient. In respect of members
not co-operating as per approval of the redevelopment project, action
under section 95(A) of the Maharashtra Housing and Area Development
Act, 1976 may be taken by MHADA.
8) A corpus fund, as may be decided by MHADA, shall be created by the
Developer which shall remain with the Co-operative Housing Societies for
the maintenance of the new buildings under the Rehabilitation
Component.
9) The Redevelopment proposals where NOC has been issued by Mumbai
Board or Offer Letter has already been issued prior to the date of coming
into force of this Regulation (hereinafter referred to as the "appointed
date") and which is valid as on the appointed date, shall either continue
to be governed by the Regulation under which the proposal is approved
or the proposal may be converted under this regulation, subject to
fulfillment of the provisions of this regulation applicable.
10) Convenience Shopping shall be permitted along layout roads with
12m 9m to 18m width.
11) (a) In case of layout of MHADA where development is proposed
under this Regulation and where such land is observed to be partially
occupied by slum, under section 4 of Slum Act existing prior to 1.1.2000
or such other reference date notified by the Govt., then for integrated
development of the entire layout area and in order to promote flexibility,
MHADA may propose development, including area occupied by the slum,
under this regulation.
(b) (i) Each eligible residential or residential cum commercial slum
dweller shall be entitled to a tenement of carpet area of 25.00 sq. m
(269 sq. ft.) and
(ii)Existing or max 20.90 sq. m whichever is less in case of non-residential
(c) If such land occupied by slum is observed to be affected by
reservation then the development of reservation on land occupied by
slum shall be regulated by the Regulation No 17(3)(C)
(d) Corpus fund: An amount of Rs.40000 or as may be decided by SRA as
per Regulation No 33(10) shall be deposited with MHADA Authority for
each eligible slum dwellers.
(EP-77)
33(6) Reconstruction of buildings destroyed by fire or which have collapsed
or which have been demolished under lawful order or which is being
demolished voluntarily by the owner: .
Reconstruction of buildings that existed on or after 10th June 1977 and
have ceased to exist for reasons cited above, shall be allowed to be
reconstructed with FSI not exceeding that of the original building as per
the Regulation No 30(C). This FSI will be subject to the following
conditions: -
Reconstruction of the new building on the plot should conform to provisions
of DP and these Regulations.
Reconstruction will be subject to an agreement executed by at least 70 per
cent of the landlord/occupants (if any) in the original building, within the
meaning of the Mumbai Rents, Hotel and Lodging House Rates Control
Act, 1947, and such agreement shall make a provision for accommodation
and re-accommodate the said landlord/all occupants in the new building
on agreed terms and a certificate from a practicing advocate having
minimum of 10 years’ experience, is submitted confirming that on the
date of application, reconstruction, agreements are executed by at least
70% of the landlords/occupants (if any) in the original building with the
developer/owner. The Advocate shall also certify that the agreements
with occupants are valid and subsisting on the date of application. copy of
such agreement shall be deposited with the Corporation before
commencing reconstruction of the new building.
The Carpet area of residential/non-residential premises may be altered with
the consent of occupants shall remain unaltered.
Reconstruction shall be disallowed on set-back areas or areas required for
road-widening and such areas shall be handed over to the Corporation.
These provisions shall not apply to buildings wholly occupied by warehouses
and godowns.
If the building is reconstructed with existing FSI/BUA prior to its
collapse/demolition, then the requirements of front & marginal open
spaces shall be as per the Regulation No.41(5) of these Regulations.
Notwithstanding anything contained in these Regulations, the other
relaxation incorporated in Regulation No. 33(10) of these Regulations
except clause 6.11, 6.15, 6.16 & 6.18 shall apply. The payment of premium
at the rate of 25% of normal premium or at the rate of 6.25% of the land
rates as per ASR (for FSI 1), whichever is more shall apply.
If the existing FSI is less than the permissible FSI then the owner may opt for
development up to permissible FSI by availing TDR/Additional FSI on
payment of premium as per Regulation 30.
7. If the building is reconstructed by using Zonal (basic) FSI/permissible FSI,
the following shall apply:
a) Requirements of open spaces shall be as per Regulation nos. 41(1) and
41(2)
b) Premium at the normal rate for area covered under Regulation No. 31(1) &
31(3) beyond the existing FSI/BUA shall be applicable.
8. Provision of Inclusive Housing as per Regulation No.15 shall have to be
made in case of 7 10 above, if applicable.
(EP-78)
33(7) Reconstruction or redevelopment of cessed buildings in the Island City
by Co-operative Housing Societies or of old buildings belonging to the
Corporation:
(1) A. For reconstruction/redevelopment to be undertaken by same or
different landlords or Co-operative societies of landlords and Cooperative
Housing Societies (existing or proposed) of existing tenants or by Co-op.
Housing Societies of landlords and/or occupiers of a cessed building
existing prior to 30/9/1969 in Island City, which attracts the provisions of
MHAD Act, 1976 and for reconstruction/redevelopment of the buildings of
Corporation existing prior to 30.09.1969, FSI shall be 3.00 on the gross
plot area or FSI required for rehabilitation of existing tenants plus
incentive FSI as specified in sr. no 5(a) below whichever is more.
B. Provided further that reconstruction/redevelopment undertaken by
proposed Co-operative Housing Society of occupiers of buildings existing
prior to 30.09.1969, which were earlier “A” category cessed buildings and
were attracting the provisions of MHAD Act, 1976 but thereafter due to
purchase/acquisition of the same by Co-operative Housing Society of
Occupiers, such buildings are exempted from payment of cess and which
have been declared unsafe by BHAD Board/MCGM, the FSI required for
rehabilitation of existing occupier plus incentive FSI as specified in Sr. no
5(c)below will be available.
(2)1. (a) The new building may be permitted to be constructed in pursuance
of an irrevocable written consent by not less than 70% 51% of the occupiers
of the old building.
(b) All the eligible occupants of the old building of cessed and non-cessed
building/structures (existing prior to 30.09.1969) certified by MBRRB, existing on
the plot having cessed building only, shall be re-accommodated in the
redeveloped building.
2. Each occupant shall be rehabilitated and given the carpet area occupied by
him for residential purpose in the old building subject to the minimum fixed
carpet area of 27.88 sq. m (300 sq. ft.) and/or maximum carpet area up to 70
120 sq. m (753 1292 sq. ft.) as provided in the MHAD Act, 1976. In case of
non-residential occupier, the area to be given in the reconstructed building
will be equivalent to the area occupied in the old building. Provided that if
carpet area for residential purpose exceeds 70 120 sq. m (753 1292 sq. ft.) the cost
of construction for the area over and above 70 120 sq. m shall be paid by tenant
/occupant to the developer. The cost of construction shall be as per ASR of that year.
However, the carpet area exceeding 70 120 sq. m (753 1292 sq. ft.) shall be
considered for rehab FSI but shall not be considered for incentive FSI. Provided
further that each eligible residential cum commercial occupant shall be entitled to a
tenement of minimum carpet area of 27.88 sq. m (300 sq. ft.).
3 The list of eligible occupants and area occupied by each of them of cessed and
non-cessed building/structures (existing prior to 30.09.1969) in the old cessed
building shall be certified by the Mumbai Repairs and Reconstruction Board
and the irrevocable written consent as specified in 1 (a) above shall be
certified verified by the Board.
4. Tenements in the reconstructed building shall be allotted by the
landlord/occupants' co-operative housing society to the occupiers as per the
list certified by the Mumbai Repairs and Reconstruction Board. The
prescribed percentage of the surplus BUA as provided in the Table in the
Third Schedule of the MHAD Act, 1976, shall be made available to the
Mumbai Repairs and Reconstruction Board for accommodating the occupants
in transit camps or cessed buildings which cannot be reconstructed, on
payment of an amount as may be prescribed under MHAD Act, 1976.
Further in case of reconstruction/redevelopment of the buildings of
Corporation existing prior to 30.09.1969 as per this Regulation, the BUA
beyond area required for re-accommodation of existing occupants and
incentive thereon of such rehab area if any shall have to be shared between
MCGM and Society of occupants in the ratio of 1(MCGM): 0.5(Society of
occupants),
Fungible FSI Compensatory Area as applicable on the surplus area to be
handed over to MHADA/MCGM shall not be allowed to be utilized on sale
component. No premium shall be charged on the fungible compensatory area
in respect of area to be handed over to MHADA/MCGM and surplus area to
be handed over to MHADA/MCGM shall be exclusive of the Fungible
compensatory BUA if availed.
Provided that the area equivalent to the market value (as per ASR of that
year) of area admissible as per the prescribed percentage of BUA to MHADA
can be made available within the same or adjoining municipal ward of
MCGM.
5. The FSI for rehabilitation of existing tenants/occupiers in a reconstructed
building and incentive FSI that will be available shall be as under:
(a) In the case of redevelopment of cessed building existing prior to
30/9/1969 undertaken by same or different landlords or Co-operative
societies of landlords and Co-operative Housing Societies (existing or
proposed) of existing tenants and/or occupiers, the total FSI shall be 3.00
of the gross plot area or the FSI required for rehabilitation of existing
occupiers plus 50% incentive FSI whichever is more.
(b) In case of composite redevelopment undertaken by same or different
landlords or Co-operative societies of landlords and Co-operative Housing
Societies (existing or proposed) of existing tenants and/or occupiers
jointly of 2 or more plots but not more than 5 plots with cessed buildings
existing prior to 30/9/1969, the FSI permissible will be 3.00 or FSI required
for rehabilitation to exiting occupiers plus 60% 65% incentive FSI,
whichever is more and the occupier shall be eligible for 5% additional
rehab Carpet Area as per serial no 2(2) above subject to maximum limit.
Provided further, that if the number of plots jointly undertaken for
redevelopment is six three or more with cessed buildings existing prior to
30/9/1969, the incentive FSI available will be 3.00 or FSI required of
rehabilitation for occupiers plus 70% incentive FSI whichever is more and
the occupier shall be eligible for 10% additional rehab Carpet Area as per
serial no 2(2) above subject to maximum limit.
Provided further that, the above provision 5(b) shall also be applicable to
municipal plots under redevelopment under this Regulation having
different residential societies on different plots.
Provided further that in case of redevelopment of municipal properties
under this regulation having eligible tenements more than 600 in numbers
the govt. may consider higher incentive.
(c) In case redevelopment undertaken by Co-operative Housing Society of
occupiers of building, which was earlier “A” category cessed building but
thereafter due to purchase/acquisition by Co-operative Housing Society of
Occupiers, it was exempted from payment of cess and which has been
declared unsafe by BHAD Board/MCGM, Provided further that
reconstruction/redevelopment undertaken by proposed Cooperative
Housing Society of occupiers of buildings existing prior to 30/9/1969 in
Island City, which were earlier cessed building and were attracting the
provisions of MHAD Act, 1976 but thereafter due to purchase/acquisition
of the same by Cooperative Housing Society of Occupiers, such buildings
are exempted from payment of cess, the total FSI shall be 2.5 of the gross
plot area or the FSI required for rehabilitation of existing occupiers plus
50% incentive FSI whichever is more.
6. The entire FSI available under clause 5 shall be allowed to be utilised on
plot/plots under redevelopment scheme. However, if the owner/society so
desire, they can avail the incentive FSI on the same plot or can avail the
benefit of TDRs to be used in in accordance with the Regulations no. 32.
7. Construction or reconstruction of old cessed building falling under
reservation/zones contemplated in the DP shall be permitted as follows
specified in Regulation No.17(3)(B).
(a) Redevelopment/reconstruction in any zone shall be allowed to be
taken in site without going through the process of change of zone. For the
Industrial user the existing segregating distance shall be maintained from
the existing industrial unit.
(b) Any plot/layout having area under non-buildable/open space
reservations admeasuring only up to 500 sq. m shall be cleared by shifting
the existing tenants from that site. Where the area of reservation, either
independently located or in cluster, is more than 500 sq. m such sites may
be allowed to be redeveloped in accordance with this Regulation subject to
the condition that the area of the land so used shall not be more than 67%
of the reservation, leaving 33% rendered clear thereafter for reservation&
shall be handed over to MCGM.
(c) In any plot having reserved/designated open space of more than of 500
sq. m and which is vacant beyond the land component of existing cessed
structure as per Zonal (basic) FSI shall have to be developed as per
provisions of Regulation no 30.
(d) Existing cessed structures on lands reserved for Municipal School (RE 1.1)
or Primary and Secondary School (RE1.2) or Higher Education (RE2.1) may
be redeveloped subject to the following:-
(i) In case of land reserved for Municipal School (RE 1.1) or Primary and
Secondary School (RE1.2) in the DP, a building for accommodating such
number of students as may be decided by the Municipal Commissioner,
not in any case for less than 500 students, shall be constructed by the
owner or developer at his cost according to the size, design,
specification and conditions prescribed by the Municipal Commissioner.
The BUA occupied by the constructed building shall be excluded for the
purpose of FSI computation, and where it is intended for a Municipal
School (RE 1.1) or Primary and Secondary School (RE1.2) the building or
part thereof intended for the school use shall be handed over free of
cost and charge to the Corporation. Thereafter, the land may be allowed
to be redeveloped with the full permissible FSI of the plot according to
this Regulation.
(ii)In the case of lands affected by reservation for Higher Education (RE2.1)
in the DP, a building of accommodating such number of students as may
be decided by the Municipal Commissioner, not in any case for less than
800 students, shall be constructed by the owner or developer according
to the size, design, specification and conditions prescribed by the
Municipal Commissioner, the built-up area occupied by the constructed
building shall be excluded for the purpose of FSI computation. The
constructed building shall be handed over to the Corporation free of
cost and charge and the Municipal Commissioner may hand over the
same or part thereof intended for the School use to a recognized and
registered educational institution for operation and maintenance on
terms decided by him. Thereafter the land may be allowed to be
redeveloped with full permissible FSI of the plot according to this
Regulation
(iii) In case area under reservation of Municipal School (RE 1.1), or Primary
and Secondary School (RE1.2) or Higher Education (RE2.1) is spread on
adjoining plot and the plot under development, then in such cases
Commissioner with special permission may insist upon construction of
Municipal School (RE 1.1) or Primary and Secondary School (RE1.2) or
Higher Education (RE2.1) in proportion to the area under reservation
affecting the plot under development.
(iv)Requirements of Play Ground as per regulation no 38(I) (2) of these
regulations may not be insisted upon for (i), (ii) and (iii) above.
(e) In case of the plot reserved for Parking Lot, 100% BUA as per Zonal (basic)
FSI of such reserved area shall be handed over to the MCGM.
(f) For other buildable reservations except (d) & (e) above, BUA equal to 25
per cent of the area under reservation in that plot, shall be made available
free of cost for the MCGM or for any other Appropriate Authority.
The developer/owner shall be entitled for BUA in lieu of cost of
construction against handing over of built up amenity as per Note (d) of
Regulation 17(1).
(g) Not withstanding anything contained in these Regulations, site of existing
cessed structures on lands reserved/designated for Rehabilitation &
Resettlement (RR2.1) shall be treated as sites for development of cessed
structures and shall be allowed for redevelopment according to this
Regulation.
(h)Contravening structures in TP Scheme and structures on the road shall also
be included in the redevelopment scheme. FSI for the same will be as under
DCR 33(12) or as provided in these Regulations whichever is more.
8. Relaxation in building and other requirements for rehabilitation:
Notwithstanding anything contained in these Regulations, the relaxations
incorporated in sub Regulation No.6 of Regulation No. 33 (10) of these
Regulations except clause 6.11, 6.15, 6.16 & 6.18 shall apply. The payment of
premium at the rate of 25% of normal premium or at the rate of 6.25% of the
land rates as per ASR (for FSI 1), whichever is more shall apply.
Even if the amenity open space (LOS) is reduced to make the project viable a
minimum of at least 10% of open space shall be maintain.
9. 20% of the incentive FSI can be used for non-residential purposes
otherwise permissible in the DCPR.
10(a) In case of redevelopment scheme in progress and such schemes where
LOI has been issued, the Owner/Developer/Co-op. Housing Society may
convert with the prior approval of Vice President and Chief Executive Officer,
Maharashtra Housing and Area Development Authority, Authority as decided by
Govt. may convert the proposal in accordance with modified regulations, only
regarding size of tenements and loading of FSI, in-situ. However, such
conversion is optional and shall not be binding and further subject
ascertaining and due verification of redevelopment scheme in progress by
Vice President and Chief Executive Officer, Maharashtra Housing and Area
Development Authority .
Provided that in case of building of Corporation, the conversion with
approval of Municipal Commissioner subject to ascertaining and due
verification of redevelopment scheme.
(b) In case of redevelopment of buildings undertaken by MHADA, where
construction is in progress, whether the area of new tenement should be
20.90 sq. m or otherwise the question shall be decided by MHADA in each
case.
However, if area of tenements is not increased to 20.90 sq. m then
development will have to be carried out as per approved plan and FSI.
11. FSI under these Regulations should be allowed by the Commissioner only
after Mumbai Repairs and Reconstruction Board is satisfied that the said
redevelopment proposal fulfills all conditions to be eligible for the benefits
under these regulations.
12. In case of the redevelopment of cessed buildings, the concessions
regarding exclusion of areas from computation of FSI for general buildings
stipulated in Regulation No. 31(1) shall apply.
13. Since the permissible FSI in clause 5 above is dependent upon the number
of occupiers and the actual area occupied by them, no new tenancy created
after 13.6.1996 or date as decided by GoM from time to time shall be
considered. Further unauthorized constructions made in the cessed buildings
shall not be considered while computation of existing FSI. However, the
occupier may be allowed to declare whether the tenement is residential or
non-residential.
14. For smooth implementation of the redevelopment scheme undertaken by
owners and/or Co-operative Housing Society of the occupiers, temporary
transit camps may be permitted on the same land or land situated elsewhere
belonging to the same owner/developer with the concessions permissible
under SRS project under Regulations 33(10) of these Regulations. Such transit
camps should be demolished within one month from the date of occupation
certificate granted by the Corporation for the reconstructed buildings for the
existing tenants/occupants.
15.Additional development cess equivalent to 100% of Development charges
on BUA (including excluding the fungible FSI compensatory area/BUA), or Rs
5,000 per sq. m whichever is more for BUA over and above the Zonal (basic)
FSI existing BUA shall be paid by the owner/developer/society, for the
rehabilitation and free sale components. This amount shall be paid to the
Corporation in accordance with the time schedule for such payment as may
be laid down by the Commissioner, MCGM provided the payment of
installments shall not go beyond the completion of construction. This amount
shall be used for Scheme to be prepared for the improvement of off-site
infrastructure in the area around the development. These infrastructural
charges Development cess shall be in addition to development charges levied
as per section 124 of MR&TP Act 1966.
16. As per the provision of clause 2 above, each residential/non-residential
occupant shall be rehabilitated only for carpet area mentioned in the said
clause No.2 above and such areas shall be clearly shown on the building plan
submitted to the Corporation/MHADA.
17. A corpus fund shall be created as prescribed by MHADA.
18. Restriction on transfer of tenements shall be governed by provision of
Rent Control Act till Co. Op. Society is formed and after that the same shall
be governed by the provision of Maharashtra Co-op. Society’s Act.
19. Non-Deduction of non-cessed Structure area in the scheme of 33(7) for
FSI purpose: In case of mix of the structure i.e. cessed & non cessed structure
and if the area of non cessed structure existing prior to 30/9/69, area of land
component under non-cessed structure works out up to a limit of 25% of plot
area, then FSI shall be considered on total plot area. If this area exceeds 25%
of the total area, then area above 25% shall be deducted from plot area. FSI
for deducted area shall be as per Regulation No 30 and the FSI for the
remaining plot area shall be as per 33(7). Provision of clause no 2 above shall
not be made applicable to non-cessed occupier.
20. (a) In case of layout of MCGM owned plots/ Municipal plot where development is
proposed under this Regulation and where such land is observed to be partially
occupied by slum, under section 4 of Slum Act existing prior to 1.1.2000 or such other
reference date notified by the Govt., then for integrated development of the entire
layout area and in order to promote flexibility, MCGM may propose development,
including area occupied by the slum, under this regulation.
MCGM shall be the Planning Authority for the areas declared as slum under section 4
of Maharashtra Slum Area (Improvement) Act, 1971 on Municipal land existing prior
to 01.01.2000 or date as notified by Govt., wherein slum area do not constitute more
than 50% of the plot area under redevelopment.
(b) (i) Each eligible residential or residential cum commercial slum dweller shall be
entitled to a tenement of carpet area of 25.00 sq. m (269 sq. ft.) and
(ii)Existing or max 20.90 sq. m whichever is less in case of non-residential.
(c) If such land occupied by slum is observed to be affected by reservation then the
development of reservation on land occupied by slum shall be regulated by the
Regulation No 17(3)(D)
(d) Corpus fund: An amount of Rs.40000 or as may be decided by SRA as per
Regulation No 33(10) shall be deposited with MCGM for each eligible slum dwellers
(EP-79)
33(7)(A) Reconstruction or redevelopment of dilapidated/unsafe existing
authorized tenant occupied building in Suburbs and extended Suburbs and
existing authorized non-cessed tenant occupied buildings in Mumbai City.
For reconstruction/redevelopment of existing authorized tenant-occupied
buildings, which have been declared unsafe for human habitation by or are to be
demolished for the same reason under a lawful order by the Municipal Corporation
of Greater Mumbai and duly certified as such, undertaken by landlord/s or Co-
operative Housing Societies of existing tenants, the permissible FSI prescribed under
these regulations and Appendix below, shall be admissible as under: -
a) In case of the plot consisting of only tenant occupied building, the F.S.I. shall
be equal to F.S.I. required for rehabilitation of existing lawful tenant plus 50%
incentive F.S.I.
b) In case of composite development i.e. the plot consisting of tenant occupied
building along with non-tenanted building such as owner occupied building/existing
Co-op Housing Society buildings etc., the FSI available shall be equal to FSI required
for rehabilitation of existing lawful tenant plus 50% incentive FSI plus FSI that has
already authorisedly been utilized/consumed by the non-tenanted
buildings/structures.
Appendix
1. The F.S.I. permissible for the new building shall be as given in sub-regulation (7)
(A) of Regulation No.33
2. (a) A new building may be permitted to be constructed in pursuance of an
irrevocable written consent by not less than 70 51 per cent of the tenants of the
old building.
(b) All the tenants of the old building shall be re-accommodated in the redeveloped
building.
3. Each tenant shall be rehabilitated and given the carpet area occupied by him for
residential purpose in the old building subject to the minimum fixed carpet area of
27.88 sq. m (300 sq. ft) and/or maximum carpet area up to 70 sq. m (753 sq. ft) free
of cost. In case of non-residential occupier the area to be given free of cost in the
reconstructed building shall be equivalent to the area occupied in the old building.
Provided that if carpet area for residential purpose exceeds 70.00 sq. m (753
sq. ft.) the cost of construction shall be paid by tenant to the developer. The cost of
construction shall be as per ready reckoner rate of that year. However, the carpet
area exceeding 70.00 sq. m (753 sq. ft.) shall be considered for rehab FSI but shall not
be considered for incentive FSI. Provided further that each eligible residential cum
commercial occupant shall be entitled to a tenement of minimum carpet area of
27.88 sq. m (300 sq. ft.).
4. No new tenancy created after 13/6/96 shall be considered. Further, unauthorized
construction made in buildings for creating new tenancy in the existing tenancies
shall not be considered while doing computation of existing FSI. A certified inspection
extract of the Municipal Corporation for the year 1995-96 or Court Order proving the
existence of tenements prior to 13/6/96 shall be considered adequate evidence to
establish the number of tenements. However, the Govt. may issue comprehensive
guidelines for determination of eligibility of occupiers and tenants therein.
5. The list of tenants and area occupied by each of them in the old building and the
irrevocable written consent as specified in 2 (a) above shall be certified by the
Municipal Corporation of Greater Mumbai.
6. The tenements in the reconstructed building shall be allotted by landlord/s or Co-
operative Housing Societies of existing tenants to the tenants as per list certified by
the Municipal Corporation of Greater Mumbai.
7. The entire FSI available under this regulation shall be allowed to be utilized on
plot/plots under redevelopment scheme.
8. Reconstruction of a new building on the plot should strictly conform to the
provisions of the development plan and these Regulations.
9. No construction or reconstruction shall be permitted on set-back areas or areas
required for road-widening and such areas shall be handed over to the Municipal
Corporation
10. For the purpose of calculating the FSI for tenanted building, the entire area of
the plot/layout including Development Plan roads and internal roads but excluding
the land under the reservation of public amenities shall be considered.
11. New building shall be reconstructed in accordance with these Regulations and all
other Regulations and orders as applicable from time to time. The Municipal
Commissioner may exercise his powers under Regulation No 6 for condonation of
minor variations in respect of such reconstruction.
12. 20% of the incentive FSI can be used for non-residential purposes otherwise
permissible as per the DCPR.
13. The fungible compensatory area admissible on rehab component shall be
granted without charging premium and such fungible compensatory area for
rehabilitation component shall not be used for free sale component and shall be used
to give additional area over and above eligible area to the existing tenants .
14. For smooth implementation of the redevelopment scheme undertaken by
landlord/s or Co-operative Housing Societies of existing tenants, temporary transit
camps may be permitted on the same land or land situated elsewhere belonging to
the same landlord/s with the concessions permissible under SRS project under
Regulations 33(10) of these Regulations. Such transit camps should be demolished
within one month from the date of occupation certificate granted by the Corporation
for the reconstructed buildings.
15. An amount of Rs.5000/- per sq. m shall be paid by the landlord/s or Co-operative
Housing Societies of existing tenants, as additional development cess for the built-up
area over and above the F.S.I. permissible as per table 12 under Regulation 30, for
the rehabilitation and free sale components. This amount shall be paid to the
Municipal Corporation in accordance with the time schedule for such payment as
may be laid down by the Municipal Commissioner, MCGM, provided the payment of
instalments shall not go beyond the completion of construction. This amount shall
be used for Scheme to be prepared for the improvement of off-site infrastructure in
the area around the development. The above development cess shall be enhanced @
10% every three years.
16. As per the provision of clause 3, each residential/non-residential tenant shall be
rehabilitated only for carpet area mentioned in the said clause 3 and such areas shall
be clearly shown on the building plan submitted to the Municipal Corporation.
17. The landlord/s or Co-operative Housing Societies of existing tenants shall
commence the reconstruction or redevelopment work within the period of one year
from the date of demolition of the building and complete it within a period of five
years. In the meantime the landlord/s or Co-operative Housing Societies of existing
tenants shall make arrangement of alternate accommodation of tenants.
18. A corpus fund is to be created by the landlord/s or Co-operative Housing
Societies of existing tenants which will take care of the maintenance of the building
for a period of 10 years.
19. Restriction on transfer of tenements shall be governed by provision of Rent
Control Act till Co. Op. Society is formed and after that the same shall be governed by
the provision of Maharashtra Co-Op. Society’s Act.
20. The State Government/ Municipal Commissioner shall prescribe the guidelines
for better implementation of the scheme in respect of model agreement, alternate
accommodation of existing tenants, eligibility criteria for tenants etc. separately.
21. If the rehab plus incentive as per this regulation is less than the
permissible FSI as per regulation 30, then the owner may opt for
development up to permissible FSI by availing TDR/Additional FSI on payment
of premium as per Regulation 30.
(EP-80)
33(7)(B) Additional FSI for Redevelopment of existing residential housing
societies excluding cessed buildings:
In case of redevelopment of existing residential housing societies excluding cessed
buildings proposed by Housing societies/land lords or through their proponents
where existing members are proposed to be re-accommodated on the same plot,
incentive additional BUA to the extent of 15% of existing BUA or 10 sq. m per
tenement whichever is more shall be permissible without premium. FSI for
redevelopment of such existing residential buildings shall be as follows:
1.Incentive Additional BUA in lieu of cost of construction of authorized existing BUA
= 1.50 (Rate of construction per sq. m as per ASR rate /Rate of developed land per sq.
m as per ASR (for FSI 1)) *(authorized existing built up area+ area of the balcony if
claimed free of FSI as per then prevailing regulation)
Provided further that if the existing authorized BUA and incentive thereon as per
stated above i.e. incentive Additional BUA is less than the permissible FSI 2.0 as per
regulation 30(A)(1), then society shall first may avail ‘Additional FSI on payment of
premium/TDR’ up to limit of permissible FSI of 2. If the existing authorized BUA and
incentive thereon as per above i.e. incentive Additional BUA is more than the
permissible FSI 2.0, then society shall be eligible for incentive additional BUA in lieu
of cost of construction of authorized existing BUA, which exceeds the permissible FSI
of 2. However, this proviso shall not be applicable to redevelopment of building
falling under Regulation No 45, in which case, the full incentive additional BUA in
lieu of cost of construction of authorized existing BUA will be available in the form of
TDR.
2. If staircase, lift & lift lobby areas are claimed free of FSI by charging premium as
per then prevailing Regulation, then such areas to that extent only will be granted
free of FSI without charging premium. If staircase, lift & lift lobby areas are counted
in FSI in earlier development, then incentive additional FSI as stated in Sr. No 1 shall
also be given on such area & such areas may be availed free of FSI by charging
premium as per these Regulations.
3. This Regulation shall be applicable only when existing members of the societies are
proposed to be re-accommodated & where authorized existing BUA is more than
Zonal (basic) FSI as per then prevailing Regulations.
4. This regulation will be applicable for redevelopment of existing authorized
buildings which are of thirty years of age or more.
5.This regulation shall not be applicable in respect of redevelopment proposal to
be/being processed under Regulation No 33(5), 33(7), 33(8), 33(9), 33(9)(A),33(9)(B),
33(10), 33(10) (A), 33(20) (A), 33(21).
Explanation: -Age of a building shall be as on the 1st of January of the year in which a
complete redevelopment proposal is submitted to the Commissioner and shall be
calculated from the date of Occupation Certificate or alternately, from the first date
of assessment as per the property tax record in respect of such building or building
on which balance/admissible FSI has been consumed by way of vertical extension as
per then prevailing Regulation, available with the MCGM.
6. This incentive additional BUA shall be independent of additional BUA as
permissible under Regulation No 14(A), 15, 16 and 17, if any.
7. Fungible compensatory area admissible under Regulation No. 31(3) on the existing
authorised BUA shall be without charging premium and also be allowed over the
incentive additional BUA by in lieu of cost of construction of authorized existing BUA
& existing authorised BUA without charging of premium.
8. The in situ FSI on any plot after development under this Regulation shall not
exceed 4 in any case. Unconsumed BUA under this Regulation due to planning
consideration and site constraint can be allowed in the form of TDR under the
provisions of these Regulations. In such cases the potential of the plot shall be
perpetually restricted to the extent of consumed BUA under this Regulation.
9. If tenanted building/s and building/s of co-operative housing society/non-tenanted
building/s coexist on the plot under development, then proportionate land
component as per the existing authorised BUA of existing tenanted building on the
plot shall be developed as per Regulation No 33(7)(A) and remainder notional plot
shall be developed as per this Regulation.
(EP-81)
33(8) Construction for Rehabilitation & Resettlement:
For the construction of the building by the Corporation/Appropriate
Authority in the category of Rehabilitation & Resettlement for the purpose of
the housing those who are displaced by the projects undertaken by the
Corporation/Appropriate Authority for implementation of proposals of the
DP/MUTP/MUIP, the FSI shall be 4.00
Such additional FSI will not be available when owner undertakes
development as per Regulation No. 17.
33(8) Construction of Affordable Housing in Special Development Zone II
(SDZ II)
(A) General
The provision of this Regulation shall apply to any contiguous, unbroken and
uninterrupted piece of land, not less than 1.0 2.0 ha, and not disqualified from
development, on account of other laws or regulations that are binding. Owners of
land parcels having plot area lesser than 1 2 ha may come together to create
contiguous land parcels of 1ha or more & submit proposal for development under this
Regulation along with proper access as per these Regulations. However, the proposal
shall be submitted with prior approval of Govt.
(B) Planning Considerations /Submission of Proposal
The proposal shall be submitted by the Owner, containing the demand assessment
for infrastructure such as roads, water supply, sewerage and storm water drains
along with clearly earmarking the area for Public Open Spaces (POS), Affordable
Housing (AH), Other Amenities (OA), (viz. Education, Health & Social Amenities) and
area for other development i.e. owners share of land. If OA/POS/AH to be handed
over to MCGM is not abutting the municipal road, the same shall be provided with
uninterrupted access as per table no 7 of Regulation No 23(1). The area of the land
after deduction of the area covered under road/uninterrupted access proposed as
above, shall be apportioned among Owner’s Share, AH, POS, and OA as detailed
below. These roads/uninterrupted access shall be handed over to MCGM and will be
eligible for additional BUA equal to area of land surrendered/transferred over and
above FSI as stipulated below in Sr. No. D
Sr. Affordable Public Open Other Area for
No Housing Spaces Amenities Other
Plot Area Development
1 Not less than 1 ha & 30% 15 % 16% 39%
up to 2 ha
2 More Not less than 30% 15 % 14% 41%
2 ha & up to 4 ha
3 More than 4 ha 30% 15 % 12% 43%
The Owner shall submit his proposal as per above to the Commissioner MCGM. While
making such submission, he will take care of the following:
(a) He shall distinctly mark lands for AH, POS, OA and Owner’s share in the layout.
Further earmarking of lands for other amenities like education, health and social
amenities cited above shall be done by the Commissioner taking the amenity
standards prescribed as minimum.
(b) Advance possession of all lands other than the Owner’s Share as detailed in the table
above shall be handed over to MCGM at the time of approval of layout. The
ownership shall be transferred in the name of MCGM within one year from the date
of advance possession or seeking commencement certificate beyond plinth of the
development of Owner’s share, whichever is earlier.
(c) The Land Owner shall have the option of developing AH, OA and handing them over
to the MCGM. However, area earmarked for POS, AH, OA shall be levelled along with
construction of compound wall before handing over to MCGM.
(d) The development of AH & OA shall be as per specifications laid down by the
Commissioner, within three years from date of approval to the individual building
plans of AH and OA, unless extended by the Commissioner for valid, recorded
reasons.
(e) Provision of amenities as per Regulation No. 14(A) and 15 shall not be applicable for
development under this Regulation.
(f) The carpet areas of the tenements to be constructed shall be for EWS, LIG and MIG
or as decided by Govt. from time to time subject to a minimum 25 sq. m.
(g) The proposal under this Regulation shall be considered with the approval of the
Municipal Commissioner.
(h) Requirement of LOS as per the provisions of Regulation No.27 on AH plot and
owner’s share of land shall be 15%. Thus overall 25% cumulative LOS of entire
holding shall be achieved by considering POS to be handed over to MCGM and
owners share of land/AH plot.
(C)Infrastructure Development
The owner shall develop the infrastructure network within the layout (AH, POS & OA)
to be handed over to MCGM (road + water supply mains + sewer line + storm water
drain + street lights pertaining to that specific scheme) as per the requirements of the
concerned departments.
(D)Permissible FSI
(a) If the Owner opts out of the responsibility of developing AH & OA, he will get FSI 1.0
of the gross plot (AH + POS+OA + area covered under road to be handed over to MCGM
+ land forming Owner’s share of that specific scheme) on the Owner’s share of land.
(b)If the Owner opts to develop the cited AH & OA, the Owner shall be entitled for FSI 1
of the gross plot (AH + POS+ OA + area covered under roads to be handed over to
MCGM + land forming Owner’s share of that specific scheme) on the Owner’s share of
land along with cost of construction in the form of BUA as per Clause (E) (a)
(c)The Owner would also be compensated for all infrastructure developed by him that is
not attributable to infrastructure pertaining to Owner’s share of land and construction
of the AH tenements & OA as described below.
(d)The Development of the plot handed over for AH shall be with FSI 2.5 on the plot of
the AH area. The Development of the plot handed over for OA shall be with FSI 2 on the
plot of OA with the structural provision for vertical extension for consumption of FSI up
to 4 on OA plot. AH Tenements & constructed amenities shall have to be handed over to
MCGM. The cost of construction of AH tenements & built up amenities shall be paid in
the form of BUA.
(e)‘TDR’ or ‘Additional FSI on payment of premium’ as per Regulation No 30 (1) (A)
[except Fungible Compensatory area as per Regulation No. 31(3)], shall not be
permissible on Owner’s share of land.
(f)The land handed over to MCGM for OA as stated above shall not be allowed to be
developed under AR as stipulated in Regulation No 17 and shall have to be used entirely
for the intended purpose as per these Regulations.
(g)Notwithstanding anything contained in these Regulations, residential/commercial
uses otherwise permissible, independent of road width to which it abuts shall be
permissible on the Owner’s share of land. 15% of admissible FSI on SH AH plot shall be
exclusively used for the purpose of convenient shops for use of residential occupants of
layout.
(h)Development charges and premium shall not be recovered for any relaxations in
open spaces, exclusion of staircase, lift and lobby areas from FSI computation & for
Fungible compensatory area as per Regulation No. 31(3) for BUA to be handed over to
MCGM.
(i)Development cess at 7% of the Land Rate (for FSI 1) for the BUA (excluding fungible
compensatory area) to be constructed on owner’s share of land as per ASR of the year
of approval shall be paid to MCGM. The Development cess shall be in addition to
development charges levied as per section 124 of MR&TP Act 1966.
(E)Compensation for development of infrastructure in lands handed over to MCGM
and constructed BUA.
a) The owner shall be entitled for the following:
BUA in lieu of cost of construction of 2.0[Rate of construction per sq. m as
AH/Built up Amenities including entire per ASR rate/rate of developed land
infrastructure development for MCGM = per sq. m as per ASR (for FSI 1)]x BUA
share of Land of all amenities & all SH AH
b) The ratio of BUA to carpet area shall be considered as 1.2 (including provisions of
various requirements as per these Regulations).
c) Area covered under staircase/lift/staircase and lift lobby for SH AH
tenements/Amenities shall not be counted in FSI/BUA and shall be without charging
premium.
d) Commencement Certificate beyond 75 % of the admissible BUA shall not be issued
unless the infrastructure development in the entire layout and construction of AH
tenements/Amenities is completed & occupation is granted.
e) The Commencement Certificate beyond 75 % of the admissible BUA may be released
once the Occupation Certificate for AH tenements/Amenities is granted.
f) BUA in lieu of development of infrastructure and construction of AH
tenements/Amenities, as detailed above may be released in proportion of 0.50 sale
(incentive) area: 1 AH/Amenity area and the construction shall progress
simultaneously in the said proportion, and 100% of incentive area in lieu of AH
tenements/Amenities& infrastructure development can be released only after
handing over of entire AH tenements/Amenities as per (e) above.
g) FSI on owner’s share of land shall be restricted to 4 only. TDR in lieu of unconsumed
incentive BUA, as per provision (a) above in proportion to handing over of such
completed AH tenements/Amenities may be allowed at the option of
owner/developer. However, 20 % of such admissible TDR for unconsumed BUA shall
be released only after handing over the entire area of AH tenements/Amenities to
MCGM.
(EP-82)
(B) Land of Govt. /Semi. Govt. /Appropriate Authority appointed by Govt. falling in
SDZII
1. General
Notwithstanding anything contained in these Regulations for lands of Govt./Semi-
Govt./Appropriate Authority falling in SDZ II, the provision of this Regulation shall
apply to any contiguous, unbroken and uninterrupted piece of land having area not
less than 1.0 2.0 ha, and not disqualified from development on account of other
laws or regulations that are binding.
2. Planning Considerations /Submission of Proposal
The proposal shall be submitted containing the demand assessment for infrastructure
such as roads, water supply, sewerage and storm water drains along with clearly
earmarking the area for Public Open Spaces (POS), Affordable Housing (AH), Other
Amenities(OA), (viz. Education, Health & Social Amenities) and area for other
development i.e. Govt./Semi-Govt./Appropriate Authority’s share of land. If OA/POS
to be handed over to MCGM and AH are not abutting the municipal road, the same
shall be provided with uninterrupted access as per table no 7 of Regulation No 23(1).
The area of the land after deduction of the area covered under road/uninterrupted
access proposed as above, shall be apportioned among Govt./Semi-
Govt./Appropriate Authority’s Share, AH, POS, and OA as detailed below. These
roads/uninterrupted access shall be handed over to MCGM and will be eligible for
additional BUA equal to area of land as surrendered/transferred over and above FSI
as stipulated below in Sr. No. 4
Sr. Affordable Public Open Other Area for
No Housing Spaces Amenities Other
Plot Area Development
1 Not less than1 ha & 30% 15 % 16% 39%
up to 2 ha
2 More Not less than 2 30% 15 % 14% 41%
1 ha & up to 4 ha
3 More than 4 ha 30% 15 % 12% 43%
The Govt./Semi-Govt./Appropriate Authority shall submit their proposal as per
above to the Commissioner MCGM. While making such submission, they will take
care of the following:
a) Govt./Semi-Govt./Appropriate Authority shall distinctly mark lands for AH, POS,
OA and Govt./Semi-Govt./Appropriate Authority’s share in the layout. Further
earmarking of lands for other amenities like education, health and social amenities
cited above shall be done by the Commissioner taking the amenity standards
prescribed as minimum.
b) Advance possession of all lands other than the Govt./Semi-Govt./Appropriate
Authority’s Share and AH plot as detailed in the table above shall be handed over to
MCGM at the time of approval of layout. The ownership shall be transferred in the
name of MCGM within one year from the date of advance possession or seeking
commencement certificate beyond plinth of the development of Govt./Semi-
Govt./Appropriate Authority’s share, whichever is earlier. The Govt./Semi-
Govt./Appropriate Authority may opt for development of the AH plot on their own as
stated in clause 4(b) below.
c) Govt./Semi-Govt./Appropriate Authority shall hand over area earmarked for POS &
OA after levelling of land along with construction of compound wall to MCGM.
d) Provision of amenities as per Regulation No. 14(A) and 15 shall not be applicable
for development under this Regulation.
e) The carpet areas of the tenements to be constructed shall be for EWS, LIG and MIG
or as decided by Govt. from time to time subject to a minimum 25 sq. m.
f) The proposal under this Regulation shall be considered with the approval of the
Municipal Commissioner.
g) Requirement of LOS as per the provisions of Regulation No.27 on AH plot and
Govt./Semi-Govt./Appropriate Authority’s share of land shall be 15%. Thus overall
25% cumulative LOS of entire holding shall be achieved by considering POS to be
handed over to MCGM and owners share of land/AH plot.
3. Infrastructure Development
Govt./Semi-Govt./Appropriate Authority shall develop the infrastructure network
within the layout (AH, POS & OA) to be handed over to MCGM (road + water supply
mains + sewer line + storm water drain + street lights pertaining to that specific
scheme) as per the requirements of the concerned departments.
4. Permissible FSI:
a) Govt./Semi-.Govt. /Appropriate Authority appointed by Govt. shall be eligible for
FSI 1 of the gross plot (AH + POS+ OA + area covered under roads to be handed over
to MCGM) on area of other Development.
b) The plot earmarked for AH shall may be developed by Government/semi-
government/ Appropriate Authority appointed by Govt. with FSI 2.5 on the plot of
AH, then the premium for the BUA is payable at 60% of land rate as per ASR (for FSI
1) except if the undertaken by State Govt. & MCGM itself. These tenements shall be
made available for general public for the AH as per policy of Govt.
c) The development of OA as per the requirements of MCGM shall be permissible as
per these Regulations. Provided further that Municipal Commissioner’s decision
regarding development of OA shall be final & binding.
d) ‘TDR’ or ‘Additional FSI on payment of premium’ shall not be permissible except
fungible compensatory area.
e) The land handed over to MCGM for OA as stated above shall not be allowed to be
developed under AR as stipulated in Regulation No 17 and shall have to be used
entirely for the intended purpose as per these Regulations.
f) Notwithstanding anything contained in these Regulations, residential/commercial
uses otherwise permissible, independent of road width to which it abuts shall be
permissible on the Govt./Semi-Govt./Appropriate Authority’s share of land. 15% of
admissible FSI on AH plot shall be exclusively used for the purpose of convenient
shops for use of residential occupants of layout
g) Development cess at 7% of the Land Rate (for FSI 1) for the BUA (excluding
fungible compensatory area) to be constructed on Govt./Semi-Govt./Appropriate
Authority’s share of land as per ASR of the year of approval shall be paid to MCGM.
5. Interchanging the location:
The Appropriate Authority may interchange the location of land earmarked as AH +
POS + OA in DP with equivalent developable land area under their ownership either
in contiguity or in parcels of land not less than 0.5 ha.
(EP-83)
33(9) Reconstruction or redevelopment of Cluster(s) of Buildings under Urban
Renewal Cluster Development Scheme(s)(CDS):
For reconstruction or redevelopment of Cluster(s) of buildings under Urban
Renewal Scheme(s) Cluster Development Scheme(s)(CDS) in the Island City of
Mumbai undertaken by (a) the MHADA or the MCGM either departmentally
or through any suitable agency or (b) MHADA/MCGM, jointly with land
owners and/or Co-op. Housing Societies of tenants/occupiers of buildings
and/or Co-op. Housing Society of hutment dwellers therein, or (c) land
owners and/or Co-op. Housing Society of tenants/occupiers of buildings
and/or Co-op Housing Society of hutment dwellers, independently or through
a Promoter /Developer, the FSI shall be 4.00 or the FSI required for
rehabilitation of existing tenants/occupiers plus incentive FSI whichever is
more as per the provisions of this Regulation as follows .
1.1 Urban Renewal Scheme" (URS) Cluster Development Scheme(CDS) means
any scheme for redevelopment of a cluster of buildings and structures over a
minimum area of 4000 sq. m in the Island City of Mumbai and 10000 sq. m in
the Mumbai Suburbs & Extended Suburbs, bounded by existing distinguishing
physical boundaries such as roads, nallas and railway lines etc. and accessible
by an existing or proposed D.P. road which is at least 12 18 m wide whether
existing or proposed in the D.P. or URP or a road for which Sanctioned
Regular line of street has been prescribed by the MCGM under MMC Act,
1888. Such cluster of buildings (hereinafter referred to as "Urban Renewal
Cluster or (URC) Cluster Development(CD)” shall be a cluster or a group of
clusters identified for urban renewal:
1) Under the Urban Renewal Cluster Development Plan (URP CDP) for the
concerned area, to be prepared by the Commissioner, who may revise the
same as and when required; or
Under the Development Plan (DP), where the DP contains such well-defined cluster
2) By the Promoter of the URS CDS,
Provided that no cluster or clusters shall be identified for redevelopment or
implementation of URS CDS by the Municipal Commissioner without carrying
out an Impact Assessment Study regarding the impact on the city and sector
level infrastructure and amenities as well as traffic and environment of the
implementation of URS CDS on such cluster or clusters.
Explanation:
1. The land under URS CDS, irrespective of the tenure of the plots comprised
therein, shall be treated as one plot for the purpose of FSI and computation of
marginal distances.
Amalgamation/ Subdivision of plots: On approval of CDS, any land
proposed / considered under CDS on various C.S. Nos. or CTS Nos.
and/or F.P. Nos. shall be treated as natural amalgamation for the
purpose of CDS. for which no separate approval for amalgamation of
lands would be necessary.
Boundaries and Area of Proposed CDS shall be decided as per the
approved layout and be confirmed by City Survey Officer after actual
measurement of CDS on site and the same shall be adopted for
planning purpose. However wherever necessary, the area may be
further subdivided to earmark separate plots/Sectors for the planning
purpose, handing over of Reservations, amenities, realigned roads, etc.
to MCGM/ Appropriate Authority. The Plot area and the BUA in
terms of sq. m of the said subdivided plots/Sectors shall be separately
mentioned in the Conveyance Deed or lease deed. In case of land of
different tenures, single PRC shall not be insisted. However, necessary
entries about CDS shall be made in respective PRC.
(EP-84)
In specific cases where URS CDS is not bounded by roads, nallas and railway lines,
the boundary of the Cluster may be decided by the Municipal Commissioner.
1.2 The URC CD may consist of a mix of structures of different characteristics such
as
(i) Cessed buildings in Island City, which attract the provisions of MHAD Act,
1976.
(ii) (a) Buildings at least 30 years of age and acquired by MHADA under MHAD
Act, 1976.
(b) Authorized buildings at least 30 years of age
Explanation: Age of a building shall be as on the 1st of January of the year in which
redevelopment proposal for URS CDS is submitted to the Commissioner and shall
be calculated from the date of occupation certificate or where such occupation
certificate is not available, from the first date of assessment as per the property tax
record in respect of such building, available with the Municipal Corporation.
(iii) (a) Buildings belonging to the Central Govt, the State Govt, Semi-Govt
Organizations and the MCGM, as well as institutional buildings, office buildings,
tenanted municipal buildings and buildings constructed by MHADA, that are at
least 30 years of age.
(b) Any land belonging to the State Govt, any semi-Govt Organization, MCGM and
MHADA (either vacant or built upon) which falls within the area of the proposed
URS CDS including that which has been given on lease or granted on the tenure of
Occupant Class II.
Provided that in case of buildings or lands belonging to the Central Govt, the State
Govt, Semi-Govt Organizations, MCGM or MHADA, prior consent of the concerned
Department shall be obtained for including such buildings or lands in any proposal
of URS CDS.
(iv) Other buildings which by reasons of dis-repair or because of structural/sanitary
defects, are unfit for human habitation or by reasons of their bad configuration or
the narrowness of streets are dangerous or injurious to the health or safety of the
inhabitants of the area, as certified by the Officer or the Agency designated for this
purpose by MHADA/MCGM or Mumbai Repair & Reconstruction Board.
(v) Slum areas declared as slums under section 4 of Slum Act or slums on Public
lands existing prior to 1.1.2000 or such other reference date notified by the Govt,
provided such slum areas do not constitute more than 50% of the area of URC CD.
Explanation: If some areas are previously developed/or are in the process of
development under different provisions of the DCPR, such areas can be included in
the URS CDS only for planning purposes. However, such areas shall be excluded for
calculation of FSI under this Regulation and the admissible FSI shall be calculated as
per the relevant provisions of the DCPR under which such areas are developed or are
being developed. However, it shall be necessary to obtain consent of owner/owners
of such areas for becoming part of the URS CDS.
2. Eligibility of Occupants for Rehabilitation under Urban Renewal Scheme
(URS) Cluster Development Scheme(CDS)
(A) For Buildings:
i. No new tenancy created after 13/6/96 or date as decided by Govt. from time to
time shall be considered. Further, unauthorized construction made in buildings for
creating new tenancy in the existing tenancies shall not be considered while doing
computation of existing FSI. A certified inspection extract of the Municipal
Corporation for the year 1995-96 or Court Order proving the existence of tenements
prior to 13/6/96 or date as decided by Govt. from time to time shall be considered
adequate evidence to establish the number of tenements. However, the Govt. may
issue comprehensive guidelines for determination of eligibility of occupiers and
tenants therein.
ii. The list of occupants and the area occupied by each of them in municipal buildings
and their irrevocable written consents shall be certified by the MCGM. The list of
occupants in other buildings excluding slums and the area occupied by each of them
and their irrevocable written consents as specified in clause 4(a) shall be certified by
the MBRRB.
iii. Notwithstanding anything contained in these regulations, mezzanine floors having
clear height of 1.8 m. and above Mezzanine floors constructed prior to 13/06/1996
and regularized subsequently shall be eligible for rehabilitation and incentive FSI.
(B) For Slum Areas:
i. All the protected Occupiers as defined in Chapter IE of Slum Act and orders issued
thereunder and certified by competent authority thereof.
ii. A structure shall mean all the dwelling areas of all persons who are enumerated
as living in one numbered house in the electoral roll of the latest date, up to 1st
January 2000 or such other reference date Notified by the Govt. and regardless of
the number of persons, or location of rooms or access.
3. Land pooling for the URS CDS:
The Promoter of URS CDS shall try to pool lands belonging to various categories
of land holders including Public lands by obtaining their consent for including
their lands in the proposed URS CDS, by resorting to any of the following methods
of land pooling:
1) Purchase of lands, including buildings, if any, standing thereupon,
Provided that if the Promoter wishes to include any building or land belonging to the
State Govt. or MCGM or MHADA or any Agency under the control of State Govt.
(hereinafter collectively referred as "Public Authority"), then he shall make a written
request in this regard through the Municipal Commissioner to an Empowered
Committee (EC) headed by the Chief Secretary. This EC shall be as formulated by
GoM.
The EC shall examine the request made by the Promoter in terms of the desirability
of making the land belonging to a Public Authority available for URS CDS and would
decide the terms of transfer of such land to the Promoter for the purpose of
implementing URS CDS. In case the land sought by the Promoter belongs to an
Authority created by or under a statute, the decision of the EC shall be subject to
ratification/approval by such Authority.
2) Exchange of such land with a suitable land of at least equivalent value as per
ASR land rates.
3) Procurement of DRs over such land, by way of registered document by the
Promoter, provided that the area over which the Promoter holds DRs shall be
regarded as one plot for all the purposes of the DCPR; or
4) Transfer of all lands included in the URS CDS to a legal entity (e.g: Registered
Society or Company, Co-operative Housing Society, Charitable Trust, etc.) to be
created by the Promoter for implementing the URS CDS where different landholders
have stakes proportionate to their share in the total land under URS CDS; or
5) Acquisition of lands, provided the Promoter has purchased or procured DRs over
at least 70% land comprised in the URC CD and there are dangerous buildings,
declared as such by the Competent Authority, on the balance lands contained in the
URC CD. In such a situation, the Promoter may approach the HPC for recommending
the proposal to the Govt. for acquisition of such balance lands. Upon receipt of such
request, the HPC may, after due examination, recommend to the Govt. as to which
lands are required to be acquired for the purposes of URS CDS. The Govt., thereafter,
shall take necessary steps to acquire such balance lands under the provisions of the
relevant law and transfer the same to the Promoter only for the purpose of
implementing URS CDS after executing an agreement with him in this regard, subject
to the Promoter depositing with the Govt. necessary amount of money for the land
acquisition. For the purpose of land acquisition, URS CDS shall be regarded as public
purpose.
4. a) Redevelopment or Reconstruction under URS CDS may be permitted in
pursuance of an irrevocable registered written consent by not less than 51 percent of
each building or 70 percent overall of the scheme of the eligible tenants/occupiers of
all the authorized buildings on each plot involved in the URS CDS or as provided in
MHAD Act, 1976. Consent as aforesaid of such 51 percent of each building and 70%
overall of the scheme of tenants/occupiers for reconstruction or redevelopment shall
not be required, if MHADA/MCGM undertakes redevelopment, on its own land,
directly without any developer.
(EP-85)
The Developer shall be required to submit along with the URS CDS proposal, proof of
ownership or procurement of DRs in respect of at least 70% of the land under the
proposed URS CDS (excluding Municipal Roads if maintained as existing in proposed
URS CDS) and it shall be mandatory for him to submit such proof of ownership or
procurement of development rights in respect of the balance area within one year
from the date of issue of the LOI.
b) All the eligible occupants/tenants of the building(s) undergoing redevelopment
shall be rehabilitated in the redeveloped building(s).
5. Conditions of Rehabilitation:
(i) Each occupant/tenant shall be rehabilitated and given on ownership basis, carpet
area equivalent to the area occupied by such occupant/tenant in the old building.
However, in case of residential/residential cum commercial occupants, such carpet
area shall not be less than 27.88 sq. m. This shall be the “basic area”.
In addition to (i) above, there shall be ‘’additional area’’ for the rehabilitation of
residential/residential cum commercial Occupants governed by the size of the URC
CD in accordance with the Table-A below
Table-A
Area of the Urban Renewal Cluster Cluster Additional Area (over & above basic
Development area)
Above 1 ha up to 2 ha 15%
Above 2 ha up to 5 ha 20%
Above 5 ha up to 10 ha 25%
Above 10 ha 30%
Provided that if the carpet area of any occupant/tenement in the old building
is 100 sq. m or more then he shall be eligible for additional area only on the basis of
carpet area of 100 sq. m
Provided further that the above provision of "Additional Area" shall be
applicable only in case of URS CDS having maximum FSI of 4.00.
Provided further that the rehabilitation entitlement of any occupant of a
commercial establishment, who is allowed by the HPC to be rehabilitated in a
residential tenement in lieu of his commercial establishment, shall also be governed
by the aforesaid provisions applicable to the residential occupants in these
Regulations. No occupant shall be given more carpet area than basic area +
additional area, except in certain cases of planning constraints, where the Municipal
Commissioner may allow marginally more area. Such additional area allowed due to
planning constraints shall be deducted from the sale component without affecting
the surplus area.
a) Each eligible residential or residential cum commercial slum dweller shall be
entitled to a tenement of carpet area of 25.00 sq. m (269 sq. ft.) and
(b)Existing or max 20.90 sq. m whichever is less in case of non-residential.
6. Total Permissible FSI for URS CDS:
a) The total permissible FSI for an URS CDS shall be 4.00 on gross plot area, but
excluding the reservations/designations, road set back, area under existing Municipal
Roads but including the BUA under reservation/designation, road set back or sum
total of the Rehabilitation FSI + Incentive FSI, whichever is more.
Provided that the aforesaid FSI shall be exclusive of the Fungible FSI Compensatory
area admissible under the provision of DCR 31(3).
b) The incentive FSI admissible against the FSI required for rehabilitation shall be
based on the ratio (hereinafter referred to as Basic Ratio) of Land Rate (LR), in Rs/sq.
m., of the lands included in the URC; as per the ASR and Rate of Construction (RC)* in
Rs/sq. m, applicable to the area as per the ASR and shall be given as per the Table-B
below:
Table-B
Basic Ratio Incentive (As % of Admissible Rehabilitation Area)
(LR/RC)*
For 0.4ha up to 1 More than 1 More than 5 ha For more
ha ha up to 5 ha up to 10 ha. than 10 ha
Above 6.00 55% 60% 65% 70%
Above 4.00 65% 70% 75% 80%
and up to
6.00
Above 2.00 75% 80% 85% 90%
and up to
4.00
Up to 2.00 85% 90% 95% 100%
Explanation: -
(i) *RC is rate of construction in respect of RCC Construction and Land Rate (LR) is the
rate of Open Land for FSI 1.
Provided further that in case there is more than one land rate applicable to
different parts of the plot under the URS CDS, a weighted average of all the
applicable rates shall be taken for calculating the Average Land Rate and the Basic
Ratio.
Provided further that for calculation of the Basic Ratio, the Land Rate (LR) and
the Rate of Construction (RC) shall be taken for the year in which the Cluster
Development Project is approved and LOI is issued by the Authority competent to
approve it and the said ratio shall remain unchanged even if such Scheme undergoes
any revision or modification subsequently during its course of completion.
Provided further that if any new area is allowed to be added to or deleted
from the URS CDS after such Scheme has been approved and if there is change in the
slab prescribed above, the incentive FSI for the total area of the revised Scheme shall
be determined as per the new slab. Provided further that any new area being added
to a URS CDS shall not be less than 75% of the minimum area required for URS CDS.
Provided further that augmentation of area of URC CD shall not be allowed
after further CC has been issued in respect of more than 75% of the total permissible
BUA sanctioned under the original Scheme and there shall be no revision of
individual areas as a result of such amalgamation of area. However, deletion of area
from a sanctioned scheme will be permissible, provided the construction of
rehabilitation component has not commenced and such deletion does not break the
contiguity of the area under URS CDS.
c) If the total of rehabilitation FSI + incentive FSI is less than 4.00, then the Balance FSI
over and above total of "rehabilitation FSI + incentive FSI" as per (b) above up to the
limit of 4.00 shall be shared in terms of BUA between MHADA and the
Promoter/Developer in accordance with Table-C below:
Table-C
Basic Ratio Sharing of Balance FSI
(LR / RC)* Promoter/Developer Share MHADA Share
Above 6.00 30% 70%
Above 4.00 and 35% 65%
up to 6.00
Above 2.00 and 40% 60%
up to 4.00
Up to 2.00 45% 55%
Provided that at the option of or with the approval of MHADA, the tenements
coming to the share of MHADA can also be provided by the Promoter/Developer
elsewhere within the same or adjoining Municipal Ward as per the following formula:
Area of tenements coming to MHADA's share at location 'B' in URS CDS = Area of
tenements coming to MHADA's share at location 'A' in URS CDS X land rate as per
ASR value of location 'A'/ land rate as per ASR value of location 'B'
Where location 'A' refers to the location where tenements coming to MHADA's share
under the Scheme are required to be given.
Location 'B' is the new location where such tenements are allowed to be given.
Provided further that the tenements so received by MHADA under its share shall first
be offered free of cost to the MCGM and MMRDA for use as PAP tenements or as
transit accommodation. If the MCGM and MMRDA do not require such tenements
for PAP's or as transit accommodation, then the tenements received under its share
shall be used by MHADA for PAPs or Transit Accommodation or shall be sold as AH
with prior permission of the Govt.
e d)"tolerated structures" encroaching upon roads in nearby vicinity shall be allowed
to be included in the URS CDS and its BUA shall be included in rehabilitation area,
provided such structures are permanently removed.
Explanation: The term "tolerated structure" means structure used for residential or
non-residential purpose and existing prior to 17th April 1964 or 1st April 1962
respectively or date as decided by Govt.
f e) It shall be permissible to implement the sanctioned URS CDS in phases provided
the area of URC CD is more than 8000 sq. m (2 acres) and the development in each
phase is strictly in conformity with the Master Plan/Layout Plan approved for the
entire URS CDS.
Subject to the master plan for the whole cluster being followed, phase wise
implementation of URS CDS may be allowed, with pro rata utilization of the total
admissible FSI.
Provided further that, while giving permission for phased implementation of the URS
CDS, the time frame for implementation of each phase shall also be given.
The minimum area for each phase shall be 4000 sq. m.
Provided further that, while giving permission for phased implementation of URS
CDS, the incentive FSI as per Table-B shall be first released as per the area of the plot
under a given phase and the balance incentive FSI shall be released while giving
approval to the last phase.
7. From the total FSI available under Clause 6, entire FSI towards rehabilitation
component and MHADA's share shall have to be utilized on plot/plots under the
Scheme. In case a part of incentive FSI is not proposed to be utilized on the same
plot, the benefit of TDR as per Regulation No 32 shall be given. However, the
quantum of TDR shall be governed by the following formula.
Incentive FSI at location 'B' in URS CDS
= Incentive FSI at location ‘A’ in URS CDS X ASR value of Land at location ‘A’/ASR
value of Land at location ‘B’
Where, location ‘A’ refers to the location where incentive FSI in URS CDS is
generated.
Location ‘B’ is the new location where such incentive FSI is to be utilized.
8. Development of DP Reservations:
Construction or reconstruction of slums/buildings falling under Reservations
contemplated in the DP shall be permissible as under- stipulated in the Regulation
No.17(3)(C)(I)
a. Redevelopment/reconstruction in any zone shall be allowed to be undertaken
without going through the process of change of zone. However, for the industrial
user, the existing segregating distance shall be maintained from the existing
industrial unit.
b. Any land under non-buildable/open space reservations, admeasuring up to
500 sq. m may be cleared by shifting the existing tenants from that site.
c. If the area under a non-buildable/ open space reservation is more than 500
sq. m, minimum 50% of the area under reservation shall be developed for the same
purpose and handed over to MCGM, subject to a minimum of 500 sq. m and the
remaining land shall be allowed for development.
d. All the reservations in the DP shall be rearranged, if necessary, with the same
area and the same width of access road or as required under DCR, whichever is more.
e. For the reservation of parking lot on a land included in URC, BUA equivalent
to Zonal (basic) FSI for the area under reservation in that plot shall be made available
free of cost to the MCGM or to any other Appropriate Authority. Such BUA to be
handed over shall be free of FSI.
f. For other buildable reservations on land, BUA equal to 60% of the Zonal (basic) FSI
under such reservations or existing BUA of the amenity(designation) whichever is
more, on that plot shall be made available free of FSI and free of cost to the MCGM
or the Appropriate Authority. The reservations of compatible nature can be
preferably constructed in one or more separate blocks, depending on the area and
nature of such reservations and Municipal Commissioner may permit composite
development of reservations in case of such reservations. However, if the
HPC/Planning Authority requires BUA under any designation/reservation in excess of
the Zonal (basic) FSI, then such excess area shall be considered as rehabilitation FSI,
and incentive FSI as admissible under this Regulation shall be permissible.
Provided that in case of development of reservations of Rehabilitation &
Resettlement under the URS, BUA equal to 30% of the Zonal (basic) FSI shall be
handed over to the MCGM free of FSI and free of cost, in addition to the
rehabilitation of the existing tenements or users if any.
The developer/owner shall be entitled for BUA in lieu of cost of construction
against handing over of built up amenity as per Note (d) of Regulation No. 17
(1) ),
(EP-86)
g a. Where a proposed DP Road or Regular line of street passes through the URS CDS
area, the entire FSI admissible under this Regulation for the area of the road may be
given in the same Scheme.
The location of and the area under DP road/ existing roads falling in the URS CDS may
be allowed to rearranged based on the comprehensive traffic study without affecting
the continuity of the existing traffic movement and without reducing the total area of
the existing road & DP Road. The existing roads may be realigned or relocated as per
provisions of MMC Act.
h b. No premium shall be charged for the fungible compensatory area FSI admissible
as per Regulation 31(3) for rehabilitation component of an URS CDS as sanctioned by
HPC and for the tenements to be handed over to MHADA and for the areas of
reservation to be handed over to MCGM/Appropriate Authority. This fungible
compensatory area FSI admissible to the rehabilitation tenements shall be utilized for
rehabilitation component only. Its utilization for Sale Component under the URS shall
not be permissible.
9. 30% of the incentive FSI can be used for non-residential purposes as otherwise
permissible under the DCR.
10. A Surcharge on Development cess at the rate of 100% of Development Charge,
subject to a minimum of Rs 5000 per sq. m. for BUA over and above the Zonal (basic)
FSI existing BUA (including excluding fungible compensatory area/BUA), for the
rehabilitation and free sale component, shall be leviable in respect of any URS CDS
by the MCGM and in accordance with the time schedule for such payment as may be
laid down by the Commissioner. These infrastructural charges Development cess
shall be in addition to development charges levied as per section 124 of MR&TP Act
1966.
This surcharge development cess shall not be applicable to the BUA to be handed
over to the MCGM or any Public Authority in lieu of reservation or to the amenity
areas to be handed over to the MCGM as per the requirement indicated by the
MCGM or the HPC.
11. Temporary transit camps may be permitted in the same URC CD or elsewhere in
MCGM limits on land belonging to the Promoter/Developer up to 4.00 FSI with the
concessions permissible under SRA Scheme under Regulation 33(10). Such transit
camps shall have to be demolished after full occupation certificate is granted to the
Rehabilitation Component by the Corporation for the reconstructed building. Till the
transit camps are fully demolished, the Commissioner shall not release FSI for the
free sale area under the URS CDS in excess of 75% of the total admissible Incentive
FSI.
12. Non-conforming Activities: All activities which are existing shall be allowed to be
re-accommodated regardless of the non-conforming nature of such activities
excepting those that are hazardous and highly polluting and those where alternative
accommodation has to be provided elsewhere by the Promoter/Developer/MCGM.
13. Relaxation in Building and other requirements:
In case of tenements of 27.88 sq. m Carpet area for rehabilitation or tenements to be
given to MHADA, towards its share and the BUA to be handed over to the Planning
Authority/Appropriate Authority, the following shall be applicable.
13.1 Calculation of FSI for all purposes shall be on gross area of the URS CDS.
Provision of ROSLOS, to be kept on the site as per prevailing D.C. Regulations.
13.2 Notwithstanding anything contained in Regulation No.31(1), areas of common
passages not exceeding 2.00 m in width, provided for giving access to the tenements
in rehabilitation component and the tenements to be handed over against
reservation and MHADA component shall not be counted towards FSI.
13.3 Front and marginal open spaces, for a building having height up to 32.0 m. in the
rehabilitation component or a composite building, shall be 3.0 and 4.5 m
respectively.
Provided that for a building having height more than 32.0 m and up to 70 m, open
space of the width of 6 m at least on one side at ground level within the plot,
accessible from the road side shall have to be maintained for the maneuverability of
a fire engine, unless the building abuts two roads of 6 m or more on two sides, or
another access of 6 m to the building is available, apart from the road abutting the
building.
13.4 Notwithstanding the provisions in Regulation No 41 (Table No 18) where the
location of the URC CD plot abuts a DP Road having width of 18.3 m and above. The
front marginal open space shall not be insisted upon beyond 3.0 m provided such
road is not an Express Highway or a road wider than 52 m.
13.5 Where the location of the URC CD plot abuts a trained nallah, the marginal open
space along the nallah shall be 4.5 6.0 m from the edge of the trained nallah,
13.6 The distance between any two rehabilitation buildings up to 32 m height shall
not be less than 6.00 m
13.7 If the height of any building constructed under URS CDS is more than 32.0 m,
marginal open space shall be as per the Regulation No 41(5).
13.8 A composite building under URS CDS shall have at least 50 percent of BUA as
rehabilitation component.
13.9 Wherever more than minimum front and marginal spaces have been provided,
such additional area provided may be considered wherever necessary, as part of the
AOS under the URS CDS comprising both rehabilitation and free sale components,
without charging any premium, in relaxation of the stipulation in Regulation No. 27.
13.10 The means of access shall be normally governed by the provisions of
Regulation No. 23 However, in the URS CDS, wherever the design of the buildings up
to 32.0 m height requires relaxation in the width of access, the same may be given.
However, high rise buildings shall be permissible as per Regulation No 19.
13.11 Even if the ROSLOS is reduced to make the project URS CDS viable, at least 10
percent of URC CD plot area shall be provided as ROSLOS. In addition, 10 percent of
URC CD plot area shall be earmarked for ROSLOS which can be adjusted against the
DP reservation/land component of built up amenity, to be handed over to MCGM, if
any, existing on such plot.
13.12 Premium shall not be charged for exclusion of staircase and lift well etc. as
covered under the provisions of Regulation 31(1)
13.13 In order to make the URS CDS viable, the Municipal Commissioner shall be
competent to sanction any relaxation in marginal open spaces except front marginal
open space and parking requirements wherever necessary due to bonafide hardship,
for reasons to be recorded in writing which shall not affect general health, fire and
safety requirements. However, the Govt. shall have the power to relax any of the
provisions in these Regulations.
13.14 All relaxations outlined hereinabove shall be admissible only in respect of the
rehabilitation component and the composite buildings under the URS CDS. Premium
shall not be charged for all or any of the relaxations given hereinabove or for any
other relaxations mentioned in Regulation No 31(1). Provided that if any further
relaxation in open spaces is granted by Municipal Commissioner then the same shall
be subject to compliance of CFO requirement and recovery of premium at the rate
2.5% of ASR.
If any relaxation in open spaces except front open space in sale component is granted
by Municipal Commissioner, then the same shall be subject to compliance of CFO
requirement and recovery of premium at the rate 2.5% of ASR.
14. The approving/sanctioning authority for the building plans under the URS CDS
shall be the Municipal Commissioner as per the MMC Act and MRTP Act, 1966 even if
the URS CDS partly consists of declared slums/slums on Municipal/ Govt. lands
existing prior to 1st January 2000 or such/other reference date notified by the
Government.
15. Religious structures existing on the site of URS CDS prior to redevelopment, if
allowed to be redeveloped in accordance with the guidelines issued by the Govt from
time to time, shall not, following such redevelopment, have area exceeding their area
prior to redevelopment.
16. Restriction on transfer of tenements shall be governed by provisions of
Maharashtra Rent Control Act, till such time that a Co-op. Housing Society is formed
and thereafter the same shall be governed by the provision of Maharashtra Co-op.
Societies Act. However, tenements constructed for slum rehabilitation shall not be
transferable for a period of 10 years.
17. Corpus Fund: An amount of minimum Rs 50,000/- per tenement or as directed by
the HPC shall be created by the Promoter/Developer as a Corpus fund, which will be
utilised for maintenance of the rehabilitation buildings for a period of 10 years.
18. Any ongoing scheme under Regulation 33(7) which fulfills the criteria under this
Regulation can be included in the proposal under Regulation 33 (9) for approval or
converted into a URS CDS under this Regulation 33(9). However, all dilutions of
reservations under Regulation 33(7) shall have to be restored as per this Regulation.
19, Heritage buildings of Grade-I and II as well as authorized and structurally sound
retainable buildings may be included in the URC CD, but shall have to be kept as they
are, along with land appurtenant, and this area shall be counted towards the slab of
Incentive FSI, but shall not be considered for FSI under this Regulation. As regards
such Heritage Structures, the Promoter/Developer shall have to contribute Heritage
Cess at 5% of ASR on the basis of BUA of the Heritage structure. Existing provisions
under the DCPR shall apply to Heritage Buildings of Grade-III and buildings in heritage
precincts. However, if the URS contains Grade I structure, the HPC shall consult the
MHCC before granting approval.
20. If HPC approves areas for amenities such as Fire Stations/Hospitals/Police
Stations/Schools, etc. other than reservations/designations under the DP, such
amenities shall be handed over to the concerned Authority free of cost. The BUA of
such amenity shall be considered towards rehabilitation FSI, and incentive FSI as
admissible under this Regulation shall be permissible.
21. HPC, headed by Municipal Commissioner and shall be constituted by the Govt.,
which shall be competent to approve the URS CDS with the previous sanction of the
Govt under this Regulation. On approval by HPC, the proposal shall be submitted to
the Municipal Commissioner, MCGM for approval of plans. The decision of HPC shall
be appealable as if it is an appeal under section 47 of the MR&TP Act, 1966.
Provided that no URS CDS shall be sanctioned by the Govt HPC without giving due
regard to the Impact Assessment study referred to in clause 1.1 above.
22. Regardless of its area, any Cluster Renewal Scheme (CRS) for which LOI has been
issued under Regulation 33(9) of DCR 1991 prior to the date of coming into force of
this Regulation can be allowed to be converted by the Commissioner in toto as per
this Regulation at the request of the Promoter/Developer, with the prior approval of
the State Govt.
(EP-87)
Provided that:
a) For the purpose of calculation of Basic Ratio, as specified in Clause 6(b) above, the
land rate (LC) and the Rate of construction (RC) shall be taken for the year in which
such CRS was approved and LOI was issued by the competent authority.
b) The surcharge on development leviable on such CRS after its conversion under this
regulation, shall be calculated in accordance with the date on which the development
cess had been paid and shall be recovered before issuing CC after the conversion of
the Scheme. Any excess amount paid towards Development Cess shall be adjusted
against any other charges due, but shall not be refunded.
c) Conversion of such CRS, as which has not had been sanctioned by the Govt. earlier,
shall not require Govt. approval. and it shall be within the competence of the HPC to
permit conversion of such CRS.
Provided further that after the coming into force of this Regulation, land pooling and
the development of buildable reservations and construction of Transit Camps in the
CRS approved prior to the coming into force of this Regulation may be done as per
the provisions of this Regulation, if the same has not been completed so far, even
where such CRS has not been converted to be developed as per this Regulation.
33 (9) (A) Regulations for Dharavi Notified Area (DNA)
Urban Renewal Scheme under Dharavi Redevelopment Project (DRP):
Areas undertaken by SRA under DRP for renewal and redevelopment of
buildings/chawls including cessed buildings situated on non-slum areas within DNA,
shall be a part of the entire DRP Area which shall have an overall FSI of 4.00. The
entitlement of FSI on that particular plot shall be 4.00 or the FSI required for
rehabilitation of existing tenants/occupiers plus incentive FSI and would be in
accordance with the guidelines laid down below.
1) Applicability of the provisions:
For achieving comprehensive planning and development of non-slum areas of DNA
through sectoral layouts of DRP, the provisions in this Regulation shall apply to the
renewal and redevelopment of buildings/chawls including cessed properties and
such schemes on areas which are part of DRP Area undertaken by DRP (SRA) through
a developer. The properties which are not part of DRP Area as defined above shall be
developed in accordance with DCR 30.
2) Renewal & Redevelopment project formulated by SRA for buildings/chawls
including cessed properties shall be with FSI of 1.72 or the FSI required for
rehabilitation of existing eligible occupants, whichever is more. This shall exclusively
be used for rehousing existing eligible occupants and for generating additional
tenements/units. The BUA of such construction with 1.72 FSI or more shall be
termed as RRC
3) (a) If areas redeveloped earlier under SRD/SRA schemes are included in the DRP
Area for renewal and redevelopment under DRP, the TDR generated from the plot in
the said SRD/SRA scheme would be deducted from overall calculation of FSI 4.00.
(b) For private unencumbered plot/s situated within DNA but presently excluded,
the FSI shall be 4.00 on their inclusion in DRP. The developer however, shall have to
pay premium as decided by DRP on BUA equivalent to 2.67 FSI of that plot upon
which he could go up to BUA equivalent to 4.00 FSI in his free sale component.
4) The construction of RRC will be carried out by the developer so appointed under
DRP at his cost as per the specifications, planning and requirements of DRP (SRA).
Each eligible occupant shall be rehabilitated and given the carpet area occupied by
him for residential purpose in the old building subject to the minimum fixed carpet
area of 27.88 sq. m (300 sq. ft.) and maximum area equivalent to the area occupied
in the old building. The carpet area up to 70 sq. m shall be part of RRC and shall be
provided free of cost. However, area above 70 sq. m will be at construction cost to be
determined by OSD, DRP (SRA) and the said cost to be paid by the respective
occupant to the developer. Such surplus residential renewal area shall not qualify for
calculating incentive RSC.
In case of non-residential occupier, the area to be given will be equivalent to the area
occupied in the old building. The renewal tenements in the so completed buildings
shall be handed over to the respective eligible occupiers of the old building as
certified by the concerned Competent Authority free of encumbrances.
“Planning Sector” and “Implementing Sector” will have the same meaning as defined
in the Regulation No 33(10)(A).
5) Eligibility for Renewal Rehab Tenements:
For URS, the existing tenants/occupants residing as on 1st January, 2000 shall be
considered eligible. A certified inspection extract of the MCGM for the year 1999-
2000 or Courts Order proving the existence of tenements prior to 1.1.2000 shall be
considered adequate evidence to establish number and size of tenements. No new
tenancy/occupancy created after 1.1.2000 shall be considered. Further unauthorized
construction made in buildings/chawls, and unauthorized extensions to the
tenements shall not be considered for any computation.
6) (a) An area equal to 13.33 sq. m BUA as Renewal Sale Component(RSC) shall be
made available against the RRC of 10 sq. m for disposal in the open market. RSC can
be clubbed with Slum Sale Component and Amenity Sale Component generated
under DCR 33(10) (A) within the same planning sector.
(b) If the FSI required for rehabilitation of existing eligible occupants plus RSC
exceeds FSI 4.00 of a particular plot, such excess quantum shall get absorbed while
calculating overall FSI of 4.00 on entire DRP Area.
7) Non-Residential User as permissible in R and C zones as per Regulation No. 34 shall
be allowed in Free Sale Components.
8) RRC shall be located at a suitable location within the respective planning sector
layout and not necessarily be on the plot where they exist at present. In case of any
site constraints, the same may be allowed to be located outside the particular sector
layout, but within the DNA, with the special permission of OSD, DRP (SRA).
9) After the proposed RRC buildings are constructed in the sector layout, at approved
location, in all respect including amenities such as water supply, sewerage lines,
electricity etc., the present occupiers of the respective buildings, chawls, tenanted
properties etc. of the concerned authorities shall be shifted to their respective newly
built tenements as per the allotment to be finalized by the concerned authorities.
10) An individual agreement shall be made by the Land-Owning Authority/SRA/the
developer so appointed by DRP (SRA) with the eligible occupier of each tenement
/unit in the joint names of pramukh occupier and spouse for every structure on the
renewal plots.
11) Tenements having a differently abled person or female-headed households shall
be given first preference in allotment of tenements. Thereafter lots shall be drawn
for allotment of tenements from the remaining tenements to the other occupiers.
12) In respect of those eligible occupiers on site who do not join the project willingly
the provisions laid down under clause no 1.14 of Regulation No.33 (10) (A) shall be
applicable.
13) The Managing Committee of the proposed Co-operative housing society of
occupants to be formed after allotment of reconstructed tenements shall have
women to the extent of one-third of the total strength of actual members on the
committee at any time.
14) The tenement obtained under this scheme cannot be sold/leased/ assigned or
transferred in any manner for a period of ten years from the date of
allotment/possession of the tenement. In case of breach of conditions, except
transfer to legal heir, the tenement will be taken over by DRP (SRA).
15) Building permissions for the Urban Renewal development shall be as per the
procedure laid down under clause no. 2.1 to 2.8 of Regulation No.33(10) A.
16) Temporary transit accommodation shall be provided within DNA. If it falls on the
area of amenity open space excluding D P road/open space reservation in accordance
with the procedure laid down under Regulation No. 4 of 33(10) (A).
17) Relaxation in building and other requirements for the Urban Renewal
development shall be as per the provisions laid down under clause no. 6.1 to 6.17 of
Regulation No. 33(10) (A).
18) Urban Renewal Development and DP Reservations shall be as per the provisions
laid down under clause no. 7.1 to 7.9 of Regulation No.33(10) A.
19) The concerned land owning authority shall give DRs of their land to DRP (SRA) in
lieu of 70% of net premium that is payable by the developers, proportionate to the
RRC generated on the said land. In case project is to be undertaken by Public
Authority, the premium payable shall be as decided by the Government.
20) Ownership and Terms of lease – If land on which the RRC of DRP is to be
constructed is part of Govt./MCGM/MHADA/MMRDA/Any Undertaking land, the
same shall be leased to the Co-operative Housing Society of the occupants on 30
years’ lease with a rent as decided by GoM from time to time and shall be renewable
for a further period of 30 years. The same conditions shall prevail for land under the
free sale component and the land shall be leased directly to the Society/Association
of the purchasers in the free sale component and not through the society of renewal
rehab occupants.
21) As soon as the approval is given to the Project, the no objection certificate for
building permission of the land-owning authority shall be given in respect of that
property to be developed under this Urban Renewal Scheme on lands belonging to any
department, undertaking, agency of the State Government including MHADA, or any
local self – Government such as the Municipal Corporation within 60 days after the
intimation of such approval to the Project is communicated. In the event of its refusal
to grant NOC, reasons thereof shall be stated and in the event not been given within
the period, it shall be deemed to have been given.
22) An amount of Rs 40,000/- or such an amount as may be decided by the Govt. from
time to time per tenement/ unit will have to be deposited by the developer with DRP as
a corpus fund for utilization by the co-operative housing society of the renewal rehab
occupants for the purpose of maintenance, in accordance with the time-schedule for
such payment as may be laid down by OSD, DRP (SRA). However, by the time of
completion of construction for occupation of tenements by the hutment dwellers, the
total amount at the rate of Rs 40000 per tenement completed should have been
deposited in full.
The building permission for the last 25 percent of the free sale component would be
given only after the entire required amount is deposited in full with DRP (SRA).
23) An amount equal to 2% of land rate as per ASR for FSI 1 shall be paid by the
Developer for the BUA over and above the Zonal (basic) FSI, for the rehabilitation and
free sale components. This amount shall be paid to DRP(SRA) in accordance with the
time schedule for such payment as may be laid down by OSD, DRP(SRA), provided the
installments shall not exceed beyond the completion of construction. This entire
amount will remain with DRP (SRA) and the same shall be used for Schemes to be
prepared for the improvement of infrastructure within Dharavi Redevelopment
Project Areas.
24. SRA, after consultation with the concerned authorities may add, alter or amend
the conditions under these Regulations with the previous approval of the Govt.
Note:-
The provisions of the DCR for Greater Mumbai, and all other applicable sections of
the MR & TP Act, 1966, shall apply mutatis mutandis to the development of land with
the modification that the expressions "Municipal Corporation of Greater Mumbai"
and "Municipal Commissioner" shall be substituted by the expressions "Slum
Rehabilitation Authority" and "Officer on Special Duty, DRP (SRA)” respectively.
33(9) (B): Reconstruction or redevelopment of Cluster of BDD chawls at Naigaon,
Worli, N.M.Joshi Marg and Shivdi under Urban Renewal Scheme(s).
For reconstruction or redevelopment of Cluster(s) of buildings under Urban Renewal
Scheme(s) in the Island City of Mumbai undertaken by the Planning Authority, the
FSI shall be 4.00 or the FSI required for rehabilitation of existing tenants/occupiers
certified by competent Authority appointed by Government for this purpose, plus
Incentive FSI as per the provisions of Appendix whichever is more.
Appendix
Regulation for Reconstruction or Redevelopment of Cluster(s) of BDD chawls at
Naigaon, Worli, N.M.Joshi Marg and Shivdi by implementing Urban Renewal
Scheme(s).
1.1 “Urban Renewal Scheme” (URS) of BDD Chawls means a scheme for
redevelopment of the cluster of buildings and structures constructed by Bombay
Development Division in the Island City of Mumbai, at four locations and boundaries
of the area as shown in DP hereinafter referred to as " Urban Renewal Cluster or URC
" shall be a cluster identified for urban renewal :--
1) Under the Development Plan (DP) , where the DP contains such well-defined
Clusters; or
2) Under the Urban Renewal Plan (URP) for the concerned area, prepared and
notified by the Officer appointed by the Planning Authority, who may revise the
same as and when required; or
3) By Planning Authority, where such clusters of BDD Chawls are not shown on
the DP and the URP is yet to be prepared.
Provided that no cluster or clusters shall be identified for redevelopment or
implementation of Urban Renewal Scheme by the Officer appointed by the Planning
Authority without carrying out an Impact Assessment Study regarding the impact on
the city and sector level infrastructure and amenities as well as traffic and environment
of the implementation of URS on such cluster or clusters.
Explanation—
1. The land under URS, irrespective of the tenure of the plots comprised therein, shall
be treated as one plot for the purpose of FSI and computation of marginal distances.
2 In specific cases where URS is not bounded by roads, nallas and Railway lines, the
boundary of the Cluster may be decided by the Officer appointed by the Planning
Authority.
1.2 The Urban Renewal Cluster may consist of a mix of structures of different
characteristics such as –
(i) Cessed buildings in Island City, which attract the provisions of MHAD Act,
1976.
(ii) (a) Buildings at least 30 years of age and acquired by MHADA
(b) Authorized buildings at least 30 years of age constructed by Bombay
Development Division (BDD).
Explanation. -- Age of a building shall be as on the 1st of January of the year in
which redevelopment proposal for the URC complete in all respects, is submitted to
the Officer appointed by the Planning Authority and shall be calculated from the date
of occupation certificate or where such occupation certificate is not available, from the
first date of assessment as per the property tax record in respect of such building,
available with the PWD.
(iii) (a) Buildings belonging to the State Government and Central Government
(b) Any land belonging to the State Government, any semi-Government
Organization, MCGM and MHADA (either vacant or built upon) which falls within
the area of the proposed Urban Renewal Scheme including that which has been given
on lease or granted on the tenure of Occupant Class II.
Provided that in case of buildings or lands belonging to the Central
Govt., the State Government, Semi-Government Organizations and MCGM or
MHADA, prior consent of the concerned Department shall have to be obtained for
including such buildings or lands in any proposal of Urban Renewal Scheme.
(iv) Other buildings which by reasons of dis-repair or because of structural/sanitary
defects, are unfit for human habitation or by reasons of their bad configuration or the
narrowness of streets are dangerous or injurious to the health or safety of the
inhabitants of the area, as certified by the Officer or the Agency designated for this
purpose by Planning Authority.
(v) All dwelling structures, as defined in Section 3 X of Maharashtra Slums Area
(Improvement, Clearance and Redevelopment) Act, 1971, existing prior 1-1-2000
Explanation: If some areas are previously developed/or are in the process of
development under different provisions of the DCPR, such areas can be included in
the urban renewal cluster only for planning purposes. However, such areas shall be
excluded for calculation of FSI under this Regulation and the admissible FSI shall be
calculated as per the relevant provisions of the DCPR under which such areas are
developed or are being developed.
2. Eligibility of Occupants for Rehabilitation under Urban Renewal Scheme (URS)
(A) For Buildings --
i. No new tenancy created after 13/6/1996 shall be considered. Further,
unauthorized construction made in buildings for creating new tenancy in the existing
tenancies shall not be considered while computing existing FSI. A certified inspection
extract of the Competent Authority/MCGM prior to 13/6/1996 and certification by
Competent Authority appointed by Government for this purpose as decided by GR
dated 30/03/2016 proving the existence of tenements prior to 13/6/1996 shall be
considered adequate evidence to establish the number of tenements and
tenants/occupants of such tenements. However, the Govt. in Housing Department, if
necessary may issue comprehensive guidelines for determination of eligibility of
occupiers and tenants therein.
ii. The list of eligible tenants and the area occupied by each of them in BDD Chawls
shall be certified by the Competent Authority appointed by Government for this
purpose.
B) For Dwelling Structures (other than tenements in B.D.D. Chawls buildings)
i) Dwelling Structures means all dwelling structures, as defined in Section 3 X of
Maharashtra Slums Area (Improvement, Clearance and Redevelopment) Act, 1971,
existing prior 1-1-2000.
ii) The eligibility of the participants will be certified by the Competent Authorities
appointed by Government.
iii) The eligibility of such occupiers including transferee under this project shall be
established in accordance with Chapter 1-B of Maharashtra Slum Area
(Improvement, Clearance, Redevelopment) Act, 1971 and orders issued there under.
3. Rehabilitation Entitlements:-
(i) Each certified residential tenant/occupant shall be rehabilitated and given on
ownership basis, a tenement of Carpet area 46.45 sq. m. This entitlement is
consolidated entitlement of rehab area. No further compensatory or other FSI would
be available.
(ii) Eligible Religious structure/Eligible onsite amenities/Eligible any other non-
residential structure shall be given existing carpet area or as decided by the
Government.
(iii) Each eligible slum dweller shall be entailed to a tenement of carpet area of 25
sq. m (269 sq. ft.)
4. Total Permissible FSI for URS:-
a) The total permissible FSI for an Urban Renewal Scheme shall be 4.00 on gross
plot area, but excluding the reservations/designations, Road set back, area under
existing Municipal Roads but including the built up area under
reservation/designation, Road set back or sum total of the Rehabilitation FSI +
Incentive FSI, whichever is more.
Provided that the aforesaid FSI shall be exclusive of the Fungible FSI
admissible under the provision of DCPR 31 (3).
b) The FSI for Urban Renewal Schemes in CRZ area shall be governed by the
MOEF Notifications issued from time to time.
c) The incentive FSI admissible against the FSI required for rehabilitation, shall
be based on the ratio (hereinafter referred to as Basic Ratio ) of Land Rate (LR ), in
Rs/sq. m, of the lands included in the Urban Renewal Cluster, as per the Annual
Statement of Rates (ASR ) and Rate of Construction (RC )* in Rs/sq. m., applicable
to the area as per the ASR and shall be given as per the Table-B below :-
Table B
Basic Ratio Incentive
( LR/RC)* ( As % of Admissible Rehabilitation Area )
For 0.4 ha to For 1.0 ha to For 5.0 ha to For 10 ha
1.0 ha. 5.0 ha 10.0 ha and above
Above 6.00 55% 60% 65% 70%
Above 4.00 and 65% 70% 75% 80%
up to 6.00
Above 2.00 and 75% 80% 85% 90%
up to 4.00
Up to 2.00 85% 90% 95% 100%
Explanation:-
(i) *RC is the rate of construction in respect of R.C.C. Construction, as published by
the Chief Controlling Revenue Authority & Inspector General of Registration,
Maharashtra State in the Annual Statement of Rates.
Provided further that in case there are more than one land rates applicable to different
parts of the plot under the Urban Renewal Scheme, a weighted average of all the
applicable rates shall be taken for calculating the Average Land Rate and the Basic
Ratio.
Provided further that for calculation of the Basic Ratio, the Land Rate (LR) and the
Rate of Construction (RC) shall be taken for the year in which the Cluster
Development Project is approved and LOI is issued by the Authority competent to
approve it and the said ratio shall remain unchanged even if such Scheme undergoes
any revision or modification subsequently during its course of completion.
d) "tolerated structures" encroaching upon the roads in nearby vicinity shall be allowed
to be included in the Urban Renewal Scheme and its BUA shall be included in
rehabilitation area, provided such structures are permanently removed.
Explanation: - The term “tolerated structure” means the structure used for residential
or non-residential purpose and existing prior to 17th April 1964 or 1st April 1962
respectively.
e) It shall be permissible to implement the sanctioned Urban Renewal Scheme in
phases. The development in each phase is strictly in conformity with the Master
Plan/Layout Plan approved for the entire Urban Renewal Scheme.
Subject to the master plan for the whole cluster being followed, phase wise
implementation of Urban Renewal Scheme may be allowed, with pro rata utilization
of the total admissible FSI for rehab and incentive component simultaneously.
Provided, further that, while giving permission for phased implementation of
the Urban Renewal Scheme, the time frame for implementation of each phase shall
also be given. The minimum area for each phase shall be as decided by the Planning
Authority.
5. Development of DP Reservations:--
Construction or reconstruction of slums/buildings falling under Reservations
contemplated in the Development Plan shall be permissible as per Regulation
No17(3)(C)(II)
6. 30% of the Incentive FSI can be used for non-residential purposes as otherwise
permissible under the DCPR.
7. Development cess at the rate of 100% of Development charge otherwise applicable
subject to a minimum of Rs 5000 per sq. m for the BUA over and above the Zonal
(basic) FSI, for the rehabilitation and incentive sale component, shall be leviable in
respect of any URS by the MCGM in accordance with the time schedule for such
payment as may be laid down by the Commissioner, MCGM. This amount shall be
kept in a separate account and shall be used for the improvement of off-site
infrastructure around the urban renewal cluster. Development cess shall be in addition to
development charges levied as per section 124 of MR&TP Act 1966.
This surcharge shall not be applicable to the BUA to be handed over to the
MCGM or any Public Authority in lieu of reservation or to the amenity areas to be
handed over to the MCGM as per the requirement indicated by the MCGM or the
Empowered Power Committee.
8. The temporary transit camps may be permitted in the same Urban Renewal Cluster
or elsewhere in MCGM limits on land belonging to the Planning Authority up to 4.00
FSI with the concessions permissible under SRA. Scheme under Regulation 33(10) of
these DCPR. Such transit camps shall have to be demolished after full occupation
certificate is granted to the Rehabilitation Component by the Officer appointed by the
Planning Authority for the reconstructed building. Till the transit camps are fully
demolished, the Officer appointed by the Planning Authority shall not release FSI for
the Incentive component area under the URS in excess of 75% of the total admissible
Incentive FSI.
9. In the case of specific designations/reservations in the Development Plan, the
Officer appointed by the Planning Authority, may shift, interchange the
designation/reservation in the same cluster, to which an access is available from
peripheral or outer road or has to be provided and the same is not encumbered,
provided that the area of such designation /reservation is not reduced.
10. Non-conforming Activities – All activities which are existing shall be allowed to
be re-accommodated regardless of the nonconforming nature of such activities
excepting those which are hazardous and highly polluting and those where alternative
accommodation has to be provided elsewhere by the Planning Authority.
11. Relaxation in Building and other requirements:-
In case of tenements of 46.45 sq. m carpet area for rehabilitation or tenements to
be handed over to the Planning Authority, the following shall be applicable.
11.1 Calculation of FSI for all purposes shall be on gross area of the URS i.e.
without deducting any percentage for recreational open space. This shall not affect the
requirement of physical recreational open space, to be kept on the site as per
prevailing DCPR
11.2 The provision in Regulation 37(20) relating to balcony shall apply to the URS
with the following specifications: - Balcony shall not reduce marginal open space to
less than 3.00 m. However, at ground level, minimum 4.5 m clear margin shall be
maintained.
11.3 Notwithstanding anything contained in Regulation 31(3) of the DCPR, areas of
common passages not exceeding 2.0 m. in width, provided for giving access to the
tenements in rehabilitation component and the tenements to be handed over against
reservation and Planning Authority component shall not be counted towards FSI.
11.4 Front and marginal open spaces, for a building having height up to 32.0 m. in
the rehabilitation component or a composite building, shall be 4.5 m.
Provided that open space of the width of 6 meters at least on one side at ground level
within the plot, accessible from the road side shall have to be maintained for the
maneuverability of a fire engine, unless the building abuts two roads of 6 meters or
more on two sides, or another access of 6 meters to the building is available, apart
from the road abutting the building.
11.5 Notwithstanding the provisions in Regulation 41 (Table 18) where the location
of the URC plot abuts a DP Road having width of 18.3 m and above. The front
marginal open space shall not be insisted upon beyond 4.5 m provided, such road is
not an Express Highway or a road wider than 52 m
11.6 Where the location of the URC plot abuts a trained nallah, the marginal open
space along the nallah shall be 6.0 m from the edge of the trained nallah, or as required
by SWD Department of MCGM, whichever is greater.
11.7 The distance between any two rehabilitation buildings shall not be less than 6.00
m
11.8 If the height of any building constructed under URS is more than 32 m,
marginal open space of 6 m or as required by CFO whichever is greater shall be
maintained.
11.9 Wherever more than the minimum front and marginal spaces have been
provided, such additional area provided may be considered wherever necessary, as
part of the amenity open space under the URS comprising both rehabilitation and
incentive FSI components, without charging any premium, in relaxation of the
stipulation in Regulation No. 27.
11.10 Pathways and Means of Access.—the ratio between the length of the pathway
and the width thereof shall be as follows:
Length Width
Up to 20 m 1.5m
21 to 30 m. 2.0m
31 to 40 m. 2.5m
41 to 59 m 3.0m
11.11 Between the dimensions prescribed for the pathway and the marginal
distances, the larger of the two shall prevail. The pathway shall act as access wherever
necessary. The building shall be permitted to touch pathways.
11.12 The means of access shall be normally governed by the provisions of
Regulation No. 23. However, in the URS, wherever the design of the buildings up to
32 m. height requires relaxation in the width of access, the same may be given.
However, high rise building shall be permissible only on access having width of 9 m.
and above.
11.13 Even if the recreational open space is reduced to make the project URS viable,
at least 10 % of URC plot area shall be provided as recreational open space. In
addition to this, 10% of URC plot area shall be earmarked for amenity space which
can be adjusted against the D.P. reservation if any, existing on such plot. The type or
location of the amenity to be decided by Officer appointed by the Planning Authority
and shall be handed over free of cost to Planning Authority. The BUA of such amenity
shall be added to the Rehab component while calculating the share of incentive
component.
11.14 Premium shall not be charged for exclusion of staircase and lift well etc. as
covered under the provisions of Regulation No 31(1)
11.15 In order to make the Urban Renewal Scheme viable, the Officer appointed by
the Planning Authority shall be competent to sanction any relaxation in marginal open
spaces except front marginal open spaces and parking requirements wherever
necessary due to bonafide hardship, for reasons to be recorded in writing which shall
not affect general health, fire and safety requirements. However the Govt. or
Empowered Committee shall have the power to relax any of the provisions in these
Regulations.
11.16 All relaxations outlined hereinabove shall be admissible to entire project area
under the URS. Premium shall not be charged for all or any of the relaxations given
hereinabove or for any other relaxations mentioned in Regulation No 31(1).
11.17 The parking in the scheme shall be provided as per Regulation No. 44.
12. The approving / sanctioning authority for the building plans under the URS
shall be the Officer appointed by the Planning Authority as per the MRTP Act, 1966
even if the URS partly consists/of declared slums/slums on Municipal/Govt. lands
existing prior to 1st January 2000 or such/other reference date notified by the
Government.
13. Religious structures existing on the site of URS prior to redevelopment, if
allowed to be redeveloped in accordance with the guidelines issued by the
Government from time to time, shall not, following such redevelopment, have area
exceeding their area prior to redevelopment.
14. Restriction on transfer of tenements shall be governed by the provisions of
Maharashtra Rent Control Act, till Co-op. Housing Society is formed and thereafter
the same shall be governed by the provision of Maharashtra Co-op. Societies Act.
However, tenements constructed for slum rehabilitation shall not be transferable for a
period of 10 years. Transfer fee and period for tenants and other beneficiary shall be as
decided by Government.
15. CORPUS FUND.—A Corpus fund shall be created by the Planning Authority as
directed by the Empowered Committee, which will be utilised for maintenance of the
rehabilitation buildings for a period of 10 years.
16. If Empowered Committee as per Govt. GR dated 30/03/2016 approves areas for
amenities such as Fire Stations/Hospitals/Police Stations/Schools, etc. other than the
reservations/designations under the Development Plan, such amenities shall be handed
over to the Planning Authority free of cost and the BUA of such amenity shall be
considered towards rehabilitation F.S.I, and Incentive FSI as admissible under this
Regulation shall be permissible.
17. Upon the recommendation by Planning Authority , the Empowered Committee
constituted vide GR dated 30/03/2016 shall be competent to approve the schematic
plans of Urban Renewal Schemes under this Regulation. On approval by the
Empowered Committee, the Officer appointed by the Planning Authority shall
sanction the final plans of URS.
Provided that no Urban Renewal Scheme shall be sanctioned by the
Empowered Committee as per GR dated 30/03/2016 without giving due regard to the
Impact Assessment study referred to in clause 1.1 of this Appendix.
(EP-88)
33 (10) Redevelopment for Rehabilitation of Slum Dwellers:
I Eligibility for redevelopment scheme:
(a) A person eligible for redevelopment scheme shall mean a protected occupier as
defined in Chapter IB of Maharashtra Slums Areas (Improvement, Clearance and
Redevelopment) Act, 1971 as amended time to time, hereinafter referred to as Slum
Act and orders issued there under.
(b)Subject to the foregoing provisions, only the actual occupants of the hutment shall
be held eligible, and the so-called structure-owner other than the actual occupant if
any, even if his name is shown in the electoral roll for the structure, shall have no
right whatsoever to the reconstructed tenement against that structure.
II Definition of Slum, Pavement, and Structure of hut:
(i) Slums shall mean those censused, or declared and notified, in the past or hereafter
under the Slum Act. Slum shall also mean area/pavement stretches hereafter notified
or deemed to be and treated as Slum Rehabilitation Areas.
(ii) If any area fulfils the condition laid down in section 4 of the Slum Act, to qualify as
slum area and has been censused or declared and notified shall be deemed to be and
treated as Slum Rehabilitation Areas.
(iii) Slum Rehabilitation area shall also mean any area declared as such by the SRA
though preferably fulfilling conditions laid down in section 4 of the Slum Act, to
qualify as slum area and/or required for implementation of any slum rehabilitation
project. Any area where a project under Slum Rehabilitation Scheme (SRS) has been
approved by CEO, SRA shall be a deemed slum rehabilitation area.
(iv) Any area required or proposed for the purpose of construction of temporary
or permanent transit camps and so approved by the SRA shall also be deemed to be
and treated as Slum Rehabilitation Areas, and projects approved in such areas by the
SRA shall be deemed to be Slum Rehabilitation Projects.
(v) A pavement shall mean any Municipal/Govt. /Semi-Govt. pavement, and shall
include any viable stretch of the pavement as may be considered viable for the
purpose of SRS.
(vi) A structure shall mean all the dwelling area of a protected occupier as defined in
Chapter I-B of Slums Act, and orders issued thereunder.
(vii) A composite building shall mean a building comprising both rehab and free-sale
components and part thereof in the same building.
(viii) Censused shall mean those slums located on lands belonging to Govt., any
undertaking of Govt., or MCGM and incorporated in the records of the land-owning
authority as having been censused in 1976, 1980, or 1985 or prior to 1st January,
1995, and 1st Jan 2000
III Joint ownership with spouse: The reconstructed tenement shall be of the
ownership of the hutment dweller and spouse conjointly, and shall be so entered and
be deemed to be so entered in the records of the co-operative housing society,
including the share certificates or all other relevant documents.
IV Denotification as Slum Rehabilitation Area: SRA on being satisfied that it is
necessary so to do, or when directed by the State Govt, shall denotify the Slum
Rehabilitation Area.
V Applicability: The following provisions will apply for redevelopment/construction
of accommodation for hutment/pavement-dwellers through owners/developers/co-
operative housing societies of hutment/pavement-dwellers/public authorities such
as MHADA, MIDC, MMRDA etc. /Non-Governmental Organizations anywhere within
the limits of MCGM. However, NGO should be registered under the Maharashtra
Public Charitable Trusts Act, 1961 and the Societies Registration Act, 1960 at least for
the last five years should also be got approved by SRA.
VI Right of the Hutment Dwellers:
1.1 Hutment-dwellers, in the slum or on the pavement, eligible in accordance with
the provisions of this Regulation shall in exchange of the protected dwelling
structure, be given free of cost a residential tenement having a carpet area of 25 sq.
m including balcony, fungible compensatory area, bath and water closet, but
excluding common areas.
1.2 Even those protected dwelling structures having residential areas more than 25
sq. m will be eligible only for 25 sq. m of carpet area where Carpet area means area
of tenements exclusive of all areas under walls including partition walls if any in the
tenement.
1.3 All eligible hutment dwellers taking part in the SRS shall have to be rehabilitated
in accordance with the provisions of this Regulation. It may be in situ and in the same
plot scheme as far as possible.
1.4 Pavement dwellers and hutment dwellers in the slum on land required for vital
public purpose or such location which are otherwise unsuitable for human habitation
or non-suitable due to other statutory restriction shall not be rehabilitated in-situ but
in other available location and in accordance with these Regulations. Competent
Authority appointed by the State Government in Housing Department shall on the
basis of verification of documents as may be prescribed shall decide on the eligibility
of hutment dwellers.
1.5 The eligibility of a person including a transferee, under a scheme of Slum
redevelopment shall be established in accordance with Chapter I B of Slum Act, and
orders issued thereunder.
1.6 An individual agreement shall be entered into by the owner/developer/co-
operative housing society/NGO with the eligible hutment-dwellers in the
slum/pavement.
1.7 An individual agreement entered into between hutment-dweller and the
owner/developer/co-operative society/ NGO shall be in the joint names of pramukh
hutment dweller and spouse for every protected dwelling structure
1.8 Hutments dwellers in category having a differently abled person or female
headed households shall be given first preference in allotment of tenements.
Thereafter lots shall be drawn for allotment of tenements from the remaining
tenements to the other eligible hutment-dwellers before grant of O.C.to rehab
Building.
1.9 Transfer of Photo passes- Since, only the actual occupant at present will be
eligible for redevelopment, there shall be no need to regularize the transfers of
photo passes that have occurred so far. A photo pass will be given after the new
tenement has been occupied.
1.10 Any person who owns a dwelling unit on ownership basis in MCGM area, shall
not be held eligible under this scheme. Any person who can be held eligible under
more than one SRS, shall be held eligible in only one scheme. whose name is enrolled
in a non-slum area in Brihan Mumbai but has purchased a hutment and therefore got
his name also included in electoral roll for the slum area, i.e. he has his name in the
electoral roll at two places, he shall not be held eligible for the scheme
1.11 Premium for ownership and terms of lease-. That part of
Government/MCGM/MHADA land on which the rehabilitation component of the SRS
will be constructed shall be leased to the Co-operative Housing Society of the slum-
dwellers on 30 years. Annual lease rent of Rs. 1001 for 4000 per sq. m. of land or part
thereof and lease shall be renewable for a further period of 30 years at a time
simultaneously land under free sale component shall be leased directly to the
Society/Association of the purchasers of the tenement under free sale component.
Pending the formation of the Society/Association of the purchasers in the free sale
component with a provision for further renewal for a period of 30 years at a time.
The lease rent for the free sale component shall be fixed by SRA.
In addition to above, the Developer/Co-op. Housing Society shall pay premium at the
rate of 25% of ASR of the year of issue of LOI, in respect of SRS proposed to be
undertaken on lands owned by Government, Semi-Government undertakings and
Local Bodies and premium shall go to land owing authority such as MHADA, MCGM,
MMRDA as the case may be as prescribed by the land-owning authority. The
premium installment so recovered shall be remitted to concern land owing authority
within 30 days from the date recovery.
In the case of Govt. land the premium shall be deposited in Nivara Nidhi.
The amount of premium shall be recovered in installment as may be prescribed by
Govt. from time to time. Land owning authority such as MCGM, MMRDA, MHADA
shall not recover land premium in any other form. Proposals for SRS on land owned
by Central Govt shall not be accepted unless NOC for the scheme is obtained from
Central Govt.
1.12 Automatic cancellation of Vacant Land Tenure and leases- If any land or part of
any land on which slum is located is under vacant land tenure, the said tenure/lease
created by MCGM or Municipal Commissioner shall stand automatically terminated
as soon as letter of Intent is issued by SRA for a SRS, which is a public purpose, on
such land is prepared and submitted for approval to the SRA. Any arrears of dues to
be collected by MCGM shall not be linked to the issue of any certificate or NOC
relating to the Slum Rehabilitation Scheme.
On sanction of SRS, rights of imla malik, municipal tenants or any other tenancy shall
stand terminated in respect of the sanctioned SRS.
1.13 Recovery of pending dues such as assessment, compensation, occupational
charges, non-agricultural tax/dues etc. pending with public authorities such as State
Govt, MHADA, and/or MCGM shall be dealt with separately and not be linked to
grant of approval or building permission to the slum rehabilitation projects.
1.14 A Slum Rehabilitation Project shall be considered preferably when submitted
through a proposed or registered co-operative housing society of hutment dwellers
on site. The said society shall include all the eligible hutment on site while submitting
the S.R. Scheme and give an undertaking to that effect to SRA.
1.15 Where 70 percent or more of the eligible hutment-dwellers in a slum and
stretch of road or pavement contiguous to it at one place agree to join a
rehabilitation scheme, it may be considered for approval, subject to submission of
irrecoverable written agreements of eligible hutment-dwellers before LOI. Provided
that nothing contained herein shall apply to Slum Rehabilitation Projects undertaken
by the State Government or Public authority or as the case may be a Govt. Company
as defined in Sec. 617 of the Companies Act 1956 and being owned & controlled by
the State Government
1.16 In respect of those eligible hutment-dwellers on site who do not join the Project
willingly the following steps shall be taken:
(i) Provision for all of them shall be made in the rehabilitation component of the
scheme.
(ii) The details of the tenement that would be given to them by way of allotment by
drawing lots for them on the same basis as for those who have joined the Project,
will be communicated to them in writing by the Managing Committee of the Co-
operative Housing Society if it is registered, or the developer. In case of dispute,
decision of the CEO/SRA shall be final and binding on all the parties concerned.
(iii) The transit tenement that would be allotted to them or rent payable would also
be indicated along with those who have joined the Project.
(iv) If they do not join the scheme within 15 days after the approval has been given to
the Slum Rehabilitation Project on that site, then action under the relevant provision
including sections 33,33(A) and 38 of the Slum Act, as amended from time to time,
shall be taken and their hutments will be removed, and it shall be ensured that no
obstruction is caused to the scheme of the majority of persons who have joined the
scheme willingly.
(v) After this action under the foregoing clause is initiated, they will not be eligible for
transit tenement along with the others, and they will not be eligible for the
reconstructed tenement by lots, but they will still be entitled only to what is available
after others have chosen which may be on the same or some other site.
(vi) If they do not join till the building permission to the Project is given, they will
completely lose the right to any built-up tenement, and their tenement shall be taken
over by the SRA, and used for the purpose of accommodating pavement-dwellers
and other slum dwellers who cannot be accommodated in-situ etc.
(vii) Pitch of about 3 m x 3.5 m will be given elsewhere if and when available, and
construction therein will have to be done on their own.
(EP-89)
1.17 The Managing Committee of the proposed as well as registered Co-operative
housing society of hutment dwellers shall have women to the extent of one-third of
the total strength of actual members on the committee at any time.
1.18 Restriction on Transfer of Tenements; the tenement obtained under this scheme
cannot be sold/leased/assigned or transferred (except to legal heir) in any manner
for a period of ten years from the date of allotment/possession of the tenement. In
case of breach of conditions, except transfer to legal heir, the tenement will be taken
over by SRA.
VII. Building Permission for Slum Rehabilitation Project:
2.1 The proposal for each Slum Rehabilitation Project shall be submitted to the
SRA with all the necessary documents, no-objection certificates, and the plans as may
be decided by the SRA from time to time.
2.2 Approval to the Project shall be given by the SRA within a period of 60 days
from the date of submission of all relevant documents. In the event of failure by SRA
to do so, the said approval shall be deemed to have been given, provided the Project
is in accordance with the provisions of these Regulations.
2.3 The SRA while giving the approval may lay down terms and conditions as may
be necessary.
2.4 The SRA shall adopt the procedure laid down in the MR & TP Act, 1966 for
giving building permission to any Slum Rehabilitation Project under this Scheme.
2.5 On compliance with the terms and conditions, the building permission shall
be given, in accordance with the provisions under section 45 of the MR & TP Act,
1966 to the Project under the SRS, first to the Rehabilitation component and
thereafter to the free-sale component subject to the provisions in clause below.
2.6 Correlation between Rehabilitation and free-sale components: Building
permission, for 10 percent of BUA of both the rehab and free-sale components may
be given simultaneously and thereafter proportionately or as may be decided by the
CEO, SRA.
2.7 Where the Project is being implemented directly by an NGO approved by SRA,
CEO (SRA) may sanction 20 percent of the free-sale component without waiting for
any expenditure on the rehabilitation component. The approval for remaining part of
free-sale component will be given only after at least 30 percent of rehabilitation
component is completed on site.
2.8 As soon as the approval is given to the Project, the NOC for building
permission of the landowning authority shall be given in respect of that slum located
on lands belonging to any department, undertaking, agency of the State Govt.
including MHADA, or any local self-Government such as the MCGM within 60 days
after the intimation of such approval to the Project is communicated. In the event of its
refusal to grant NOC, reasons thereof shall be stated and in the event of its not being
given within the period, it shall be deemed to have been given’.
2.9 Occupation certificate shall not be held up only for want of lease documents
to be executed, in all slum rehabilitation projects taken up on lands belonging to any
department, undertaking, agency of the State Govt., including MHADA, and any local
self-Government such as the MCGM.
VIII. Rehabilitation and Free-Sale Component:
3.1 FSI for rehabilitation of eligible slum/pavement-dwellers includes the FSI for the
rehab component, and for the free-sale component. The ratio between the two
components shall be as laid down herein below.
3.2 BUA for rehabilitation component shall mean total construction area of
rehabilitation component, excluding what is set down in 31 (1) of D. C. Regulations,
but including areas under passages, aaganwadi, health centre / outpost, community
hall /gymnasium / fitness centre, skill development centre, women entrepreneurship
centre, yuvakendra/ library, Balwadi/s society office, religious structures as
permitted under Government Home Department Resolution dt. 05/05/2011 and
18/11/2015, other social infrastructure like School, Dispensary, Gymnasium run by
Public Authority or Charitable Trust, 5 percent incentive commercial areas for the Co-
operative society, and the further 5 percent incentive commercial area for the NGO,
Govt./Public Authority/Govt. Company wherever eligible.
3.3 In Island City, if rehab component is 10 sq. m of built-up area, then an additional
7.5 sq. m built-up area will be permitted so that this additional 7.5 sq. m can be
utilised for disposal in the open market and the rehab component subsidized.
3.4 In suburbs and extended suburbs, if rehab component is 10 sq. m of built-up
area, then an additional 10 sq. m of built-up area will be permitted so that this
additional 10 sq. m can be utilised for disposal in the open market and the rehab
component subsidized.
3.5 In difficult areas as may be notified by the SRA hereafter, if the rehab component
is 10 sq. m of built-up area, then an additional 13.33 sq. m of built-up area will be
permitted and this area of additional 13.33 sq. m can be utilised for disposal in the
open market and the rehab component subsidized.
(EP-90)
3.6 In addition to the entitlement under Provisions in 3.3 and 3.4 herein above, for
slum rehabilitation schemes that attempt larger agglomerated development allowing
enhanced planning & quality of life, the following additional BUA incentive will be
admissible under free sale component of Slum Rehabilitation Schemes as shown in
table below:
Area of the S.R. Scheme Additional built-up area
admissible under free sale
component
5 acre up to 10 acres 5 %
upto 1 ha NIL
above 10 acre up to 20 acres 10 %
2 to 4 ha 5%
above 20 acre up to 40 acres 15 %
4 ha to 8 ha 10%
above 40 acres 20%
8 ha to 16 ha 15%
16 ha & above 20%
(EP-91)
3.7 FSI to be sanctioned on a Slum Rehabilitation scheme site may exceed 4.0 3.0
3.8 Maximum FSI Permissible for consumption on the Plot: FSI that can be utilised in-
situ on any slum site shall be 4 3 or sum total of rehabilitation FSI plus incentive FSI
whichever is more with Minimum Tenement Density of 650 500 per Net Hectare. Due
to local planning constraints and viability of the Slum Rehabilitation Project the
density norms of 650 per net hectare may be reduced up to 25% by Chief Executive
Office. Thereupon the difference between sanctioned FSI that can be utilized in-situ,
will be made available in the form TDR in accordance with the provisions of
Regulation no 32. The computation of FSI shall be done for both rehab and free-sale
components in the normal manner, that is giving the benefit of what is set down in
Regulation No. 31(1). While the areas referred in sub regulations No 6.8 6.6 and 8.2 of
this Regulation shall not be included for computation of FSI the said areas shall be
included for computation of the rehab component of 10 sq. m in sub-Regulations 3.3
to 3.5 herein above. In all such cases where FSI sanctioned cannot be utilised in situ
even after relaxation of 650 per net hectare norms by Chief Executive Officer the
difference between sanctioned FSI and that can be constructed in-situ, will be made
available in the form of TDR in accordance with the provisions of Regulation No. 32.
Provided that if the existing tenement density is more than 650 hectares, the CEO
(SRA) after ascertaining and due verification of proposal may allow FSI consumption
in-situ to be exceeded up to 4. The difference between sanctioned FSI (rehabilitation
FSI plus incentive FSI) and that can be constructed in-situ, will be made available in
the form of TDR in accordance with the provisions of Regulation No. 32.
Provided that the aforesaid FSI shall be exclusive of the Fungible FSI compensatory
area admissible under the provision of DCR 31(3).
(EP-92)
3.9 Notwithstanding the provisions in 3.8 above, the slum dweller
society/NGO/Developer undertaking the scheme may opt to claim TDR in lieu of sale
component available for the scheme, on account of constraints such as height
restrictions, uneconomical site conditions, etc.; if the full permissible FSI cannot be
used on the same site, TDR may be allowed as may be necessary even by reducing
the Minimum Tenements Density requirement of 650 per hector upto 25 % by CEO
SRA without consuming permissible FSI on the same site. However, TDR may be
allowed only when the frame work for one complete building in rehab component is
constructed or when 10% of the rehab component has been constructed on site and
the said TDR will not exceed 50 percent of the construction of rehab component at
any point of time till the total rehab component has been completed. On completion
of the total rehab component balance TDR will be allowed.
3.10 The rehabilitation component shall mean all residential tenements as well as
non-residential built-up premises given free of cost in accordance with the provisions
of the SRS outlined in this Regulation excluding what is set down in Regulation
No.31(1) and including aaganwadi, health centre / outpost, community hall
/gymnasium / fitness centre, skill development centre, women entrepreneurship
centre, yuvakendra /library existing eligible religious structure, school, dispensary,
gymnasium run by Public Authority or charitable trust etc. as per provision of 8.1 &
8.2 but excluding built-up area given for buildable DP reservations.
3.11 Notwithstanding anything contained in this regulation, If if rehabilitation
project of a slum located on land belonging to public authority and needed for a vital
public purpose and where eligible slum dwellers which cannot be accommodated in
the in-situ SRS of land under non-buildable reservations, is taken up on an
unencumbered plot in addition to the rehabilitation and free-sale components as laid
down hereinabove, TDR as per regulation 32(1) sr.no. 8 of table 12(A) equal to for the
area of the land spared for this purpose shall also be sanctioned for the owner of the
said unencumbered plot and the TDR in due lieu of cost of construction tenements as
per note (d) of regulation 17(1) shall be permissible or in proportion as per provision
of 33(11)(A) for the land and BUA so transferred. Provided that the State Govt. or
Public authority or a Govt. Company as defined in Sec. 617 of the Companies Act
1956 and owned and controlled by the State Govt. (herein after referred as the
Agency) may undertake Slum Rehabilitation Project on its own land and be eligible
for the benefits under this Regulation subject to following conditions:
1) The Rehabilitation Project is approved by the SRA.
2) The tenements so constructed in execution of the Project are offered to slum
dwellers located on land belonging to Govt. or Public Authority and needed for vital
public purpose and within 270 days from the date of issue of LOI the Agency shall
identify the slum dwellers.
3) If the Agency fails to identify the slum dwellers needed to be shifted for a vital
public purpose, as above, then the tenements so constructed shall be offered;
a) to the slum dwellers located on land belonging to Government or Public
Authority within a distance of 2 km. from the land on which the Project is
undertaken, or
b) to the slum dwellers located anywhere in Greater Mumbai on lands belonging
to Govt. or Public Authority, or
c) to the slum dwellers located on private lands if the land owner pays the entire
cost of tenements as determined by the Agency.
Provided further that in all the three categories of slum dwellers referred to at (a), (b)
& (c) TDR of land component shall not be given and the construction TDR shall be
released only after identification of eligible slum dwellers.
4) Further provided that in all above cases the relocation of. slum dwellers in any
case will be undertaken not with reference to individuals but reference to assembly
of slum dwellers for the purpose of releasing the plot of land wholly from slums and
not only the patches of land.
Provided that notwithstanding anything mentioned above, project affected persons
under Mumbai Urban Transport Project (MUTP) due to any vital Public Projects
undertaken by MMRDA including PAP’s under Mumbai Urban Transport Project
(MUTP) being resettled as per the provisions contained in Government Resolution,
Housing and Special Assistance Department, by order no. 700/CR 31/slum-2 dated
12/12/2000 and certified by the Project Director, MUTP will also be eligible for
redevelopment scheme under this Regulation, as amended from time to time.
Provided further that in case of the ongoing scheme as per this provision and where
the work as per tenements of size 20.90 sq. m in building for which full
commencement certificate/occupation permission is issued/work competed but not
occupied and where the TDR in lieu of this rehab area is already availed; in such cases
at the option of owner/developer and with the approval of CEO(SRA), may convert
this tenements as per this regulation (of size 25 sq. m), then the TDR for additional
BUA as per size of 25 sq. m carpet area may be made permissible (while granting the
additional TDR as per this regulation the quantum of the TDR already availed shall be
deducted from the total admissible TDR).
(EP-93)
3.12(A) Minimum Density on the Plot Including Non-Residential Units: The
minimum density of rehabilitation so as to generate adequate number of additional
rehabilitation tenements and affordable housing tenements in situ under any Slum
Rehabilitation Project will be 650 500 tenements per net hectare as, that is, after
deducting all reservations actually implemented on site including the land appurtenant
thereto, but not deducting the recreational/amenity open space on the remaining area.
If the number of tenements to be provided to all eligible hutment dwellers is less than
the minimum so constructed as per minimum density of 650 500 per net hector, the
balance shall be handed over free of cost to the SRA. The Authority shall use them for
the purpose of transit or Project-affected persons or pavement-dwellers or slum
dwellers from other slums or distribution would be done as per policy decided by the
GOM.
(B) If there is balance FSI available in a slum scheme, after in situ development of
rehab as well as sale component, development of additional tenements for the
purpose of rehabilitation of slum dwellers on untenable land or for any other category
as per policy & priority decided by Government, may be allowed in the scheme up to
an extent such that this development and corresponding sale component development
remains within the limit of maximum permissible FSI in the said scheme.
(EP-94)
Provided that any ongoing Slum Rehabilitation Scheme where the eligibility of Slum
Dwellers is revised and certified in accordance with guidelines contained in
Government Resolutions zopudho-100/C.R.125/14/ zopasu-1, dt 16/05/2015, the
scheme parameters shall be revised in accordance with above norms on certification
of structural stability from competent Government/ Semi- Government Reputed
Technical institutions such as IIT, VJTI etc.
Provided further that in case of slum redevelopment where there are no eligible
commercial slum dwellers and where it is possible to provide commercial tenements
on ground floor, then in such cases commercial PAP tenements of size of carpet area
20.90 sq. m (225 sq. ft.) or of required size in consultation with MCGM shall be
provided as decided by CEO(SRA) and same shall be handed over free of cost to
SRA.’
Provided if SRS is undertaken by a Federation, Co- Op. Housing society consisting of
members who are serving or retired State Govt. Employees/Employees of the State
Govt. Undertakings/Employees of local bodies of State Government for providing
housing to its members, such tenements which are generated over and above the
tenements to be provided to the existing eligible hutment dwellers, shall be handed
over back to the said Federation/Co.-operative Housing Society for providing housing
to its above mentioned members and subject to further additional terms and
conditions as would be imposed by the CEO, SRA to ensure adequate membership of
class III and class IV employees.
C) whenever total number of slum dwellers as certified Annexure-II of any proposed
or slum rehabilitation is more than 500 but less than 650 or more than 650 / per
hectare, as the case may be, such Slum Rehabilitation Scheme will be sanctioned
with the FSI 4 in-situ taking into account all slum dwellers in Annexure-II so that
rehabilitation slum dwellers can happen together including those declared illegible at
the later stages by Competent or Appellate Authorities.
Provided that if number of slum dwellers declared eligible finally by Competent
or Appellate Authority are less than less rehab tenements so constructed under any
Slum Rehabilitation Scheme then remaining tenements shall be used by Slum
Rehabilitation Authority for the purpose of transit or PAP or pavement dwellers or
slum dwellers from other areas and its distribution may be done as per policy decided
by Government of Maharashtra.
(EP-95)
3.12 All non-residential built-up areas shall be included in the computation of
minimum density but on the scale of 25 sq. m of carpet area being one tenement. In
slums where the existing tenement density is already more than 650 per net ha, the
calculation of FSI for all purposes shall be on gross area, that is, without deducting
any percentage for recreational open space. This shall not affect the requirement of
keeping aside the said recreational open space on site, subject to the provisions in
these Regulations.
3.13 Amalgamation/Subdivision of Plots and Balancing of FSI Thereon: Any land
declared as slum rehabilitation area or on which slum rehabilitation project has been
sanctioned, if it is spread on part or parts of C.S. Nos. or CTS Nos. or S. Nos or F. P.
Nos shall be treated as natural amalgamation/subdivision/s of that C.S. or CTS or S.
No. or F.P. No. for which no separate approval for amalgamation/subdivision of land
would be necessary.
3.14 Boundaries and the Slum Rehabilitation Area shall be declared by the
competent authority after actual measurement of plot area on site and the same
shall be adopted for planning purpose for calculation of density and floor space
index.
3.15 The CEO, SRA may if required, adjust the boundary of the plot declared as
slum rehabilitation area so as to suit the building design and provide proper access to
these Scheme. Provided further that the encumbered area under D P
Road/Sanctioned Regular line road abutting the SRS shall be included in the scheme
to be developed.
3.16 After approval is given to the Slum Rehabilitation scheme, the area may be
further subdivided if necessary to earmark separate plots for the rehab component
and the free sale component. The Plot area and the built-up area in terms of square
meters on the said plot shall be separately mentioned in the lease agreements and
Record of Rights.
3.17 The CTSO/SLR, of the district on payment of such fees as may be decided by
the Govt. ensure that the City Survey sheet and property cards are corrected
accordingly and fresh property cards are opened for each of the plots giving details
regarding the area of the plots and the total area of the floors of the built-up
property and TDR given that is, the FSI used on that plot.
3.18 Declaration of Additional Areas as Difficult Category: The SRA may consider
declaring additional areas as difficult and publish it in the Maharashtra Government
Gazette, provided the following criterion/criteria are fulfilled:
(i) Overcrowding, High density, and Unhygienic conditions, or
(ii) To vacate land required for implementation of reservations for essential
public purposes/for implementation of vital public projects, or
(iii) Required for rehabilitation to avoid loss of human life
Provided that for difficult areas to be declared on account of overcrowding, high
density and unhygienic conditions, the area required shall not be less than 20
hectares in one contiguous area fulfilling the conditions mentioned in (i) above.
(EP-96)
4 Temporary Transit Camps:
4.1 The multistoried temporary transit camp shall be provided on the site itself or
outside the SRA project site on portion of plot which is not designated/reserved for
public purpose or not affected by road widening and is preferably close to the site.
4.2 The eligible slum dwellers shall be shifted to temporary transit camp or on rent as
may be mutually decided between the proposed society and developer.
4.3 The area of temporary transit tenements shall be excluded from the computation
of FSI, but the safety of the structure shall be ensured by a license structural
consultants. The minimum area of individual transit tenement shall be 14.5 sq. m.
4.4 Such building permission shall be given within 15 days from the date of
application and after approval to the project by Slum Rehabilitation Authority, failing
which it shall be deemed to be given.
4.5 On any nearby vacant site without any reservation in the DP construction of
temporary transit tenements made of light material with the consent of the land-
owners, shall be allowed up to an FSI of 4.0 and this shall be applicable in Island City
as well as in suburbs and extended suburbs. Temporary shall mean made of
detachable material such as tubular/prefabricated light structures.
4.6 In all such cases where the temporary transit camp is erected, the condition shall
be that the structures shall be demolished by the Developer/Society/NGO within 30
days of granting Occupation Certificate to the rehab buildings and the site should be
brought back to the original state. Till the transit camps are fully demolished,
development rights for the free sale area shall not be permitted to be used beyond
75% of the total admissible free sale area permissible under this Regulation.
5. Commercial / Office / Shop / Economic Activity Free of Cost:
5.1 The eligible existing area under commercial/office/economic activity shall be
computed on actual measurement/inspection, and/or on the basis of official
documents such as License under the Shops and Establishment Act, Electricity bills,
Photo pass etc.
5.2 In the rehabilitation component, the BUA for
commercial/office/shop/economic activity that existed prior to the date as decided
by the Govt.1st January, 1995 subject to the provisions in the sub-regulation below,
shall be given. Where a person has both residential and commercial premises
without common wall between residential and commercial premises, for
commercial/office/shop/economic activity in the slum/ pavement, he shall be
considered eligible for a residential/Commercial unit including BUA for
commercial/office/shop/economic activity, both free of cost and carpet area of such
unit shall not exceed 25 sq. m.
5.3 BUA for commercial/office/shop/economic activity up to 20.90 sq. m. (225 sq.
ft.) carpet area or actual area whichever is less, shall be provided to the eligible
person free of cost as part of the rehabilitation project. Any area in excess of 20.90
sq. m to the extent of existing area may, if required, be sold on preferential basis at
the rate for commercial area in the free-sale component.
5.4 Such area may be allowed on any side of the plot abutting 3.0 m wide
pathway and deriving access from 3.0 m wide pathway/open space. Back-to-back
shopping on ground floor shall also be allowed for the purpose of rehabilitation.
After exhausting these provisions, it may be allowed on the first floor to the extent
necessary.
5.5 Non-Conforming Activities: All activities which were previously existing shall
be allowed to be relocated regardless of the non-conforming nature of the activities,
except those which are hazardous and highly polluting, and except in cases where the
alternative accommodation has already been allotted elsewhere by the MCGM.
5.6 Convenience Shopping in Free-Sale Component: Convenience shopping in the
free-sale component vide DCR 2 (IV) 30 32 shall be permitted along the layout roads.
The CEO, SRA may add to alter or amend the said list for convenience shopping.
5.7 Incentive Commercial Areas for Society and NGO
(a) The scheme, when undertaken by a Co-operative Housing Society of slum
dwellers, may provide an additional 5 per cent built-up area on the rehabilitation
area free of cost for commercial purpose. This area will be at the disposal of the Co-
operative Housing Society of the hutment-dwellers. The corpus amount shall not be
spent, but the income from the property/corpus alone shall be used by the Society
for maintenance of the building and premises, and such other purposes as may be
laid down by the SRA.
(b)Where the scheme is undertaken by a Non-Government Organization Govt. or
Public Authority or Govt. Company another additional 5 per cent BUA on the
rehabilitation area may be given free of cost for commercial purpose. This area shall
be at the disposal of the Non-Governmental Organization Govt. or Public Authority or
Govt. Company in consultation with the cooperative housing society.
6. Relaxation in Building and Other Requirements:
Provision
6.1 Separate kitchen shall not be necessary. Cooking space (alcove) shall be
allowed without any minimum size restrictions. Where a kitchen is provided,
the minimum area shall be 5 sq. m provided the width shall be at least 1.5 m.
6.2 There shall be no size restriction for bath or water closet unit. Moreover, for
bathroom, water closet or kitchen, there shall be no stipulation of one wall
abutting open space, etc. as long as artificial light & ventilation through any
means are provided.
6.3 In water closet flushing system shall be provided with minimum seat size of
0.46 m (18 inches).
6.4 A septic tank filter bed shall be permitted with a capacity of 150 liters per
capita, where the municipal services are likely to be available within 4-5 years
6.5 In the rehabilitation component, lift shall not be insisted upon, up to ground
plus five floors.
6.6 Notwithstanding anything contained in this regulation areas of common
passages not exceeding 2.0 m in width provided in rehabilitation component to
give access shall not be counted towards FSI even while computing FSI on site.
6.7 Where the location of the plot abuts a nallah, the marginal open space
along the nallah shall not be insisted upon beyond 3 m from the edge of the
trained nallah provided at least on one side of nalla, marginal open space
of 6 m is provided.
6.8The distance between any two rehab/composite buildings up to height of 32
m shall not be less than 6 m
6.9A composite building shall contain at least 50 percent of the built-up area as
rehabilitation components provided it shall be reduced to 40 percent for the
projects in difficult areas.
6.10 Wherever more than the minimum front and marginal spaces have been
provided, such additional area provided may be considered as part of the
amenity open space in the project comprising both rehabilitation and free sale
components, and without charging any premium, in a relaxation of the
stipulations in DCR No. 27,
6.11 Even if the amenity space is reduced to make the project viable a minimum
of at least 8% of amenity open space (LOS) shall be maintained at ground level.
6.12 Between the dimensions prescribed for the pathway and marginal
distances, the larger of the two shall prevail. The pathway shall act as access
wherever necessary. The building shall be permitted to touch pathways.
6.13 The means of access shall be normally governed by the provisions of
Regulation No. 23. However, in the project, wherever the design of the
buildings in the same land requires relaxation, it may be given. Access through
existing pathways including the roads maintained under section 63K of the
MMC Act, 1888 but not less than 3.6 m in width, shall be considered adequate
for any slum rehabilitation project, containing buildings having height up to 32
m including stilts
6.14 Premium shall not be charged for exclusion of staircase and lift-well etc. as
covered under the provisions of DCR 31(1).
6.15 All relaxations outlined hereinabove shall be given to the rehabilitation
component, and also to the composite buildings in the project. Premium shall
not be charged for all or any of the relaxations given herein above. Provided
that if any further relaxation in open spaces is granted by Chief Executive Officer
then the same shall be subject to compliance of CFO requirement and recovery
of premium at the rate 2.5% of ASR.
6.16 Relaxations for the free sale component – Relaxation contained in sub
regulation No. 6.9 above, as well as other necessary relaxation shall be given to
the free sale components on payment of premium at the rate of 2.5% of Ready
Reckoner Rate or 10% of normal premium whichever is more.
6.17 In order to make the SRS viable, the CEO of SRA shall be competent to
make any relaxation wherever necessary for reasons to be recorded in writing.
6.18Notwithstanding anything contained in the regulations for rehabilitation
tenements under regulation 33 (10) the parking spaces for two-wheeler at the
rate 1 Parking per tenement shall be provided
7. Slums and Development Plan Reservations:
7.1 Slums situated in lands falling under various reservations/zones in the DP shall be
developed in accordance with the Regulation No 17(3)(D). following provisions
7.2 Slums in any zone shall be allowed to be redeveloped in-situ without going
through the process of change of zone. In the free-sale component in any zone, in
addition to residential uses, all the uses permitted for the original zone shall be
permitted. For industrial uses, the segregating distance shall be maintained from the
existing industrial unit.
7.3 (i) Any plot/layout having area under non-buildable/open space reservations
admeasuring up to 500 sq. m shall be cleared by shifting the slum-dwellers from that
site.
(ii) Where the area of site having non buildable/open space reservation, is more than
500 sq. m such sites may be allowed to be developed for slum redevelopment
subject to condition that the ground area of the land so used shall not be more than
67% of the reservation and leaving 33% rendered clear thereafter for the reservation.
7.4 Existing slum structures on lands reserved for Municipal School (RE 1.1)/ Primary
and secondary school (RE1.2) or a Higher Education (RE2.1) may be developed
subject to the following:
(i) In case of land reserved for Municipal School (RE 1.1), Primary and secondary
school (RE1.2) in the DP, a building for accommodating such number of students as
may be decided by the Municipal Commissioner, nor in any case for less than 500
students, shall be constructed by the owner or developer at his cost according to the
size, design, specification and conditions prescribed by the Municipal Commissioner.
The built-up area occupied by the constructed building shall be excluded for the
purpose of FSI computation, and where it is intended for a Municipal School (RE 1.1),
the building or part thereof intended for the school use shall be handed over free of
cost and charge to the Corporation. Thereafter, the land may be allowed to be
redeveloped with the full permissible FSI of the plot according to this Regulation
(ii)In the case of lands affected by the designation or reservation of a Higher
Education (RE2.1)in the DP, a building for accommodating such number of students
as may be decided by the Municipal Commissioner, not in any case for less than 800
students, shall be constructed by the owner or developer at his cost according to
the size , design, specification and conditions prescribed by the Municipal
Commissioner, the built-up area occupied by the constructed building shall be
excluded for the purpose of FSI computation. The constructed building shall be
handed over to the Corporation free of cost and charge and the Municipal
Commissioner may hand over the same or part thereof intended for the School use
to a recognized and registered educational institution for operation and maintenance
on terms decided by him. Thereafter the land may be allowed to be redeveloped
with full permissible FSI of the plot according to this Regulation.
(iii) In case area under reservation of Municipal School (RE 1.1)/ Primary and
secondary school (RE1.2) or a Higher Education (RE2.1) is spread on adjoining plot
and the plot under development, then in such cases Commissioner with special
permission may insist upon construction of Municipal School (RE 1.1) or a Higher
Education (RE2.1) in proportion to the area under reservation affecting the plot
under development. Requirements of Play Ground as per Regulation No 38 (I) (2) of
these regulations may not be insisted for (i) above.
7.5 For other buildable reservations excluding Municipal School (RE 1.1) or a Higher
Education (RE2.1)on lands under slum built-up area equal to 25 percent of the area
under that reservation in that plot, shall be demanded free of cost by the Slum
Rehabilitation Authority for the Municipal Corporation or for any other appropriate
Authority.
7.6 In case of the plot reserved for the Parking Lot 100% built up area as per zonal
basic permissible FSI of such reserved area shall be handed over to the MCGM.
The developer/owner shall be entitled for the Built up Area (BUA) in lieu of cost of
construction against handing over of built up amenity as per Note (d) of Regulation
17(1)
7.7 Existing slum structures on lands reserved for Rehabilitation & Resettlement (RR
2.1) shall be treated as sites for development of slum structures and shall be allowed
for redevelopment according to this Regulation.
7.8 Where DP road passes through slum rehabilitation area, the entire 100 per cent
FSI of the road may be given in the same site, on the remainder of the plot.
(EP-97)
7.9 7.1 Wherever slum and municipal/MHADA property are found together or
adjoining, it would be eligible for redevelopment using provisions of both DCR 33(7)
and of DCR 33(10) Development of slum and contiguous non-slum area provided
slum area shall be more than 75% of the scheme area under any other provisions of
regulations may be allowed together in order to promote flexibility of design as well
as to raise more resources, provided that the FSI of non-slum quantum of area shall
be restricted to that permissible in the surrounding zone, inclusive of admissible TDR
on non-slum area. Such a project shall be deemed to be a Slum Rehabilitation Project
and plans for non-slum area including the plans for admissible TDR shall be approved
by CEO, SRA. The power under D.C. Regulation 13(6) for shifting and/or interchanging
the purpose of designations/reservations shall be exercised by the CEO, SRA.
However, in case of shifting of the alignment of Road /D P Road, same shall be done
in consultation with MCGM.
Whenever a non-slum land other than NDZ SDZ-I, where zonal (basic) FSI
offered is less than one in residential zone, is contagious contiguous to a slum plot
getting developed under 33(10) & is needed for better planning, SRA may sanctioned
the amalgamation of the said plot with the scheme provided that 30% of the area of
non-slum plot is handed over free of cost & encumbrances to the Corporation for
purposes of POS or amenity open space. On such amalgamation 70% of the area
getting appended to the slum scheme shall be treated at par with non- slum
residential plot that are attached to the scheme. However, utilization of ‘TDR’ or
‘Additional FSI on payment of premium’ on such non-slum plot shall not be
permissible.
7.10 7.2 Slum Rehabilitation Permissible on Town Planning Scheme Plots: Slum
Rehabilitation Project can be taken up on Town Planning Scheme plots also, after
they are declared as slums/slum rehabilitation areas.
7.11 7.3 Contravening structures in the adjoining final plots, if declared as a slum
rehabilitation area by the competent authority, may be included in the Slum
Rehabilitation Scheme in the relevant Final Plot of the Town Planning Scheme.
7.12 7.4 In case of a slum rehabilitation project adjoining railway tracks, a boundary
wall of minimum 2.4 m in height shall be constructed.
Note: In case where LOI was issued by CEO (SRA) prior to sanction of DP 2034 in
respect of plot affected by reservations as per SRDP 1991, then those reservations
shall remain in force as per DCR 1991 even after the sanction of DP 2034 and shall be
developed as per DCR 1991.
8. Aaganwadi, Health Centre / Outpost, Community Hall /Gymnasium / Fitness
Centre, Skill Development Centre, Women Entrepreneurship Centre, Yuva Kendra /
Library Society Office, and Religious Structures:
8.1 There shall be Balwadi, Welfare hall and any of two amenities mentioned
above. There shall be health Centre/ outpost, Aaganwadi, skill development centre,
women entrepreneurship centre, yuvakendra / library of size 25 sq. m for every
multiple of or part of 250 hutment dwellers. In case of misuse, it shall be taken over
by the SRA which will be competent to allot the same to some other organization
/institution for public use. Balwadi shall also be provided for on a similar scale. An
office for the Co-operative housing society shall be also constructed for every 100
rehab tenements in accordance will D.C. Regulations No. 37(119). However, if the
number of rehab tenements exceeds 100 then for every 100 rehab tenements such
additional society office shall be constructed. There shall be a community hall for
rehab bldg. of the Project as a part of the rehabilitation component. The area of such
hall shall be 2% of rehab built up area of all the buildings or 200 sq. m whichever is
less.
Religious structures existing prior to redevelopment, if allowed in accordance with
the guidelines issued by Govt. from time to time as part of redevelopment shall not
exceed the area that existed prior to redevelopment. Other social infrastructure like
School, Dispensary and Gymnasium run by Public Authority or Charitable Trust that
existed prior to the redevelopment shall be allowed without increase in existing area.
However, it is provided that in the slum rehabilitation project of less than 250
hutments, there shall be Balwadi, Welfare hall and any of two amenities mentioned
above, as decided by co-operative housing society of slum dwellers, of size of 25
sq.mt and office for the Co-operative housing society in accordance with D.C.
Regulations No. 37(9). CEO, SRA may permit accumulation of the amenities
mentioned above but ensure that it shall serve equitably to the rehab area.
(EP-98)
8.2 All the areas underlying Aaganwadi, health centre / outpost, community hall
/gymnasium / fitness centre, skill development centre, women entrepreneurship
centre, yuvakendra / library community hall/s, society office, balwadi/s, religious
structure/s, social infrastructure like School, Dispensary, Gymnasium run by Public
Authority or Charitable Trust, the commercial areas given by way of incentives to the
co-operative society and the nongovernmental organisation shall be free of cost and
shall form part of rehabilitation component and it is on this basis the free-sale
component will be computed. These provisions shall apply to construction of transit
camps under DC Regulations 33(11) also.
8.3 Aaganwadi, health centre / outpost, community hall /gymnasium / fitness centre,
skill development centre, women entrepreneurship centre, yuvakendra / library
society office, Balwadi/s and religious structures, social infrastructure like School,
Dispensary and Gymnasium run by Public Authority or Charitable Trust in the rehab
component shall not be counted towards the FSI even while computing permissible
FSI on site.
9. Payments to be made to SRA and Instalments:
9.1 An amount of Rs. 40,000/- or such an amount as may be decided by the Planning
Authority from time to time per tenement including the welfare hall and balwadi in
the rehab component as well as in the case of permanent transit camp tenements
will have to be deposited by the owner/developer/society with the Slum
Rehabilitation Authority, in accordance with the time-schedule for such payment as
may be laid down by the CEO, SRA. However, by the time of completion of
construction for occupation of tenements by the hutment dwellers, the total amount
at the rate of Rs. 40,000/- per tenement completed should have been deposited in
full. The building permission for the last 25 percent of the free-sale component
would be given only after all the required amount is deposited in full with SRA.
9.2. An amount at the rate of 2% of ready reckoner rate as prevailing on the date
of issue of LOI per sq. m or such an amount as may be decided by GOM from time to
time shall be paid by the Owner/Developer/Society/NGO for the BUA over and
above the Zonal (basic) FSI (including excluding fungible compensatory area BUA),
for the rehabilitation and free-sale components. Similarly, it shall be paid for the
built-up area over and above the normally permissible FSI for construction of
permanent transit camps in accordance with the provisions under DCR 33(11). This
amount shall be paid to the SRA in accordance with the time-schedule for such
payment as may be laid down by the CEO, SRA provided the installments shall not
exceed beyond the completion of construction. This amount shall be used for
Schemes to be prepared for the improvement of infrastructure in slum or slum
rehabilitation areas. These infrastructural charges shall be in addition to
development charges levied as per section 124 of MR&TP Act 1966.
Provided that out of amount so recovered as Infrastructural charges, 90% amount
will go to MCGM and 10% amount will remain with SRA.
10 Clubbing:
In case of two or more nos. of slum schemes or two or more slum rehabilitation
schemes 33 (11) or slum rehabilitation scheme along with ancillary Slum Scheme
taken up for development by same or collaborating owners/developers/Co-Operative
Societies of the slum dwellers under any legal arrangement approved by CEO (SRA),
both rehab and sale components of the said slums can be combined & located in any
proportion in those plots provided in any plot, the FSI does not exceed permissible
FSI subject to the condition that the said slums have the same ratio of Rehab
component to Free Sale Component as laid down in the Clause 3.3 to 3.5 of this
Regulation
Whenever such clubbing of SR schemes on plots/lands having different ASR rates is
approved & sale component is shifted on land having higher ASR rate, then
Developer shall have to pay the premium equal to 51% unearned income on extra
sale component being available than which would have been otherwise available on
such plot as standalone scheme. Such unearned income shall be equal to difference
of rate of open land in sq. m as per ASR for BUA of land where such extra sale
component to be allowed & from the land from which such sale component is
shifted.
Such premium shall be paid to SRA in two stages viz-50% at the time of IOA of such
extra sale component to be allowed & balance at the time of issuing CC for the same.
Clubbing by the same developers, holding company & subsidiary company under the
provisions of Companies Act shall be permissible. However, in the case of
independent companies/Firms, common directors/partners shall have more than 75%
shareholding in both the companies/firms
Note.— This provision shall not apply to the plots wherein permissible Zonal F.S.I. is
less than 1.00.
The entire rehabilitation components including Base FSI may be categorized as
permanent transit component as applicable and the corresponding sale components
from the additional FSI amongst two or more schemes under this regulation can be
permitted to be interchanged. A developer / developers making an application under
this regulation may club more than one plot belonging to single or multiple owners
and offer permanent transit component on a single plot while shifting sale
component as well as base FSI of the plot to other plots provided all right holders of
these plots agree and make a joint application. However, clubbing shall be allowed
only if it leads to an independent plot / building / wing as the case may be with
permanent transit component being handed over to Planning Authority.
The developer shall have to pay premium equal to 40% of unearned income
calculated with the rates of construction as well as sale given in ASR of the year of
payment. The unearned income shall be computed by calculating valuation of sale
component awarded in lieu of component for Planning Authority after deducting cost
of construction of sale as well as Planning Authority’s component and the cost
incurred to various authorities towards statutory payments relating to Planning
Authority as well as sale component. In case there is shifting of base FSI within plots
in clubbing scheme, difference of land valued in ASR shall be taken into account while
finalizing unearned income, and this difference shall be calculated as 100% towards
premium.
Such clubbing can be allowed for the schemes falling within the distance of 5 km.
Provided further that the development under this regulation and under regulation
33(11) on non-reserved plot having the zonal (basic) FSI 1 or more, shall be
permissible.
(EP-99)
Such clubbing shall not be permissible for development under the provision of
scheme under the clause 3.11
Note: The premium amount so collected under rehabilitation scheme under this
regulation shall be kept in the separate account to be utilized as shelter fund for the
State of Maharashtra.
11. Conversion of Old Project into New Project:
11.1 Projects, where LOI has been granted, shall be treated as per the DCR provisions
existing on the date of LOI. In case such a project comes up for revised LOI or change
of developer or any other change, including recording and resubmission without
change in slum boundary, prevailing DCR provisions shall apply. Provided further
that for clubbing of schemes or amalgamation of schemes being sought and for
schemes that have been sanctioned under different regulations (earlier as well as
current one), FSI calculations shall apply as per the DCR regulations as on LOI dates of
different schemes.
11.2 Exceptions
1) Schemes approved prior to coming into force of these Regulation:
The slum rehab schemes where LOI has been issued by SRA prior to the date of
coming into force of these Regulations and which is valid (where not opted for
revision) may continue to be governed by the regulation applicable prior to these
Regulations.
2) Wherever the S.R. Scheme sanctioned by CEO (SRA) is under progress on
reservations as per sanctioned scheme note below clause No 7 of this Regulation,
shall be valid & continue.
33 (10) (A) Slum Rehabilitation Scheme under within Dharavi Notified Area (DNA)
for Dharavi Redevelopment Project (DRP):
Areas undertaken by Slum Rehabilitation Authority under DRP for redevelopment of
hutments situated on slum areas within DNA shall be part of entire DRP Area. The
DRP area which shall have an overall FSI of 4.00. The entitlement of FSI on that
particular plot would be in accordance with the guidelines given below
I Eligibility for redevelopment scheme
(a) For redevelopment of slums including pavements, whose inhabitant’s names
and structures appear in the electoral roll prepared with reference to 1st Jan, 2000 or
a date prior thereto, but where the inhabitants stay at present in the structure, the
provisions of this Regulation shall apply on the basis of a tenement in exchange for
an independently numbered structure.
(b) Subject to the foregoing provision, only the actual occupants of the hutments
shall be considered eligible, and the so-called structure owner other than the actual
occupant if any, even if his name is shown in the electoral roll for the structure, shall
have no right whatsoever to the reconstructed tenement against that structure.
II Definition of Slum, Pavement, Structure of hut, planning sectors and related
terms:
i) For this purpose, slums shall mean those censused, or declared and notified,
in the past or hereafter under the Maharashtra Slum Areas (Improvement, Clearance
and Redevelopment) Act. 1971 as amended time to time, hereinafter referred to as
Slum Act. Slums shall also mean areas/portions of pavement stretches, existing &
proposed roads, Railway Lands, area under electric H.T. power lines, Nalla banks
hereafter notified or deemed to be and treated as DRP Area.
ii) If any area fulfills the condition laid down in section 4 of the Slum Act to
qualify as a slum area and has been censused or declared and notified shall be
deemed to be and treated as DRP Area.
iii) DRP Area shall also mean any area declared as such by the SRA though preferably
fulfilling conditions laid down in section 4 of the Slum Act to qualify as slum area
and/or required for implementation of (DRP). Any area where a scheme under DRP
within DNA has been approved by Officer on Special Duty (OSD), DRP (SRA) shall be a
deemed DRP Area.
iv) Any area required or proposed for the purpose of construction of temporary
or permanent transit camps and projects on any/adjacent land for the amalgamated
land for developments so approved by the SRA shall also be deemed to be and
treated as DRP Area, and projects approved in such area by the DRP cell of SRA shall
be deemed to be DRP.
v) A pavement shall mean any Municipal/Govt./Semi–Govt. pavement and
shall include any viable stretch of the pavement as may be considered viable for the
purpose of DRP scheme.
vi) A structure shall mean by all dwelling areas of all persons who were
enumerated as living in that one numbered house in the electoral roll of the latest
date, up to 1st Jan 2000 and regardless of the number of persons, or location of
rooms or access.
vii) A composite building shall mean a building comprising both rehab and free-
sale components and part thereof along with built up amenity, if proposed, in the
same building.
viii) Censused shall mean those slums located on lands belonging to Govt., any
undertaking of Govt., or MCGM and incorporated in the records of land owning
authority as having been censused in 1976, 1980, 1985, 1995 or prior to 1st Jan 2000.
ix) “Dharavi Notified Area (DNA)” shall mean the area of Dharavi for which
GoM, by exercising the powers conferred by sub-section(1B) of section 40 of MR &
TP Act, 1966, have appointed ‘SRA’ as SPA for Planning & Development and which is
specifically defined in the Govt.’s notification no.TPB-4304/322/CR-56/04/UD-11 dt.
9/3/2005. and no.TPB-4308/3499/CR-83/09/UD-11 dtd. 25.6.2009.
x) “Planning sector” shall mean the plot of lands comprising C.S. Nos. /CTS
Nos. partly or wholly derived from DNA and which will be bounded mainly by existing
major roads, railway lines, village boundary and the proposed major roads so as to
achieve well planned and controlled development of DRP along with various
amenities and facilities to be provided for people at large within the boundaries of
such plots/areas. Such divided plots/areas are termed as planning sectors. The extent
of area and number of planning sectors shall be as per approval obtained from the
Committee of Secretaries appointed to monitor DRP vide Government Resolution of
Housing Department No. SRA/2003/CR-189/SI-1A dt. 4.2.2004 (hereinafter referred
to as “Committee of Secretaries”).
xi) “Implementing Sector” shall mean the plot of lands comprising C.S. Nos.
/CTS Nos. wholly derived from Planning Sector of DNA and which may be or may not
be bounded by existing major roads, railway lines, village boundary and the proposed
major roads with area not less than 4000 sq. m so as to achieve well planned and
controlled development within Planning Sector of DRP along with various amenities
and facilities to be provided for people at large within the boundaries of such
plots/areas.
III Joint ownership with spouse: The reconstructed tenement shall be of the
ownership of the hutment dweller and spouse co-jointly, and shall be so entered and
be deemed to be so entered in the records of the co-operative housing society to be
formed after getting allotment in the completed rehab building through Asst.
Register of societies (SRA), including the share certificates or all other relevant
documents.
IV Denotification as DRP Area: OSD, DRP (SRA) on being satisfied that it is
necessary so to do, or when directed by the state GoM, shall denotify the DRP Area.
1. Applicability of the provisions of this appendix:
The following provisions will apply for redevelopment/construction of
accommodation for hutment/pavement –dwellers which are part of DRP undertaken
by DRP (SRA) through the developer to be appointed by DRP(SRA) with the prior
approval of the committee formed by the Housing Department Resolution no.
Zopuyo 2003/CR-189/Zopsu-1 dt.4.2.2004 by following competitive bidding process
for DRP (SRA) through the developer or through Public Authority or as decided by
Government from time to time. This Regulation is not applicable to the properties
which are not part of DRP.
The properties which are not part of DRP as defined above shall be developed in
accordance with Regulation No 30 only. The other provisions of DCR allowing higher
FSI which are permitted under Regulation No 33 shall not be applicable to such
properties which are not part of DRP.
Right of the Hutment Dwellers:
1.1 Hutment-dwellers having existing carpet areas up to 27.88 sq. m (300 sq. ft.),
in the slum or on the pavement, eligible in accordance with the provisions of DCR
33(10) (A) shall in exchange for their structure, be given free of cost a residential
tenement having a carpet area totaling to 27.88 sq. m (300 sq. ft.) with a separate
living room, kitchen, bedroom, bath and water closet, but excluding common areas.
Carpet area shall mean exclusive of all areas under walls including partition walls if
any in the tenement.
1.2 For those structures having residential areas more than 27.88 sq. m (300 sq.
ft.) will be eligible for residential tenement having carpet area totaling to 37.16 sq. m
(400 sq. ft.). Out of this total 37.16 sq. m area, 27.88 sq. m (300 sq. ft.) area will be
free of cost and area above 27.88 sq. m (300 sq. ft.) admeasuring 9.29 sq. m (100 sq.
ft.) will be at construction cost to be determined by OSD, DRP (SRA) and the said cost
to be paid by the hutment dweller to the developer. Carpet area shall mean exclusive
of all areas under walls including partition walls if any in the tenement. Only 37.16 sq.
m (400 sq. ft.) carpet area shall be given and if proposal contains more area, it shall
not be taken up for consideration.
1.3 All eligible hutment dwellers taking part in the DRP shall have to be
rehabilitated according to the provisions in this Regulation. It may be in the same
sector or other sectors within the jurisdiction of DRP.
1.4 Pavement dwellers and hutment dwellers in the slum on the land required
for vital urgent public utility/purpose or on the hazardous location or affected by DP
proposals shall not be rehabilitated in-situ but in other available plots within
jurisdiction of DRP.
1.5 A certified extract of the relevant electoral roll shall be considered adequate
evidence to establish the eligibility of a person provided he is found residing in the
structure. This is to avoid the possibility of persons who have left the structure
coming back to claim free tenement under the scheme even though they have in the
normal course left the slum and gone away into a proper non-slum area or out of
DRP Area. If the hutment dwellers are found resident in the structure, but the names
are on the electoral roll on or prior to 1st Jan 2000, at another slum/pavement site in
Brihan Mumbai, they shall be considered eligible but only at the place of present
residence. In case of doubt or dispute, the decision of the Competent Authority to be
appointed by the Govt in Housing Department shall be final and binding on all the
parties concerned.
1.6 An individual agreement shall be entered into by the developer so appointed
under DRP by DRP (SRA) with the eligible hutment dwellers of each structure in the
slum/pavement.
1.7 The individual agreement entered into between hutment dwellers and the
land-owning authority/SRA/developer shall be in the joint names of pramukh
hutment dweller and spouse for every structure.
1.8 Hutments having a physically handicapped person or female-headed
households shall be given first preference in allotment of tenements to the other
hutment-dwellers. Thereafter lots shall be drawn for allotment of tenements from
the remaining tenements to the other hutment-dwellers.
1.9 Transfer of Photo passes – Since only the actual occupant at present will be
eligible for redevelopment, there shall be no need to regularize the transfers of
photo passes that have occurred so far.
1.10 Any person whose name is enrolled in a non-slum area in Brihan Mumbai but
has purchased a hutment in DRP area and therefore got his name also included in
electoral roll for the slum area, i.e. he has his name in the electoral roll at two places,
he shall not be eligible for the scheme.
1.11 Ownership and Terms of lease – The part of
Govt/MCGM/MHADA/MMRDA/Any Undertaking land on which the rehabilitation
component of DRP will be constructed shall be leased to the co-operative Housing
Society of the slum dwellers on 30 years lease at the lease rent of Rs. 1001 for 4000
sq. m of land or part thereof and renewable for a further period of 30 years. The
same conditions shall prevail for the land under the free sale component and the
land shall be leased directly to the Society/Association of the purchasers in the free
sale component and not through the society of hutment dwellers.
‘Premium for ownership and terms of lease-. That part of
Government/MCGM/MHADA land on which the rehabilitation component of the SRS
will be constructed shall be leased to the Co-operative Housing Society of the slum-
dwellers for 30 years. Annual lease rent of Rs. 1001 for 4000 per sq. m. of land or part
thereof and lease shall be renewable for a further period of 30 years at a time.
Simultaneously, land under free sale component shall be leased directly to the
Society/Association of the purchasers of the tenement under free sale component.
Pending the formation of the Society/Association of the purchasers in the free sale
component with a provision for further renewal for a period of 30 years at a time.
The lease rent for the free sale component shall be fixed by SRA.
In addition to above, the Developer/Co-op. Housing Society shall pay premium at the
rate of 25% of ASR in respect of SRS proposed to be undertaken on lands owned by
Government, Semi-Government undertakings and Local Bodies and premium shall go
to land owing authority such as MHADA, MCGM, MMRDA as the case may be. The
premium installment so recovered shall be remitted to concerned land owing
authority within 30 days from the date of recovery.
In the case of Govt. land, the premium shall be deposited in Nivara Nidhi.
The amount of premium shall be recovered in installment as may be prescribed by
Govt. from time to time. Land owning authority such as MCGM, MMRDA, MHADA
shall not recover land premium in any other form. Proposals for SRS on land owned
by Central Govt shall be accepted only after NOC for the scheme is obtained from the
concerned Central Govt. Department.
(EP-100)
1.12 Automatic cancellation of Vacant Land Tenure – If any land or part of any land
on which slum is located is under vacant land tenure the said tenure/lease created by
MCGM or Municipal Commissioner shall stand automatically terminated as soon as
DRP, which is a public purpose, on such land is prepared and submitted for approval
to the DRP cell of SRA. Any arrears of dues to be collected by MCGM shall not be
linked to the issue of any certificate or NOC relating to the DRP.
1.13 Recovery of pending dues such as assessment, compensation, occupational
charges, non-agricultural tax/dues etc. pending with public authorities such as State
Govt, MHADA, and/or MCGM shall be dealt with separately and not be linked to
grant of approval or building permission to the DRP.
1.14 In respect of those eligible hutment dwellers on site who do not join the
Project willingly the following steps shall be taken:
i) Provision for all of them shall be made in the renewal/rehabilitation
component of the scheme.
ii) The transit tenement that would be allotted to them would also be indicated
along with those who have joined the Project
iii) If they do not join the scheme within 15 days after the developer informs
OSD, DRP (SRA) of the unwillingness of the said dweller, then action under the
relevant provisions of the Slum Act, shall be taken and their structures will be
removed, and it shall be ensured that no obstruction is caused to the scheme of the
majority of persons who have joined the scheme willingly.
iv) After this action under the foregoing clause is initiated, they will not be
eligible for transit tenement along with the others, and they will not be eligible for
the reconstructed tenement by lots, but they will still be entitled only to what is
available after others have chosen which may be on the same or some other site.
v) If they do not join till the building permission to the Project is given, they will
completely lose the right to any built-up tenement, and their tenement shall be taken
over by the SRA and used for the purpose of accommodating pavement dwellers and
other slum dwellers who cannot be accommodated in situ etc.
vi) A pitch of about 3m x 3.5m will be given elsewhere if and when available, and
construction therein will have to be done on their own.
1.15 The Managing Committee of the Co-operative Housing Society of hutment
dwellers to be formed after allotment of reconstructed tenements shall have women
to the extent of one-third of the total strength of actual members on the committee
at any time.
1.16 Restriction on Transfer of Tenements: The tenement obtained under this
scheme cannot be sold/leased/assigned or transferred in any manner for a period of
ten years from the date of allotment/ possession of the tenement. In case of breach
of conditions, except transfer to legal heir, the tenement will be taken over by Slum
Rehabilitation Authority.
2. Building Permission under Dharavi Redevelopment Project:
2.1 The proposal for each planning sector of DRP shall be submitted to the DRP
cell of SRA with all the necessary documents, no-objection certificates and the plans
as may be decided by the SRA from time to time.
2.2 The approval to the Project shall be given by the DRP cell of SRA within a
period of 60 days from the date of submission of all relevant documents. In the
event of a failure by SRA to do so, the said approval shall be deemed to have been
given, provided the Project is in accordance with the provisions of this Regulation.
2.3 For DRP the SRA while giving the approval may lay down terms and conditions
as may be necessary.
2.4 DRP (SRA) shall adopt the procedure laid down in the MR&TP Act, 1966 for
giving building permission to any development in DRP under this Scheme.
2.5 On compliance with the terms and conditions, the building permission shall
be given in accordance with the provisions under Section 45 of the MR&TP Act, 1966
to the sectoral development under DRP, first to the Rehabilitation component and
thereafter to the free sale component subject to the provisions in clause below.
2.6 Correlation between Rehabilitation and Free sale components: Building
permission for 10 percent of BUA of both the rehab and free sale components may
be given simultaneously and thereafter proportionately or as may be decided by the
OSD, DRP, and SRA.
2.7 As soon as the approval (Letter of Intent) is given to the Project, the NOC for
building permission of the landowning authority shall be given in respect of that
lands belonging to any department, undertaking, agency of the State Govt including
MHADA, or any local self – Govt such as the MCGM within 60 days after the
intimation of such approval to the Project is communicated. In the event of its
refusal to grant NOC, reasons thereof shall be stated and in the event of its not been
given within the period, it shall be deemed to have been given.
2.8 Occupation certificate shall not be held up only for want of lease documents
to be executed in all sectoral developments under DRP taken up on lands belonging
to any department, undertaking, agency of the State Govt, including MHADA and any
local self-Govt such as the MCGM.
3. Rehabilitation and Free Sale Component
3.1 FSI for rehabilitation of eligible slum/pavement dwellers includes the FSI for
the rehab component and for the free sale component. The ratio between the two
components shall be as laid down herein below.
3.2 BUA for rehabilitation component shall mean total construction area of
rehabilitation component, excluding what is set down in 31(1) of D.C. Regulations,
including areas under passages, aaganwadi, health centre/outpost, community hall
/gymnasium / fitness centre, skill development centre, women entrepreneurship centre,
yuvakendra/ library balwadis, welfare centers, society office, religious structures, as
permitted under Government Home Department Resolution dt. 05/05/2011 and
18/11/2015 ‘other social infrastructure like school, dispensary, Gymnasium run by
Public Authority or Charitable trust’ 5 percent incentive commercial areas for the Co-
operative society, and the further 5 percent incentive commercial area for the NGO,
Govt./Public Authority/Govt. Company wherever eligible. and also including BUA of
various buildable reservations/additional amenities to be proposed in buildable form
in DNA
3.3 If the rehab component is 10 sq. m of BUA, then an additional 13.33 sq. m of
BUA will be permitted and this area of additional 13.33 sq. m can be utilized for
disposal in the open market and the rehab component subsidized.
3.4 (a) If the FSI required for rehabilitation of existing hutment dwellers plus free
sale component exceeds FSI 4.00 of a particular plot, such excess quantum shall get
absorbed while calculating overall FSI of 4.00 on entire DRP Area.
(b) The FSI in CRZ area within DNA, shall be governed by the MOEF
notifications issued from time to time.
3.5 The rehabilitation component shall mean all residential tenements as well as
non-residential built up premises given free of cost in accordance with the provisions
of the DRP outlined in this Regulation excluding what is set down in Regulation 31(1)
including anganwadi, health centre /outpost, community hall /gymnasium / fitness
centre, skill development centre, women entrepreneurship centre, yuvakendra / library
existing eligible religious structure, school, dispensary, gymnasium run by Public
Authority or Charitable Trust etc. as per provision of 8.1 & 8.2 BUA given for
buildable DP reservations and additional amenities & facilities to be provided as per
regulation no. 7.1 below.
3.6 Minimum Density on the Plot including Non-Residential Units: The minimum
density of rehabilitation component on plot shall be 650 tenements per net ha that
is, after deducting all reservations actually implemented on site including the land
appurtenant thereto, but not deducting the recreational/amenity open space on the
remaining area. If the number of tenements to be provided to the hutment dwellers
is less than the minimum, the balance shall be handed over free of cost to the SRA,
the Authority shall use them for the purpose of transit or Project affected persons or
pavement dwellers or slum dwellers from other slums.
3.7 All non-residential BUA shall be included in the computation of minimum
density and on the scale of 27.88 sq. m. of carpet area being one tenement. The
calculation of FSI for all purposes shall be on gross area, that is, without deducting
any percentage for recreational/amenity open space. This shall not affect the
requirement of keeping aside the said recreational/amenity open space physically on
site, subject to the provisions in this Regulation in that regard.
3.8 Amalgamation/Subdivision of Plots and Balancing of FSI thereon: Any land
declared as DRP Area or on which DRP has been sanctioned, if it is spread on part or
parts of C.S. Nos. or CTS Nos. or S. Nos. or F.P. No shall be treated as natural
amalgamation/subdivisions/ of that C.S or CTS or S. No. or F.P. No. for which no
separate approval for amalgamation/subdivision of land would be necessary.
3.9 Boundaries and the measurement of plot areas of the DRP Area shall be
declared by the competent authority after actual measurement of plot area on site
and the same shall be adopted for planning purpose for calculation of density and
floor space index.
3.10 The OSD, DRP(SRA) may if required, adjust the boundary of the plot declared
as DRP Area so as to suit the building design and provide proper access to the
Project/any other plot/s located within Sector/s.
3.11 After approval is given to the DRP, the area may be further subdivided if
necessary to earmark separate plots for the rehab component, amenity plot and the
free sale component. The Plot area and the BUA in terms of square meters on the
said plot shall be separately mentioned in the lease agreements and Record of Rights.
3.12 The Settlement Commissioner, Maharashtra State on payment of such fees as
may be decided by the Govt ensure that the City Survey sheet and property cards are
corrected accordingly and fresh property cards are opened for each of the plots
giving details regarding the area of the plots and the total area of the floors of the
built-up property and TDR given that is, the FSI used on that plot.
4. Temporary Transit Camps:
4.1 The temporary transit camp/transit accommodation shall be provided within
DNA or nearby lands with prior approval of DRP(SRA) and if need be on the area of
statutory open space to be left in accordance with Regulation No. 27 on the plot.
4.2 On the slum site itself approved for rehabilitation, multi-storeyed temporary
transit tenement may be allowed to be constructed.
4.3 The area of temporary transit tenements shall be excluded from the
computation of FSI, but the safety of the structure shall be ensured.
4.4 Such building permission shall be given within 15 days from the date of
application of the appointed developer of a sector, by OSD, DRP(SRA) failing which it
shall be deemed to be given.
4.5 On any vacant site without any reservation in the DP Excluding construction
of temporary transit tenements made of light material with the consent of the land-
owners or concerned govt authority shall be allowed up to the FSI of 4.0 Temporary
shall mean made of detachable material such as tubular/prefabricated light
structural or any other materials approved by OSD, DRP (SRA) but such structures
which are erected temporarily.
4.6 In all such cases where the temporary transit camp is erected, the condition
shall be that the structures shall be demolished by the Developer within 30 days after
such intimation given by SRA and as per phase programme of development as
approved by DRP Cell and the site should be brought back to the original state.
5. Commercial/Office/Shop/Industrial Structures/Structures for Potters
Business Activity Free of Cost:
5.1 The eligible existing area under commercial/office/shops/industrial
establishments/structures for potters business activity shall be computed on actual
measurement/inspection, and/or on the basis of official documents such as License
under Shops and Establishment Act, Trade License, Factory License, Electricity bills
and Photo pass etc.
5.2 In the rehabilitation component, the BUA for
commercial/office/shop/Industrial establishments/potters structures/economic
activity that existed prior to 1st January, 2000, subject to the provisions in the sub-
regulation below, shall be given. Where a person has residential and commercial
premises without common wall between residential and commercial premises, for
commercial/office/shop/structures for potter’s economic activity in the
slum/pavement, he shall be considered as eligible for a residential unit and also for
BUA for commercial/office/shop/Industrial establishments/structures for
potter’s/economic activity, both free of cost.
5.3(a) Commercial & Industrial Structures:
BUA for Commercial and Industrial establishment up to 20.90 sq. m (225 sq. ft.)
carpet area or actual area whichever is less, shall be provided to the eligible person
free of cost as part of the rehabilitation project. Any area in excess of 20.90 sq. m
may, if required, be sold to the extent of area in the following manner:
Existing Carpet Area to be provided (in sq. ft.)
Carpet Area in
At free of With Cost
the range of …
cost, as a But not as part of incentive sale area
(in sq. ft.) part of
With 10% With 20% With 30%
Rehab
Reduction Reduction Reduction
component
225 to 250 225 Nil Nil Nil
251 to 1000 225 251 to 1000 Nil Nil
1001 to 1500 225 251 to 1000 1001 to 1500 Nil
1501 and 225 251 to 1000 1001 to 1500 1501 and above
above
However, only non-polluting and non-hazardous industry can be allowed to be re-
accommodated under this scheme. The rehab area in excess of 20.90 sq. m. (225 sq.
ft.) will be at construction cost to be determined by OSD, DRP (SRA) and the said cost
to be paid by the hutment dweller to the developer.
(b) Structures of Potters’ Business Activity:
BUA Structures of Potters’ Business Activity up to 20.90 sq. m (225 sq.
ft.) carpet area or actual area whichever is less, shall be provided to the eligible
person free of cost as part of the rehabilitation project. Any area in excess of 20.90 sq.
m may, if required, be sold to the extent of area in the following manner.
Existing Carpet Area to be provided (in sq. ft.)
Carpet Area in
At free of With Cost
the range of …
cost, as a But not as part of incentive sale area
(in sq. ft.) part of
With 10% With 20% With 30%
Rehab
Reduction Reduction reduction
component
225 to 250 225 Nil Nil Nil
251 to 1000 225 251 to 1000 Nil Nil
1001 to 1500 225 251 to 1000 1001 to 1500 Nil
1501 and 225 251 to 1000 1001 to 1500 1501 and above
above
The rehab area in excess of 20.90 sq. m (225 sq. ft.) will be at construction cost to be
determined by OSD, DRP/SRA and the said cost to be paid by the hutment dweller to
the developer.
5.4 Such area may be allowed on any side of the plot abutting at least 6.0 m wide
pathway and deriving access from at least 6.0 m wide pathway/open space. Back-to-
back shopping on ground floor shall also be allowed for the purpose of rehabilitation.
After exhausting these provisions, it may be allowed on the first floor to the extent
necessary.
5.5 Non-Conforming Activities: All activities which previously existed shall be
allowed to be relocated regardless of the non-conforming nature of the activities,
except those which are hazardous and highly polluting and except in cases where the
alternative accommodation has already been allotted elsewhere by the MCGM.
5.6 Non-Residential User in Free Sale Component:
Non-Residential User as permissible in R and C zones as per DCR 34
shall be allowed in Free Sale Components.
6. RELAXATION IN BUILDING AND OTHER REQUIREMENTS:
6.1 A Residential rehab/renewal tenement shall essentially have a separate living
room, kitchen, bedroom, water closet unit, bathroom along with enclosed balcony
merged in carpet area of the tenement
6.2 There shall be no restriction on zone and balcony shall not reduce marginal open
space to less than 2.0 m for calculating of area of 27.88 sq. m and 37.16 sq. m size of
rehab tenements, the area of the balcony shall be included.
6.3 Notwithstanding anything contained in these Regulations, common passages
to be provided in the Rehab Component to give accesses to Residential tenements
and Commercial/Industrial units shall not be less than 2.0 m in width. If podium is
proposed, the corridors formed under the podium up to 12.00 m in width to be used
as passage for Rehab & Renewal Commercial/Industrial units & Amenities, shall not
be counted towards FSI even while computing 4.00 FSI on site. The areas under such
common passages not exceeding 2.00 m in width and up to 12.00 m width shall form
part of Rehab Component and it is on this basis the free sale component will be
calculated.
6.4 Corridors formed under the podium up to 12.00 m in width giving access to
the sale commercial component shall also be considered free of FSI.
6.5 Front and marginal open spaces for building having height up to 32 m in the
rehab component or composite building for the ground + 1 podium to be proposed
to accommodate rehab commercial/industrial units as well as sale commercial areas
in composite structures, the front and marginal open space shall be at least 3.0 m for
these buildings.
6.6 Notwithstanding the provisions of Regulation No. 41 Table No 18 where the
location of the plot abuts DP Road, having width of 18.3 m and above, the front
marginal open space shall be at least 3.00 m provided it is not an express highway or
road wider than 52 m
6.7 Where the location of the plot abuts a nallah, the marginal open space along
the nallah shall not be insisted upon beyond 3 6 m from the edge of the trained
nallah.
6.8 The distance between any two rehab/composite buildings shall not be less than 6
m for the height up to 32 m and for the building with height more than 32 m the
open spaces shall be as per Regulation No 41(5).
6.9 A composite building shall contain at least 40 percent of the built-up area as
rehabilitation components.
6.10 Wherever more than the minimum front and marginal spaces have been
provided, such additional area provided may be considered as part of the AOS in the
project comprising both rehabilitation and free sale components, and without
charging any premium in relaxation of the stipulations in DCR No.27, wherever
necessary.
6.11 The pathway shall act as access wherever necessary. The building shall be
permitted to touch pathways.
6.12 The means of access shall be normally governed by the provisions of Regulation
No. 23. However, in the project, wherever the design of the buildings in the same
land requires relaxation, it may be given. Access through existing pathways including
the roads maintained under Section 63K of the MMC Act, 1888 but not less than 3.6
m in width, shall be considered adequate for any slum rehabilitation project,
containing buildings having height up to 32 m including stilts.
6.13 Even if the AOS is reduced to make the planning of the rehab sub-plot viable, a
minimum of 15 percent of amenity open space shall be maintained.
6.14 Premium shall not be charged for exclusion of staircase and lift-well etc. as
covered under the provisions of DCR 31(1).
6.15 All relaxations outlined hereinabove shall be given to the rehabilitation
component, and also to the composite buildings in the project. Premium shall not be
charged for all or any of the relaxations given hereinabove, or for any other
mentioned in DCR 31(1). Provided that further relaxation in open spaces if any
is considered, then the same shall be subject to compliance of CFO
requirement and recovery of premium at the rate 2.5% of Annual Schedule of
Rate.
6.16 Relaxations for the free sale component – Relaxation contained in sub-
regulation No.6.6, 6.7, 6.11, 6.12, 6.13 above, other necessary relaxation shall be
given to the free sale components for deficient area on payment of premium at the
2.5% rate of ASR for open land (for FSI 1) or 10% of normal premium whichever is
more.
6.17 In order to make the Slum Rehabilitation Scheme viable, the OSD, DRP shall be
competent to make any relaxation wherever necessary for reasons to be recorded in
writing by charging 2.5% rate of ASR of open land (for FSI 1.) or 10% of normal
premium whichever is more.
7. SLUMS AND DEVELOPMENT PLAN RESERVATIONS:
7.1 Reservations in the DP shall be developed to the fullest extent. Additional
amenities and facilities shall be provided as per the quantum shown in Annexure – ‘A’
to this Regulation. Relocation of reservations within sector if so required to
overcome the sector planning constraint shall be permitted with the special
permission of CEO/OSD(DRP) of SRA.
Area of amenities and facilities to be provided as per Annexure-A shall be inclusive of
reservations in sanctioned DP. Types of reservations and area of reservations shall in
no case be reduced
7.2 Slums/Structures under renewal situated in lands falling under residential(R),
commercial(C), industrial (I) zones which are not affected by any other
allocations/designations/reservations in the final DP & may be developed subject to
the following:
(i) (a) Lands in residential (R) and commercial (C) zones occupied by existing
slums/structures under renewal be allowed to be developed in accordance with the
provisions contained in this Regulation.
(b) Lands in industrial zones (I)/Industrial estate may be allowed to be converted
into residential users in accordance with Regulation No 14(B). Such lands occupied
by existing slums/structures under renewal may further be allowed to be developed
in accordance with the provisions contained in this Regulation.
(ii) Lands in industrial zone (I) occupied by existing slums/structures under
renewal shall be allowed to be developed in accordance with the provisions
contained in this sub-regulation 33(10) (A) and 33 (9) (A).
(iii) As a special case for DRP nonresidential activities to be developed as
described under clause no.5.3 and 5.6 of this Regulation & clause no. 4 & 7
Regulation No 33 (9) (A) shall be allowed to be developed without going through the
process of the change of zone.
7.3 Slums/structures under renewal situated on lands
reserved/designated/allotted for existing or proposed non-buildable reservations
such as playground, garden, park and any other open users in the Final DP occupied
by existing slums/structures under renewal shall be shifted within the same planning
sector in which such plots belongs/vests and sites occupied by them shall be cleared
for the implementation of DRP in which such quantum of designated/allotted for
existing or proposed non-buildable reservation shall be fully subsumed in the
additional amenities & facilities to be provided under DRP as in clause no. 7.1 above
as per the specifications of DRP (SRA) or the concerned Govt. authority and shall be
handed over free of cost and charge to the DRP (SRA) or the concerned Govt.
authority. The land area under such reservation shall be allowed to be included in the
project plot area to be considered for FSI purpose.
7.4.(a) Slums/structures under renewal situated on lands
reserved/designated/allotted for existing or proposed buildable Public reservations
in the Final DP such as Municipal/Private primary or secondary schools, Municipal
dispensary, Municipal hospitals, Maternity home, Municipal chowky, Fire brigade,
Sewage treatment plant, Pump house, Municipal retail market shall be shifted within
the same planning sector in which such plots belong/vest and sites occupied by them
shall be cleared for the implementation of DRP in which such quantum of
designated/allotted for existing or proposed buildable reservation shall be fully
subsumed in the additional amenities & facilities to be provided under DRP as in
clause no. 7.1 above as per the specifications of DRP/SRA or the concerned Govt.
authority to whom this developed amenity is to be handed over. This developed
buildable amenity shall be handed over free of cost & charge to the DRP/SRA or the
concerned Govt. authority. The BUA of such amenity shall be excluded for the
purpose of FSI. Thereafter the full permissible FSI of the plot according to this
Regulation shall be allowed to be included in the project plot area to be considered
for FSI purpose.
7.4 (b) For other buildable reservations on lands under slum which are not covered
under clause no. 7.4(a) above, BUA equal to 25 percent of the area under that
reservation in that plot shall be demanded free of cost by the SRA for MCGM or any
other appropriate Authority. The BUA of such amenity shall be excluded for the
purpose of FSI computation. Thereafter the development for DRA be allowed as per
the full permissible FSI of the entire plot according to regulation 33(10) (A) read with
this Regulation and subject to provisions in clause No. 7.1
7.5 Where DP road/Proposed road passes through DRP area, the entire 100
percent FSI of the road may be given in the same site, on the remainder of the plot.
7.6 Development of Slum Plots under DCR 33(10) (A) and Urban Renewal plots
under DCR 33(9) (A) in a planning sector may be allowed to be developed together in
order to promote flexibility of design as well as to raise more resources. The power
under Regulation 13(6) for shifting and/or interchanging the purpose of
designations/reservations shall be exercised by the OSD, DRP (SRA) in respect of DNA
as a SPA in consultation of MCGM.
7.7 In case of DRP adjoining railway tracks, a boundary wall of minimum, 2.4 m in
height shall be constructed.
7.8 Slums/structures under renewal on lands designated or reserved for purpose
of Rehabilitation and Resettlement shall be treated as sites for slum redevelopment
and redevelopment to be allowed according to this Regulation.
7.9 Existing slums occupying lands/structures under renewal in dangerous
locations such as marshy lands, near water bodies, lands abutting railway tracks/in
railway lands, NDZ and sites immediately required for the public and semi-public
projects may be relocated at other suitable locations within the planning sectors and
may be allowed to be developed in accordance with this Regulation.
8. WELFARE HALL, BALWADI, SOCIETY OFFICE AND RELIGIOUS STRUCTURE
Aaganwadi, Health Centre / Outpost, Community Hall /Gymnasium / Fitness
Centre, Skill Development Centre, Women Entrepreneurship Centre, Yuva Kendra /
Library, Society Office, and Religious Structures:
8.1 There shall be a welfare hall in each project as part of the rehabilitation
component. It shall be at the rate of 25.00 sq. m for every multiple or part of 100
hutment dwellers’ families, but located so as to serve all the floors and buildings
equitably. Further, they may be clubbed together suitably for its better utility. In case
of misuse, it shall be taken over by the DRP (SRA) which will be competent to allot
the same to some other organization/institution for public use. Balwadi shall also be
provided for on a similar scale. An office for the Co-operative Housing Society shall
also be constructed in accordance with Regulation No. 37(11). However, if the
number of Rehab Tenements exceeds 100 then for every 100 Rehab Tenements such
additional society office shall be constructed. Religious structures existing prior to
redevelopment, if allowed in accordance with the guidelines issued by Govt from
time to time as part of redevelopment shall not exceed the area that existed prior to
redevelopment. Social infrastructure/s like School/s, Dispensary/s, Gymnasium/s
certified by the Competent Authority as existing prior to the redevelopment shall be
allowed without increase in existing area.
There shall be health Centre/ outpost, Aaganwadi, skill development centre, women
entrepreneurship centre, yuvakendra / library of size 25 20.90 sq. m for every multiple
of or part of 250 100 hutment dwellers. In case of misuse, it shall be taken over by the
DRP(SRA) which will be competent to allot the same to some other organization
/institution for public use. Balwadi shall also be provided for on a similar scale. An
office for the Co-operative housing society shall be also constructed for every 100
rehab tenements in accordance will D.C. Regulations No. 37(9). However, if the
number of rehab tenements exceeds 100 then for every 100 rehab tenements such
additional society office shall be constructed. There shall be a community hall for
rehab bldg. of the Project as a part of the rehabilitation component. The area of such
hall shall be 2% of rehab built up area of all the buildings or 200 sq. m whichever is
less.
Religious structures existing prior to redevelopment, if allowed in accordance with the
guidelines issued by Govt. from time to time as part of redevelopment shall not exceed
the area that existed prior to redevelopment. Other social infrastructure like School,
Dispensary and Gymnasium run by Public Authority or Charitable Trust that existed
prior to the redevelopment shall be allowed without increase in existing area.
However, it is provided that in the slum rehabilitation project of less than 250
hutments, there shall be Balwadi, Welfare hall and any of two amenities mentioned
above, as decided by co-operative housing society of slum dwellers, of size of 25
sq.mt and office for the Co-operative housing society in accordance with D.C.
Regulations No. 37(9). OSD, DRP(SRA) may permit accumulation of the amenities
mentioned above but ensure that it shall serve equitably to the rehab area.
(EP-101)
8.2 All the areas underlying social infrastructure/s like School/s, Dispensary/s,
Gymnasium/s certified by the Competent Authority as existing prior to the
redevelopment shall be free of cost & shall form part of rehabilitation component
and it is on this basis the free sale component will be computed.
All the areas underlying Aaganwadi, health centre / outpost, community
hall/gymnasium / fitness centre, skill development centre, women entrepreneurship
centre, yuvakendra / library community hall/s, society office, balwadi/s, religious
structure/s, social infrastructure like School, Dispensary, Gymnasium run by Public
Authority or Charitable Trust, the commercial areas given by way of incentives to the
co-operative society and the nongovernmental organisation shall be free of cost and
shall form part of rehabilitation component and it is on this basis the free-sale
component will be computed.
These provisions shall apply to construction of transit camps under DC Regulations
33(11) also.
8.3 Welfare halls, society office, balwadis and religious structure/s, “Social
infrastructure/s like school/s, Dispensary/s and Gymnasium/s certified by the
Competent Authority as existing prior to the redevelopment in the Rehab Component
shall not be counted towards the FSI even while computing 4.00 FSI on site.
However, social infrastructure like school, dispensary and gymnasium run by other
than Public Authority or Charitable Trust shall be counted towards F.S.I.
Aaganwadi, health centre / outpost, community hall /gymnasium / fitness centre,
skill development centre, women entrepreneurship centre, yuvakendra / library,
society office, Balwadi/s, and religious structures, social infrastructure like School,
Dispensary and Gymnasium run by Public Authority or Charitable Trust in the rehab
component shall not be counted towards the FSI even while computing permissible
FSI on site.
9. PAYMENTS TO BE MADE TO SRA AND INSTALMENTS:
9.1 An amount of of Rs 20,000 40000/- or such an amount as may be decided by
the Govt from time to time per tenement/unit will have to be deposited by the
developer with DRP as a corpus fund for utilization by the co-operative housing
society of the rehab residents for the purpose of maintenance, in accordance with
the time-schedule for such payment as may be laid down by OSD, DRP (SRA).
However, by the time of completion of construction for occupation of tenements by
the hutment dwellers, the total amount at the rate of Rs 40000 per tenement
completed should have been deposited in full. The building permission for the last 25
percent of the free sale component would be given only after the entire required
amount is deposited in full with DRP (SRA). A matching amount of Rs 20000/- per
rehab tenement/unit shall also be deposited by DRP and added to the said corpus
fund.
9.2 e granting approval
burbs,(250250250250250250250250250250250250250250250250250250250250
250250250250250250250250250250250250250250250250250250250250250250
250250250250250250250250250250250250250250250250250250250250250250
250250250250250250250250250250250250250250250250250250250250250250
250250250250250250250250250250An amount at the rate of 2% of ASR for BUA or
such an amount as may be decided by Govt from time to time shall be paid by the
Developer for the BUA over and above the normally permissible FSI, for the
rehabilitation and free sale components. This amount shall be paid to the SRA in
accordance with the time schedule for such payment as may be laid down by the
OSD, DRP of SRA, provided the installments shall not exceed beyond the completion
of construction. These infrastructural charges shall be in addition to development
charges levied as per section 124 of MR&TP Act 1966.
Provided that out of amount so recovered as Infrastructural Charges, 90%
amount shall be go to MCGM and 10% amount will go to DRP (SRA).
9.3 The part of land premium to be made available to the land-owning authority as
per rates to be decided by GoM shall be exclusively used for schemes to be prepared
for the improvement of infrastructural developments in the benefit of DRP.
ANNEXTURE –“A”
10. Additional amenities and facilities to be provided under DRP to be read with
clause 7.1 of Regulation no. 33 (10) (A):
Sr. Description of
Legends Units Additional amenities & facilities to be provided under DRP
No. the Amenity
Sector I Sector II Sector III Sector IV Sector V Total I to V
Buildable Amenities
for which Sale
Incentive is available.
Primary and
sq. m
Secondary RE1.2 9066.97 16433.89 13600.46 12467.09 5100.17 56668.58
School
2 Higher
10000.00
Education
RE2.1 sq. m (with 2
Secondary 6066.97 16433.89 12650.55 11517.18 56668.58
colleges)
School
3 Municipal
Dispensary RH1.1&
/Health Post & sq. m
RH1.3 6272.00 11368.00 9408.00 8624.00 3528.00 39200.00
Municipal
Maternity
Sr. Description of
Legends Units Additional amenities & facilities to be provided under DRP
No. the Amenity
Sector I Sector II Sector III Sector IV Sector V Total I to V
Homes
/Polyclinics
4 Welfare Centres
+ Gysm + sq. m
-- 200.00 200.00 200.00 200.00 200.00 1000.00
Community Hall
5 Library -- sq. m 200.00 200.00 200.00 200.00 200.00 1000.00
6 Fire Station RPU1.1 sq. m 0.00 0.00 0.00 3990.00 0.00 3990.00
7 Post Office -- sq. m 665.00 0.00 0.00 665.00 0.00 1330.00
8 Police Station RPU3.1 sq. m 1995.00 1995.00 0.00 0.00 0.00 3990.00
9 Retail Market RSA1.2 sq. m 2511.04 4551.26 3766.56 3452.68 1412.46 15694.00
10 Police Chowky RPU3.2 sq. m 140.00 140.00 140.00 140.00 140.00 700.00
11 Potters Institute
(common work - sq. m 0.00 2230.00 0.00 0.00 0.00 2230.00
space)
Total 27116.99 53552.04 39965.57 41255.95 20580.64 182471.17
Total Land Area of
Buildable Amenities
not to be constructed
by the developers.
12 Best Bus Facility
RT1.4 Ha 0.00 0.00 0.06 0.00 0.00 0.06
Station
13 Best receiving
station /Tata
ha 0.00 1.30 0.00 0.00 0.00 1.30
Receiving
Station
14 Pumping station Ha 0.00 0.00 0.37 0.00 0.00 0.37
15 NID & ITI
(Other RE3.1 Ha 0.00 0.30 0.000.30 0.00 0.00 0.30
Education)
Total 0.00 1.60 1.30 0.43 0.73 0.00 0.00 2.03
Total Land Area of Un-
Buildable Amenities
16 Parking Lot RT1.6 ha 0.00 0.00 0.00 0.00 1.84 1.28 1.84 1.28
Sr. Description of
Legends Units Additional amenities & facilities to be provided under DRP
No. the Amenity
Sector I Sector II Sector III Sector IV Sector V Total I to V
17 Public Open
Spaces (can be
ha 1.58 0.00 1.58 1.58 1.58 6.32
mixed user /
part of layout)
18 Layout RG that
would be
provided in sale ha 0.77 1.39 1.15 1.06 0.43 4.81
and rehab areas
to be multi used
19 Play Ground
attached to
schools (mixed Ha 0.40 0.73 0.60 0.55 0.23 2.50
use / part of
layout)
20 Mahim
Recreational
Ground (Rajiv
Gandhi Nagar)
Mahim Nature
Park Extension Ha 0.00 0.00 0.00 0.00 3.20 3.2
(1.33 ha),
Afforestation
(0.83 ha) and RG
below HTL (1.04
ha)
21 Potters Institute - Ha 0.00 0.22 0.00 0.00 0.00 0.22
(common open
space)
22 Land to be given Ha 0.00 0.40 0.00 0.00 0.00 0.40
to TATA Power
Electric Co.
Total 2.75 2.74 3.33 3.19 7.28 6.72 19.29 18.73
Not All the additional amenities and facilities to be provided within DRA are deemed to be treated as DP Proposals.
e
All proposed roads having width of 12 m & above are deemed to be treated as DP Proposals.
The SRA may add, alter or amend category and quantum of additional amenities and facilities to be provided within
DNA with the approval of GoM.
Note:
The provisions of the DC Rules for Greater Mumbai, and all other applicable sections
of the MA & TP Act, 1966, shall apply mutatis mutandis to the development of land
with the modification that the expressions "MCGM" and "Municipal Commissioner"
shall be substituted by the expressions "SRA" and "OSD, DRP (SRA)” respectively.
33(11) Provisions relating to Permanent Transit Camp tenements for Slum
Rehabilitation Scheme/Rental housing:
Total FSI on gross plot area may be allowed to be exceeded up to 4 for construction
of Transit Camp tenements for SRA/Rental Housing.
(A) The FSI & distribution of additional FSI for the construction of Transit Camp
Tenements/Rental Housing shall be as shown below:
Locatio Plot area Minimu Total Zon Addition % FSI for % FSI for
n excluding area m Road permissib al al FSI Transit sale
to be handed Width le FSI FSI tenemen compone
over in lieu of ts for nt of total
Reservation SRA/ additional
/Designation in Rental FSI
the DP except Housing
affected by of total
proposed DP additiona
roads/Sanction l FSI
ed RL under
MMC Act
1 2 3 4 5 6 7
Island Up to 2000 sq. 12m Up to 3.0 1.33 Up to 1.0
City m 1.67 1.67 37%
Above 2000 sq. 18m Up to 4.0 1.33 Up to 63%
m 2.67
Suburbs Up to 2000 sq. 12m Up to 3.0 1.00 Up to 1.50 1.50
& m 2.0 50% 50%
Extende
Above 2000 sq. 18m Up to 4.0 1.00 Up to
d
m 3.00
Suburbs
(B) Such Schemes shall not be permissible on lands reserved/designated existing
amenity in the DP & in NDZ SDZ/GZ.
(C) Transit tenements for SRA out of additional FSI could be used for construction of
Transit Camp of tenements having carpet area of 25 sq. m (269sq.ft.). Ground floor
shall be used for commercial tenement shaving carpet area of 20.90 sq. m
(225 sq. ft.) for project affected commercial tenements & same shall be
handed over free of cost to SRA. Alternatively, residential tenements can be used
for Govt Staff Quarters etc.
(D) Provision of Aaganwadi, Health Centre / Outpost, Community Hall /Gymnasium /
Fitness Centre, Skill Development Centre, Women Entrepreneurship Centre, Yuva
Kendra / Library, Society Office, Balwadi, shall be as per sub-regulation 8 of
regulation 33(10) to these transit camps. 25% of Zonal (basic) FSI shall be exclusively
used for the purpose of shops along layout road for use of residential occupants of
layout.
(E) Additional FSI over & above Zonal (basic) FSI may be released in co-relation to the
BUA of the tenements that are required to be handed over free of cost to SRA/
MCGM as the case may be. Alternatively, TDR in lieu of unconsumed sale component
of additional FSI, as per this Regulation, may be permitted for Permanent Transit
Camp (PTC) and Rental Housing for which SRA will be the Planning Authority.
(F) Only after the Transit Camps are handed over free of cost to the SRA, the
Occupation Certificate, water connection, power connection etc. for the other
portion shall be given by the Appropriate Authority.
(G) Clubbing: In case of two or more nos. of PTC/schemes taken up for development
by same owner or collaborating owners/developers/Co-Operative Societies of slum
dwellers under any legal arrangement approved by CEO (SRA), both rehab and sale
components of the said slums can be combined and located in any proportion in
those plots provided that the FSI as stipulated in Table above is not exceeded.
However, clubbing shall be allowed only if it leads to an independent
plot/Building/Wing as the case may be with SRA component being handed over to
SRA.
Whenever such clubbing of PTC schemes on plots/lands having different ASR is
approved &PTCs are shifted on land having lesser ASR, the Developer shall have to
pay premium equal to 51% of unearned income on extra sale component being
available than which would have been otherwise available on such plot as standalone
scheme. Such unearned income shall be equal to difference of rate of open land in
sq. mas per as per ASR (on the date of clubbing of the scheme) of BUA of land where
such extra sale component to be allowed & from the land from which such sale
component is shifted. Such premium shall be paid to SRA in two stages viz-50% at the
time of IOA of such extra sale component to be allowed & balance at the time of
issuing CC for the same. However, such clubbing shall not be permissible for
development under the provision of SRA scheme under clause 3.11
Note.— This provision shall not apply to the plots wherein permissible Zonal F.S.I. is
less than 1.00.
The entire rehabilitation components including Base FSI may be categorized as rental
housing and permanent transit component as applicable and the corresponding sale
components from the additional FSI amongst two or more schemes under this
regulation can be permitted to be interchanged. A developer / developers making an
application under this regulation may club more than one plot belonging to single or
multiple owners and offer permanent transit component on a single plot while
shifting sale component as well as base FSI of the plot to other plots provided all right
holders of these plots agree and make a joint application. However, clubbing shall be
allowed only if it leads to an independent plot / building / wing as the case may be
with permanent transit component being handed over to Planning Authority.
The developer shall have to pay premium equal to 40% of unearned income
calculated with the rates of construction as well as sale given in ASR of the year of
payment. The unearned income shall be computed by calculating valuation of sale
component awarded in lieu of component for Planning Authority after deducting cost
of construction of sale as well as Planning Authority’s component and the cost
incurred to various authorities towards statutory payments relating to Planning
Authority as well as sale component. In case there is shifting of base FSI within plots
in clubbing scheme, difference of land valued in ASR shall be taken into account while
finalizing unearned income, and this difference shall be calculated as 100% towards
premium.
Such clubbing can be allowed for the schemes falling within the distance of 5 km.
The premium shall be paid to the Planning Authority in two stages 50% at the time IOA and
50% at the time of issuing C.C. for the incentive FSI. or the developer has to surrender
equivalent sale FSI in form of constructed BUA to the extent of premium in the scheme to be
valued at ASR rate of sale in the year of such surrender of built up area.
Note: Out of the The total premium amount so collected under rehabilitation scheme
under this these Regulation, 2/3 shall be kept in a separate account to be utilized as
shelter fund for the State of Maharashtra and 1/3 shall be deposited at the Office of the
Deputy Director of Town Planning, Greater Mumbai.
(EP-102)
33(12). Redevelopment of contravening structures included in the Final Plot of a
Town Planning (TP) Scheme and Removal and re-accommodation of
tolerated structures falling in the alignment of road:
(A) Redevelopment of contravening structures included in the Final Plot of a TP
Scheme.
For the redevelopment/reconstruction of contravening structures situated in TP
Schemes, additional FSI over and above permissible FSI prescribed under these
Regulations shall be admissible as under:
a. In the redevelopment scheme the number of tenants as recorded in the TP
Scheme Book and residing in the contravening structures shall be accommodated by
giving alternative accommodation in the redevelopment schemes in the same
scheme or in the same administrative ward having carpet area of 25 sq. m (269 Sq.
ft.) each, irrespective of their original holding provided the overall FSI consumption of
the Final Plot shall not exceed 4.0.
b. The Commercial users may be permitted in the redevelopment scheme to
accommodate the existing commercial tenants, provided the commercial area in the
redevelopment scheme shall not exceed the original commercial area.
c. The tenants not listed in the records of TP Scheme but residing in contravening
structure or such structures which have come up after TP Scheme is finalized, but are
existing before 01.01.1995 on date as notified by the GoM from time to time and
where structures and inhabitants names are appeared in the Legislative Assembly
Voter’s List of 1995 year as notified by the GoM from time to time shall also be
eligible for being included in the Redevelopment Scheme. Such tenants shall also be
granted accommodation at the rate of 25sq. m of carpet area per tenant 25 sq. m. in
case of residential/residential cum commercial occupants and in case of commercial
occupants, existing area or 20.90 sq. m, whichever is less provided the total FSI of the
plot does not exceed 4.0.
d. BUA equivalent to the area held by the tenant or 25 sq. m whichever is less shall
be handed over free of cost to the respective tenant by the Developer/Owner, while
for the balance BUA, an amount as may be mutually agreed to between tenant and
Owner/Developer shall be paid by the tenant. Condition to this effect shall be
prescribed by the MCGM while approving redevelopment proposal.
e. For the purpose of this redevelopment scheme, the owner/ developer shall get
further additional FSI to the extent of 50% of the area of the structures covered
under Sr. No. (a), (b), (c) & (d) above provided further that the overall FSI of the Final
Plot shall not exceed 4.0.
f. The Fungible compensatory area shall be permissible for rehab component without
charging premium and to the incentive BUA by charging premium for the tenants as
recorded in the TP Scheme Book and residing in the contravening structures.
(EP-103)
Notes: For the purpose of this Regulations the contravening structures shall mean:
i.Structure situated outside the original plot but included fully or partly within the final
plot allotted to a person in the TP Scheme.
ii.Structures which are partly included in the final plot allotted to a person and partly
included in the roads sites reserved for public purpose/adjoining final plot.
iii.Structures which are included in the TP Scheme area but situated outside the final
plot allotted to a person and are affected by sites reserved for public purpose,
provided the Planning Authority has no objection for rehabilitation of such
structures.
iv.However, structures included in the common area comprising of original plots and
final plots shall not be treated as contravening structures.
(B) Removal and re-accommodation of tolerated /protected structures falling in the
alignment of road: -
In a scheme where removal of tolerated/protected structures falling in the alignment
of existing road or widening of existing road for which road line has been prescribed
or DP Road and re-accommodation of these tolerated/protected structures in the
same administrative ward has been proposed for the expeditious removal of
bottlenecks, the FSI may be allowed to be exceeded above the permissible FSI as
mentioned below subject to following condition:
a) The tolerated residential structures shall be existing since prior to 17.04.1964 and
non-residential structure shall be existing since prior to 01.04.1962 falling in the
alignment of existing road or widening of existing road for which road line has been
prescribed or DP Road.
b) The structures shall be reflected in the true extract of Revenue Record prior to
1961-62 or in the assessment records prior to datum line as mentioned (a) above.
c) The scheme plot and the tolerated structures as mentioned above falling in the
alignment of the road shall be relocated in the same administrative ward.
d) The provisions of this Regulation shall not be applicable to the structures where
development of plot, where such tolerated/protected structures are situated, is
proposed to be undertaken or in progress.
e) It shall be responsibility of the scheme owner/developer who wishes to seek
benefit under this Regulation to execute tri party registered agreement with the
owner of the plot where such tolerated/protected structures are situated and with
the occupiers of such structures in respect of removal of structures falling on road
and the copy of the same shall be submitted to MCGM.
f) The owner/developer will have to submit the advance possession receipt to
MCGM for handing over of such plot affected by road line/DP road having built up
structures as detailed above to MCGM.
g) The owner of the plot shall be eligible for TDR as per Zonal (basic) FSI of the
plot in lieu of handing over of the land affected by road. TDR for such land shall be
issued only when ownership of land has been transferred in PR card in the name of
MCGM.
h) The existence of the structure on site, carpet area of the structures and
occupancy of the eligible occupants in case of non-cess structures shall be certified as
detailed above by the Assistant Commissioner of respective ward and by MHADA in
case of cessed structures.
i) In case of such area is occupied by cessed structures and affected by road
widening/DP Road, NOC from MHADA shall be insisted.
j) The eligible residential/residential cum commercial tenant/occupants of
tolerated structures shall be entitled for the minimum carpet area of 27.88 sq. m or
the area equivalent to existing carpet area and in case of non-residential
tenant/occupants, area equal to existing carpet area shall be allotted.
k) The owner of scheme shall be eligible for the BUA required for rehabilitation
of existing tenants/occupants plus incentive BUA to the extent of 50% of BUA
required for rehabilitation. However, the FSI on plot/layout shall not be allowed to be
exceeded up to 4.0.
l) If the part of the structures is falling in alignment of roads, then such
occupants shall, be eligible for the benefit as above. However, TDR equivalent to
Zonal (basic) FSI of the land so handed over will be eligible.
m) The owner shall be eligible for the commencement certificate for the
incentive BUA only after rehabilitation of occupants of affected tolerated structure
/removal of structures falling in the alignment of road line/DP Road.
n) The fungible BUA compensatory area shall be permissible for rehab without
charging premium and to the incentive BUA by charging premium.
o) The protected structures falling in the alignment of Road/DP road as notified
by government from time to time and as certified by competent authority shall also
be eligible for the rehabilitation as per this regulation subject to condition that
rehabilitation area shall be 25 sq. m in case of residential/residential cum commercial
occupants and in case of commercial occupants, existing area or 20.90 sq. m,
whichever is less.
33(13) – Buildings of Information Technology Establishments
With the Special permission, the Commissioner may permit the floor space indices to
be exceeded beyond Zonal (basic) FSI specified in this Regulation No.30 Table No. 12
up to 5.0 as given in the following table, to all registered Public & Private IT/ITES
Parks/ AVGC Parks/IT SEZs or IT Parks in SEZs/Stand-alone IT/ITES units in public IT
Park (including IT/ITES units located in Residential/Industrial/Special Development
Zone/ Green Zone or any other land-use zone in which such users are permissible),
which have been approved by the Directorate of Industries, proposed to be set up or
already set up under present/ previous IT/ITES policies by charging premium as per
the conditions specified as detailed below this table.
Sr No Plot area excluding area to be handed Minimum Maximum
over in lieu of Reservation /Designation Road Permissible
in the DP except affected by proposed Width FSI
DP roads/Sanctioned RL under MMC
Act
1 Up to 2000 sq. m 12m Up to 3
2 Above 2000 and up to 3000 sq. m 18m Up to 4
3 Above 3000 Sq. m 30m Up to 5
The grant of additional FSI as stated above shall be subject to following conditions, in
respect of
a) All IT and ITES units in Public IT Parks
b) All registered IT and ITES Units located in Private IT Parks, approved by Director of
Industries in the State.
Provided that maximum of 80% of the total FSI may be used for IT/ITES/IT supported
Financial Services with the prior approval of the State Govt. and remaining 20% may
be used for commercial services.
c) The IT supported financial services shall be restricted to the users specified by the
Industries Department, in its Government Resolution IMC/2008/CR-46/IND-2 dated
13/8/08 and as may be amended from time to time by the High-Power Committee
and Industries Department.
a) d)The additional FSI shall be granted beyond permissible FSI as per regulation
30(A)(1) upon the payment of premium. Such premium shall be recovered for the
BUA at the rate of 80% of ASR for open develop land (for FSI 1) 25% for IT/ITES
users, 40% for the IT supported financial services and 100% for commercial users
of the present market value of the land under reference as indicated in the Ready
Reckoner
Provided that 40% of the present market value of land under reference as indicated
in the Ready Reckoner will be liable to be paid even if only a part of 80% of the total
area is used for IT supported Financial Services.
b) e) 25% the total premium so charged shall be paid to the Govt. and remaining 75%
shall be paid to the said Authority. The premium so collected shall be shared between the
Planning Authority and the Government in the proportion of 50:50. The share of the
Government shall be paid to the Deputy Director of Town Planning, Greater Mumbai.
(Explanation: - Premium charges shall be calculated on the value of lands under such zones,
determined by considering the land rates of the said land as prescribed in Annual Statement
of Rates (ASR). These charges shall be paid at the time of permitting additional F.S.I. by
considering the ASR for the relevant year without applying the guidelines)
f) The premium so collected by the Planning Authorities shall be primarily used for
development/up gradation of off-site infrastructure.
g) Additional FSI for IT supported Financial Services & 20% commercial users will be
applicable in those zones where the DCR permit such use.
h) Users as permissible as per IT policy of Govt. amended from time to time shall be
allowed.
c) Maximum 20% of total proposed Built-up area (excluding parking area) inclusive of
such additional F.S.I. may be permitted for support services as defined in IT/ITES
Policy 2015, in IT Parks and remaining built-up area shall be utilized for IT/ITES.
d) Maximum 40% of total proposed Built-up area (excluding parking area) inclusive of
such additional F.S.I. may be permitted for support services in IT Parks in Municipal
Corporations which are not covered under Serial No. c) above and remaining built-up
area shall be utilized for IT/ITES.
e) New said unit shall allocate at least 2% of the total proposed built-up area, for
providing incubation facilities for new units. This area would be treated as a part of
the Park to be used for IT activities and eligible for additional FSI benefits accordingly.
f) Premium to be received by the Planning Authority as per provisions in this regulation
shall be deposited in a separate fund viz. "Critical Infrastructure Fund for IT/ITES
Industries" and this fund shall be utilized only for creation of Critical Infrastructure
for IT/ITES Industries:
Provided that in the event, the developer come forward for providing such off
site infrastructure at his own cost, instead of paying premium as prescribed above,
then the Planning Authority may determine the estimated cost of the work by using
rates prescribed in District Schedule of Rates (DSR) of the relevant year, in which
order for commencement of such work is issued. The Planning Authority shall also
prescribe the standards for the work. After completion of the works, the Planning
Authority shall verify and satisfy itself that the same is developed as per prescribed
standards and thereafter, by deducting the cost of works, the balance amount of
premium shall be recovered from such developer before issuing Occupancy
Certificate.
Provided that, in case the cost of work is more than the premium to be
recovered, such additional cost to be borned by such developer.
g) Permission for erecting towers and antenna up to height permitted by the Civil
Aviation Department shall be granted by the Commissioner as per the procedure
followed for development permission or otherwise as may he decided by the
Government.
h) While developing site for IT/ITES with additional FSI, support services as defined in
the IT Policy 2015, shall be allowed.
i) Notwithstanding anything contained in these regulations, no amenity space is
required to be left for development of plot/land up to 2.00 Hect. for IT/ITES.
j) The Directorate of industries will develop a web portal on which the developer of
every IT park will be bound to provide/update detailed information about names of
the units in the park, utilization of built-up area and activities being carried out,
manpower employed in the It Park for IT/ITES and support services on yearly basis.
If a private IT park has availed additional FSI as per the provisions of IT/ITES
policy and subsequently it is found that the built-up space in the park is being used
for non IT/ITES / commercial activities/ any other activity not permitted as per the
IT/ITES policy under which the said park was approved, a penal action as below will
be taken, the payment shall be shared between the concerned Planning Authority
and the Government in the ratio of 3: 1.
a) The misuse shall be ascertained by physical site verification of the said private IT
park by a team of officers from the Directorate of industries and the Planning
Authority which has approved the building plans of the said private IT park.
b) A per day penalty equal to 0.3% of the prevailing ready reckoner value of the
built-up area that has been found to be used for non- IT/ITES activities.
c) The penalty will be recovered from the date of commencement of unauthorized
use till the day non IT use continues.
After payment of the penalty to the concerned Planning Authority which has
sanctioned the building plans of the concerned private IT park, the said private IT
Park will restore the use of premises to the original purpose for which
LOI/Registration was granted. If the private IT Park fails to pay penalty and / or
restore the use to its original intended use, the concerned Planning Authority will
take suitable action under the Maharashtra Regional and Town Planning Act 1966,
against the erring private IT Park under intimation to the Directorate of Industries.
This provision will also be applicable to existing IT Parks.
These provisions will be over and above the penal provisions of the MRTP Act.
(EP-104)
33(13)(A) Buildings of Smart Fin Tech Centre
1) The Commissioner may permit additional FSI up to 200 % over and above the basic
permissible F.S.I. to Smart Fin Tech Centre located in Residential /
Industrial/Commercial Zone, which have been approved by the Directorate of
Information Technology, proposed to be set up ( hereinafter referred to as the
"said unit") by charging premium of 30% of the land rate for the said land as
prescribed in Annual Statement of Rates for the relevant year of granting such
additional F.S.I.
Provided that additional FSI shall be permissible only on plots having an access
road of minimum 18 meters width and subject to approval by committee chaired by
the Principal Secretary, Information Technology and comprising representatives of
Industries, Finance and Urban Development Department (UD-1).
Provided further that, the premium so collected shall be shared between the
Planning Authority and the Government in the proportion of 50 : 50. The share of the
Government shall be deposited in the Fin Tech Corpus fund which is being set up by
Director of Information Technology.
(Explanation :- Premium charges shall be calculated on the value of lands under such
zones, determined by considering the land rates of the said land as prescribed in
Annual Statement of Rates (ASR). These charges shall be paid at the time of
permitting additional F.S.I. by considering the ASR for the relevant year without
applying the guidelines)
2) The total maximum permissible F.S.I. shall not exceed limit of 3.00. in suburbs and
extended suburbs and Mumbai City. In case of plot having area of 2,00,000 sq.
mtr. or above, which front on roads having width of 24.00m or more, the F.S.I.
may be permitted to be exceeded upto 4.00.
3) Notwithstanding anything contained in these Regulations, no amenity space is
required to be left for development of plot/land up to 2.00 Hectare for Smart Fin
Tech Centre.
4) At least 85% of total proposed Built-up area (excluding parking area) shall be
permitted for business of Fin Tech (start-ups, incubators, and accelerators),
banking, financial service including NBFC and insurance, and IT/ITES with focus on
Fin Tech.
5) The Directorate of Information Technology will develop a web portal on which the
developer of every Smart Fin Tech Centre will be bound to provide / update
detailed information about names of the units in the park, utilization of built-up
area and activities being carried out, manpower employed in the Smart Fin Tech
Centre on yearly basis.
6) If a Smart Fin Tech Centre has availed additional FSI as per the provisions of Smart
Fin Tech Centre policy and subsequently it is found that the built-up space in the
Smart Fin Tech Centre is being used for non-Fin Tech / commercial activities / any
other activity, not permitted as per the Smart Fin Tech Centre policy under which
the said Centre was approved, a penal action as below will be taken, the payment
shall be shared between the MCGM and the Government in the ratio of 3:1.
a) The misuse shall be ascertained by physical site verification of the said Smart
Fin Tech Centre policy by a team of officers from the Directorate of Information
Technology and the MCGM, which has approved the building plans of the said
Smart Fin Tech Centre.
b) A per day penalty equal to 0.3% of the prevailing ready reckoner value of the
built-up area that has been found to be used for non-Fin Tech activities, shall be
imposed
c) The penalty will be recovered from the date of commencement of
unauthorized use till the day non-Fin Tech activities.
After payment of the penalty to the MCGM, which has sanctioned the building plans
of the concerned Smart Fin Tech Centre, the said Smart Fin Tech Centre will restore
the use of premises to the original purpose for which LOI/ Registration was granted. If
the Smart Fin Tech Centre fails to pay penalty and / or restore the use to its original
intended use, the MCGM will take suitable action under the Maharashtra Regional
and Town Planning Act 1966, against the erring Smart Fin Tech Centre under
intimation to the Directorate of Information Technology.
These provisions will be over and above the penal provisions of the MRTP Act,
1966.
7) In this regulation the terms and expression shall have the meaning specified in Fin
Tech Policy declared by Directorate of Information Technology vide Govt. Resolution
No.DIT-2018/CR-17/D-1/39 dated 16th February 2018. Notwithstanding anything
contained in the existing regulation, the above provisions shall be applicable for
Smart Fin Tech Centre. Other provisions of existing regulations, which are not
specifically mentioned in this regulation shall be applicable.
(EP-105)
33(14) Shifting of cattle sheds outside Greater Mumbai:
For Development of lands becoming vacant consequent upon shifting of cattle sheds
existing thereon, to places outside Greater Mumbai, additional FSI to the extent of
33% over and above Zonal (basic) permissible FSI, shall be allowed on land occupied
by cattle sheds and subject to the following conditions:
(i) Such additional FSI shall be available for authorized /tolerated (existing prior
to 01/04/1962) cattle sheds existing in Suburbs & extended Suburbs only;
(ii) The development of such lands that have become vacant consequent upon
shifting of cattle shall be regulated by the zoning Regulations of the zone in which
such lands are situated.
(iii) The additional FSI shall be worked out case by case by a Committee
comprising of following members as constituted by Govt in Urban Development
Department.
1. The Chief Engineer (D.P), Municipal Corporation of Greater Chairman
Mumbai, Mumbai
2. Cattle Controller, ADF Department, Mumbai Member
3. The Deputy Director of Town Planning Greater Mumbai, Mumbai Member
4. The Superintendent of Land Records, Mumbai Suburban District, Member
Mumbai
The proposed development shall further be subject to such conditions as may be
prescribed by the Committee and payment of such amount of premium as may be
fixed by Govt. in Urban Development Department.
33(15) - Development of land earmarked for the MHADA/Mill Workers Housing
under Regulation No 35.
For development of land for transit camp/mill workers housing undertaken by
MHADA, FSI up to 4.0 including Zonal (basic) FSI shall be allowed on land earmarked
for MHADA/Mill Workers Housing under Regulation No 35 subject to following
conditions -
(i) The development of land earmarked for mill workers shall be exclusively used for
mill workers housing,
(ii)The development of land earmarked for MHADA for public housing, at least 100%
FSI shall be exclusively used for mill workers housing and balance FSI for transit camp
only.
Relaxation in buildings and other requirements:
1) The permissible FSI shall be calculated on gross plot area.
2) Recreational Open Spaces up to 8% shall be allowed.
3) Requirement of open spaces shall be as per the Regulation No 41(5)
4) No premium shall be charged for the fungible FSI compensatory area & BUA
excluded as per the provision of regulation no 31(1) to be utilized for Mill workers
housing/transit tenements & component to be handed over to MHADA.
(EP-106)
33(16) Reconstruction/Redevelopment in Gaothan/ Koliwada/Adiwasipada area –
FSI for reconstruction/redevelopment of any property in gaothan /koliwada/
adiwasipada i.e. on land with tenure ‘A’ shall be as follows:
(a) For plots fronting on roads below 9 m width but more than 6.0 m, permissible FSI
will be 1.5
(b) for plot fronting on road width of 9 m and above (existing or proposed), additional
0.5 FSI shall be allowed for commercial use subject to condition that margin and
parking space as required under these Regulations are provided.
Provided that for (a) & (b) above, consumed FSI of existing buildings, utilized
authorizedly shall be permitted.
(c) The boundaries of Gaothan/ Koliwada/Adiwasipada as finalized by Revenu
Department shall be deemed to be reflected as boundaries of Gaothan/
Koliwada/Adiwasipada on the Development Plan.
(d) Independent provision for development of Gaothan/ Koliwada/Adiwasipada areas
may be made by Government.
(EP-107)
33(17) Buildings of Biotechnology Establishments: -
With the Special permission, the Commissioner may permit the floor space indices to
be exceeded beyond Zonal (basic) FSI specified in this Regulation No. 30 Table No. 12
up to 5.0 as specified in the following table, in respect of buildings in independent
plots for exclusively developing Biotechnology units set up by Public Bodies like
MHADA, SEEPZ, MIDC, SICOM, CIDCO or their joint venture companies having more
than 11% stake of these bodies or their lessees.
Sr Plot area excluding area to be handed Minimum Maximum
No over in lieu of Reservation /Designation Road Permissible
in the DP except affected by proposed Width FSI
DP roads/Sanctioned RL under MMC
Act
1 Up to 2000 sq. m 12m Up to 3
2 Above 2000 and up to 3000 sq. m 18m Up to 4
3 Above 3000 Sq. m 30m Up to 5
The Commissioner may specify terms and conditions.
Provided that in the above cited cases of grant of additional FSI for Biotechnology
units, premium recovered for the BUA at the rate of 80% of ASR for open develop
land (for FSI 1) or as may be determined by Govt shall be paid to MCGM out of
which 50% shall be payable to the Govt.
(EP-108)
33(18) Development of Multi Storey Public Parking Lots (PPL):
With the previous approval of the Govt for For development of Multi-storeyed PPL on
any plot abutting a road of minimum width of 18m, and/or a stretch of road,
additional FSI (hereinafter referred to as “Incentive FSI”) as specified below on built
up parking area, created and handed over to the MCGM free of cost, shall be
allowed, on the land belonging to a private owner /Lease hold plots of Govt. and
MCGM with prior consent, which is not reserved for any public purpose, subject to
the conditions contained herein below:
(EP-109)
I. The minimum area of plot shall be 1000 sq. m. in Island City & 2000 sq. m in suburb
and extended suburbs of Greater Mumbai. The minimum number of Motor Vehicle
public parking spaces provided shall not be less than 50 subject to minimum parking
space of 700 sq. m. The location of parking spaces can be in basement, ground floor
or upper floors, with access through ramp/lift or combination of both subject to
clearance from CFO with special emphasis on fire hazard.
II. A Till the formation of Parking Authority, a Committee under the Chairmanship of
Municipal Commissioner, MCGM shall earmark/select the plots for public parking, on
the basis of their suitability and seek Government's approval for it. The Committee
shall comprise the following or their representatives (i) Metropolitan Commissioner,
MMRDA. (ii) Joint Commissioner of Police (Traffic), (iii) Dy. Director of Town Planning,
Greater Mumbai (iv) Chief Engineer (Road), MCGM (Member Secretary).
III. The incentive FSI given on this account will be over and above the Zonal (basic) FSI
permissible under any other provisions of DCPR. This incentive FSI shall be allowed to
be used on the same plot in conformity with DCPR/DP, within the overall cap/limit of
total maximum permissible FSI as given at (vii) below.
IV. The proposed development shall be subject to any other conditions prescribed by
the Municipal Commissioner.
V. Concerned land owner/development/society/company shall not be allowed to
operate the public parking.
VI. Area covered under parking shall not be counted towards FSI consumption.
VII. The incentive FSI permissible under this Regulation against BUA of the PPL, shall
be 50% of the BUA of the PPL, such that the total permissible FSI including the
incentive FSI under this Regulation does not exceed 4.0 in the Island City and 3.0 in
the Suburbs and extended Suburbs as detailed below: -
Plot Area Maximum permissible FSI
Up to 2000 sq. m 3.00
Above 2000 sq. m 4.00
(EP-110)
VIII. Public Parking shall be limited to G + 4 and three basements.
IX. The maximum cap on BUA per parking shall be 50 sq. m for LMVs, 65 sq. m for
LCVs and 120 sq. m for HMVs/Buses. Incentive FSI shall be calculated as per BUA of
the PPL, based on these norms or the actual BUA of the PPL, whichever is less.
X. The developer of the PPL shall pay ‘premium’, worked out as per the following
formula:
Premium = 60% of [Value of the additional BUA corresponding to the incentive FSI
admissible under this Regulation, as per A.S.R. – (Cost of construction of PPL + cost of
any extra amenities/facilities provided + cost of construction of BUA corresponding
to the incentive F.S.I. admissible under this Regulation)]
For the purpose of calculating premium as above, the cost of construction of PPL
including amenities/facilities and the cost of construction of BUA corresponding to
the Incentive FSI admissible under this Regulation shall be 75% and 125% respectively
of the rate of RCC construction as per ASR.
(XI) The Premium shall be paid in two stages – 50% before the issuance of I.O.D. for
the PPL and 50% before the issuance of C.C. for the incentive FSI admissible under
this Regulation.
Upon Payment of 100% premium as foresaid, C.C. shall be issued in respect of 50% of
incentive FSI. In no case, shall the remaining 50% Incentive FSI be released without
the handing over of the PPL, complete in all respects, to MCGM.
The year in which 50% premium is paid before the issuance of I.O.D. for the PPL shall
be taken as the year for determination of construction cost as well as ASR for
calculation of the premium. Out of the total premium payable, 50% shall be paid to
the GoM and the remaining 50% to MCGM.
Provision of this Regulation may also be applicable to lease hold plots of Govt and
MCGM with prior approval from Gov. /Municipal Corporation.
(XII) Plot for which development permission has already been granted by GoM. for
Public Parking Lot, as per the Regulation No 33(24) of DCR 1991 and if the plot is
reserved/designated for public purpose of Public Parking Lot in DP 2034, then the
plot has to be developed under this Regulation only and not under AR.
(EP-111)
33(19) Additional FSI for Commercial user development in Central Business District
(CBD) or plot situated in Residential or Commercial Zone or Independent plot
converted in Residential or Commercial Zone from Industrial zone:
The Commissioner may allow FSI up to 5.0 including permissible FSI as per provision
of Regulation 30(A)1 Table No 12 for commercial user/development on plots in
marked as CBD or independent plot converted in Residential or Commercial zone
from Industrial zone after compliance of Regulation 14(B) of these Regulations on
payment of premium subject to following conditions: -
(EP-112)
1) Additional FSI shall be allowed only for plots situated in CBD which are not
reserved/designated in the DP except affected by proposed DP roads/Sanctioned RL
under MMC Act.
2) The development of reserved/designated plots in CBD shall be governed by
provisions of these Regulations.
3) Development for residential purpose to the extent of maximum 30% of the
permissible FSI as per provisions of Regulation No.30 (A) 1, Table No 12 may be
allowed. Additional FSI as per this regulation shall not be permissible for residential
user/development.
4) Premium for granting such additional BUA beyond permissible FSI as per
Table No 12 shall be charged at the rate of 80 % of ASR for open developed land of
FSI 1 and shall be equally shared between the GoM. and MCGM.
5) Provision of IH shall not be applicable for development in CBD.
Provided further that in case the entire commercial development is on a plot
situated in Commercial Zone/Independent plot in Residential Zone, and satisfies
other related provisions of these Regulations, the Commissioner may allow FSI as
detailed below including permissible FSI as per provision of Regulation 30(A)1 Table
No 12 for commercial uses/development on area of plots excluding area covered
under Reservation/Designation in the DP except affected by proposed DP
roads/Sanctioned RL under MMC Act, on payment of premium for BUA @ 80 % of
ASR for open developed land for FSI 1 and shall be equally shared between the GoM
and MCGM. In this case, no residential development will be allowed on such plot.
Sr. No Plot area excluding area covered under to Minimum Maximum
be handed over in lieu of Road Width Permissible FSI
Reservation/Designation in the DP except
affected by proposed DP
roads/Sanctioned RL under MMC Act
1 Up to 2000 sq. m 12m 3
2 Above 2000 and up to 3000 sq. m 18m 4
3 Above 3000 30m 5
(EP-113)
33(20) Affordable Housing (AH)/ Rehabilitation & Resettlement (R & R):
(A) Development or redevelopment of plots earmarked/reserved for AH/R&R on the
lands of MCGM/Govt./Appropriate Authority as notified by Govt. or unreserved plot
of these authorities and in possession, may undertake development for AH and/or
R&R for the purpose of the housing those who are displaced by projects
undertaken by the Corporation/Appropriate Authority for implementation of
proposals such as DP/MUTP/MUIP and other vital public projects with
permissible FSI 4.0 subject to the following conditions as detailed below:
Plot Area Minimum Road Maximum
Width permissible FSI
Up to 2000 sq. m 12m 3.00
Above 2000 sq. m 18m 4.00
The following conditions shall be observed:
(EP-114)
1) The carpet areas of the tenements to be constructed under the concept of “AH” shall
be for EWS, LIG and MIG, Rental Housing or as decided by Govt. from time to time
subject to a minimum 25 sq. m. Development of other types of tenements shall not
be permissible under this Regulation.
2) No premium shall be charged for fungible FSI compensatory area and for features
covered under the provision of Regulation No 31(1) for the development for AH /R&R
tenements.
3) The MCGM/Public Authority shall make provision for offsite infrastructure charges at
the rate of 7% of land rate as per ASR for FSI 1 for BUA beyond Zonal (basic) FSI. Out
of 7% charges, 5/7 of such charges shall be transferred to the fund allocated for
infrastructural development for developing necessary offsite infrastructure.
4) The requirement of open spaces shall be as per Regulation No 41(5) subject to
clearance from CFO.
5) Once the development of AH/R&R tenements is completed and Occupation
Certificate is granted, it shall be the responsibility of the MCGM/Public Authority of
allotment of AH/R&R tenements within 12 months from the date of grant of
occupation or earlier. Once development proposal is approved for AH/R&R, the
MCGM/Public Authority may start process of sale proceeds.
6) The fund so received on account of sale proceeds of such tenements i.e. EWS, LIG,
MIG, after deduction of cost of development including off site infrastructure charges
for development of AH/R&R, 50% amount shall be utilized towards implementation
of D.P. and rest amount shall be used for the development of AH/R&R tenements at
other locations.
7) The MCGM/Public Authority may develop AH/R&R in the plot of land reserved for
Rehabilitation & Resettlement, but the same shall not be applicable when private
owner undertakes development.
8) The land with approved BUA shall be leased out to such society of occupants of
building.
9) In case of layout 25% of Zonal (basic) FSI shall be exclusively used for the purpose of
convenience shopping along layout road for use of residential occupants of layout.
(EP-115)
(B) Development of AH/R&R on private plot or plot of authority other than
Govt./MCGM/Appropriate Authority.
The permissible FSI may be allowed to be exceeded up to 4.0 when the private owner
other authority proposes to develop non-reserved/non-designated private land for
AH/R&R tenements and hand over the area of AH/R&R tenements free of cost to
MCGM.
(a) The FSI & distribution of additional FSI for the construction AH/R&R shall be as
shown below:
Locatio Plot area Minimu Total Zon Additio % FSI for % FSI for
n excluding m Road permissi al nal FSI Transit sale
area to be Width ble FSI FSI teneme compone
handed over nts for nt of
in lieu of SRA/ total
Reservation Rental addition
/Designation Housing al FSI
in the DP of total
except addition
affected by al FSI
proposed DP
roads/Sanctio
ned RL under
MMC Act
1 2 3 4 5 6 7
Island Up to 2000 sq. 12m Up to 3.0 1.33 Up to
City m 1.67 1.67 1.0
37%
Above 2000 18m Up to 4.0 1.33 Up to 63%
sq. m 2.67
Suburb Up to 2000 sq. 12m Up to 3.0 1.00 Up to 1.50 1.50
s & m 2.0 50% 50%
Extend
Above 2000 18m Up to 4.0 1.00 Up to
ed
sq. m 3.00
Suburb
s
(EP-116)
(b)Such Scheme shall not be permissible in NDZ SDZ/GZ.
(c) The carpet areas for AH/R&R tenements to be constructed shall be as required for
EWS, LIG and MIG as decided by Govt. from time to time subject to a minimum 25 sq.
m
(d) The ratio of BUA to carpet area shall be 1.2, including all the amenities &
facilities. The area of features permissible free of FSI as per Regulation No 31 shall
not be considered for the calculation of carpet areas.
(e) The owner shall have to declare the intension for developing the plot for AH/R&R
initially. The AH/R&R shall be marked on the plan clearly with note, “to be handed
over to MCGM’’.
(f)The additional FSI over & above Zonal (basic) FSI may be released in co-relation as
per BUA of tenements that are required to be handed over free of cost to MCGM, in
proportion 0.50 sale: 1 AH/R&R area and 100% sale area can be released only after
handing over of entire AH/R&R tenements.
Alternatively, TDR in lieu of unconsumed sale component of additional FSI, as per
provision of this Regulation in proportion as stated above can be released. However,
20 % of such admissible TDR shall be released only after handing over the entire area
of AH to MCGM.
(g) After AH/R&R tenements are handed over free of cost to MCGM, Occupation
Certificate for sale portion shall be given.
(h) No premium shall be charged for fungible FSI compensatory area and features
permitted free of FSI as per Regulation No 31 for the development for AH/R&R
tenements. However, payments of the premium shall be applicable on the owners
share wherever required.
(i) The offsite infrastructure charges at the rate of 7% of land rate as per ASR for FSI
1.0 for BUA beyond Zonal (basic) FSI shall be payable.
(j) The owner shall be allowed to utilize the Zonal (basic) FSI and BUA as per column
no (6 7) of above table for the uses permissible in the zone.
(k) In case of layout, 25% of Zonal (basic) FSI shall be exclusively used for the purpose
of convenience shopping along layout road for use of residential occupants of layout.
(EP-117)
(C) Shramamsafaly/AshrayYojana
The tenements required for Shramsafalya/Ashray yojana may be allowed to be
constructed as per the provisions of Regulation (A) & (B) above with the special
permission of Municipal Commissioner subject to condition that the sizes of
tenements constructed shall be governed by the requirements of such schemes.
33(21) Development and Redevelopment of Municipal Market/Public Amenities by
MCGM/Government
(A) Development and Redevelopment of Municipal Market
If development/redevelopment of existing Municipal Market of MCGM or land
Reserved/Designated for Municipal Market/ Existing Municipal market on land
belonging to MCGM is proposed by MCGM itself, then development/redevelopment
of such existing Municipal market / designated/reserved land of Municipal Market
shall be as follows:
i. The permissible FSI shall be 5.0 on gross plot area as specified below:
Sr No Plot area excluding area affected Minimum Road Maximum
by proposed DP roads/Sanctioned Width Permissible
RL under MMC Act FSI
1 Up to 2000 sq. m 12m 3
2 Above 2000 and up to 3000 sq. m 18m 4
3 Above 3000 Sq. m 30m 5
(EP-118)
ii. The existing licensed vendors on such lands, if any, as certified by Market
Department of MCGM, shall be allotted spaces in the proposed redevelopment.
While reallocating, they shall be reallocated with 20% more carpet area over and
above their existing carpet area (excluding fungible BUA compensatory area). The
status of the licensed vendor shall remain as it was prior to redevelopment.
iii. BUA as per Zonal (basic) FSI or BUA required for accommodation/rehabilitation of
existing licensed vendors certified by the Market Department of MCGM, whichever is
more, shall be exclusively developed for Market purpose and balance potential may
be utilised for the users permissible in the respective zone and conforming with these
regulations or the user as stated below in this Regulation.
iv. The commercial galas so constructed and available with MCGM, will be first allocated
to existing licensed vendors certified by Market Department, second to PAPs of vital
public purpose projects, third to new licensees as per policy decided by the MCGM.
v. Balance BUA may be used for (a) Municipal Office, (b) Municipal Housing (c) PAPs
displaced due to Municipal Projects, (d) Municipal essential Staff Quarters, (e)
Municipal Maternity Home/Dispensary, (f) Drama Theatre (g) hawker’s plaza or any
other uses permissible under these Regulations and as decided by Municipal
Commissioner maximum up to 50%.
vi. The MCGM may undertake such development on its own or through public private
partnership.
vii. Minimum 6 m open space or open spaces as required under Regulation no 41(5) shall
be deemed to be sufficient subject to fulfilment of requirement from fire safety point
of view.
viii. Separate access for the market area and other development shall be provided.
ix. Notwithstanding anything contained in this Regulation, where the existing
Market/designated land is having combination of user/reservation, the existing BUA
of such user shall be necessarily put to such use.
x. No premium shall be charged for Fungible FSI compensatory area as per Regulation
No 31(3).
(B) Public Amenities by MCGM/Government:
For the construction of building for public purpose/ public amenities by the
Corporation/Govt. on their own, on the plot of land belonging to them, the FSI shall
be 5.0 as specified below:-
Sr No Plot area excluding area Minimum Maximum
affected by proposed DP Road Width Permissible FSI
roads/Sanctioned RL under
MMC Act
1 Up to 2000 sq. m 12m 3
Above 2000 and up to 3000 sq. 18m
2 4
m
3 Above 3000 Sq. m 30m 5
Such additional FSI will not be available when private owner undertakes
development as per Regulation No. 17.
No premium shall be charged for Fungible FSI compensatory area as per Regulation
No 31(3).
(EP-119)
33 (22) Regulation for Exhibition-cum-Convention Centers in MCGM Area
1) Definition: An Exhibition-cum-Convention Centre is a complex comprising buildings, halls
and open spaces which are designed to host and/or organize --
(a) business-to-business and business-to-customer exhibitions where products, machinery,
art, skills, services, activities etc. are displayed on temporary or permanent basis; and
(b) large congregations for the purpose of conventions, meetings, conferences, assemblies,
rallies, concerts, cultural activities and performances.
2) Admissibility: - Development of Exhibition-cum-Convention Centre shall be permissible in
Mumbai, on a plot in Residential (R2) / Industrial (I1, I2, I3)/Commercial (C1, C2)/ No
Development Zone subject to following conditions:-
i) For the purpose of calculating the FSI, the remaining area after excluding the land under
the Development Plan Roads / Reservation of public amenities shall be considered.
ii) In case of plots in Residential (R2)/Industrial (Il, I2, I3)/ Commercial (C1, C2) Zone, the
Floor Space Indices specified in Table 14 above may be permitted to be exceeded up to 4.00
F.S.I by charging premium at the rate of 10% of the land rate as prescribed in Annual
Statement of Rates published by Revenue Authority for the relevant year of granting such
F.S.I. without applying the guidelines mentioned therein.
iii) In case of plots in No Development Zone, if infra-structure facilities are sufficient or land
owner/ developer is ready to provide it, then the Maximum permissible F.S.I. may be
permitted to be exceeded upto 2.00 by charging premium above 0.20 F.S.I. , at the rate of
10% of the land rate as prescribed in Annual Statement of Rates published by Revenue
Authority for the relevant year of granting such F.S.I. without applying the guidelines
mentioned therein.
3)Conditions for Development of Exhibition-cum-Convention Centre:-
a. Such Plot should have a minimum area of 5 hectares excluding Development Plan
proposals of reservation and/or roads, if any.
b. Entry Gates of the Exhibition-cum-Convention Centre must abut a main road/ highway
having a minimum width of 18.30 mtr. with minimum 2 each of ingress and egress of proper
width.
c. The ground coverage of the Exhibition-cum-Convention Centre on such plot shall not
exceed 2/ 3rd of the gross plot area excluding Development Plan proposals of reservation
and/ or roads, if any.
d. Recreation Ground and Amenity Area shall be provided on such plot as prescribed for
Industrial layouts in Regulation 23(2).
Provided that the limit of maximum area of 2500 sq.mtrs. shall not apply for the
development under this Regulation.
The Recreation Ground area shall be counted in 1/3 open space required as per
regulation 3(c).
e. Out of the total permissible built up area on such plot, at least 2/3rd shall be allocated for
Exhibition-cum-Convention Centre buildings/ halls, toilet blocks, Organiser's office; protocol
lounge; VIP lounge; Press lounge; registration areas; pre-function areas; refreshment &
snack centres; meeting rooms; business centre; creche; meditation rooms; wellness centre;
bank & forex service counters; surveillance & security rooms; service contractor's office;
audio-visual/ sound room; green room; maintenance workshop; maintenance staff office;
strong rooms, first aid and emergency room.
f. Remaining permissible built up area, not exceeding 1/ 3rd of the total built up area, on such
plot may be allocated for Support Services as described below in Table-1.
TABLE-1
Sr. No. Support Services
1. Hotels not less than 3-star category Hotels
2. Dining Areas: Food Courts, Cafeteria, Fine Dining Restaurants, Restaurants & Bar,
Convenience Store
3. Recreation Areas: Indoor children's play area, Indoor games area, Fitness center
4. Fire Services
5. Health post for emergency services with ambulance facility shall be provided.
6. Staff quarters for minimum 25 tenements per 5 Ha. Each having not less than 25
Sq.mtr. BUA
7. Space for Police Chowky of minimum 100 sq. mtr. shall be provided as per
requirement of Police Department.
8. Sewerage treatment system as per design and drawings approved by MCGM.
9. Rain water harvesting plant shall be provided.
10. Special provisions for Drinking water & PSC blocks for gents & ladies shall be
provided.
11. Dedicated Electric Sub-station as per requirement of Power Supply Company,
shall be provided
Note: Regulation 33(4) pertaining to hotels shall not be applicable to the hotels in any
Exhibition-cum-Convention Centre.
g. Occupation Certificate (OC) in respect of a minimum of 1/6th built-up area of the
Exhibition-cum-Convention Centre shall be obtained prior to obtaining Commencement
Certificate in respect of Support Services.
4). FSI Computation for Exhibition-cum-Convention Centre:-
FSI computation for areas shall be as per Regulation 35(2) and 35(3).
Provided that height of any Exhibition Hall or Convention Hall greater than 3.90
meters shall not be deemed to have consumed an additional FSI of 50% of the relevant floor
area.
5) Marginal Open Spaces:
i) The marginal open space shall be minimum 12.00 mt. from all sides of the plot.
ii) Canopies may be permitted in front open space, provided the marginal open
space does not become less than 6.00 mt.
6) General Requirements for Exhibition / Convention Halls shall be as under:
i) The size of each hall shall not be less than 4,000 sq. m.
ii) Minimum width of the hall shall not be less than 50m.
iii) The minimum floor to floor height of the Exhibition Hall / Convention Hall shall be
8.00 mt.
iv) It shall be permissible to construct the Exhibition-cum-Convention Centre
buildings / halls in multiple levels.
v) For the planning of all the other habitable / non habitable areas for amenities
areas and Support services, Regulation 38 shall be applicable.
vi) Minimum width of the internal road shall be 13.40 mtr.
vii) Requirement of fire shall be as per Regulation 43 of these Regulations.
7). Parking requirements for Exhibition-cum-Convention Centre shall be follows:-
i) Allotted parking space for one (1) Fire Engine and one (1) Ambulance shall be
compulsorily provided.
ii) (a) Convention Center- For every 10 seats, parking space for 2 cars
shall be provided.
(b) Exhibition Area-- For every 1000 Sq. mtrs of exhibition area,
including open exhibition area, parking space for
25 cars shall be provided.
(c) In addition to the parking spaces provided for 4-wheeler vehicles.
The following shall be provided.
1. For 2-wheeler vehicles, minimum 25% of the total number of required parking
for 4-wheelers, shall be provided.
2. Taxi Stand for minimum 25 taxis and 50 Auto Rikshaws.
3. Bus Terminal for minimum 10 buses shall be provided.
iii) For the area of Support Services, parking shall be provided as per Regulation 36.
iv) The additional parking space may be granted without counting the such area of
parking into F.S.I.
8) In CRZ areas, the FSI for such proposals, shall be governed by the MoEF Notification issued
for time to time.
9) No relaxation under these Regulations shall be granted.
(EP-120)
33(22) Additional FSI for Redevelopment of existing residential housing
societies, residential tenanted buildings excluding cessed buildings:
In case of redevelopment of existing residential housing societies, residential
tenanted buildings excluding cessed buildings proposed by Housing societies/land
lords or through their proponents where existing members, tenants are proposed to
be re-accommodated on the same plot, additional FSI for redevelopment of such
existing residential buildings shall be as follows:
1.Additional BUA in lieu of cost of construction of authorized existing BUA = 1.50
(Rate of construction per sq. m as per ASR rate /Rate of developed land per sq. m as
per ASR (for FSI 1)) *(authorized existing built up area+ area of the balcony if
claimed free of FSI as per then prevailing regulation)
Provided that this incentive shall not exceed 40% of existing authorized BUA.
Provided further that if the existing authorized BUA and incentive thereon as per
above is less than the permissible FSI 2.0 then society may avail the ‘Additional FSI on
payment of premium/TDR’ up to limit of permissible FSI up to 2.
2. If staircase, lift & lift lobby areas are claimed free of FSI by charging premium as
per then prevailing Regulation, then such areas to that extent only will be granted
free of FSI without charging premium. If staircase, lift & lift lobby areas are counted
in FSI in earlier development, then additional FSI as stated in Sr. No 1 shall also be
given on such area & such areas may be availed free of FSI by charging premium as
per these Regulations.
3. This Regulation shall be applicable only when existing members of the
societies/tenants are proposed to be re-accommodated & where authorized existing
BUA is more than Zonal (basic) FSI as per then prevailing Regulations.
4. This regulation will be applicable for redevelopment of existing authorized
buildings which are of thirty years of age or more.
5.This regulation shall not be applicable in respect of redevelopment proposal to
be/being processed under Regulation No 33(5), 33(7), 33(8), 33(9), 33(9)(A), 33(10),
33(10) (A), 33(20) (A), 33(21).
Explanation: -Age of a building shall be as on the 1st of January of the year in which a
complete redevelopment proposal is submitted to the Commissioner and shall be
calculated from the date of Occupation Certificate or alternately, from the first date
of assessment as per the property tax record in respect of such building available
with the MCGM.
6. This additional BUA shall be independent of additional BUA as permissible under
Regulation No 14(A), 15, 16 and 17, if any.
7. Fungible FSI admissible under Regulation No. 31(3) shall also be allowed over the
additional BUA in lieu of cost of construction of authorized existing BUA & existing
authorised BUA on payment of premium.
(EP-121)
33(23) The regulations for Transit Oriented Development (TOD) FSI with the other
conditionality to promote densification along Mass Transport Corridor will be
formulated separately.
(EP-122)