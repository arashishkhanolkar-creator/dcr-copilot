# Part VII: Land Use Classification and Uses Permitted

34. Land use Zoning & Uses Permitted
The Proposed Land-use plan depicts the five land use zones.
Explanation: For ascertaining Land-use Zone for a given plot of land please refer
to relevant proposed Land-use Map of DP. Eventually web-enabled map will be
available on the MCGM website, where by providing the name of Ward,
Division/Village/Town Planning Scheme and Survey Number (either C.S. No.,
C.T.S. No. or F.P. No.) of the concerned plot, the land use zone could be
ascertained.
(EP-123)
1 General:
In case of development of any land, the intended use shall conform to the
permissible uses of the zone in which the land is situated.
2 Zoning definitions:
Following five land use zones are demarcated on the Proposed Land-use
Plan.
Table No. A
Zoning Definitions
Zone Representation Broad Description
Residential Zone(R – R The Residential Zone is a mixed
Zone) use zone with residential use as
the predominant one and where
other uses as specified are
permitted.
Commercial Zone (C – C The Commercial Zone is a mixed
Zone) use zone with commercial use as
the predominant one and where
other uses as specified are
permitted.
Industrial Zone (I – I Industrial zone is a zone with
Zone) manufacturing as the primary
activity. In addition,
warehousing and logistics are
also permissible. New industrial
Zone Representation Broad Description
activity shall be non-polluting,
non-hazardous and subject to
clearance from MPCB. Existing
Industrial users are protected
subject to certification by MPCB.
Conversion of land use can be
permitted as specified in these
Regulations.
No Special N SDZ No Special Development Zone (N
Development SDZ) is a zone which is to be
Zone developed predominantly for the
society at large with emphasis on
Social Affordable Housing, POS
and necessary Social
infrastructures. comprising
potentially developable land
kept in reserve for future
development.
Port’s POZ Port’s Operational Zone (POZ) is
Operational a zone for development of Port
Zone and Port related activities
Port’s Water PWFDZ Port’s Water Front Development
Front Zone (PWFDZ) is a zone with a
Development focus on the water front
Zone development with mixed land
use.
Natural Areas NA Natural Area Zone (NA) is an
/Zone environmentally sensitive zone
not amenable to buildable
development with the approval
of the Competent Authority.
Green Zone GZ Green Zone (GZ) is a large area
predominantly with green cover.
Note: In conformity with the intent and spirit of these Regulations, with the
special permission of the Commissioner may modify the boundary limit of a zone
where the boundary line of the zone divides a plot.
3 Uses and ancillary uses permitted in the zones:
The purpose of this Regulation is to allow environmentally compatible uses in a
zone on a given plot of land and specifically prevent non-compatible uses. Where
an activity not specifically listed in these Regulations is proposed, its approval or
rejection will be decided with the special permission of the Commissioner
3.1 Conditions/parameters under which land-uses are permissible
The conditions under which land-uses are permissible in the zones and
which are required to be complied with as detailed in Table No. C are
described in this Regulation listed in Table No. B below.
Table No. B.
Conditions/ parameters under which land-uses and occupancies are permissible.
Sr No Conditions under which Land-use and Occupancies are
permissible
1 Independent plot
2 Independent building
3 Separate wing with separate access
4 Separate floor with separate access
5 On ground floor
6 On ground floor with separate access.
7 On stilt
8 On the top of podium
9 On ground/stilt, 1st&2nd floors with separate access
10 On Terrace
11 Minimum area of plot-1,000 sq. m
12 Minimum area of plot-2,500 sq. m
13 Minimum width of street on which the plot abuts-9.00 m
14 Minimum width of street on which the plot abuts-12.00 m
15 Minimum width of street on which the plot abuts-13.40 m
16 Minimum width of street on which the plot abuts-18.30 m
17 Permissible on street on which the plot abuts road having
width more than 18.3 m excepting roads as stated below (a)
in regulation below this table
18 All ancillary uses limited to 50% floor space of principal use
19 Minimum width of side & rear marginal open Space-6.0 m.
20 In a single-storeyed detached or semi-detached structure each
unit having an area not more than100 sq. m
21 With the Special permission of Commissioner
Sr No Conditions under which Land-use and Occupancies are
permissible
22 Subject to permission of Commissioner of Police
23 Subject to approval from Traffic Police.
24 Subject to permission from Executive Health Officer of
MCGM.
25 Subject to permission from Director of Industries
26 Subject to permission from Controller of Explosives
27 Minimum width of side & rear marginal Open Space - 9.0 m.
28 By maintaining segregating distances as per Regulation
No 41
Roads listed as per serial no. 17 of above Table
(a) (1) All Express Highways/Freeways
(2) East West Corridor i.e. Jogeshwari Vikroli link Roads, Goregaon Mulund Link
RoadGeneral Arun Kumar Vaidya Marg, Santacruz Chembur Link Road, Ghatkopar
Mankhurd Link Road, Andheri Ghatkopar Link Roads, Mathurdas Visanji Marg
(Andheri Kurla Road), Jai Prakash Road
(3)Western Corridor-:From Regal Cinema junction to Vithabhai Patel Road, Khar
covering Madam Cama Road, Netaji Subhash Road, Dr. N.A. Purandare Marg,
Babulnath Road, Justice Patkar Marg, Bhulabhai Desai Road, Lala Lajpatrai Road,
Dr. Annie Besant Road, Veer Savarkar Marg, Mahim Causeway, Vithalbhai Road
upto its junction with Chitrakar Dhurandhar Marg, Khar and Juhu Tara Road.
(4)Central Corridor.- From Regal Cinema junction to V.N.Purav Marg, Trombay,
covering Mahatma Gandhi Road, Dadabhai Navroji Road, Lokmanya Tilak Road,
Dr.B. Ambedkar Marg, Sion Road, Tatya Tope Road, V.N. Purav Marg upto
Anushakti Nagar.
(5)a)Other Roads viz. Shahid Bhagatsingh Road, Lokmanya Tilak Road,
L.Jagmohandas Road (Napean Sea Road), Bhulabhai Desai Road (Warden Road),
August Kranti Marg,Walkeshwar Road, S.K. Barodawala Marg (Altamount Road),
Dahanukar Marg (Carmichael Road), Manav Mandir Road,
b) Proposed Roads having width 45.70 m and above.
3.2 Conditions applicable for permitting various land-uses and occupancies
The conditions applicable for permitting various land-uses and occupancies in
Residential, Commercial & Industrial Zones as described in Table No. B, are given
in Table No. C with following for their permissibility.
P “P” Denotes Permissible Use without conditions in a Zone.
When conditions are reflected without indication of “P”, such
uses shall be permissible in that zone subject to compliance of
those conditions.
NP Denotes Non-Permissible Uses in a Zone.
Table No. C.
Conditions under which uses and occupancies will be permitted in
Residential, Commercial & Industrial Zones
Sr. Uses and Occupancies Conditions/Parameters under which land uses and
No. occupancies will be permitted in zones
R C I Additional Conditions/
Parameters
1 Residential P 1 or 2 or 3 NP In case of CBD, FSI will be
or 4 regulated as per
Regulation No 33(19)
2 Customary home occupations P 1 or 2 or 3 NP subject to compliance of
including professional works or 4 condition 1 or 2 or 3
from home in all such as
detached, semi-detached and
multi-family houses
3 Residential care activities for 1or 2 or 3 or 1 or 2 or 3 NP
the elderly and disabled, 4 or 4
orphanages, boarding
homes/institutions for children
and women
4 Short term
accommodation
(i) 4 or 5 Star category
1 or 2 or 3 & 1 or 2 or 3 1 or 2 or 3
hotels
11,16,21 &11,16,21, &11,16,21,
(ii)3 Star category hotels 1 or 2 or 3 1 or2 or 3 1 or 2 or 3
&15,21 &15,21 &15,21,28
(iii)Other categories of 1 or 2 or 1 or 2 or 1 or 2 or 3
Hotels 3,&14,21 3&14,21 & 21,28
iv)Motels, resorts, 1 or 2 & 1 or 2 or 3 1 or 2 or In case of 3 in residential
14,21 &,21 3 &21,28 premises, it shall be
subject to condition no 18
v)Guest houses, circuit houses, 1 or 2 or 3 1 or 2 or 3 1 or 2 & In case of 3 or 4 and in
hostels and boarding / lodging or 4 & 13 or 4 28 residential premises, it
houses, Dharmashala shall be subject to
Sr. Uses and Occupancies Conditions/Parameters under which land uses and
No. occupancies will be permitted in zones
R C I Additional Conditions/
Parameters
condition no 18
vi)Club Houses or Gymkhanas 1 or 2 or 3 1 or 2 P NP P
with extension counter or branch or 8
of Bank
General agriculture, horticulture 1 or 2 1 or 2 NP 1 or Poultry farming permitted
and poultry farming (but not dairy 2 at the rate of 0.25 sq. m.
farming) BUA per bird in plot
measuring not less than 1
ha.; provided that no
offensive odors, dirt
and/or dust are created,
that there is no sale of
products not produced on
the premises, and the
accessory buildings are
not located within 9 m of
the boundaries or 6 m.
from the main buildings or
the plot:
Provided further that the
above restriction on space
shall not apply to any
poultry kept for domestic
consumption only.
5 A)Health Care facilities without 1 or 2 or 3 1 or 2 or 3 NP 1 or In case of 3,6,9 and in
indoor bedding facilities for or 6 or 9 or 6 or 9 P 2 residential premises it shall
patients like, dental, medical be subject to condition no
practitioners, pathological 18
laboratory, diagnostic clinic, eye
clinic ,veterinary clinic & clinics
of other medical allied facilities
B)Health Care facilities with 1 or 2 or 3 1 or 2 or 3 NP 1 or In case of use already
indoor bedding facilities for or 6 or 9 or 6 or 9 P 2 existing prior to coming in
patient like maternity homes, force of these Regulations,
polyclinics, nursing homes, eye without fulfillment of
hospitals & other medical allied condition no 3,6 and 9,
Facilities the said use may be
allowed to continue
subject to compliance of
condition no 21 & 24
6 All other hospitals correctional 1 or 2 or 3 & 1 or 2 or 3 NP 1 or Hospital principally for
and mental institutions, 16 & 16 P 2 contagious diseases shall
institutions for children, the aged be located not less than
or widows sanatoria and hospitals 36 m. from any
Sr. Uses and Occupancies Conditions/Parameters under which land uses and
No. occupancies will be permitted in zones
R C I Additional Conditions/
Parameters
(except veterinary hospitals) boundaries. In case of 3 in
residential premises, it
shall be subject to
condition no 18
7 (i)Preprimary school, montessori 1or 2 or 3 or 1or 2 or 3 NP Permissible with minimum
school ,kinder garten schools, 6 or 9 or 6 or 9 area 40 sq. m in
balwadis & coaching classes residential building & in
case of 3, 6, 9 subject to
no nuisance being caused
to the occupants of the
building. In case of 3,6,9
in residential premises, it
shall be subject to
condition no 18
(ii)Primary schools/Primary 1 or 2 or 3 1 or 2 or 3 NP In case user is proposed in
cum secondary school & 13 or 6 or 9 & residential building as per
13 3, the same shall be
permissible subject to no
nuisance being caused to
the occupants& as per
condition no 21. In case of
3 in residential premises it
shall be subject to
condition no 18
(iii)Composite Schools and 1 or 2 or 3 1 & NP
colleges with other activities & 14 14
such as sports, recreational,
cultural and educational support
services. Educational
Universities, Hostels
8 Institutional uses other 1 or 2 or 3 1 or 2 or NP In case of 3 & 4 in
than specified in this or 4 & 15 3 or 4 & residential premises it
table 15 shall be subject to
condition no 18
9 Police Station, Govt. or Municipal 1 or 2 or 3 1 or 2 or 3 1 or 2 In case of 3,6 in
sub-offices, branches of Banks or 6 & 14 or 6 or 9 or 3 residential premises it
with safe deposit vaults, or 4 shall be subject to
telephone exchange, sub-office or 6 condition no 18
of consulate offices, sub offices
of electric supply company, Post
office, Civil Defense warden post
and First Aid post, Home Guard &
Civil Defense center.
Sr. Uses and Occupancies Conditions/Parameters under which land uses and
No. occupancies will be permitted in zones
R C I Additional Conditions/
Parameters
10 Electricity consumer/ 1 or 2 or 3 1 or 2 or 3 1 or 2 or 3
distribution sub stations or 6 or 7 or 6 or 7 or 6 or 7 or
or 8 or 8 8
11 Fire station, 1 or 2 or 3 1 or 2 or 3 1 or 2 In case of 3 in residential
& 13 & 13 premises it shall be
subject to condition no 18
12 Electricity distribution/ 1 or 2 & 1 or 2 or 5 1 or 2
receiving stations, public 14 & 12
utilities & services such as
pumping station, sewage
disposal work, water supply
installation & ancillary
structures thereof
13 Convenience Shops 5 , 14 & P NP In Gaonthan & Koliwadas
18 areas shall be permissible
on road width of 9.0m &
above.
14 Photographic studios with 5,14 &18 P P Each employing not more
laboratories, Photo-copying, than 9 persons & Power
video-taping establishments etc, not more than 3.75 KW
local sub-offices of any public for Photographic studios
utility, pawnshops, undertaker's with laboratories, Photo-
premises, private lockers, data copying, video-taping
processing unit including desk top establishments.
publishing, with use of computers,
travel agencies, ticket booking
and selling agencies for air,
surface or water travel or
transport of any other modes of
travel or transport, shoe repair
and sports shops, fish or meat or
frozen food store
15 Shops for the collection and 5 or 6 & 5 or 6 P P In case of 5, 6 in
distribution of clothes and other 16,17 residential premises shall
materials for cleaning, pressing be subject to condition no
and dyeing establishments. 18. Cleaning, pressing and
dyeing establishments
may be permitted in
service industrial estate
16 Tailoring, embroidery and button- 5 or 6 & 5 or 6 P P In case of 5,6 in
hole making shops, 16 14,17 residential premises shall
be subject to condition no
Sr. Uses and Occupancies Conditions/Parameters under which land uses and
No. occupancies will be permitted in zones
R C I Additional Conditions/
Parameters
Each employing not more
than 9 persons. Tailoring,
embroidery and button-
hole making shops may be
permitted in service
industrial estate
17 Cleaning and pressing 5 or 6 & 5 or 6 P P Each occupying a floor
establishments for clothes, 16,17 area not more than 200
sq. m. and not employing
solvents with a flash point
lower than 590 C, machine
with dry-load capacity not
exceeding 30 Kg. and
employing not more than
9 persons: Provided that
the total power
requirement does not
exceed 4 KW.In case of 5,
6 in residential premises it
shall be subject to
condition no 18. Cleaning
and pressing
establishments for clothes
may be permitted in
service industrial estate.
18 Coffee grinding establishments 1 or 2 or 1 or 2 or 3 P With electric motive
3 or 5 or or 5 or 6 power not exceeding 0.75
6 & P KW. (0.025 KW individual
16,17 motor each).
In case of 3, 5, 6 in
residential premises it
shall be subject to
condition no 18.
19 Establishments using power only 1 or 2 or 1 or 2 or 3 P In case of 3, 5, 6 in
for heating refrigeration or air- 3 or 5 or or 5 or 6 residential premises it
conditioning purposes. 6 & P shall be subject to
16,17 condition no 18.
20 Bulk storage of kerosene and 1 or 2 or 1 or 2 or 3 P& 21,26 In case of 3, 5, 6 in
bottled gas for domestic 3 or 5 or or 5 or 6 & residential premises it
consumption 6 & 21 ,26 shall be subject to
16,17,21, condition no 18.
21 Fish or meat, Vegetable, fruit, 5,14 &17 5,14 NP In Gaonthan & Koliwadas
Sr. Uses and Occupancies Conditions/Parameters under which land uses and
No. occupancies will be permitted in zones
R C I Additional Conditions/
Parameters
flower, frozen fish, frozen meat or & 18 areas shall be permissible
frozen food shops, Coal or fire- on road width of 9.0m &
wood shops above.
22 Shops for goldsmiths, lock-smiths, 5,14 & 17 1 or 2 or 9 1 or 2 P In Gaonthan & Koliwadas
watches and clocks, electronic & 18 P areas shall be permissible
goods and their repairs, bicycles on road width of 9.0m &
and their rental and repairs, above. Each employing
optical glass grinding and repairs, not more than 9 persons.
musical instruments and their
In the vicinity of
repairs, picture-framing, radio,
obnoxious industries
television and household
subject to 28.
appliances and their repairs,
umbrellas and their repairs and
upholstery work,
23 a) Art galleries i.e. display shops 1or 2 or 3 P NP In case of 3,6 & 20 in
or 5 or 6 residential premises it
.
or 20 & shall be subject to
b) Personal services 16,17 condition no 18
establishments
c) Motor driving schools
d) Hair dressing saloons and
beauty parlours.
24 Professional offices and studies of 18 P NP In residential premises
a resident of the premises and each not occupying a floor
incidental to such residential use, area exceeding 50 sq. m
or medical and dental on any floor
practitioners’ dispensaries or
clinics of a resident of the
building with only outpatient
treatment facilities without any
indoor work,
25 Business Offices and services 1 or 2 or 1 or 2 NP In case of 3 in residential
establishments 3 & 16 or 3 & premises it shall be
16 subject to condition no 18
There shall be no
restriction of width of
street in case of business
office in commercial
zone.
26 Restaurants, eating houses, 1 or 2 or 1 or 2 or NP In case of 3,6,9 in
Sr. Uses and Occupancies Conditions/Parameters under which land uses and
No. occupancies will be permitted in zones
R C I Additional Conditions/
Parameters
cafeteria, ice-cream and milk 3 or 6 or 3 or 6 or residential premises it
parlours 9 & 16 & 9 shall be subject to
17 &18 condition no 18
.
27 Retail trade and shops/stores or 6 or 20 & 6 or 20 NP Storage or sale of
shops for conduct of retail 16 15,17, or 9 &17 combustible materials
business, 18 P shall be permissible
subject to condition no
21.In case of residential
premises shall be subject
to condition no 18.
28 Malls/shopping centers 1 or 2 or 1 or 2 or NP Additional 3.0 m front
/Multiplex/Departmental Stores 3 & 16 3 & 16 open space for the traffic
and Independent Market building management / holding
along with their ancillary storage bay shall be provided.
29 Sale of used or second hand goods 1 or 2 & 1or 2 P P
for merchandise, excepting for 16,17
junk, cotton and other waste rags
or other materials of an offensive
nature.
30 Storage of furniture and 1 or 2 or 1or 2 P 14 P
household goods 3 or 6 &
16,17
31 Retailing of building materials, 1 or 2 & 1or 2 P 14 P With not more than 500
open or enclosed, 16,17 sq. m of area per
establishment.
32 Pasteurizing and milk processing 1 or 6 or 1 or 6 or P
plants each employing not more 20 & 20 & 14
than 9 persons and 7.5 KW motive 16,17
power within an area not more
than 100 sq. m.
33 Repair, cleaning shops and 1 or 2 or 1 or 2 or P Each employing not more
analytical experimental or testing 3 or 6 or 6 or 20 P than 15 persons (but not
laboratories 20 & including cleaning and
16,17 dyeing establishments,
using a cleaning or dyeing
fluid having a flash point
lower than 50 degree C
and machines with dry-
load capacity not
exceeding 30 kg. or any
establishment carrying on
Sr. Uses and Occupancies Conditions/Parameters under which land uses and
No. occupancies will be permitted in zones
R C I Additional Conditions/
Parameters
activities that are
offensive because of
emission of odour, dust,
smoke, gas, noise or
vibration or otherwise
dangerous to public
health and safety),
provided that the motive
power requirement of
each such establishment
does not exceed 7.5 KW.
34 Paper-box manufacturing, NP 1 or 2 or P Each employing not more
including paper-cutting, 5 or 6,14 than 9 persons with
motive power not
exceeding 3.75 KW and
area not more than 100
sq. m.
35 Establishments requiring power NP 1 or 2 or P Each employing not more
for sealing tins, package, etc. 5 or 6,14 than 9 persons with
motive power not
exceeding 2.25 KW
36 Ice factories in independent 1 or 2 & 1 or 2, 14 P In case of R & C Zone
buildings. 16,17 each with an area of not
more than 250 sq. m and
power not more than 34
KW
37 Aquariums. 1 & 16,17 1,16 P
38 Cemeteries and 1 1 1 subject to approval of the
graveyards Corporation
39 Private parks, gardens and 1 1 1
playfields on non-reserved plots
40 Stadiums, golf courses and 1 1, 16 NP
amusement parks
41 Libraries, reading halls, study 1 or 2 or 3 1 or 2 or NP In case of 3,6,9 in
halls, creative arts, archives, or 6 or 9 & 3 or 6 or residential premises it
museums and other cultural 14 9 P 14 shall be subject to
activities condition no 18
42 Places of worship, 1 or 2 & 1 or 2 & 1 or 2 &
Religious buildings. 14,21 & 22 14,21 & 14,21 &
22 22
Sr. Uses and Occupancies Conditions/Parameters under which land uses and
No. occupancies will be permitted in zones
R C I Additional Conditions/
Parameters
43 Multipurpose Community halls, 1 or 2 or 3 1 or 2 or NP In case of 3 in residential
welfare centers, & 14 3 & 14 P premises it shall be
subject to condition no 18
44 Commercial halls, exhibition halls 1 or 2 or 3 & 1 or 2 or NP In case of 3 in residential
,Marriage halls, Auditorium, 17 16 3 or 4 or premises it shall be
clubs, assembly or concert halls, 5 or 6 & subject to condition no
dance and music studios 14 16 P 18.Additional 3.0 mt front
open space for the traffic
management / holding
bay shall be provided.
45 Drama theatre, Cinema 1 or 2 or 3 1 or 2 or NP Minimum front open
theatre, Drive-in-theatre & 16 3 & 16 space of 12 m shall be
provided.
46 Gymnasiums, 1 or 2 or 3 P NP In case of 3 or 9 in
or 9 residential premises it
shall be subject to
condition no 18,if
proposed other than
permissible as per
regulation no37
47 Radio broadcasting and 1 or 2 or 3 1 or 2 or NP In case of 3 in residential
television studios, 3 P premises it shall be
subject to condition no 18
48 Sound recording and 1 or 2 or 3 P NP In case of 3 in residential
dubbing studios/ Preview or 6 or 9 premises it shall be
Theater subject to condition no 18
49 Flour Mill 1 or 2 or 3 1or 2 or 3 NP Power requirement shall
or 20 &18 or 20 & not exceed 7.5 KW each
50 Storage and Retail sale of 1,or 6 or 1, or 6 & 1, or 6 & In case of 6 in residential
household fuel Storage of liquified 14 & 21, 26 21, 26 21, 26 premises it shall be subject
petroleum gas cylinders (bottled to condition no 18
gas) for domestic consumption
not exceeding 300 kg. in a
residential building and not
exceeding 8000 kg. in an
independent ground floor
structure (except a garage) at any
one time, with the special
permission of the Commissioner
and subject to compliance with
statutory safety requirements.
Sr. Uses and Occupancies Conditions/Parameters under which land uses and
No. occupancies will be permitted in zones
R C I Additional Conditions/
Parameters
51 Vehicles repair/ servicing garages, 1 or 6 or 20 1 or 6 or 1 or 6 or In case of 6, 20 in
driving school, & 16,17 20,15 20 P residential premises it
shall be subject to
repairing garages, without
condition no 18.
activities of body-building and
Employing not more than
spray painting,
9 persons or using 1.5 KW
motive power
52 Sale of motor vehicles, parts and 1or 2 or 6 1 or 2 or P 16
accessories, Showrooms for & 16,17 6 P 16
motor vehicles
53 Bus stations, taxi stands, auto- 1 & 14 & 1 & 14 & 1 & 14 &
rickshaw stands, Bus Shelters, 23 23 23
Bus Depots and Railway stations.
54 Heliports Heliports shall be allowed
subject to compliance of
Regulation No 37(35)
55 Public parking areas, including 14 14 NP P
multistoried parking
56 Cottage Industries, 1 or 2 or 3 1 or 2 or 3 P In case of 3,4,6 in
or 4 or 6 or 4 or 6 residential premises it
P shall be subject to
condition no 18
57 Service industrial uses as per 1 or 2 or 3 1 or 2 or P In case of 3,6 in residential
table (D) below or 6 or 20 3 & 16 premises it shall be
&16 subject to condition no 18
58 Service Industrial estates 1 or 2 & 1 or 2 or P In case of 3in residential
16,17 3, 16 & premises it shall be
17 subject to condition no 18
59 Collection and disposal of NP 1 or 2 & P
nonhazardous waste 19
60 Warehousing, NP N P
P
61 Ware housing activities of NP NP 25,26,27
hazardous material
62 Logistics activities and truck NP 1 & 15, 1 & 15
terminals 16
63 I.T.&I.T.E.S unit/s (pertaining to 1 or 2 or 14 14 In case of 3,4,9 in
software only as per IT policy of 3 or 4 or residential premises it
Sr. Uses and Occupancies Conditions/Parameters under which land uses and
No. occupancies will be permitted in zones
R C I Additional Conditions/
Parameters
GoM or Central Govt.) 9 &14 shall be subject to
condition no 18
64 Offices, Information Technology 1 or 2 & 14 1 or 2 or 14
Establishment 3 & 14
65 Biotechnology units NP NP 14
66 Wholesale trade and storage 1 or 2 or 3 1 or 2 or 3 1 or 2 or In case of 3 or 20 in
or 20 & or 6 or 20 6 or 20 residential premises it
16,17 &14 16 shall be subject to
condition no 18
67 Prisons NP 1 or 1 or 2 &
2 & 22
68 a)Trade and other similar schools, 1 or 2 & 1 or 2 or 3 P
not involving any danger of fire or 16, 17 or 4 P
explosion, or offensive noise,
vibration, smoke, dust, odour,
glare, heat or other objectionable
features.
b) Bakeries, with no floor above, 1 or 2 & 1 or 2 or 3 P Not employing more than
each not occupying for production 16, 17, or 20 9 persons, if the power
an area more than 75 sq. m. requirement does not
exceed 4 KW where only
electrical ovens are used,
an additional heating load
up to 12 KVA being
permitted.
c) Confectioneries and 1 or 2 or 3 1 or 2 or 3 P Employing not more
establishments for the or 6 20 & or 20 P than 9 persons, motive
preparation and sale of eatable 16, 17 power not exceeding 1.12
each not occupying for production KW in residential zone.
an area more than of 100 sq. m
In case of Commercial
per establishment. .
zone area not in excess of
250 sq. m per
establishment, employing
not more than 25 persons,
motive power not
exceeding 10 KW with no
floors above over the
furnace portion. If only
electrical ovens are used
an additional load up to
Sr. Uses and Occupancies Conditions/Parameters under which land uses and
No. occupancies will be permitted in zones
R C I Additional Conditions/
Parameters
24 KVA may be permitted.
d) Sugarcane and fruit juice 5 or 20 & 5 5 Employing not more than
crusher 14, 17,18 6 persons with motive
power not exceeding 1.12
KW
e) Printing presses 5 or 20 or 5 or 20 P Aggregate motive power
16,17,18 P 14 each not exceeding 3.75
KW and not employing
more than 9 persons and
individual electric motors
of not more than 1.5 KW.
f) Battery charging and repairing 5 or 20 or 5 or 20 P P Each not employing more
establishments with an area not 16,17,18 than 6 persons and not
more than50sq.m more than 2 charges with
power not exceeding 5 KW
g) Electronic industry of assembly, 5 or 20 or 5 or 20 P P Area not exceeding
but not of manufacturing type, 16,17,18 100.00 sq. m. total electric
power inclusive of motive
.
power and heating load
not to exceed 3.75 KW
and employing not more
than 9 persons each
69 Research & experimental & 1 or 2 or 1 or 2 P Not involving any danger
testing laboratories 3 or 3 or of fire or explosion or of
4 P any obnoxious nature and
located on a plot not less
than 4 ha. in area,
provided that the
laboratory is at least 30 m.
from any of the
boundaries of the site and
the accessory residential
building is at least 30 m.
from the laboratory.
70 Industrial manufacturing, NP N P
fabrication, assembly and P
processing activities other than
Service Industries
71 Filling stations of petrol, diesel, 1 or 2 or 1 or 2 or 26, 16 In case of existing
compressed natural gas stations 3, 26,16 3, 26, 16
petrol pump,
and/or any other motor vehicle
criteria of road
Sr. Uses and Occupancies Conditions/Parameters under which land uses and
No. occupancies will be permitted in zones
R C I Additional Conditions/
Parameters
fuel width may not be
insisted
72 Manufacturing not classified NP N 25
elsewhere P
73 Manufacturing, processing &
usage of
(a)Chemicals, fertilizers, gases, NP N 25,26,27
metal compounds, soap, soda, P
acids, starch, automobiles, boiler
works, metals, ceramics, asphalt,
ammonia, alcohol, leather
processing ,metal processing,
paints, varnish, turpentine,
dyestuff, tar products, paraffin,
gypsum, plaster or plaster of paris
manufacture; photographic films
manufacture, lime manufacture,
match manufacture pesticides,
organic industry, match-sticks, fat
rendering, fat tallow, grease or
lard refining or manufacturing,
gelatin or glue manufacture, or
processes, involving recovery
from fish or animal offal.
pyroxylin manufacture;
(b)Cellulose manufacture, NP N 25,26,27
explosives, fireworks and P
petroleum & its products (
inflammable)
7 Ready Mix Plant NP N P Subject to NOC from the
3 P Environment Department
of MCGM
(EP-123)
TABLE No. D
Service Industrial users and conditions governing such uses:
Se Category of Industry Service Industry permitted subject to Special conditions, if any
ria
Maximum Maximum Maximum
l
permissibl permissible permissibl
N
e power employmen e floor
o.
(in KW) t. area (sq.
(3)
m)
(2) (4) (5) (6)
(1
)
I Food Products-
i Ground nut decorticators,
ii. Grain mill for production of
flour,
iii. Manufacture of supari and
masala grinding, 7.5 9 50 250
iv. Rice-hullers,
v. Manufacture of milk and
dairy products,
vi Manufacture of ice- cream
and ice candy.
vii. Manufacture of bakery (i) Fuel used shall be
electricity, gas or
products
Smokeless fuel.
(ii) No floor above the
furnace portion
10 25 250
(iii) Where only electric
oven is used, an additional
heating load of 24 KVA
permitted per
establishment.
viii. Coffee curing, roasting and
1.5 9 50 250
grinding.
ix. Manufacture of ice 45.0 20 250
x. Sugarcane and fruit juice
1.5 9 25 250
crashers
II Textile and Textile Products-
xi. Embroidery and making of 3.75 9
50 250
crepe laces and fringes.
xii. Manufacture of textile
goods, such as wearing
apparel, curtains, mosquito
net, mattresses, bedding 2.25 9
50 250
material, pillow cases, and
textile bags.
xiii. Mattress making and
cotton cleaning.
III Wood Products and Furniture-
xiv. Manufacture of wooden 2.75 9
50 250
furniture and fixtures.
Not permitted under or
adjoining a dwelling unit.
xv. Manufacture of bamboo
and cane furniture and 2.25 9 50 250
fixtures.
IV Paper products and Printing (i)Manufacture with
Publishing- paper pulp not permitted.
(ii) No restrictions on
xvi. Manufacturing of
power, number of
containers and boxes from
employees, area of hours
paper board.
of operation shall apply if
3.75 9 50 250
located in a building on a
separate plot not less
than 500 sq. m in area
and if special permission
of the Commissioner is
obtained.
xvii. Printing and publishing (i)Manufacture with
periodicals, books, journals, paper pulp not permitted.
atlases, maps, envelopes,
(ii)No restrictions on
picture post-cards and
power, number of
embossing.
employees, area or hours
of operation shall apply, if
xviii. Engraving, etching, block- 7.5 9 120 250
located in a building on a
making etc.
separate plot not less
than 500 sq. m in area
xix. Book binding.
and if special permission
of the Commissioner is
obtained.
V Leather products excluding Manufacture of leather or
tanning- leather processing not
permitted.
xx. Manufacture of leather
3.75 9 50 250
footwear.
xxi Manufacture of wearing
apparel like coats, gloves.
xxii. Manufacture of leather
consumer goods such as
upholstery, suitcases, pocket
books, cigarette and key cases,
purses.
xxiii. Repair of footwear and
other leather products.
VI Rubber and Plastic
Products-
xxiv. Retreading, recapping
1.5 9
50 250
and vulcanizing works.
xxv Manufacture of rubber
balloons, hand-gloves and
allied products.
VII Metal products-
xxvi. Tool sharpening and razor
sharpening works. 0.75 9 25 250
xxvii Umbrella assembly 0.75 9 50 250
works
VII Electrical Goods-
I
xxviii. Repairs of household
electrical appliances, such as
radio and television sets, tape
No spray painting
recorders, video sets, heaters, 2.25 9 50 250
permitted.
irons, shavers, vacuum cleaner,
refrigerators, air-conditioners,
washing machines, electric
cooking ranges, meter
rewinding works.
xix. Electronic industry of Only permitted on ground
3.75 9 50 250
assembly type. floor.
IX Transport Equipment
xxx. (a)Servicing of motor
vehicles and motor cycles. No floor above.
3.75 9 100 250
No spray painting
(b) Repair of motor vehicles
permitted.
and motor cycles.
(c)Battery charging and repairs. 5.0 6
25 250
(d) Repair of bicycles and cycle
3.75 6 50 250
rickshaws.
X Other Manufacturing and
Repairs, Industries and
Services-
xxxi. Manufacture of jewellery
and related articles.
xxxii. Repairs of watches, 2.25 9
clocks and jewellery.
50 250
xxxiii. Manufacture of musical
instruments and their repairs.
xxxiv. (a) Repairs of locks,
stoves, umbrellas, sewing
machines gas-burners, buckets
and other sundry household
equipments.
(b) Optical glass grinding and
repairs.
2.25 3 50 250
XI xxxv. Petrol filling stations in
plot size of 30.5 m. x 16.75 m.
and petrol filling and service 7.5 9 No limit
stations in plot size of 36.5 m.
x30.5 m.
xxxvi Filling stations of Petrol, (i)quantities in (b) or (c)
Diesel, Compressed Natural will be permitted for
Gas stations and/or any other daughter booster
motor vehicle fuel in plot size pumping station and on
(a)15
of 30.5 Mt x 16.75 Mt. And pumping station
filling and service stations. respectively over(a)
(b)30 per No limit
Petrol, Diesel, Compressed
compressor or (ii)permissible power
Natural Gas Stations and/or
(not more 3 9 mentioned in (b) & (c) will
any other motor vehicle fuel in No limit
be used exclusively for
plot size of 36.5 mt x 30.5 Mt.
compressor )
compressing and filling
and 6 gas in vehicle
(c)150 per
(B) Filling stations of only
compressor( (iii)Special permission of
Compressed Natural Gas
not more than commissioner is
Minimum area of plot 300
necessary after clearance
sq.mt 3 compressor) 6
by Maharashtra Pollution
No limit
Control Board from noise
pollution point of view
and controller of
Explosive and chief fire
officer and observance of
conditions as they may
prescribe.
Xxxvii Audio, taping 4.0 9 50
recording, manufacture of
equipment for the same and
recording
studio.
xxxviiii Laundries, laundry 4.0 9 50 i) Cleaning and dyeing
services and cleaning, dyeing, fluid used should not
bleaching and dry cleaning. have a flash point lower
than a 59 0 C.
(ii)Machinery having dry
load capacity of 20 kg.
and above.
xxxix Data Procession units 4.0 9 50
with use of computer.
xl Photo-processing, 3.75 9
laboratories, Xeroxing,
photocopying, video taping
and their laboratories.
xli Repacking and mixing of 2.25 9 50
liquids, powders, pastes etc.
not involving any chemical
reaction which is non-
hazardous in nature.
XII Xlii Business /Administrative
office
Xliii Business /Administrative 50% of
offices of the Service the area
Industry/Small Scale Industry under the
within the same premises Service
Industry/S
mall Scale
Industry
(EP-124)
Note 1 i) Service industrial uses amended from time to time by government shall be
allowed.
ii) With the approval of Corporation special permission, Commissioner may from time to
time add to, alter or amend the above Tables.
Note 2 :( a) Conditions governing other uses permitted in Residential Zone: The
uses permissible in the Residential zone shall be restricted and subject to the
conditions below:
(i) A depth of 12 m. measured from the building line along the front portion
abutting the street shall be provided.
(ii) Shops, except convenience shopping, may be permitted up to second floor with
separate access unless otherwise specified, subject to road having width of 18 m or
more, except as stated in condition no 17 of Table B.
(iii) Motive power, no of persons working in shops shall be such that it shall not
attract provisions of Factory Act
(iv) Power may be discontinued if the Commissioner is satisfied that the
particular use is a nuisance to the residents.
(b)Other uses in the Industries Zone (I-Zone): If a plot in the Industrial Zone (I-
Zone) becomes un-buildable for industrial use because of restrictions in the
Industrial Location Policy of GoM or restrictions regarding segregating distances
under these Regulations, the following uses may be permitted on such plot
without maintaining the required segregation distances:
i. Fuel-stations and service stations/motor garage;
ii. Parking lots/Parking garages;
iii. Electric sub-stations, Distribution Sub Station;
iv. Offices for public utility concerns or organizations
v. Police stations, Government and Semi-Government offices, municipal sub-
offices, fire stations and posts and telegraph offices.
vi. Warehouses.
vii. Community Facilities
viii Convenience shops
ix. Hotels with rooms not exceeding 75 nos.
x. Branches of banks with safe deposit vaults
The Commissioner may alter, amend or add to the list of the above uses.
3.3 Exceptions
In case of Residential/Commercial/Industrial Zone following exceptions shall apply
to the permissible uses:
1) Existing non-conforming uses to continue in certain circumstances:
a) The existing authorized uses in the zone that are not listed in the permissible
uses will be allowed to continue and will not be considered as non-conforming in
redevelopment/reconstruction.
b) Any lawful use of land/building premises existing before the coming into force of
these Regulations may continue even after redevelopment/reconstruction of
land/building even if it does not conform to the use provisions of these Regulations
provided such non-conforming use is not extended or enlarged except as provided
in these Regulations.
c) In case a building accommodating any nonconforming use collapses, is pulled
down or is destroyed, any new building on the site shall conform to these
Regulations and to the land use prescribed for the plot in DP.
d) In rehabilitation scheme undertaken by Mumbai Repair and Reconstruction
Board (A MHADA unit) or Slum Rehabilitation Authority (SRA) or in Dharavi
Redevelopment Project (DRP) where a new building is constructed in place of an
old building, containing authorized non-conforming uses, the Commissioner may
allow the same non-conforming use in new building provided such user is not
industrial, hazardous or likely to cause pollution. In case of such rehabilitation
scheme in Industrial Zone, authorized residential use may be permitted only in
independent building subject to 2 below
e) In case of redevelopment, existing authorized non-residential uses in a
residential building will be allowed to be continued on the ground floor, first or
second floor or floor above stilts/parking floors or in a separate wing of a building
with the special permission of the Commissioner.
f) Any permitted non-conforming uses or those existing prior to 01.04.1962
including industries which are nonhazardous or nonpolluting may be allowed to
continue without addition to such non-conforming use
g) Non-conforming industries.- Non-conforming industries which are neither
hazardous nor polluting and which have been permitted to operate, without any
requirement that they may shift to a conforming zone after a specific period, may,
with the Commissioner's special permission, be allowed to make additions to start
a new process or to manufacture new products, provided the degree of nuisance
from the existing unit will in no way be affected by such additions and subject to
requirements of these Regulations for such additions.
h) In C and I Zone, if entire building is constructed for non-residential use, the
requirement of separate access shall not be insisted upon.
2) Prohibition of Factories in Residential Building in Conforming Zones:
Notwithstanding anything contained in these Regulations, no permission shall be
granted for establishing any factory, workshop or work place (for the establishment
of which previous permission is required under Section 390 of the MMC Act, 1888)
wholly or partly on lands used for residential purposes even if such use is in
conformity with these Regulations and the aforesaid Act;
Provided that the uses in a residential building permissible under this Regulation
which are compatible with the residential use unless & otherwise specified may be
permitted on the ground floor.
3) All Municipal land of the Municipal Octroi Check Nakas, shown for existing
‘Truck Terminus’ or otherwise, shall be developed as ‘Comprehensive Transport
Hub’, which will interalia include a bus/truck terminus and such land shall be
considered as falling not utilized to full potential, shall be considered as land in
Commercial Zone and be treated as Central Business District (CBD)/Parking
Transport Hub including intercity bus station for development apart from primary
function of octroi naka and may and shall be developed as per the relevant
provisions of these Regulations.
Provided that, if development is proposed by MCGM on its own, then the payment
of premium for BUA beyond zonal (basic) FSI, shall not be applicable. However,
payment of premium shall be applicable if the project is developed through PPP
model/ allowed to be developed through any other agency.
Provided further that in case of combined development of comprehensive
transport hub interalia bus/truck terminus along with the Commercial
development, then area of the parking of vehicles including areas required for
maneuverability of vehicles of bus or truck terminus shall be allowed free of FSI.
(EP-125)
3.4 No Development Zone (NDZ):-
(A) Development of land in No Development Zone (NDZ):
1. General
The provision of this Regulation shall apply to any contiguous, unbroken and uninterrupted
piece of land, excluding the land under reservation for the public purpose, not less than 4.0
ha, and not disqualified from development on account of other laws or regulations that are
binding. Such plot shall have means of access of width not less than 18m. Owners of land
parcels having plot area lesser than 4 ha may come together to create contiguous land
parcels of 4 ha or more & submit proposal for development under this Regulation.
2. Submission of Proposal
The proposal shall be submitted by the Owner containing the demand assessment for
infrastructure such as roads, water supply, sewerage and storm water drains.
3. Planning Considerations
(a) The proposed development, as far as possible, shall be planned in such a way that the
Public Open Space (POS) falls centrally and Affordable Housing (AH) and Owner’s
development fall on either side of the Public Open Space (POS).
(b) A Road shall be proposed on both sides of the POS to be made public, as per the
provision of these Regulations subject to each having minimum width of 12 m. They shall
also serve as connecting roads for the area proposed to be developed beyond the area for
which proposal under this Regulation is submitted. These roads shall be handed over to
MCGM.
(c) The area of the land after deduction of the area covered under above referred roads
shall be apportioned among Owner’s Share, AH, POS, Institutional Amenities (IA), and Other
Amenities as detailed below:
Public Open Spaces & Affordable Housing, Education, Health & Social
Sr. Institutional Area Amenities Area for
No. 33% 33% Other
Development
Public Institutional Affordable Educational Medical Social
Open Area Housing
Space
1 25 % 8 % 25% 4 % 3% 1% 34 %
4. Procedure of Approval
The Owner shall submit his proposal in accordance with Sr. No. 1, 2 and 3 above to the
Commissioner MCGM. While making such submission he will take care of the following:
(a) He shall distinctly mark lands for AH, POS, 2 numbers of roads and Owner’s share in the
layout. Further earmarking of lands for Institutions, education, health and social amenities
cited above shall be done by the Commissioner taking the amenity standards prescribed as
minimum.
(b) Advance possession of all lands other than the Owner’s Share as detailed in Sr. No 3(b) &
(c) above shall be handed over to MCGM at the time of approval of layout. The ownership
shall be transferred in the name of MCGM within one year from the date of advance
possession or seeking commencement certificate beyond plinth of the development of
Owner’s share, whichever is earlier.
(c) The Land Owner shall have the option of developing all AH, POS, Institution, education,
health and social amenities (hereafter referred to as AH & Amenities) and handing them
over to the MCGM.
(d) The development of AH & Amenities shall be as per specifications laid down by the
Commissioner, within three years from date of approval to the individual building plans of
AH, POS and amenities, unless extended by the Municipal Commissioner for valid, recorded
reasons.
(e) Provision of amenities as per Regulation No. 14(A) and 15 shall not be applicable for
development under this Regulation.
(f) The carpet area of affordable housing tenements shall be EWS (30 m²), LIG (45 m²) and
MIG (60 m²) in the ratio of 0.35, 0.35 & 0.30 respectively. Any minor variation in tenement
percentages must be recorded in writing and be reflective of actual demand. Over a period
of time, with approval of GoM, the carpet area of tenements may be upwardly revised to
reflect a rising economy, higher incomes and the aspirations of citizens.
(g) The proposal under this Regulation shall be considered with the approval of the Municipal
Commissioner.
(h) Notwithstanding anything contained in these Regulations, residential/commercial uses
otherwise permissible, independent of road width to which it abuts shall be permissible on
the Owner’s share of land.
5. Infrastructure Development
The owner shall develop the infrastructure network within the layout (AH & Amenities) to
be handed over to MCGM (road + water supply mains + sewer line + storm water drain +
street lights pertaining to that specific scheme) as per the requirements of the concerned
departments.
6. Permissible FSI:
(a) If the Owner opts out of the responsibility of developing AH & Amenities, he will get FSI 0.8
of the gross plot (AH + POS+ all public amenity land + area covered under 2 numbers of
roads to be handed over to MCGM + land forming Owner’s share of that specific scheme)
on the Owner’s share of land.
(b) If the Owner opts to develop the cited AH & Amenities, the Owner shall be entitled for FSI
1 of the gross plot (AH + POS+ all public amenity land + area covered under 2 numbers of
roads to be handed over to MCGM + land forming Owner’s share of that specific scheme)
on the Owner’s share of land.
(c) The Owner would also be compensated for all infrastructure developed by him that is not
attributable to infrastructure pertaining to Owner’s share of land and construction of the
AH tenements & other amenities as described in serial no. 7(a) below.
(d) In addition, the Owner would be eligible to receive the sale proceeds of 15 % of AH units
from MCGM after deduction of administrative charges.
(e) The Development of the plot handed over for AH shall be with FSI 3.0 on the plot of the AH
area. AH Tenements & constructed amenities shall have to be handed over to MCGM. The
cost of construction of AH tenements& built up amenities shall be paid in the form of BUA.
(f) The development of Amenities as per the requirements of MCGM shall be permissible as
per these Regulations. Provided further that Municipal Commissioner’s decision regarding
development of Amenities/Institutional Amenities shall be final and binding on the
concerned.
(g) ‘TDR’ or ‘Additional FSI on payment of premium’ as per Regulation No 30 (1) (A) [except
Fungible FSI as per Regulation No. 31(3)], shall not be permissible on Owner’s share of
land.
(h) The land handed over to MCGM for public amenities as stated above shall not be allowed
to be developed under AR as stipulated in Regulation No 17 and shall have to be used
entirely for the intended purpose as per these Regulations.
(i) Notwithstanding anything contained in these Regulations, residential/commercial uses
otherwise permissible, independent of road width to which it abuts shall be permissible on
the Owner’s share of land
(j) Development charges and premium shall not be recovered for any relaxations in open
spaces, exclusion of staircase, lift and lobby areas from FSI computation & for Fungible FSI
as per Regulation No. 31(3) for BUA to be handed over to MCGM.
(k) Off-site infrastructure charges at 7% of the Land Rate (for FSI 1) for the BUA (including
fungible FSI) to be constructed on owner’s share of land as per ASR of the year of approval
shall be paid to MCGM. These off-site infrastructural charges shall be in addition to
development charges levied as per section 124 of MR&TP Act 1966.
7. Compensation for development of infrastructure in lands handed over to MCGM
and constructed BUA.
a) The owner shall be entitled for the following:
BUA in lieu of cost of constriction of 2.0[Rate of construction per sq. m as per
AH/Built up Amenities including entire ASR rate/rate of developed land per sq. m
infrastructure development for MCGM = as per ASR(for FSI 1)]x BUA of all
share of Land amenities & all AH
This shall be subject to maximum 50% of the BUA of AH/Amenity to be handed over to
MCGM.
b) The ratio of BUA to carpet area shall be considered as 1.2 (including provisions of various
requirements as per these Regulations).
c) Area covered under staircase/lift/staircase and lift lobby for AH tenements/Amenities shall
not be counted in FSI/BUA and shall be without charging premium.
d) No premium shall be charged for Fungible FSI and features permitted free of FSI as per
Regulation No 31 for the development of AH tenements/Amenities/IA.
e) Commencement Certificate beyond 75 % of the BUA as per serial No 6(a) shall not be
issued unless the infrastructure development in the entire layout and construction of AH
tenements/Amenities/IA is completed & occupation granted.
f) The Commencement Certificate beyond 75 % of BUA as per serial No 6(a) may be released
once the Occupation Certificate for AH tenements/Amenities/IA is granted.
g) BUA in lieu of development of infrastructure and construction of AH
tenements/Amenities/IA, as detailed in 7(a) above may be released in proportion of 0.50
sale (incentive) area: 1 AH/Amenity/IA area and the construction shall progress
simultaneously in the said proportion, and 100% of incentive area in lieu of AH
tenements/Amenities/IA & infrastructure development can be released only after handing
over of entire AH tenements/Amenities/IA as per (f) above.
h) TDR in lieu of unconsumed incentive BUA, as per provision (a) above in proportion to
handing over of such completed AH tenements/Amenities/IA may be allowed at the
option of owner/developer. However, 20 % of such admissible TDR for unconsumed BUA
shall be released only after handing over the entire area of AH tenements/Amenities/IA to
MCGM.
i) Requirement of ROS as per Regulation No 27 may be kept at 8% on Owners share of land &
in respect of plot of AH.
(B) Land of Govt. /Semi. Govt. /Appropriate Authority appointed by Govt falling in NDZ
1. General
Notwithstanding anything contained in these Regulations the land of Govt./Semi-
Govt./Appropriate Authority falling in NDZ, the provision of this Regulation shall apply to any
contiguous, unbroken and uninterrupted piece of land having area not less than 4.0 ha,
excluding the land under reservation for the public purpose and not disqualified from
development on account of other laws or regulations that are binding.
2. Planning Considerations
(a) The proposed development, as far as possible, shall be planned in such a way that the
POS falls centrally and AH and area for other development fall on either side of POS. These
areas shall have proper access as per provisions of these Regulations.
(b) The area of the land after deduction of the area covered under above referred roads shall
be apportioned among Appropriate Authorities’ Share, AH, POS + Roads, IA, and Other
Amenities as detailed below:
Public Open Spaces & Affordable Housing, Education, Health & Social
Sr. Institutional Area Amenities Area for
No. 33% 33% Other
Development
Public Institutional Affordable Educational Medical Social
Open Area Housing
Space
1 25% 8 % 25% 4 % 3 % 1% 34 %
3. Procedure of Approval
The Appropriate Authority shall submit the proposal to the Commissioner, MCGM, distinctly
showing lands for AH, POS, 2 numbers of roads and share of other development in the layout.
Further earmarking of lands for education, health and other amenities cited above shall be
done by the Commissioner taking the amenity standards prescribed as minimum.
(a)Provision of amenities as per Regulation No. 14(A) and 15 shall not be applicable for
development under this Regulation.
(b) The proposal under this Regulation shall be considered with the approval of the Municipal
Commissioner.
(c)The area of social amenities, POS and roads shall be handed over to MCGM. Advance
possession receipt shall be submitted at the time of approval of proposal and the ownership
shall be transferred in the name of MCGM in revenue records before seeking Occupation to
any of the development in layout.
4. Permissible FSI:
a) Govt./Semi-.Govt./Appropriate Authority appointed by Govt. shall be eligible for FSI 1 of
the gross plot (AH + POS+ all public amenity land + area covered under 2 numbers of roads
to be handed over to MCGM) on area of other Development.
b) The Development of the plot earmarked for AH with FSI 3.0 on the plot of AH area shall be
done by Government/semi-government/ Appropriate Authority appointed by Govt. These
tenement shall be made available for general public for the affordable Housing as per
policy of Government.
c) The carpet area of affordable housing tenements shall be EWS (30 m²), LIG (45 m²) and
MIG (60 m²) in the ratio of 0.35, 0.35 & 0.30 respectively. Any minor variation in tenement
percentages must be recorded in writing and be reflective of actual demand. Over a period
of time, with approval of GoM, the carpet area of tenements may be upwardly revised to
reflect a rising economy, higher incomes and the aspirations of citizens.
d) The development of Amenities as per the requirements of MCGM shall be permissible as
per these Regulations. Provided further that Municipal Commissioner’s decision regarding
development of Amenities shall be final & binding.
e) Institutional Amenities may be developed by Govt./Semi-.Govt./Appropriate Authority
appointed by Govt, as decided by the Govt. /Appropriate Authority.
f) ‘TDR’ or ‘Additional FSI on payment of premium’ shall not be permissible except fungible
FSI.
g) The land handed over to MCGM for public amenities as stated above shall not be allowed
to be developed under AR as stipulated in Regulation No 17 and shall have to be used
entirely for the intended purpose as per these Regulations.
h) Notwithstanding anything contained in these Regulations, residential/commercial uses
otherwise permissible, independent of road width to which it abuts shall be permissible on
the Owner’s share of land
i) Off-site infrastructure charges at 7% of the Land Rate (for FSI 1) for the BUA (including
fungible FSI) to be constructed on owner’s share of land as per ASR of the year of approval
shall be paid to MCGM.
j) Requirement of ROS as per Regulation No 27 may be kept at 8% on area of other
development & in respect of plot of AH
5. Interchanging the location:
The Appropriate Authority may interchange the location of land earmarked as Affordable
Housing (AH) + Public Open Space (POS) + Institutional Area(IA) in DP with equivalent
developable land area under their ownership either in contiguity or in parcels of land not less
than 2 ha.
Special Development Zone (SDZ):- Special Development Zone (SDZ) is a zone which
is to be developed predominantly for society at large with emphasis on Social
Affordable Housing, POS and necessary Social infrastructures. The said zone is
further subdivided into Special Development Zone-I (SDZ-I) and Special
Development Zone-II (SDZ-II). The development of SDZ shall be under the provision
of regulation 33(8)
Provided that the structures attracting the provisions of Maharashtra Slums Areas
(Improvement, Clearance and Redevelopment) Act, 1971 shall be developed under the
provision of Regulation 33(10)
1.Special Development Zone-I (SDZ-I): SDZ-I is a zone occupied by protected
occupants as defined in Chapter IB of Maharashtra Slums Areas (Improvement, Clearance
and Redevelopment) Act, 1971. Development of SDZ-I is governed by the Regulation
No 33(10) and 17(3) (C) (c). The structures even if are situated within the physical
boundary of SDZ-I, but not attracting the provisions of Maharashtra Slums Areas
(Improvement, Clearance and Redevelopment) Act, 1971, will be deemed to be situated in
SDZ II.
2. Special Development Zone-II (SDZ-II): SDZ-II is a zone not covered in SDZ-I but
wherein development is predominantly for society at large with emphasis on Social
Housing, POS and necessary Social infrastructures plots of which may be vacant,
occupied by authorized structures and structures occupied by occupants not covered
under Chapter IB of Maharashtra Slums Areas (Improvement, Clearance and
Redevelopment) Act, 1971. Development in SDZ-II for the Social Housing shall be
governed by Regulation No 33(8) and other development will be governed by
following:-
(EP-126)
(C) (A) Other Development in NDZ SDZ II:
The following uses are also permissible provided, however, no services of any kind
or Limited/available services will be provided by the Corporation. No subdivision of
the land creating size of plot less than 4 1 2.0 ha or less shall be permissible.
(EP-127)
(I) Institutional Development
Institutional Development such as Higher & Other educational Institutions, Medical
Institutions, Urban Planning Institutions, Financial Institutions & Other Institutions
such as Research & Development Institutions shall be permitted subject to the
following conditions:
a. Maximum FSI limit shall be 0.20 (excluding area of DP road). As far as possible,
the development shall be at one place of the total land.
b. Ground coverage shall not exceed 10% of the area of plot.
c. Indigenous tree plantation shall be done at the rate of 500 trees/ha on the
remaining land excluding the BUA and the surrounding open space/utility space.
d. Essential residential development for the staff/officer's accommodation shall be
permitted up to the extent of 33% of the permissible BUA.
(II) Development of Cinema and TV Film production,
Development of Cinema and film production, shooting, editing and recording
studios with its ancillary and supporting uses, including Film School with their
shooting stages and screening rooms, Performing Art Academy, Students Hostels
and faculty residences, Auditoria, Art Gallery, Museums, Preview Theatres,
construction of staff quarters, rest rooms, canteens etc. shall be allowed subject to
the following conditions:
a) The total permissible FSI shall not exceed 0.2 (excluding area of DP road).
b) Out of the permissible BUA equivalent to 0.2 FSI; BUA of supporting uses shall
not exceed 1/3 of permissible FSI 0.2.
c) The construction shall be confined to 10% of the plot and the remaining plot
(excluding areas required for parking, roads etc.) shall be planted with indigenous
trees at the rate of at least 500 trees per ha.
(III) Information Technology & Information Technology Enabled Services (IT/ITES) &
Biotech units
IT/ITES Parks/Units or, set up by public or private sector; shall be
permissible with the special permission of Commissioner, subject to following
conditions:
A) Total FSI shall not exceed 0.20 (excluding area of DP road).
B) Construction of buildings for IT/ITES shall be permitted to the extent of 20% on
10% of the total plot area and shall be located such that, as much of remaining
open space is available in a contiguous manner and on remaining 90% of plot area,
indigenous trees shall be planted at the rate of at least 500 trees per ha.
C) The permission from the Director of Industries to set up IT/ITES Parks/Units shall
be necessary.
(IV) Tourism Development Area (TDA)
Sites or plots identified by the Tourism Department of GoM. in consultation with the
MTDC, and as specified by GoM from time to time as suitable for promotion of
tourism to serve as holiday or beach resorts, hotels or motels may be included in a
Tourism Development Area (TDA), and allowed to be developed for activities like
beach resorts, hotels, motels, restaurants, health farms, water sports facilities, arts
and crafts complexes, golf courses, gliding, powered gliding, grass skiing facilities,
marinas, jetties and pontoons for docking of boats and swimming pools.
If such specified sites are situated in the NDZ SDZ II, they shall be permitted to be
developed for the aforesaid purposes with a FSI 0.20 0.50(excluding area of DP road)
notwithstanding anything contained in these Regulations, additional FSI in such Zone
shall not be admissible.
(EP-128)
Note- If such sites are situated in zone other than NDZ SDZ II and Natural Area, the
FSI permissible shall be that corresponding to the FSI permissible in the respective
zones as stipulated in Table 12 of Regulation No.30(1)(A).
Guidelines for identification of TDA and for development to be permitted therein
(1)General Conditions:
i) TDA can be developed by individual or Company or Partnership firm or
Govt/Semi-Govt. organization/ corporations.
ii) These guidelines shall be applicable for TDA, as set out herein below.
iii) Proposals for lands to be specified as TDA shall be approved by UD department,
GOM and shall not be permissible on plot Reserved/Designated for Play
Ground/Park/Garden/Any other POS reservation
TOURISM DEVELOPMENT AREA COMMITTEE
Proposals for lands to be specified as Tourism Development Area shall be
recommended for consideration of Government in Urban Development Department
by a Committee consisting of:
1 Secretary, Tourism Development Chairman
Department Mantralaya
2 Metropolitan Commissioner MMRDA Member
3 Municipal Commissioner,Municipal Member
Corporation of Greater Mumbai
4 Dy. Director of Town Planning, Greater Member
Mumbai
5 Representative of Hotel Industries, Member
Mumbai
6 Environmentalist Member
7 Architect, having 20 years experience in Member.
architectural practice.
This Committee may be called “Tourism Development Area Committee” (TDAC).
The persons at 5, 6 & 7 of the Committee may be nominated by Secretary, Tourism
Department and the tenure of these members shall change after every 3 years,
provided that the same person shall be eligible for reappointment as a Member.
(2) SIZE OF PLOT AND FSI
Maximum area permissible as TDA out of a holding in SDZ-II shall be as follows:-
Special Development Zone- II
Total SDZ-II Holding Maximum TDA area Maximum FSI Permissible
permissible (fixed) (in ha.)
More than 2 but less 40% 0.5 FSI over the TDA area
than 5 Ha subject to premium of 10% of
Equal to or more than 50% A.S.R. over and above the
5 Ha but less than 6 Ha Zonal (basic) F.S.I. i.e.0.025
6 - 7 Ha 60% for SDZ-II, out of the amount
7 - 8 Ha 70% of premium 50% is payable to
8 - 9 Ha 80% State Government and 50%
9 10 Ha 90% payable to MCGM
Equal to or more than 100%
10 Ha
Explanation:
1. After deducting the area of TDA, FSI will be available for the rest of the land in
SDZ- II, as provided for the area in SDZ-II as per clause (VI) (xii).
2. In case of plots having area more than 2 ha in SDZ-II, no subdivision of plots shall
be permitted.
(EP-129)
(a) Smaller Plots:
For existing landholders having smaller plots in NDZ SDZ II, the provisions of
promotion of Tourism through bed-and-breakfast type arrangements for tourists
shall be permissible, approved by the Govt. in Urban Development Department.
These shall have the same FSI as per B (A)(VI) of this regulation.
(b) Prohibition for Inclusion in Tourism Development Land falling in categories
specified below shall not be permissible for TDA:
i Lands affected beyond permissible levels by pollution in land, water and air, as
may be decided and certified by the MPCB.
ii Lands covered by mangroves.
iii Areas from NDZ SDZ II directly abutting the Residential Zone without being
separated by road having width not less than 18.30 m.
(c) Infrastructural Facilities:
All the infrastructural facilities required on site and as specified by the MCGM shall
be provided by the developer at his own cost on the site. Proper arrangement for
treatment and disposal of sewage and sullage and solid wastes shall be made to the
satisfaction of the MCGM and MPCB. No untreated effluent shall be allowed to pass
into the sea or any water body.
(d) Reserved Sites for Tourism Development:
Where the lands are located in a unique/unusual area, particularly suitable for
development of tourism in view of an existing water body, scenic beauty, tree
plantations or geological formation can be specified as TDA. The minimum area of
such site however shall not be less than 1.00 ha. The floor space index available for
development in such a site will be 0.20.
(e) Environment:
Places where rare species of migratory birds are known to visit and where there is a
heritage of flora and fauna shall be given preference for development as TDA. Efforts
should be made for creating environmental awareness among the local population
and especially among the school-going children in nearby area.
(f)The projects identified as Mega Tourism Projects by Tourism and Cultural Affairs
Department of the State Govt. under the Tourism Policy of Maharashtra- 2006” shall
be governed by the following special provisions :-
Mega Tourism Projects:-
1) The ground coverage shall be 1/2 of the gross plot area.
2) The uses which are not covered under this Regulation like studio and Film School
with their shooting stages and screening rooms, performing Arts Academy, Students
Hostels and faculty residences, Auditoria, Art Gallery, Museums, Multiplex, Food &
Beverage areas and also a combination of compatible uses may be allowed, with the
approval of the Urban Development Department of GOM.
3) The height up to 70m may be allowed for Building of Film Studio, subject to the
provisions of Regulation 43.
4) The height of a room in occupancy mentioned at Sr. No.1(e) (ii) of Table 15 of
Regulation 37, may be permitted for Studio, Museum, Screening Rooms, Multiplex
and Auditoria.
5) The 20% fungible Compensatory Floor Space Index may be allowed, subject to the
provisions of Regulation 31(3).
Note: - The development in the Eco Sensitive Zone and Coastal Regulation Zone shall
be governed and regulated as per MoEF's Notification in this regard and Circulars
issued from time to time.
(EP-130)
(V) Amusement park:
Amusement park in a plot of not less than 4 ha. in area, with recreational and
amusement devices like a giant wheel, roller coaster, merry-go-round or similar
rides, ocean -park, swimming pool, magic mountain and lake, ethnic village, shops
for souvenirs, toys, goods, refreshments and beverages shall be permissible with the
special permission of commissioner. The Permissible FSI shall not Exceed 0.025
(excluding area of DP road)
a) The entire land for the amusement park shall vest in a single ownership and the
land shall not be sub-divided at any time.
b) The required infrastructure, like proper and adequate access to the park, water
supply, sanitation, conservancy services, sewage disposal and adequate off-street
parking will have to be provided and maintained by the promoters of the project at
their cost and to the satisfaction of the Commissioner.
c) The promoters of the project shall provide adequate facilities for collection and
disposal of garbage at their cost, and to the satisfaction of the Commissioner and
will keep, at all times, the entire environment clean, neat and hygienic.
d) Structures for ancillary activities, such as administrative offices, exhibition hall or
auditorium, restaurant, open air theatre, essential staff quarters, store buildings,
fast food shops, museum, souvenir and small shops, ancillary structures to
swimming pool, may be permitted
e) Structures permitted in the amusement park (except those intended for park
apparatus, entertainment such as magic mountain etc. and other equipment) should
be ground floor structures, with the construction blending with the surrounding
environment and landscape.
f) Except for minor dressing, hills and natural features, if any, shall be maintained
in their natural condition and beautified with planting of trees etc.
g) All trees already growing on the land shall be preserved to the extent possible,
except that if it becomes necessary to cut any tree, the required permission of the
Competent Authority should be obtained under the law. At least 5 indigenous trees
per 100 sq. m shall be planted and grown within the area of the park.
h) Structures, buildings or monuments of historical, aesthetical, architectural, or
heritage importance, if any, shall be preserved and maintained properly.
i) Sufficient parking facilities and ancillary facilities for cars, buses, transport
vehicles etc. shall be provided on site as prescribed by and to the satisfaction of the
Commissioner and Commissioner of Police.
j) The promoters of the project will prepare a suitable layout with appropriate
land-scaping of the recreational and other facilities and obtain approval of the
Commissioner.
k) No objection certificate of the Tourism Department shall be obtained.
l) The development shall be regulated according to other requirements of these
Regulations and subject to all other clearances as may be required.
m) Proper arrangements for safety, regulations of traffic approaches to the park
etc. shall be made to the satisfaction of the Commissioner of Police from the law
and order and traffic aspects.
(VI) Miscellaneous Uses:
The following uses shall be permissible where the permissible where FSI shall not
exceed 0.025 (excluding area of DP road)
(i) Agriculture, horticulture and animal husbandry (except for keeping animals on
a commercial scale), subject to a limit of 10 head of cattle per acre and providing
necessary buildings, garages, pig sties, stables and storage buildings
(ii) Gardens and poultry farms;
(iii.) Forestry;
(iv.) Golf clubs and links;
(v.) Public parks, private parks, play fields, stadia, gymkhanas, swimming pools,
gliding facilities, temporary camps for recreation of all types.
(vi.) Race tracks and shooting ranges.
(vii.) Fish curing on open land/fish farming.
(viii.) Salt manufacture from sea water.
(ix.) Public utility establishments such as electric sub-stations, receiving stations,
switch yards, over-head line corridors, radio and television stations, receiving
stations, main stations for public gas distribution, sewage treatment and disposal
works, Storm Water Drain Pumping Station, facilities for the disposal of Solid Waste,
water works along with residential quarters for essential staff for such works, with
the special permission of the Commissioner.
(x.) Cemeteries and crematoria and structures incidental thereto.
(xi.) Structure for watchmen's quarters each not exceeding 20 sq. m numbers of
such structures in each plot to be decided by the Commissioner
(xii.) A residential building, not more than ground and one story with a height not
exceeding 9.75 m including the height of stilted portion.
(VII) Periphery of Vihar and Pawai lake:
In order to prevent erosion of soil and silting in lakes, an exclusive green belt of
100 m shall be provided around the periphery of Vihar and Pawai Lake, in which no
construction whatsoever shall be allowed. If within 100 m from the periphery of
Vihar and Pawai lake there exists Municipal/Public Road, then buffer of green belt
beyond Municipal/Public Road may not be insisted.
(EP-131)
3.5 Port’s Operational Zone (POZ)(To be kept in abeyance)
1. General
The provisions shall apply to the development of port and port related activities
proposed in the land belonging to Mumbai Port Trust (MbPT) specifically
earmarked on the DP by a verge as Port’s Operational Zone. Approval to any
development/redevelopment in this Zone shall be granted only after Master
Layout Plan incorporating all reservations/designations listed in note below is
approved from MCGM.
Permissible Activities
The following activities are permissible in this zone
a) Development of port and port related activities with prior approval of the
MoEF, GOI.
b) Storage related activities such as Godowns, Cargo Yards, Container Yards,
Logistic Parks etc. those are necessary for import/export of goods.
c) Transport related activities such as Railway Goods Yard, Truck Terminus,
Surface and Multi-level Parking lots, Public Transport Terminals etc.
d) Water Transport and related activities, Operational Offices, Restaurants and
Hotels, Rest Houses and other related amenities and utilities.
e) Land Uses permissible in Industrial Zone as per Table C of Regulation No. 34
(3).
f) Any other related activity with the approval of the Ministry of Shipping and
Transport, GOI.
g) Retention of Activities existing in the zone.
2. Manner of Development
a) Any development undertaken by the Mumbai Port Trust shall be governed by
these Regulations.
b) Any slum notified and eligible under Slum Rehabilitation Scheme for
redevelopment shall be undertaken by the MbPT for its redevelopment,
either in this zone or in Port’s Water Front Development Zone.
c) Redevelopment/Retention of any existing use undertaken by
Government/Semi-Government organization, MHADA, MCGM shall be
permitted as per these Regulations.
d) Designations listed below in table shall be maintained as per these
Regulations during redevelopment.
e) Reservations or roads if any shall be implemented as per these Regulations.
f) Relocation of designations/Reservations as per these Regulations shall be
permitted either in this zone or in Port’s Water Front Development Zone.
g) Regulation Nos 14 and 15 shall not be applicable to the development or
Redevelopment in the Port’s Operational Zone.
h) The Mumbai Port Trust shall have an option to continue with the existing
‘Industrial Activities’ in ‘Port’s Operational Zone’ and shall have liberty to
relocate the same within the Zone or to convert into activities conforming to
the zone.
3. Floor Space Index
The FSI permissible shall be 1.33 subject to other restrictions as per these
Regulations.
3.6 Port’s Water Front Development Zone (PWFDZ) (kept in abeyance)
1. General
The provisions shall apply to the Port’s Water Front Development Zone and its related
activities proposed in the land belonging to Mumbai Port Trust (MbPT) specifically
earmarked on the DP by verge as Port’s Water Front Development Zone. Approval to
any development/redevelopment in this Zone shall be granted only after Master
Layout Plan incorporating all reservations/designations listed in note below is
approved from MCGM.
2. Approval
The Mumbai port trust shall prepare detail Master Plan of its area showing different
land use sectors with basic infrastructure and social amenities in accordance with
these Regulations and get approval of the Commissioner. The Mumbai port Trust shall
however be entitled to modify such layout subject to his approval.
Permissible Activities
The following activities are permissible in this zone
a) Any Water Front Development and related activities subject to approval of the
MoEF, GOI wherever necessary.
b) Water Transport and related activities, Marina along with commercial
activities.
c) Operational Offices, Restaurants and Hotels, Rest Houses and other related
amenities and utilities.
d) Aquariums, Seaquariums, Maritime Museums, Naval Museums.
e) Water Sports, Scuba diving facilities, Marine Parks and related Recreational
activities.
f) International Tourists facilities and amenities.
g) Cruise and Boating facilities
h) Land Uses permissible in Industrial Zone as per Table C of Regulation No. 34
(3).
i) Any other related activity with the approval of the Ministry of Shipping and
Transport, GOI.
j) Retention of Activities existing in the zone.
k) Any other activity related to water front development.
l) Public Transport facilities, surface and multilevel Parking facilities.
m) Any slum notified and eligible under Slum Rehabilitation Scheme for
redevelopment shall be permitted by the MbPT for its redevelopment.
n) Redevelopment/Retention of any existing use undertaken by
Government/Semi-Government organization, MHADA, MCGM shall be
permitted as per these Regulations.
o) Any designation listed below shall be maintained as per these Regulations
during redevelopment.
p) Reservations or roads listed below shall be implemented as per these
Regulations.
q) Relocation of Designations/Reservations as per these Regulations shall be
permitted only with the prior consent of the Appropriate Authority.
r) Regulation Nos 14 and 15 shall not be applicable to the development or
Redevelopment in the Port land.
s) The Mumbai Port Trust shall have an option to continue with the existing Industrial
Activities in the Port’s Water Front Development Zone and shall have liberty to relocate
the same within the Zone or to convert into activities conforming to the zone.
t) The MbPT shall provide separate area to the extent as per directives of the State Govt.
for Social Housing subject to these Regulations.
3. The permissible FSI
The FSI shall be permissible in accordance with provisions laid down in relevant
sections of Development Control & Promotion Regulations-2034.
Note: - The reservations/designations listed below in Port’s Operational Zone (POZ)
and in Port’s Water Front Development Zone (PWFDZ) shall be developed as per the
provisions of these Regulations.
Port’s Operational Zone (POZ)
Port Operational Zone 1 Designation
Sheet
Designation Code Designation Name Plot Area (sq. m) Plot Area (Ha)
Ward no
Government staff
A IC 11 DR1.3 2273.13 0.23
Quarters
A IC 11 DO2.1 Government office 5217.92 0.52
Fire Station/ Command
B IC 14 DPU1.1 1582.82 0.16
Centre
Port Operational Zone 1 Total Area(Designation) 9073.87 0.91
Port Operational Zone 2 Designation
Sheet
Designation Code Designation Name Plot Area (sq. m) Plot Area (Ha)
Ward no
F/S IC 24 DPU2.1 Fuel station 1920.11 0.19
Port Operational Zone 2 Total Area (Designation) 1920.11 0.19
Mazagaon Port Operational Zone Designation
Sheet Plot Area
Designation Code Designation Name
Ward no Plot Area (sq. m) (Ha)
E IC 14 DE1.1 Municipal School 605.13 0.06
Electric Transmission &
0.20
E IC 17 DPU5.2 Distribution Facilities 2005.68
E IC 17 DPU3.2 Police Chawky 36.75 0.0037
E IC 14 DPU4.1 Post & Telegraph 103.58 0.01
Municipal Retail Market +
Municipal School + 3320.14 0.33
E IC 17 DSA1.1+DE1.1+DR1.1 Municipal Staff Quarters
Mazagaon Port Operational Zone Total Area 6071.28 0.61
Port’s Water Front Development Zone (PWFDZ)
Port's Waterfront Development Zone Designation
Plot Area
Designation Code Designation Name
Ward Sheet no (Ha)
B IC 14 DMS3.1 Solid waste Management Facilities 0.02
B IC 14 DPU2.1 Fuel station 0.12
Municipal Dispensary/ Health Post
0.06
E IC 14 DH1.1 (2nos)
E IC 17 DH1.2 Municipal Hospital 0.12
E IC 14,17 DMS4.3 sewage Pumping station (2nos) 0.19
E IC 14 DO2.1 Government Office (5nos.) 0.83
E IC 19 DPU2.1 Fuel station (5nos.) 0.36
E IC 17 DPU3.1 Police station 0.14
E IC 17 DPU3.2 Police chowky (2nos) 0.15
E IC 17 DPU4.1 Post & Telegraph 0.04
E IC 14,17 DR1.3 Government staff Quarters (2nos.) 1.85
E IC 17 DR1.4 BEST Staff Quarters 0.04
E IC 17 DR1.5 Municipal Housing 0.64
E IC 17 DSA3.2 Cinema Theatre 0.11
E IC 17 DT4.1 Railway station 0.65
E IC 17, 19 DT4.3 Railway Yard/ Track (3nos.) 5.86
F/S IC 19 DMS5.1 Reservoir 0.19
F/S IC 19 DO2.1 Government Office (2nos.) 0.63
F/S IC 19 DOS2.6 Recreation Ground 1.22
F/S IC 19 DPU1.1 Fire Station/ Command centre 0.36
F/S IC 19 DPU2.1 Fuel station (3nos.) 0.31
F/S IC 19 DPU3.1+DR1.2 Police station + Police staff Quarters 0.52
F/S IC 21 DPU3.2 Police chowky 0.06
F/S IC 19 DR1.2 Police staff Quarters 0.26
F/S IC 19 DR1.3 Government staff Quarters (3nos.) 1.76
F/S IC 19 DT4.1 Railway station 0.38
F/S IC 19 DT4.3 Railway Yard/ Track (2nos.) 5.78
Port's Waterfront Development Zone Total Area (Designation) 22.65
Port's Waterfront Development Zone Reservation
Ward Sheet no Reservation Code Reservation Name Area (HA)
E IC 17 RE1.1 Municipal School 0.15
E IC 17 RH1.2 Hospital 2.95
E IC 19 RMS3.1 Solid Waste Management Facilities
5.02
(3nos)
E IC 17 RMS6.1 Storm Water Pumping station 0.26
E IC 17 ROS1.4 Play Ground (2nos.) 0.96
E IC 17,19 ROS1.5 Garden/ Park (12 nos) 9.80
E IC 17 RPU2.1 Fuel Station 0.09
E IC 17 RPU3.4 Police Facilities 1.14
E IC 17 RPU6.1 Service Industrial Estate (2nos.) 0.53
E IC 17 RR2.2 Social Housing (4nos.) 8.80
E IC 17 RSA2.1 Multipurpose community centre 0.52
Adhar Kendra with Skill
0.50
E IC 17 RSA6.2 Development Centre
E IC 17 RT1.4 BEST Bus Facilities 1.91
F/S IC 19 RE1.1 Municipal School 1.05
F/S IC 19 RE4.4 Other Institute 3.87
F/S IC 19 RMS1.3 Municipal Facilities 0.24
Solid waste Management Facilities
RMS3.1 2.42
F/S IC 19 (3 nos.)
F/S IC 19 ROS1.4 Play Ground 0.92
F/S IC 19 ROS1.5 Garden/ Park (15 nos) 16.85
F/S IC 19 RPU1.1 Fire Station 0.31
Electricity Transmission &
RPU5.2 0.11
F/S IC 19 Distribution facilities
F/S IC 19 RR2.2 Social Housing 51.55
Municipal market with Vending
RSA1.1 0.34
F/S IC 19 zone
F/S IC 19 RSA2.9 Homeless Shelter 0.13
Cultural center/ Drama Theater/
RSA3.3 0.45
F/S IC 19 Theatre
F/S IC 19 RSA3.5 Museum 0.67
F/S IC 19 RSA7.1 Film/ TV studio 1.05
F/S IC 21 RT1.6 Panking lot 0.25
Port's Waterfront Development Zone Total Area (Reservation) 112.85
3.57 Natural Areas (N A)
It is an environmentally sensitive zone amenable to buildable development with
the approval of the Competent Authority where following facilities may be
permissible
a) Board walks in mangroves, trekking facilities, Public Sanitary Conveniences for
visitors, Sewerage Pumping Station.
b) Uses permissible as per the notifications issued by the Ministry of Environment
and Forest, if any, as amended from time to time.
Note: - 1. Structures constructed in NA, with due sanction of Competent Authority,
before coming into force of these regulations stand protected.
2. Reservation proposed in Natural Area shall be allowed to be developed at par
with other zones subject to approval of the Competent Authority and subject to
compliance of conditions as mentioned in the notifications issued by the Ministry of
Environment and Forest, if any, as amended from time to time.
(EP-132)
3.8 Green Zone (GZ)
It is a large area predominantly with green cover where following facilities may
be permissible
a) Construction of Zoo with FSI of 0.025;
b) Uses approved by GoM. with permission from the Ministry of Environment and
Forest;
c) Rehabilitation and Resettlement of the original inhabitants of the forest
(adiwasis, tribals of Sanjay Gandhi National Park) as per the provisions of
Regulation No.30 with Zonal (basic) FSI.
Note: - 1. Structures constructed in GZ, with due sanction of Competent Authority,
before coming into force of these regulations stand protected.
2. Reservation proposed in Green Zone if any shall be allowed to be developed at
par with other zones subject to approval of the Competent Authority and subject to
compliance of conditions as mentioned in the notifications issued by the Ministry of
Environment and Forest, if any, as amended from time to time.
(EP-133)
35. Development or redevelopment of lands of cotton textile mills (mills).-
1) The development or redevelopment of land of cotton textile mills, (hereafter referred to as
“mills”) shall be permissible with the special permission of the Commissioner. The proposal
for the development of land of mills shall be considered under any of the following three
categories:
(i) Development of Lands of sick and / or closed mills- With the previous approval of the
Commissioner to a layout prepared for development or redevelopment of the entire land of a
sick and/or closed mill and on such conditions specified by him and as a part of a package of
measures recommended by the Board of Industrial and Financial Reconstruction (BIFR) for
the revival/rehabilitation of a potentially viable sick and/or closed mill, the Commissioner
may allow development.
(ii) Lands of mills for purpose of modernization- With previous approval of the Commissioner
to a layout prepared for development or redevelopment of the entire land of a mill which is
not sick or closed, but requiring modernization on the same land as approved by the
competent authorities, such development or redevelopment shall be permitted by the
Commissioner, subject to the condition that it shall also be in accordance with scheme
approved by Government.
(iii) Lands of mills after shifting- If a cotton textile mill is to be shifted outside Greater
Mumbai but within the State, with due permission of the competent authorities, and in
accordance with a scheme approved by Government, this Regulation shall also apply in
regard to the development or redevelopment of its land after shifting.
2. The proposal of the above mentioned three categories shall be formulated according to the
provisions mentioned below;
(a) Areas earmarked for development by the owner/developer as per Column No 5 of the table
below to be utilized-
(i) For the same mill or related user subject to observance of all other Regulations;
(ii) For diversified industrial user in accordance with the industrial location policy, with
office space only ancillary to and required for such uses, subject to and observance of all
other Regulations;
(iii)For the residential and commercial user as permitted under these Regulations;
(b)The entire lands of the mills shall be apportioned in the manner as described in Table
below:
Sr. No Extent Percentage to Percentage to be Percentage to be earmarked
be earmarked earmarked and handed and to be developed for
for POS as over for development by residential or commercial use
specified by the MHADA for Public Housing (including uses permissible in
Commissioner / for mill worker's housing residential or commercial zone
as per guidelines as per these Regulations) or
approved by Government diversified Industrial uses as per
Industrial Location Policy, to be
developed by the owner
(5)
(2) (4)
(3)
(1)
Up to and
1 inclusive of 16.5 16.5 67
5 ha.
2 Above 5 ha. 18 18 64
Notes-
(i) In addition to the land to be earmarked for public open space, as in column (3) of the above
Table, open spaces, public amenities and utilities for the lands shown in columns (4) and (5) of
the above Table as otherwise required under the provision of Regulation No 27 shall also be
provided.
(ii) Segregating distance as required under these Regulations shall be provided within the
lands intended to be used for residential/commercial uses.
(iii)Notwithstanding anything contained in these Regulations, Development Rights/FSI in
respect of the lands earmarked and handed over as per column (3) and (4) shall be available to
the owner of the land for utilization in the land as per Column (5) or as TDR as aforesaid as per
Regulation No.32.
(iv) Where open land is not available, for the purposes of column (3) and (4) of the above
Table, land will be made open by demolishing the existing structures to the extent necessary
and made available accordingly.
(v)Where lands accruing as per Columns (3) & (4) are, in the opinion of the Commissioner, of
such small sizes that they do not admit of separate specific uses provided for in the said
columns, he may earmark the said lands for use as provided in Column (3); allow POS for any
mills received as MCGM’s share of mill land as per column no. (3), to be earmarked for
MHADA in exchange of such plots, for using as per column no. (4),
(vi) It shall be permissible for the owners of the land to submit a composite scheme for the
development or redevelopment of lands of different mills, under common ownership, upon
which lands comprised in the scheme shall be considered by the Commissioner in an
integrated manner. The land to be handed over as per column no (3) and (4) shall be
preferably handed over in the respective land of mills. Provided further that where owner
intends to hand over the share of land as per column no (3) and (4) at other mill within the
integrated scheme having different stamp duty ready reckoner rate then area to be handed
over shall be in proportion to the stamp duty ready reckoner rate of these lands of mills.
(vii)Notwithstanding anything above, the lands earmarked for MHADA & POS as per the
approved layout shall be handed over to the concerned Authority immediately after the
approval of layout and such period of handing over shall not be more than six months.
(viii) Land of the mill to be considered for the apportionment as stipulated in above Table shall
be exclusive of notional plot area as per the Zonal (basic) FSI of the existing residential
buildings/chawls to be developed as per sub Regulation no 3 below.
(ix) If the developer proposes to utilize 20% of the total floor area on owner’s share of land as
per column no 5 of the above table for residential development, with each tenement having
BUA up to 50 sq. m the provision of Regulation No 15 shall not be applicable.
(3) For reconstruction/redevelopment to be undertaken by landlord/or Co-op. Housing society
of occupiers in respect of residential buildings/chawls located on the lands of mills, the
following shall apply:
i)if and when the BUA of a mill occupied for residential purposes as on the 1st of January, 2000
is developed or redeveloped, it shall be obligatory on the part of the land owner to provide to
the occupants in lieu of each tenement covered by the development or redevelopment
scheme, free of cost, an alternative tenement of the size of carpet area. Provided that no such
occupants shall be evicted till such time, he/she is provided with alternative accommodation
of 27.88 sq. m carpet area in such development or redevelopment scheme.
ii) In case of redevelopment of buildings occupying part of larger holding, the notional area of
plot on the basis of Zonal (basic) FSI and the total BUA of the building shall be computed and
thereafter considering such notional area of the plot, FSI of 4.0 shall be allowed.
The FSI computation of 4.0 shall be as follows:
Rehab area shall be the total BUA required for rehabilitation of all the occupants of residential
buildings/chawls with the carpet area of 27.88 sq. m. each. In case of authorized non-
residential occupier existing on 1st January, 2000 the area to be given in the reconstructed
building will be equivalent to the area occupied in the old building.
Difference between FSI 4.0 and FSI used for rehabilitation of existing occupants shall be shared
as follows:
a) Available difference shall be divided into two parts in a ratio of 1: 0.40
b) Out of these two parts, 1.00 shall be constructed by the mill owners in the form of
additional tenements having 27.88 sq. m carpet area each and shall be handed over to
MHADA/Government and to be used for rehabilitation of mill workers.
c) The mill owners shall be entitled for FSI of above 0.4 part as stated in (a) in lieu of
construction done and handed over to MHADA/Government.
d) Construction for rehabilitation of all the occupants of residential buildings/chawls shall be
done by mill owner. No incentive FSI against such construction shall be given to landlord/or
Co-op. Housing society of occupiers
iii) All the occupants of the old building shall be re-accommodated in the redeveloped
building.
Iv) In case of cessed building, the list of occupants and area occupied by each of them shall be
certified by Mumbai Repairs and Reconstruction Board. For non cessed buildings, it shall be
certified by MCGM.
v) In case of dispute, the matter shall be referred to the Monitoring Committee whose
decision shall be binding on all parties.
vi) An amount of Rs 50,000 per tenement has to be deposited by developer as a corpus fund
with the society of the occupants at the time of completion of construction, for maintenance
of the buildings.
vii) Notwithstanding anything contained in these Regulations, the relaxations incorporated in
Regulation No. 33(7) of these regulations and amended from time to time, shall apply.
(a) if and when a mill is shifted or the mill owner establishes a diversified industry, he shall
offer on priority in the relocated mill or the diversified industry, as the case may be,
employment to the worker or at least one member of the family of the worker in the employ
of the mill on the 1st January 2000 who possesses the requisite qualifications or skills for the
job;
(b) for purposes of clause (a) above, the mill owner shall undertake and complete training of
candidates for employment before recruitment of personnel/starting of the relocated
mill/diversified industry takes place.
(c) Notwithstanding anything contained above, if and when a mill is taken up for development
/redevelopment for any industrial/commercial purpose, the mill owner/developer/occupier of
the premises shall on priority provide employment to the workers or at least one member of
the family of the worker in the employ of the mill on the 1st January, 2000 who possesses the
requisite qualifications or skills for the job.
4 (a) Funds accruing to a sick and/or closed mill or such mill requiring modernization or is to be
shifted, from the utilisation of BUA as per clause (a) of Sub-Regulations (2) and from the sale
of TDR in respect of the land as per columns (3) & (4) of the Table contained in clause (a) of
Sub-Regulations (2) or from the development by the owner of the land as per column (5),
together with FSI on account of the land as per column(3)&(4), shall be credited to an escrow
account to be operated as hereinafter provided.
(b) The funds credited to the escrow account shall be utilised only for the revival /
rehabilitation or modernisation or shifting of the mill, as the case may be, provided that the
said funds may also be utilised for payment of workers’ dues, payments under Voluntary
Retirement Schemes (VRS), repayment of loans of banks and financial institutions taken for
the revival/rehabilitation or modernisation of the mill or for its shifting outside Greater
Mumbai but within the State.
5.(a) In order to oversee the due implementation of the package of measures recommended
by BIFR for the revival/rehabilitation of a potentially sick and/or closed textile mill, or schemes
approved by Government for the modernisation or shifting of mills, and the permissions for
development or redevelopment of lands of mills granted by the Commissioner under this
Regulation, the Government shall appoint a Monitoring Committee under the chairmanship of
a retired High Court Judge with one representative each of the mill owners, recognised trade
union of mill workers, the Commissioner and the Government as members.
(b) The Commissioner shall provide to the Monitoring Committee the services of a Secretary
and other required staff and also necessary facilities for its functioning.
(c) Without prejudice to the generality of the functions provided for in clause (a) of this Sub-
Regulation, the Monitoring Committee shall: --
(i) lay down guidelines for the transparent disposal by sale or otherwise of built up space,
open lands and balance FSI by the mills;
(ii) lay down guidelines for the opening, operation and closure of escrow accounts;
(iii) approve proposals for the withdrawal and application of funds from the escrow
accounts;
(iv) monitor the implementation of the provisions of this regulation as regards housing,
alternative employment and related training of mill workers.
(d)The Monitoring Committee shall have the powers of issuing and enforcing notices and
attendance in the manner of a Civil Court.
(e)Every direction or decision of the Monitoring Committee shall be final and conclusive and
binding on all concerned.
(f)The Monitoring Committee shall determine for itself the procedures and modalities of its
functioning
6.Notwithstanding anything stated or omitted to be stated in these Regulations, the
development or redevelopment of all lands in Greater Mumbai owned or held by all mills,
irrespective of the operational or other status of the said mills or of the land use zoning
relating to the said lands or of the actual use for the time being of the said lands or of any
other factor, circumstance or consideration whatsoever shall be regulated by the provisions of
this Regulation and not under any other Regulation.
However, the lands reserved for public purposes which is owned or held by Mills, shall not
be regulated by the provisions of these Regulations and reserved lands shall be handed over
to MCGM or the Appropriate Authority in lieu of FSI/TDR or shall be developed as per the
provisions laid down under Regulation No 17.
7 The provisions of sub Regulation no 2(b) of this Regulation shall not be applicable where the
share of MHADA and MCGM land has already been handed over as per then prevailing
Regulations.
(1) Lands of sick and/or closed cotton textile mills:- With the previous approval of the
Commissioner to a layout prepared for development or redevelopment of the entire open land
and built-up area of a sick and/or closed cotton textile mill and on such conditions deemed
appropriate and specified by him and as a part of a package of measures recommended by the
Board of Industrial and Financial Reconstruction (BIFR) for the revival/rehabilitation of a
potentially viable sick and/or closed mill, the Commissioner may allow:-
(a) The existing built-up areas to be utilised-
(i) For the same cotton textile or related uses subject to observance of all other Regulations;
(ii) For diversified industrial uses in accordance with the industrial location policy, with office
space only ancillary to and required for such uses, subject to and observance of all other
Regulations;
(iii) For commercial purposes, as permitted under these Regulations;
(b) Open lands and balance FSI shall be used as in the Table below:-
Serial Extent Percentage to Percentage to be Percentage to be
be earmarked earmarked and earmarked and to be
No.
for Garden/ handed over for developed for residential
Playground or development by or commercial use
any other POS MHADA for Public (including uses
as specified by Housing/for mill permissible in residential
the worker's housing or commercial zone as
Commissioner as per guidelines per these Regulations) or
approved by diversified Industrial uses
Government, to as per Industrial Location
be shared equally Policy, to be developed
by the owner
1 2 3 4 5
1 Up to and 33 27 40
inclusive of 5
Ha.
2 Between 5Ha 33 34 33
and up to 10
Ha.
3 Over 10 Ha. 33 37 30
Serial Extent Percentage to Percentage to be Percentage to be
be earmarked earmarked and earmarked and to be
No.
for Garden/ handed over for developed for residential
Playground or development by or commercial use
any other POS MHADA for Public (including uses
as specified by Housing/for mill permissible in residential
the worker's housing or commercial zone as
Commissioner as per guidelines per these Regulations) or
approved by diversified Industrial uses
Government, to as per Industrial Location
be shared equally Policy, to be developed
by the owner
1 2 3 4 5
1 No limit 33 33 34
(kept in abeyance)
Notes-
(i) In addition to the land to be earmarked for garden/playground or any other open use as in
column (3) of the above Table, open spaces, public amenities and utilities for the lands shown
in columns (4) and (5) of the above Table as otherwise required under these Regulations shall
also be provided.
(ii) Segregating distance as required under these Regulations shall be provided within the lands
intended to be used for residential/commercial uses.
(iii) The owner of the land will be entitled for the FSI as per the Regulation No 30(A) (1) and (4),
excluding area of notional plot of residential buildings/chawls located on the lands of Cotton
Textile Mills if any.
(iv) Where FSI is in balance but open land is not available, for the purposes of column (3) and
(4) of the above Table, land will be made open by demolishing the existing structures to the
extent necessary and made available accordingly.
(v) Where the lands accruing as per Columns (3) & (4) are, in the opinion of the Commissioner,
of such small sizes that they do not admit of separate specific uses provided for in the said
columns, he may, earmark the said lands for use as provided in Column (3); the commissioner
may allow any other POS Lands for any Mills received as Municipal Corporation of Greater
Mumbai's share of Mill land as per column no. (3), to be earmarked for MHADA in exchange of
such plots, for using as per column no. (4), special permission of Commissioner.
(v) It shall be permissible for the owners of the land to submit a composite scheme for
the development or redevelopment of lands of different cotton textile mills, whether under
different/common ownership or otherwise, upon which the lands comprised in the integrated
scheme shall be considered by the Commissioner in an integrated manner. The land to be
handed over as per column no (3) and (4) shall be preferably handed over in the respective
land of mills. Provided further that where owner intends to hand over the share of land as per
column no (3) and (4) at other mill within the integrated scheme having different stamp duty
ready reckoner rate then area to be handed over shall be in proportion to the stamp duty
ready reckoner rate of these lands of mills.
(vii) Notwithstanding anything above, the layout of mill land shall be submitted by the mill
owner within six months of closure of the mill or within six months from sanction of these
Regulations whichever is later and the lands earmarked for MHADA & POS shall be handed over
to the concerned Authority within six months after the approval of layout and such period of
handing over shall not be more than six months.
(2) Lands of cotton textile mills for purpose of modernization.- With previous approval of the
Commissioner to a layout prepared for development or redevelopment of the entire open land
and/or built-up area of the premises of a cotton textile mill which is not sick or closed, but
requiring modernization on the same land as approved by the competent authorities, such
development or redevelopment shall be permitted by the Commissioner, subject to the
condition that it shall also be in accordance with scheme approved by Government, provided
that, with regards to the utilization of built up area, the provisions of clause (a) of sub-
Regulation (1) of this Regulation shall apply.
(3) Lands of cotton textile mills after shifting--If a cotton textile mill is to be shifted outside
Greater Mumbai but within the State, with due permission of the competent authorities, and in
accordance with a scheme approved by Government, the provisions of sub-clauses (a) and (b)
of Sub-Regulation (1) of this Regulation shall also apply in regard to the development or
redevelopment of its land after shifting.
(4) The condition of recommendation by the Board of Industrial and Financial Reconstruction
(BIFR) shall not be mandatory in the case of the type referred to in sub-Regulations (2) and (3)
above.
(5) Notwithstanding anything contained above, the Commissioner may allow additional
development to the extent of the balance FSI on open lands or otherwise by the cotton textile
mill itself for the same cotton textile or related use.
(6) With the previous approval of the Commissioner to a layout prepared for development or
redevelopment of the entire open land and/or built up area of the premises of a cotton textile
mill which is either sick and/or closed or requiring modernization on the same land, the
Commissioner may allow:--
(a) Reconstruction after demolition of existing structures limited to the extent of the built up
area of the demolished structures, including by aggregating in one or more structures the built
up areas of the demolished structures;
(b) Multi-mills aggregation of the built-up areas of existing structures where an integrated
scheme for demolition and reconstruction of the existing structures of more than one mill,
whether under common ownership or otherwise, is duly submitted, provided that FSI is in
balance in the receiving mill land.
Multi-mills aggregation of the built-up areas of existing structures where an integrated scheme for
demolition and reconstruction of the existing structures of more than one mill, whether under common
ownership or otherwise, is duly submitted, provided that FSI is in balance in the receiving mill land.
Provided further that FSI on each individual plot of integrated scheme of mill land as per column no 5
of table of sub-regulation 1(b) above (excluding the area of notional plot of residential
buildings/chawls located on the lands of Cotton Textile Mills if any) shall not exceed 4.
(7) Notwithstanding anything contained above---
(a) if and when the built up areas of a cotton textile mill occupied for residential purposes as on
the 1st of January, 2000 developed or redeveloped, it shall be obligatory on the part of the land
owner to provide to the occupants in lieu of each tenement covered by the development or
redevelopment scheme, free of cost, an alternative tenement of the size of 27.88 sq. m (300 sq.
ft) carpet area; Provided that no such occupants shall be evicted till such time, he/she is
provided with alternative accommodation of the size 27.88 sq. m (300 sq. ft) carpet area in such
development or redevelopment scheme.
For reconstruction/redevelopment to be undertaken by landlord/or Co-op. Housing society of
occupiers in respect of residential buildings/chawls located on the lands of Cotton Textile Mills,
the following conditions shall apply.
i) In case of redevelopment of buildings occupying part of larger holding, the notional area of
plot on the basis of Zonal (basic) FSI and the total built up area of the building shall be
computed and thereafter considering such notional area of the plot, FSI of 4.0 shall be allowed.
ii) The FSI computation of 4.00 shall be as follows:
Rehab area shall be the total built up area required for rehabilitation of all the occupants of
residential buildings/chawls with the carpet area of 27.88 sq. m (300 405 sq. ft) each or
existing carpet area whichever is more. In case of authorized non-residential occupier existing
on 1st January, 2000 the area to be given in the reconstructed building will be equivalent to
the area occupied in the old building. Provided further that each eligible residential cum
commercial occupant shall be entitled to a tenement of minimum carpet area of 27.88 sq. m
((300 405 sq. ft.). Over and above BUA mentioned above, However, fungible compensatory
area as permissible as per Regulation No 31(3) on the rehab component shall not be allowed.
without charging premium.
Difference between FSI 4.00 and FSI used for rehabilitation of existing occupants shall be used
and shared as follow:
a) Available difference shall be divided into two parts in a ratio of 1:60.
b) Out of these two parts, 1.00 shall be constructed by the mill owners in the form of additional
tenements having 27.88 sq. m(300 sq. ft) carpet area each and shall be handed over to
MHADA/Government and to be used for rehabilitation of mill workers.
c) The mill owners shall be entitled for FSI of above 0.6 parts as stated in (a) in lieu of
construction done and handed over to MHADA/Government.
d) Construction for rehabilitation of all the occupants of residential buildings/chawls shall be
done by mill owner. No incentive FSI against such construction shall be shall be given to
landlord/or Co-op. Housing society of occupiers.
iii) All the occupant of the old building shall be re-accommodated in the redeveloped building.
iv) In case of the case building, the list of occupants and area occupied by each of them in the
old building shall be certified by MHADA and for other building it shall also be certified by
MHADA.
v) In case of dispute the matter shall be referred to the Monitoring Committee and the decision
of the committee shall be binding on all parties.
vi) An amount of Rs. 50.000/- per tenement have to be deposited by developer as a corpus fund
with the society of the occupants at the time of completion of construction, for maintenance of
the buildings.
vii) Notwithstanding anything contained in these Regulation, the relaxations incorporated in
clause 8 of regulation No. 33(7) of these regulations and amended from time to time, shall
apply.
(b) If and when a cotton textile mill is shifted or the mill owner establishes a diversified
industry, he shall offer on priority in the relocated mill or the diversified industry, as the case
may be, employment to the worker or at least one member of the family of the worker in the
employ of the mill on the 1st January 2000 who possesses the requisite qualifications or skills
for the job;
(c) For purposes of clause (b) above, the cotton textile mill owner shall undertake and complete
training of candidates for employment before the recruitment of personnel and starting of the
relocated mill or diversified industry takes place.
(d) Notwithstanding anything contained above, if and when a cotton textile mill is taken up for
development / redevelopment for any industrial/commercial purposes, the mill owner or the
developer or the occupier of the premises shall on priority provide employment to the worker
or at least one member of the family of the worker in the employ of the mill on the 1st January,
2000 who possesses the requisite qualifications or skills for the job.
(8)(a) Funds accruing to a sick and/or closed cotton textile mill or a cotton textile mill requiring
modernization or a cotton textile mill to be shifted, from the utilization of built up areas as per
this Regulation shall be credited to an escrow account to be operated as hereinafter provided.
(b) The funds credited to the escrow account shall be utilised only for the revival/
rehabilitation or modernization or shifting of the cotton textile mill, as the case may be,
provided that the said funds may also be utilised for payment of workers dues, payments
under Voluntary Retirement Schemes (VRS), repayment of loans of banks and financial
institutions taken for the revival/rehabilitation or modernization of the cotton textile mill or
for its shifting outside Greater Mumbai but within the State. The escrow account may be
closed after compliance of all the terms and conditions.
(9)(a) In order to oversee the due implementation of the package of measures recommended
by the Board of Industrial and Financial Reconstruction (BIFR) for the revival/rehabilitation of a
potentially sick and/or closed textile mill, or schemes approved by Government for the
modernization or shifting of cotton textile mills, and the permissions for development or
redevelopment of lands of cotton textile mills granted by the Commissioner under this
Regulation, the Government shall appoint a Monitoring Committee under the chairmanship of
a retired High Court Judge with one representative each of the cotton textile mill owners,
recognised trade union of cotton textile mill workers, the Commissioner and the Government
as members.
(b) The Commissioner shall provide to the Monitoring Committee the services of a Secretary
and other required staff and also the necessary facilities for its functioning.
(c) Without prejudice to the generality of the functions provided for in clause (a) of this Sub-
Regulation, the Monitoring Committee shall:--
(i) lay down guidelines for the transparent disposal by sale or otherwise of built up space, open
lands and balance FSI by the cotton textile mills;
(ii) lay down guidelines for the opening, operation and closure of escrow accounts;
(iii) approve proposals for the withdrawal and application of funds from the escrow accounts;
(iv) monitor the implementation of the provisions of this regulation as regards housing,
alternative employment and related training of cotton textile mill workers.
(d) The Monitoring Committee shall have the powers of issuing and enforcing notices and
attendance in the manner of a Civil Court.
(e) Every direction or decision of the Monitoring Committee shall be final and conclusive and
binding on all concerned.
(f) The Monitoring Committee shall determine for itself the procedures and modalities of its
functioning.
(10) Notwithstanding anything stated or omitted to be stated in these Regulations, the
development or redevelopment of all lands in Gr. Mumbai owned or held by all cotton textile
mills, irrespective of the operational or other status of the said mills or of the land use zoning
relating to the said lands or of the actual use for the time being of the said lands or of any other
factor, circumstance or consideration whatsoever shall be regulated by the provisions of this
regulation and not under any other Regulation except TDR and Fungible Compensatory FSI.
However the lands reserved for public purposes which is owned or held by Cotton Textile Mills,
shall not be regulated by the provisions of this regulations and reserved lands shall be handed
over to MCGM or the Appropriate Authority in lieu of TDR or shall be developed as per the
provisions laid down under Regulation No 17
If the residential buildings/chawls are situated on a reserved parcel of land, then land
component of the chawl shall be developed as per the provisions of clause (7) of this
Regulation without considering the reservation & remaining reserved land shall be developed
as per the provisions laid down under Regulation No 17.
11) The provisions of sub Regulation no 1(b) of this Regulation shall not be applicable where the
share of MHADA and MCGM land has already been handed over as per then prevailing
Regulations.
(EP-134)