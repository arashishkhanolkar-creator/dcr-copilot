# Part VIII: General Building Requirements

36. Occupancy Load
Space requirements of various parts of Buildings, etc.-This Part sets out the standard
space requirements of various parts of a building and those of light and ventilation,
the building services, fire safety, etc. Some of these items depend on the number of
persons who would normally occupy the building, for which the occupant load
should be worked out from Table No 13 hereunder:
Table No: 13
Occupant Load
Type of Occupancy Occupant load per
Serial
100 sq. m. of plinth
No .
(2) or covered area
(1)
(3)
Residential 8
Educational 25
Institutional 6.6*
Assembly :
(a)With fixed or loose seats and dance floor 166.6**
(b)without seating facilities including dining 66.6**
rooms
Mercantile :
(a)Street floor and sales basement 33.3
(b)Upper sales floors 16.6
Business and Industrial 10
Storage, Wholesale establishment 3.3
Hazardous 10
*The occupant load in dormitory portions of homes for the aged, orphanages
or mental hospitals, etc. where sleeping accommodation is provided shall be
calculated at not less than 13.3 persons per 100 sq. m.
** The plinth or covered area shall include, in addition to the main assembly
room or space, any occupied connecting room or space in the same storey or in
the storeys above or below, where entrance is common to such rooms and spaces
and they are available for use by the occupants of the assembly place. No
deductions shall be made in the plinth/covered area for corridors, closets and
other sub-divisions; that area shall include all space serving the particular
assembly occupancy.
37. Requirements of parts of buildings
(1) Plinth: The plinth or any part of a building or outhouse shall be so located with
respect to the surrounding ground level that adequate drainage of the site is
assured.
(i) Main Building: The height of the plinth shall not be less than 30 cm with respect
to the surrounding ground level or plinth shall not be less than 15 cm with respect
to the surrounding ground level in case of stilt/covered parking spaces. In areas
subject to flooding, the height of the plinth shall be at least 60 cm above the high
flood level or shall be at least 45 cm above the high flood level in case of
stilt/covered parking spaces. Architect on record shall certify that the plinth has
been proposed after taking due cognizance of High Flood Level (HFL) with reference
to available Contour map.
(ii)Interior court-yards, covered parking spaces and garages: These shall be raised
at least 15cm above the surrounding ground level and shall be satisfactorily drained.
(2) Habitable Rooms/Rooms:
(i) Size and Width: The minimum size and width shall be as given in the Table No 14
hereunder.
Table No: 14
Minimum size and width of Habitable Rooms/Rooms
Occupancy Minimum size Minimum width in
Serial
in sq. m m
No.
(2) (3) (4)
(1)
Any habitable room.
1 9.5 ---- 2.4
Rooms in a two-room Kitchen
2 tenement & above
one of the rooms. 9.5 ---- 2.4
other room/rooms 7.5 ---- 2.4
Kitchen 5.5 --- 1.8
One room Kitchen tenements
9.5 ----
3 one room 2.4
7.5 ----
Kitchen 2.1
Occupancy Minimum size Minimum width in
Serial
in sq. m m
No.
(2) (3) (4)
(1)
Multipurpose Room
4 (with provision of alcove) 12.5 2.4
5 Single-bedded room in a hostel. 7.5 2.4
Shop
6 6.0 1.2
Vending stalls & kiosks
7 3.0 1.2
38.0 or area at
the rate of 0.8
sq. m. per
8 Class room in an Educational
student or as
building 5.5
decided by
Govt. from time
to time.
Institutional building
(a) special room .. ..
9 9.5 3.0
(b) general ward .. ..
40.0 5.5
10 Bathroom 1.50 1.10
11 Water Closet (W.C.) 1.10 0.90
12 Combined Bathroom and Water 2.20 1.10
Closet (W.C.)
Cinema hall, theatre, auditorium, In conformity with the Maharashtra
13 assembly hall, etc. Cinema Rules.
In conformity with the Bombay
Entertainment Duty Act 1923,
14 Multiplex/Multiplex theatre complex Revenue and Forest Dept. Govt. of
Maharashtra.
(ii) Height- (i) The minimum and maximum height of a habitable room shall be as given in
Table No 15 hereunder: -
(ii) Notwithstanding the above restriction as stated in Table No. 15, any telematics
equipment storage or erection facility can have a height as required for effective functioning
of that system.
(iii) Notwithstanding the above restrictions as stated in TableNo.15, for cinema/TV films
production, shooting, editing, recording studios, more height as required for their effective
functioning shall be permitted.
Table No: 15
Height of Habitable Room/s
Occupancy Minimum Maximum height
Sr.
height in meters (m)
No.
in meters (m)
(2) (3) (4)
(1)
Flat roof.
1.
(a) Any habitable room 2.75 3.9 4.2
(b) Bathrooms, Water Closets, combined Bath 2.2 3.9 4.2
& WC
(Measured from the surface of the floor to
the lowest point of the ceiling)
(c) Air-conditioned habitable room. 2.4 3.9 4.2
(d) i) Assembly halls, residential hotels of all
types, institutional, educational, industrial,
hazardous or storage occupancies, 3.6 4.2 6.0*
departmental stores, malls, entrance halls
and lobbies to departmental stores and
assembly, Data Centre, Data ware house,
Large/ Big Box Retailors
ii) IT buildings, office buildings 2.75 4.2*
(e)i) Exhibition cum Convention Centre, Sport 4.2 8.8*
facility requiring more height
ii) Sound Recording/Film Studio, Warehouse 4.2 12*
(f) Shops. 2.75 3.9 4.2
Pitched roof –
2.
(a) Any habitable room 2.75 3.9 4.2
(average with (Average with 2.8 m at the lowest
2.4 m at the point).
lowest point)
(EP-135)
* Subject to the special permission of the Commissioner greater height may be permitted.
Provided that- (i) the minimum clear head-way under any beam/tie beam of pitched roof
shall be 2.4 m.
(ii) In all occupancies except those included in Sr. No. 1(d) & (e) in the table above, any height
in excess of 3.9 4.2 m shall be deemed to have consumed an additional F.S.I. of 50% of the
relevant floor area.
(iii) Other requirements- One full side of a habitable room must abut an exterior open space
same as provided in sub-regulation (2) of Regulation 41.
(iv) Other Requirements of Kitchen- Every room to be used as a kitchen shall have-
(a) unless separately provided in a pantry, means for the washing of kitchen utensils
which shall lead directly or through a sink to a grated and trapped connection to the waste
pipe;
(b) on an upper floor, an impermeable floor;
(c) at least a window not less than 1 sq. m in area, opening directly on to an interior or
exterior open space.
(3) Bathroom and water closets:
(i) A sanitary block consisting of a bathroom and water closet for each wing of each
floor at each mid-landing staircase level/stilt/podium/parking floor of the building
for the use of domestic servants engaged on the premises may be permitted by
the Commissioner
(ii) Other Requirements Bathroom or Water Closet
(a) Every bathroom or water closet shall be so situated that at least one of its walls
shall abut on to an exterior open space or an interior/exterior chowk or ventilation
shaft of the size specified in clause (a) of sub-regulation (8) of Regulation 41 or a
ventilation shaft of the size specified in sub-regulation (2) of Regulation 40 with
the openings (windows, ventilators, louvers) not less than 0.3 sq. m in area or 0.3
m in width.
(b) No bathrooms or water closet shall be situated directly over any room other than
another water closet, washing place, bathroom or terrace unless the said floor is
made impervious with adequate water-proofing treatment. However, in no case
shall a water closet or bathroom be provided over a kitchen.
(c) Every bathroom or water closet shall have the platform or seat or flooring made
of water-tight non-absorbent material.
(d) It shall be enclosed by walls or partitions and the surface of every such wall or
partition shall be finished with a smooth impervious material to a height of not
less than 1m above the floor of such a room.
(e) It shall be provided with an impervious floor covering sloping towards the drain
with a suitable grade and not towards a verandah or any other room.
(f) Every water closet and/or a set of urinals shall have a flushing cistern of
adequate capacity attached to it.
(g) All the sewerage outlets shall be connected to the municipal sewerage
system. Where no such system exists, a septic tank shall be provided within the
plot conforming to the requirements of sub-regulation 29 27 of Regulation 37.
(4) Loft:
(i) Location: Lofts may be provided over kitchens, habitable rooms, bathrooms,
water closets and corridors within a tenement in residential buildings, in shops
and in industrial buildings.
(ii) Height: The height of the loft shall not be more than 1.5 m. If it exceeds 1.5 m, it
shall be counted towards FSI.
(iii) The lofts in non-residential buildings shall be located at least 2 M away from the
entrance.
(5) Mezzanine Floor:
(i)The aggregate area of mezzanine floor in any room shall not exceed 50% of the
BUA of that room. The size of mezzanine floor shall not be less than 9.5 sq. m if it
is used as a living room. The area of the mezzanine floor shall be counted towards
FSI.
Provided, however, that in existing authorized buildings having no balance FSI,
area of the mezzanine floors constructed prior to 15th August, 1997 without
approval, may be exempted from FSI with special permission of the Commissioner
subject to the terms and conditions and payment of premium as may be specified
by the Commissioner.
Note- Lofts having head room more than 1.5 m above shall be treated as
mezzanine floor.
(ii) Height-The minimum height/head-room above a mezzanine floor shall be 2.2m.
The head-room under a mezzanine floor shall not be less than 2.2m.
(iii) Other Requirements-A mezzanine floor may be permitted over a room or a
compartment, if
(a) it conforms to the standards of living rooms in regard to lighting and ventilation
in case its size is 9.5 sq. m or more;
(b) it is so constructed as not to interfere under any circumstances with the
ventilation of the space over and under it;
(c) no part of it is put to use as a kitchen/sanitary block;
(d) it is not closed, so that it could be converted into an unventilated compartment;
(e) it is at least 1.8 m away from the front wall deriving access of such room;
(f) access to the mezzanine floor is from within the respective room below only;
(g) where it is in an industrial building, NOC from the relevant authorities of the
Industries Department is obtained for the additional floor area.
(6) Store Room:
(i) Size. -The area of a store room where provided in residential buildings shall not
be more than 4sq.m.
(ii) Height -The height of store room shall not be less than 2.2 m.
(iii)Store Room shall be treated as non-habitable room
(7) Prayer Room:
(i) Size. -The area of a prayer room where provided in residential buildings shall not
be more than 3 sq. m.
(ii) Height -The height of prayer room shall not be less than 2.2 m.
(8) (6) Garage:
(i) Size-The size of a private garage shall not be less than 2.5 m x 5.5 m or 2.3 mx
4.5m as provided in clause (ii) and the note under it in sub-regulation (1) of
Regulation 44.
(ii) Location-If not within the building the garage may be located at its side or rear,
but at least 7.5 m away from any access road.
(iii) Area of garage shall be counted in FSI & it shall be at least 1.5m meter away
from compound wall.
Explanation: For purposes of this Regulation, the term "garage" means a detached
ground floor structure in the open space of the plot or on the ground floor of a
building and intended for parking or shelter of mechanically controlled vehicles
but not for their repairs.
(9) (7) Basement:
(i) The basement may be allowed to be constructed beyond building line in the
required front open space under the provision of these regulations provided clear
distance of 3.0 m between plot boundary/edge of road and basement line is
maintained. The open spaces from the other boundaries of the plot except front
open space shall not be less than 1.5 m. Basement may be at one level or more.
(ii) Height- The height of the basement from the floor to the underside of the roof-
slab or ceiling or under side of a beam when the basement has a beam shall not be
less than 2.4 m. The height of basement below soffit of the slab shall not be more
than 3.9 m. In case of mechanical parking more height as per the requirement may
be allowed.
(iii) Ventilation- The extent of ventilation shall be the same as required by the
particular occupancy for which the basement is used. Any deficiency must be
made good by resort to a mechanical system, viz. blowers, exhaust fans, air-
conditioning system, according to the standards in Part VIII Building Services
Section I-Lighting and Ventilation, NBC.
(iv) Uses permitted – A basement may be put to the following uses only:
(a)(i) Storage of household or other non-hazardous goods;
(ii) Store rooms, bank lockers or safe deposit vaults;
(b) Air conditioning equipment/AHU and other machines used for services and
utilities of the building;
(c) Parking spaces;
(d) DG set, meter room and Electric substation (which will conform to specified
safety requirements);
(e) Effluent Treatment Plant, suction tank, pump room, Water Treatment Plant,
Sewerage Treatment Plant, Laundry Room, Boiler Room;
(f) MRI, Cancer Radiation Area, & X-Ray rooms and other uses allowed by GoM. from time
to time;
(g) Shops and offices, recording studio;
(h) Commercial user except kitchen with flame. (kitchen without flame may be permitted)
(i) Sanitary facility
(j)Play area for school if other ancillary uses have not been proposed at that level of
basement.
Provided that the uses mentioned at (a), (f), (g), (h) & (j)above shall be permitted
in the 1st basement and the uses as mentioned in (f) above shall be permitted in
lower basement only by counting in FSI subject to compliance of requirements of
habitable rooms the following conditions:
(EP-136)
i)All requirements regarding access, safety (including fire safety), ventilation, etc.
shall be complied with.
ii) All the planning standards (particularly as regarding parking) should be strictly
adhered to.
(v) Other Requirements-Every basement shall meet the following specifications:
(a) The ceiling of an upper basement shall be at least 0.6 m and not more than 1.2 m
above the average surrounding ground level within the building line & may be
flush with the average surrounding ground level beyond building line, Provided
further that the height of basement above average surrounding ground level
within building line may be reduced up to 0.15 m case of stilt and 0.30 m in case
ground floor, when basement beyond building line is flush with average
surrounding ground level, subject to provision of artificial light and ventilation.
(b)Adequate arrangements shall be made to ensure that surface drainage does not
enter the basement.
(c)The walls and floors of the basement shall be water-tight and the effect of the
surrounding soil and moisture, if any, should be taken into account in design and
adequate damp-proofing treatment shall be given.
(d) Any access to the basement through a staircase or pedestrian ramp shall meet
requirements of clause (18 16) of this Regulation. Open ramps may be permitted in
the open spaces except in the front open space within plot boundary, subject to
(b) above and the fire protection requirements.
(e)Any access to the basement through vehicular ramps shall meet the requirements
of item, (ii) of clause (18 16) of this Regulation.
(10)(8) Cabin: Where cabins are provided, a clear passage not less than 0.9 m wide
will be maintained. The size of a cabin shall not be less than 3 sq. m and the
distance from the farthest space of cabin to the nearest exit shall not be more
than 18.5 m. If the cabin does not derive direct light and ventilation from any
open spaces/mechanical means, its maximum height shall be 2.2 m.
(11) (9) Office Room: In every residential/non-residential building, constructed or
proposed to be constructed for the use of a co-operative society or an apartment
owners’/lessee’s association, an office room for one for each society limited to one
per building will be permitted on the ground floor or 1st any floor or parking floors
or stilt floor. In an already developed property, it may be on an upper floor. The
area of the room inclusive of toilet shall be limited to 20 sq. m.
(12) (10) (a) Letter Box Room: A separate letter box room of appropriate dimensions
shall be provided on the ground floor /stilt floor/over podium or any other
convenient location in residential, commercial and industrial occupancy in each
wing.
(b) Letter Boxes- Letter boxes of appropriate dimensions shall be provided at a
convenient location on the ground floor/stilt floor/over podium or any other
convenient location for every unit of residential, commercial and industrial
occupancy in each wing.
(13) (11) Electric Meter/Service Utility Room: An independent and ventilated
Electric meter/Service utility room directly accessible from the outside common
areas shall be provided on ground floor and/or on upper floors/Podium/Parking
floor and in the first basement floor with proper ventilation, according to the
requirements of the electric supply undertaking. The door to the room shall have
fire resistance of not less than two hours.
(14) (12) Refuse Chute/Garbage Chute: In all residential buildings, refuse
chutes/garbage chute may be provided with openings on each floor or on mid-landing.
Design and specifications of refuse chutes shall be in accordance with provisions of IS
6924.
(15) (13) Corridor: The minimum width of a common corridor shall be as shown in
Table No 16 hereunder. Provided that any corridor identified as an exit (vide
Regulations 47) shall also conform the requirements therein.
(16) (14) Door: Doors shall conform to the under mentioned provisions. In addition,
in order to satisfy fire-fighting requirements, any doorway identified as an exit
shall conform to the requirements stipulated in Regulation 47,
(i) Width- A door shall be at least 0.9 m wide, except that doors to bathrooms,
water-closets or stores may at least be 0.7 m wide.
(ii) Height-The minimum height of a doorway shall be 2 m.
(17) (15) Stairway: Stairways shall conform to the following provisions in addition to
items (i) to (ix) below. In addition, in order to satisfy fire-fighting requirements,
any stairway identified as an exit stairway shall conform to the requirements
stipulated in Regulation 47
(i) Width- The minimum width of a staircase other than a fire escape shall be as
given in Table No 16 hereunder.
Table No: 16
Minimum width of common Stairways/Corridors for various occupancies.
Type of Occupancy Minimum width of Minimum width of
Sr.
stairway/corridor (in stair- way/corridor
No.
meters) for buildings (in meters) for
up to 70.00 m height buildings more than
70.00 m height
Residential buildings-
(a) General 1.201.50 1.50 2.00
(b) Row housing (2 storeyed) or 0.75 0.90 -
internal staircase in duplex
flat
(c) Hotels 1.50 2.0
Educational buildings
(a) Up to 32 m high 1.50 -
(b) Over 32 m high 2.0 -
Institutional buildings 1.50 2.0
Assembly buildings 2.0 2.0
Mercantile storage, hazardous 1.50 2.0
buildings
Industrial Building 2.00
Note:
Width of stairways or corridor in case of 1(b) above shall be limited to 1.20 m.
(ii)Flight- No flight shall contain more than 12 risers, but in residential buildings, in
narrow plots a single flight staircase may be permitted.
(iii)Risers- The maximum height of a riser shall be 17.50 cm in any occupancy.
However, on an internal stairway within a dwelling unit a riser may be 25 cm high.
(iv) Treads- The minimum width of the tread without nosing shall be 25cm for
staircases of a residential building, other than fire escapes. In other occupancies,
the minimum width of the tread shall be 30cm it shall have a non-slippery finish.
(v) Head-room- The minimum head-room in a passage under the landing of a
staircase and under the staircase shall be 2.2m.
(vi)Floor Indicator- The number of each floor shall be conspicuously painted in
figures at least 15cm large on the wall facing the flights of a stairway or at such
suitable place as is distinctly visible from the flights.
(vii) Hand rail- Handrails with a minimum height of 0.9m from the center of the
treads shall be provided.
(viii) Except for the row houses or for the internal staircase of a duplex tenement, no
staircase shall be made of wooden or other combustible material.
(ix) Corridors and Stairway side identified as fire exits shall conform to other relevant
provisions of National Building Code.
(18) (16) Ramps:
(i) Ramps for pedestrians-
(a)General: The provision applicable to stairways shall generally apply to ramps. A
ramp in a hospital shall not be less than 2.25 m wide. In addition, to satisfy the fire-
fighting requirements, a ramp shall conform to sub-regulation (7) of Regulation 48
(b)Slope: A ramp shall have a slope of not more less than 1 in 12 8 for vehicular
traffic & 1 in 12 for pedestrian. It shall be of non-slippery material.
a) Handrail- A handrail shall be provided on both the sides of the ramp with
minimum height of 0.90 m above the surface of the ramp.
b) For every 9 m of ramp length, a landing of 1.5 m shall be provided
c) Landing of minimum 1.5 m length shall be provided at every entry & exit of
ramp.
(ii) Ramps for basement or podium, multi-storeyed parking- For parking spaces in a
basement and upper floors, ramps of adequate width as tabulated below and
adequate slope shall be provided preferably at the opposite ends. Such ramps may
be permitted in the side and rear marginal open spaces after leaving sufficient space
for movement of fire-fighting vehicles subject to the provision of sub-regulation (7)
of Regulation 48. Provided that, when a building abuts 3 or more roads, then ramps
shall be allowed in front marginal open space facing the road having least width.
Alternatively, for ingress & egress of vehicles minimum two numbers of car lifts for
vehicles up to 200 parking and one additional car lift for every 100 parking beyond
200 parking or part thereof shall be provided.
Sr. Type of Vehicle Clear width of Ramp in meters(m)
No One Way Ramp Two Way Ramp without
central divider
I Light Motor Vehicle (LMV) 3.00 6.00
Ii Medium Commercial Vehicle 3.50 7.00
(MCV)
Iii Heavy Motor Vehicle (HMV) 4.50 9.00
Note- a) In case of two-way ramp with dividers, each carriageway will be considered
as one way ramp.
b) At turnings, width of ramp mentioned above shall be enhanced/increased for
smooth maneuvering as per the sketch of Annexure 23 appended herewith.
c) The gradient of the ramp shall not be more than 1 in 10 8.
d) Separate provision for ingress & egress shall be made.
(19) (17) Lifts: Lifts shall conform to the provisions given below and to the
provisions of sub-regulation (2) of Regulation 50.
(i) At least one lift shall be provided in every building more than 16m in height. In
case of buildings more than 24m high at least two lifts shall be provided in order to
serve each dwelling unit. One of these lifts shall be fire lift & shall be in conformity
with the fire safety regulations. It shall be ensured that at least one lift must serve
access to the lowest level of basement & may also extend up to terrace floor except
in areas where civil aviation and other restrictions operate.
(ii) Other requirements. -
a. The number, type and capacity of lift shall satisfy the requirements of part 8,
Sec.5, and those of Installation of Lifts and Escalators National Building Code of
India and modified provision thereof from time to time.
b. At ground floor level, a grounding switch shall be provided to enable grounding
the lift cars in an emergency.
c. The lift machine room shall be separate and no machinery other than required
for the lift shall be installed therein.
d. The number of each floor shall be conspicuously painted in figures at least 15cm.
large on the wall opposite the lift/lifts opening or on other suitable surface so as to
be distinctly visible from the lift cage.
e. In high rise residential buildings having height more than 70m, one of the lifts
installed shall be a freight lift. The freight lift will be designed in such a way that it
shall serve as stretcher lift also.
f. A new lift with passage thereto in an existing building with height up to 16m may
be permitted with the permission of the Commissioner.
(20) (18) Porch: A porch, if any, shall be at least 1.5 m clear of the plot boundary,
shall have a level difference of 0.3 m in relation to the level of the floor; the area of
a porch up to 5.5 m in length (parallel to the main building) shall not be counted
towards FSI. A parapet wall 0.23 m in height is permissible over a porch. The
Commissioner may permit larger porches for mercantile, institutional, IT, Mall,
Commercial, hotel and public buildings.
(21) (19) Canopy: A cantilevered and un-enclosed canopy with level difference of 0.3
m in relation to the floor level may be permitted over each entrance and staircase, if
a clear distance of at least 1.5 m is maintained between the plot boundary and the
outer edge of the canopy. The minimum clear height of the canopy shall be 2.2 m.
The Commissioner may permit larger canopies for mercantile, institutional, IT, Mall,
Commercial hotel and public buildings.
(22) (20) Balcony: Balconies may be permitted at each floor.
(i) No balcony shall reduce the minimum marginal open space to less than 3 m at the
rear and sides and 1.5m in the front. The width of the balcony will be measured
perpendicular to the building line and reckoned from that line to the balcony's
outermost edge. The enclosed balcony will be considered as part of room Balcony
shall not be enclosed. Balcony shall not be permissible on ground floor.
(ii) The balconies in existing residential buildings claimed free of FSI as per then
prevailing Regulation may be enclosed on payment of Balcony enclosure fee as
decided by the Commissioner from time to time.
(EP-137)
(23) (21) Roof:
(i)Effective drainage of rain water- The roof of a building shall be so constructed or
framed as to permit effective drainage of the rain water therefrom by means of rain
water pipes at the scale of at least one pipe of 10cm diameter for every 40-sq. m of
roof area. Such pipes shall be so arranged, jointed and fixed as to ensure that the
rain water is carried away efficiently.
(ii)Rain water pipes shall be connected to Rain Water Harvesting system, if required
to be provided under these Regulations or to a drain through a covered channel
formed beneath the public footpath to connect the rain water pipes to the road side
storm water drain or in any other approved manner.
(iii)Manner of fixing rain water pipes- Rain water pipes shall be affixed to the
outside of the walls of the building or in recesses or chases cut or formed in such
walls or in such any other manner as may be approved by the Commissioner.
(24)(22) Common Terraces: Common Terraces shall not be sub-divided and shall be
accessible by a common staircases/lift. The terraces may be used for additional
recreational green area over and above the mandatory ROSLOS requirement under
these Regulations, provided that the terrace shall be designed and made impervious
considering recreational green area. The terraces will also serve as community open
spaces for the occupants of the building. The terraces may allowed for roof top
farming/ gardening Overhang of terrace to the extent of 1.20 m beyond building line
subject to requirement of open spaces as per Regulation no 42(e) & 42(f) may be
allowed from elevation point of view.
Provided further that completely commercial buildings including buildings of
residential hotels, terraces may be permitted to be used as restaurant; subject to
condition that no inflammable material shall be used and safety and security shall
be ensured. No construction whatsoever, temporary or permanent, except service
platform & toilet block, shall be permissible.
(EP-138)
(25)(23) Parapet: Parapet walls and hand-rails provided on the edges of the roof
terrace, balcony, etc. shall not be less than 1.15 1.50 m from the finished floor level
and shall not more than 1.30m in height above the finished floor level. Parapet wall
having height more than 1.30 1.50 m may be allowed on top most common terrace
level with the approval of commissioner. For the height of building beyond 32 m &
up to 70 m parapet wall of height 2 m, for the building height beyond 70 m parapet
wall with height up to 5 m with 60% voids in surface area beyond height of 1.30 m
only on two sides of common terrace may be allowed.
(26) (24) Boundary wall and main entrance:
(i) Boundary wall-
(a) Except with the permission of the Commissioner, the maximum height of a
boundary wall shall be 2.0 2.4 m above the surrounding ground level of plot. A
boundary wall up to more than 2.4 m height may be permitted if the top 0.9m is of
open type construction, to facilitate through vision.
(b)At a corner plot, the height of the boundary wall shall be restricted to 0.75m for a
length of 10m on the front and side of the inter-section and the balance height of
0.75m if required in accordance with (i) above may be made up of open type
construction (through railings).
(c) The provisions of (a) and (b) above will not apply to the boundary walls of
correction facilities (jails/prison/remand home).
(d) In case of electric sub-stations, transformer stations, institutional buildings like
sanatoria, hospitals, educational buildings like schools, colleges, including hostels,
industrial buildings and other uses of public utility undertakings, a height up to 2.4m
may be permitted by the Commissioner. However, in case of electric sub-stations a
height up to 3.6 m may be permitted.
(e) In case a boundary wall around a POS such as Play Ground, is contemplated, the
height of Boundary shall not be preferably higher than 0.45 m & shall have width of
0.45 m or wider (in any case the height of boundary wall shall not exceed 1.50 m or
as per the requirements of Commissioner) with smooth top finish which can be
comfortable for sitting purpose. However, for Gardens & Parks boundary wall up to
1.5 m height may be permitted if the top 0.9 m is of open type construction, to
facilitate through vision.
(ii) Main Entrance-The main entrance to a plot accommodating a high rise or a
special building shall be at least 4.5m wide and shall be so designed as not to
obstruct easy movement of a fire-engine or truck. The entrance gate to it shall open
inside and fold back against the compound wall.
Provided further that ornamental entrance gate with the height not less than
4.5m or as required for movement of fire Engine shall be permissible.
(27) (25) Bore well/Tube well/Open well:
(a) May be constructed with the locational approval from the Hydraulic Engineering
Department of MCGM.
(b) The construction shall be as per the provision of State Ground Water Survey
Department.
(28) (26) Overhead Tanks: Every overhead water storage tank shall be maintained in
proper hygienic condition. The distance between terrace & soffit of the overhead
water tank shall not exceed 1.5 m. The construction of the water storage tanks shall
be as per the guidelines issued by Hydraulic Engineering Department of MCGM.
(29) (27) Septic Tanks-Location and sub-soil dispersion: A sub-soil dispersion system
shall not be closer than 12m to any source of drinking water such as a well, to
mitigate the possibility of bacterial pollution of water supply. It shall not be closer
than 3 m from Tube well/Bore well. It shall also be as far removed from the nearest
habitable building as economically feasible but not closer than 2 m to avoid damage
to the structure.
The construction of septic tank shall be carried out as per the relevant provisions of
IS Code 2470-1985 Part I & II.
(30) (28) Yogalaya or Fitness Centre: In every residential building, either existing or
constructed or proposed to be constructed for the use of existing or proposed Co-
Operative Housing Society or an Apartment Owners Association, a Yogalaya or
Fitness Centre including toilet facilities will be permitted subject to following
conditions:
i. The application for the proposed Yogalaya or Fitness Centre shall be made by the
Registered Co-Operative Housing Society/Apartment Owners Association of the
buildings that has been issued the occupation certificate/BCC. The owner/developer
may make an application for proposed Yogalaya or Fitness Centre with registered
undertaking stating that constructed Yogalaya or Fitness Centre shall be handed
over to proposed Co-Operative Housing Society/Apartment Owners Association; and
in turn shall ensure the handing over on completion.
ii. The area of such center shall be allowed free of FSI equivalent to 2(two) percent
of the total BUA for every building subject to a condition that, it shall not be less
than 20 sq. m and not more than 200 sq. m per building distributed as desired.
Any additional BUA, in excess of this limit would be counted towards FSI.
iii. The center shall not be used for any purpose other than for fitness centre
activities and Reading Room.
iv. The Yogalaya or Fitness Centre activities shall be exclusively confined for to the
members of the concerned housing society or an Apartment Owners Association.
v. The ownership of the premises of the Yogalaya or Fitness Centre shall vest only
with the concerned society or the apartment owner’s association as the case may
be.
vi. In case of larger layout where there is existing/proposed Club House in layout RG
under Regulation 27 of these regulations, then the Yogalaya or Fitness Centre in the
individual building shall not be permissible free of FSI.
(31) (29) Special Provisions for Institutional, Assembly, Business or Mercantile and
Industrial Buildings: A Crèche of minimum 40 sq. m BUA shall be provided for
Institutional, Assembly, Business or Mercantile Building where total number of
employees is 1000 or more.
(32) (30) Parking floor: The parking floors above ground/stilt floor within building
line, for the provision of parking, accessible either by ramp or by minimum two car
lifts up to 200 parking and one additional car lift for every 100 parking beyond 200
parking or part thereof. The height of the parking floor shall not be more than 2.4m
below soffit of the beam & maximum height of the floor permitted in this regulation
below soffit of slab. In case of mechanical parking more height as per the
requirement may be allowed.
(33) (31) Podium: A podium may be permitted in plot admeasuring 1000 sq. m or
more.
The podium provided with ramp may be permitted in one or more level, total height
not exceeding 32 m above ground level.
Podium not provided with ramp but provided with car lifts may be allowed subject
to minimum two numbers, for vehicles up to 200 parking and one additional car lift
for every 100 parking beyond 200 parking or part thereof.
The podium shall be used for the parking of vehicles, provision of DG set, and
substation as per requirement of electric supply company. Further, drivers’ room,
toilet block, society office, Air Handling Unit (AHU) and Yogalaya or Fitness Centre,
swimming pool on top most podium open to sky may also be permitted without
affecting recreational area if provided and if other requirements of these
Regulations are fulfilled.
The ROSLOS as laid down under Regulation No 27, may be provided as per note
therein. The additional ROSLOS, if any, may be provided on the podium.
Podium may be allowed to be constructed beyond building line in the required front
open space under the provisions of these Regulations provided clear distance of 3.0
m between plot boundary/edge of road and podium line is maintained.
Such podium may be extended beyond the building line in consonance with
provisions of DC Regulation 47(1) on one side whereas on other side and rear side it
shall not be less than 1.5 m from the plot boundary.
Ramps may be provided in accordance with DC Regulation 37(18 16).
(34) (32) Service Floor: A service floor of height not exceeding 1.8 m may be
provided in a building exclusively for provision/diversion of services. Provided
further that a service floor with height exceeding 1.8 m may be allowed in a building
of medical use or in building having height more than 70 m with the special
permission of Commissioner with reasons recorded in writing.
(35) (33) Helipad: A helipad may be allowed on the rooftop of the building having
height more than 200 m or at a suitable location subject to;
(i) prior permission from Director General of Civil Aviation(DGCA)as per the guide
lines issued by Ministry of Civil Aviation,
(ii) prior permission from Ministry of Defence and Government of Maharashtra,
(iii) structural stability certificate from the registered Structural Engineer,
(iv) provision for firefighting as prescribed by DGCA/CFO,
(v) unrestricted access as required by MCGM/any Government agencies in case of
emergency and submission of registered undertaking to that effect.
(38) Special Design Requirement For
(I) Educational Building:
(1) In addition to the class-rooms and other areas, every educational building shall
be provided with -
(a) a tiffin room with a minimum area of 18 sq. m for every 800 students or part
thereof;
(b) a separate tiffin room for teachers where strength of students exceeds 1000;
(c) a room/space with drinking water facilities for every 300 students or part thereof
on each of the floors.
These requirements may be amended by the Commissioner in consultation with the
Education Department of the State Government.
(2) Play Ground-
(a) In case of educational development by Educational Institution on their
vacant land, at least 40% of the plot area at one place (inclusive of recreational area
as required under Regulation No 27) shall be provided mandatorily for Play Ground.
However as per these Regulations, for the educational purpose if additional FSI is
due, then while allowing said due FSI, it is not necessary to increase the area of Play
Ground.
(b) In case of educational development by Educational Institution on their land, if
additional FSI is due and if the existing open area is less than 40% of the plot area,
additional FSI can be sanctioned as per these regulations without reducing the open
area further and without increasing the plinth coverage area, by ensuring structural
stability of the existing building. Further where existing open area is more than 40%,
then minimum 40% of plot area shall be maintained as open area (inclusive of
recreational area as required under Regulation No 27) while allowing additional FSI
as per these Regulations.
Note- 1) The permissible FSI shall be on the entire plot.
2) If existing Municipal Play Ground/POS is abutting to the plot of Educational
Institute or may be across the road, then the provision of 40% of play area within
plot of Educational Institution may not be insisted upon if the combined play area
available is at least 40% of plot area. Provided further, if ownership of Play
Ground/POS having area at least 40% of area abutting to the plot of Educational
Institute is vesting with the Educational Institution, then the provision of 40% of
play area within plot of Educational Institution may not be insisted upon.
3. 50% of the required Play Ground area may be allowed in stilt subject to condition
that said carved out area will not be used for the parking or any other utility
purpose by taking proper safety measures.
(II) Building for Medical use-
For Hospital, Maternity Homes and Health Centre, Sanatorium, Multi-Specialty
Hospitals:
a) minimum area of general wards shall be 40sq.m with no side less than 5.5 m;
b) the basic requirements for building put to medical use shall conform to IS
12433:2001
(III) Public Building-
A Crèche shall be provided as per the Regulation no 37(3129)
39. Special Regulations for Differently abled persons
Differently Abled People
As per the provisions of the Persons with Disabilities Act, 1995, seven categories of
disabilities have been identified viz., blindness, low vision, leprosy cured, hearing
impairment, loco motor disability, mental retardation and mental illness. Persons
falling under the above categories with a minimum of 40% disability are covered
under Differently Abled People. The provisions made under Differently Abled People
are also applicable to elderly, pregnant women and mothers with small children on
prams.
1 Scope:
These bye laws are applicable to all existing and proposed public buildings &
facilities having BUA more than 2000 sq. m.
In case of proposed residential buildings and public buildings/facilities having BUA
less than 2000 sq. m the access path and walkways up to lift/staircase on ground
level/stilt/podium from drop off zone shall be provided for differently abled
persons.
2. Site Development:
Level of the roads, access paths and parking areas shall be described in the plan
along with specification of the materials.
2.1 Access path/walk way-
Access path from plot entry and surface parking to building entrance shall be of
minimum 1.5 m width having even surface without any slope. Slope if any shall not
have gradient greater than 1 in 20. Finishes shall have a nonskid surface with a
texture traversable by a wheel chair. Where transfer has to be made from a
vehicular surface to a pedestrian surface, the driveway and the pavement or
footway surfaces shall be blended to a common level or ramp. Kerb Ramps shall be
preferably provided.
(A) Kerb Ramps
Provision Kerb Ramps are to be provided where the vertical rise is less
and than 0.15m, located or protected to prevent obstruction by
Location parked vehicles and should be free from any obstruction such as
signposts, traffic lights, etc.
Dimensions The gradient of a kerb ramp should not be steeper than 1:12,
and slopes the flared sides should not be more than 1:10 and width should
not be less than 0.9 m.
Design and A slip-resistant surface, should be designed not to allow water
Finish accumulating on the walking surface, should not project onto
the road surface
B) Drop-off Zone
Provision & Drop-off zones if provided should be at the same grade as
Location the driveway
Dimensions  Min width of drop-off zone 1.5 m, and min length 4.5 m.
 Change in level between the drop-off and the plinth
should be through a ramp of maximum gradient 1:12
Design & Finish The surface of the drop-off zone should be finished with a
non-skid material
C) Access Path:
Provision and ● At least one continuous unobstructed accessible route or
Location accessible path of travel shall be provided which connects
all accessible elements and spaces in a building or facility
for Differently Abled individuals.
● An accessible route shall be provided from public
transportation stops, accessible parking, passenger loading
zones and public streets or sidewalks to the accessible
building entrances and lifts served.
● Directional signs bearing the symbol shall be displayed at
all other non-accessible entrances to direct to the
accessible entrance.
● The access path should have an even surface without any
slope.
Dimensions Access path from plot entry and surface parking to building
entrance shall be of minimum 1.5 m width and for a two-
way traffic, it should be 1.8 m wide.
Slope ● Slope if any shall not have gradient greater than 1 in 20.
● Such access shall be free from protrusion, hazards, steps,
kerbs other than dropper kerbs, doors or doorways which
will impede the passage of a wheelchair, or other form of
barrier which will prevent access by Differently Abled
persons.
Design and Finish ● The surface of an access route shall be firm and non-
slippery.
● Tactile guiding path is requirement to ensure visually
impaired person familiarize with the road and path. It shall
be avoided with the vehicular movement.
D) Ramps:
Provision and ● When the horizontal run of the approach ramp exceeds
Location 9 m length, an alternative stepped approach (Refer
Staircases section) is to be provided in addition to the
ramp approach.
● Where there is a large change in elevation that requires
multiple ramps and landing combinations, other
solutions such as elevators should be considered.
Design and Finish ● Single row of tactile warning blocks should be placed at
beginning and end of each ramp at also at beginning and
end of each run.
● Ramps and landing surfaces should be slip resistant.
Dimensions
Level Difference Minimum Ramp Width Comments
gradient
≥ 0.15 m < 0.30 1:12 1.2 m
m
≥ 0.30 m < 0.75 1:12 1.5 m Landing every 5 m of ramp run
m
≥ 0.75 m < 3.0 m 1:15 1.8 m Landing every 9 m of ramp run
≥ 3.0 m 1:20 1.8 m Landing every 9 m of ramp run
2.2 Parking- For parking of vehicles by Differently abled individuals, the following
provisions shall be made:
a) Minimum two surface parking spaces for the first 100 parking spaces and one
parking space for next 200 parking spaces or part thereof shall be provided near
entrance for the Differently abled persons with maximum travel distance of 30 m
from building entrance.
b) The width of parking bay shall be minimum 3.6 m.
c) The information stating that the space is reserved for wheel chair users shall be
conspicuously displayed.
d) Indication/directional signage along driveway showing the way leading to the
parking spaces reserved for Differently abled persons should be provided
3. Building Requirements:
The specified facilities for the buildings for Differently abled persons shall be as
follows:
1. Approach to plinth level.
2. Corridor connecting the entrance/exit for the Differently abled persons.
3. Stairways.
4. Lift.
5. Toilet.
6. Drinking Water.
3.1 Approach to Plinth Level- Every building shall have at least one entrance
accessible to the Differently abled persons and shall be indicated by proper signage.
This entrance shall be approached through a ramp together with the stepped entry.
3.1.1 Ramped Approach- Ramp to enter the building shall be finished with non-
skid material. Minimum width of ramp shall be 1.5 m with maximum gradient 1:12.
Length of ramp shall not exceed 9.0 m having 0.9 m high hand rail on both sides
extending 0.3 m beyond top and bottom of the ramp. Minimum gap from the
adjacent wall to the hand rail shall be 0.050 m.
3.1.2 Stepped Approach- For stepped approach size of tread shall not be less than
0.3 m and maximum riser shall be 0.15 m with provision of 0.9 m high hand rail on
both sides of the stepped approach similar to the ramped approach.
3.1.3 Exit/Entrance Door: -The details shall be as under: -
Provision & Publicly accessible buildings should preferably have
Location automatic/self-closing doors, instead of manual doors.
Manual doors should be easy and light in operation.
Revolving doors should be avoided, but, in cases where a
revolving door is the single means of entry, adequate space
to accommodate wheelchair users should be provided.
Dimensions a. The minimum clear opening of doorways shall be 0.9 m
measured between the face of the door and the face of
the doorstop with the door open at 90° as illustrated in
Sketch No 1 in Annexure 23
b. Thresholds of doorways should not exceed12 mm.
Raised threshold and floor level changes at doorways
should be leveled off with a slope on each side of
threshold.
c. Manual doors should incorporate kick plates 0.3 m-0.4
m high to withstand impact of wheelchair footrest (this
is especially important where doors are glazed).
d. All doors opening outwards (into a circulation
space) should be fitted with vision panels between
0.9 m and 1.5 m from finished floor level.
e. The doorway of a one-way swing door shall have
maneuvering spaces on both sides for wheelchairs and
the following clear spaces shall be provided adjacent to
the leading edge of the door as illustrated in Sketch No
2 in Annexure 23
▶ On Pull Side–Minimum space of 0.6 m
▶ On Push Side–Minimum Space of 0.3 m
Where two-way swing doors or sliding doors are used, a
minimum space of 0.3 m adjacent to the leading edge of the
door shall be provided on each side of the door.
f. If frameless doors are used, it shall be prominently
marked so as to make it visible.
g. Double action self-closing door shall have a check
mechanism to prevent the door swinging beyond closed
position
3.1.4 Entrance Landing- Entrance landing shall be provided adjacent to ramp with
the minimum dimension 1.8 m x 2.0 m. It shall have a non-skid surface with a
texture traversable by a wheel chair. Kerbs wherever provided should blend to a
common level.
3.2 Corridor Connecting the Entrance/Exit for the Differently abled persons -
The corridor connecting the outdoors to a place where information concerning the
overall use of the specified building can be provided to visually impaired persons
either by a person or by signs, shall be provided as follows:
a) The minimum width shall be 1.5 m
b) In case there is a difference of level, slope ways shall be provided with a slope of
1:12.
c) Hand rails shall be provided for ramps/slope ways.
d) No appliances, fixtures and fittings shall project beyond 90 mm from the surface
of any wall in corridors, paths and lobbies below a level of 2000mm above the
finished floor level unless they are unavoidable, in which case they shall also be
extended downwards to the finished floor level or guided by tactile flowing
materials.
e) To facilitate the way-finding for persons with visual impairment, surfaces and
finishes with luminous contrast between the wall and the ceiling, and between the
wall and the floor should be adopted. Appropriate lighting design with adequate
illumination should be considered.
f) All corridors should have non-slippery-resistant surfaces.
g) A minimum luminous contrast of 30% should clearly define between wall, floor
and door surfaces.
3.3 Stair Ways- One of the stair-ways near the entrance/exit for the Differently
abled persons shall have the following provisions:
a) The minimum width shall be1.5 m.
b) Height of the riser shall not be more than 0.15 m and width of the tread 0.3 m.
The steps shall not have abrupt (square) nosing.
c) Maximum number of risers on a flight shall be limited to 12.
d) Hand rails shall be provided on both sides and shall extend 0.3 m on both sides
and shall extend 0.3 m on the top and bottom of each flight of steps.
e) The minimum clear headroom in pedestrian area such as walkways, halls,
corridors, passageways or aisles shall be 2.2 m.
f) A detectable guardrail or other barrier having its leading edge at or below 0.580 m
from the floor level shall be provided where the head room of an area adjoining an
accessible route is reduced to less than 2.2 m as shown in the Sketch No 3 in
Annexure 23
g) The provision of Braille and high luminous contrast signs is recommended along
with tactile guiding path
3.4 Lifts- Wherever lift is required as per bye-laws, provision of at least one lift
shall be made for the wheel chair user with the following cage dimensions:
Clear internal depth: 1.2 m
Clear internal width: 1.4 m
Entrance door width: 0.9 m
a) A hand rail not less than 0.6 m long at 1.0 m above floor level shall be fixed
adjacent to the control panel. Also, switch control /call button shall be at an
operating height of 0.9 m to 1.2 m.
b) The lift lobby shall be of an inside measurement of 1.8 m x 1.8 m or more.
c) The time of an automatically closing door should be minimum 5 second and the
closing speed should not exceed 0.25 m/sec.
d) The interior of the cage shall be provided with a device that audibly indicates the
floor the cage has reached and indicates that the door of the cage for entrance/exit
is either open or closed.
e) The gap between the lift floor and floor landing shall not be more than 12 mm.
f) Grab bars shall be placed on all three internal sides of the lift car at a height of 0.9
m from the finished floor level. Grab bars shall not have a gap of wider than 0.15 m
at the corners as shown in the Sketch No 4 in Annexure 23.
g) Audio announcement system in lift shall be provided.
3.5 Toilets- One special W.C. in a set of toilet with non-skid surface shall be
provided for the use by the Differently abled persons with essential provision of
wash basin near the entrance: -
a) The minimum size shall be 1.5 m x 1.75 m
b) Minimum clear opening of the door shall be 0.9 m and the door shall swing out.
c) Suitable arrangement of vertical/horizontal handrails with 50 mm clearance
from wall shall be made in the toilet.
d) The WC seat shall be 0.5 m from the floor. The flushing control shall be mounted
on the wide side of the cubicle at a height from 0.6 m to 1.05 m above the finished
floor level.
e) The wash basin shall be mounted with the rim not higher than 0.75 m above the
finished floor level. A clearance of 0.55 m shall be maintained from the finished
floor level to the bottom of the apron.
f) Two horizontal grab rails not less than 0.35 m to 0.50 m shall be provided on the
rear side and on other side (different side from the one with wash basin). Drop
down vertical grab bars shall be provided on both sides of WC. Grab bars shall have
50 mm clearance from the wall. The grip space shall be 0.30 m clear of mounting
wall. One folding grab rail on the wide side of the cubicle adjacent to the WC at a
height from 0.725 m to 0.75 m above the finished floor level when lowered from the
wall.
g) If more than one urinal is provided, at least one urinal shall have a clear leveled
space of not less than 0.80 m wide x 1.5 m deep in front. A vertical grab rail near
urinal.
h) An emergency call bell shall be provided in an accessible WC cubicle.
3.6 Drinking Water- Suitable provision of drinking water shall be made for the
Differently abled persons near the special toilet provided for them.
3.7 Designing for Children- In the buildings, including toilet, meant for the
predominant use by children, it will be mandatory to adjust the height of the
handrail and other fittings and fixtures, etc. suitably.
3.8 Protruded objects in the common areas or common ways
1. Objects or obstructions, with their leading edges at any height above 0.580 m
from the floor level shall not protrude more than 0.1 m in to pedestrian areas as
illustrated in Sketch No 5 in Annexure 23.
2. Objects or obstructions, with their leading edges up to a maximum height of 580
mm from the floor level, may protrude more than 0.1 m into pedestrian are as
illustrated in Sketch No 5 in Annexure 23.
3. Free standing objects placed between the height of 0.58 m and 2.0 m from the
floor level shall have an overhang of not more than 0.3 m as illustrated in Sketch
No 6 in Annexure 23.
4. The maximum height of the bottom edge of free standing objects with a space
of more than 0.3 m between supports shall be 0.58 m from the floor level as
illustrated in Sketch No 6 in Annexure 23.
3.9 Special requirements at public spaces like auditorium and theatre
Provision a. In cinemas, theaters, concert halls, stadia or other places of
&Location public recreation where permanent fixed seating
arrangement is provided, a minimum of two wheelchair
spaces shall be provided for every 200 seats or less.
Additional one wheel chair space shall be provided for every
subsequent addition of 200 seats or part thereof accessible
seating should be distributed and integrated throughout
seating areas of assembly rooms with different vantage
points accessible to all persons with disabilities.
b. Guideline: All entertainment and assembly areas should be
able to cater for and accommodate Differently abled persons
using various mobility aids.
c. Wheelchair spaces should be an integral part of any seating
plan. Efforts must be made to distribute such seating spaces
throughout the seating area and in each pricing tier, arranged
so as not to obstruct the view of persons who may be seated
behind
Dimensions The wheelchair spaces, each measuring 0.9 m x 1.2 m shall be
located alongside the fixed seats to enable wheelchair users to sit
together with their able bodied or ambulant companion.
3.10 Proper signage
a) Appropriate identification of specific facilities within a building for the differently
abled persons should be done with proper signals.
b) Visually impaired persons make use of other senses such as hearing and touch to
compensate for the lack of vision, whereas visual signals benefit those with hearing
disabilities. Signs should be designed and located so that they are easily legible by
using suitable letter size (not less than 20 mm high).
c) For visually impaired persons, information board in brail should be installed on
the wall at a suitable height and it should be possible to approach them closely.
d) Directional signs and tactile guiding path should readily identify and provide a
logical sequence from a starting point to a point of destination and a clear indication
of return routes to the named exits. Clear indication of the existence of steps or
ramps on a route should be provided at both ends of the route
d) To ensure safe walking, there should not be any protruding sign which creates
obstruction in walking.
e) Public Address System may also be provided in busy public areas.
f) The symbols/information should be in contrasting colour and properly illuminated
because people with limited vision may be able to differentiate amongst primary
colours.
g) International Symbol Mark for wheel chair be installed in a lift, toilet, staircase,
parking areas, etc., that have been provided for the differently abled
4.0 Design Guidelines – Streetscapes for Public Street
Road Intersections, Median Refuge, Traffic Signals, Subways & Foot over Bridges
a. Guide strips should be constructed to indicate the position of pedestrian
crossings for the benefit of people with visual impairments and have kerb ramps
b. Raised Median Refuges are to be cut through and levelled with the street
and should have kerb ramps.
c. A coloured tactile marking strip at least 0.6 m wide should mark the
beginning and the end of a traffic island, to guide pedestrian with visual
impairments to its location.
d. Pedestrian traffic lights should be provided with clear audible signals and
these acoustic devices should be installed on a pole at the point at the origin of
crossing and not at the point of destination
e. Signages for Foot over bridges and Subways are to be provided.
f. There should be a provision of slope ramps/lifts at both ends to enable wheelchair
accessibility.
g. Provisions of a sidewalk are to be followed
5.0 Guidelines and Provisions:
For details & additional information/guidelines reference may be made to following
1. The Handbook on Barrier Free and Accessibility”, (2014), Central Public Works
Department, GoI
2. Model Building Bye-Laws, (2016), Town and Country Planning organisation,
Ministry of urban Development, GoI.
3. “National Building Code”, amended up to date (2005), Bureau of Indian
Standards,
4. “National Policy for Persons with Disabilities”, (2006), Ministry of Social Justice
and Empowerment, GoI.
40. Lighting and Ventilation
(1) Adequacy and manner of provision- All parts of any habitable room shall be
adequately lighted and ventilated. For this purpose, every room shall have -
(a) one or more apertures, excluding doors, with area not less than one-sixth of the
floor area of the habitable room, with no part of any habitable room being more
than 7.50 m away from the source of light and ventilation. However, a staircase shall
be deemed to be adequately lighted and ventilated, if it has one or more openings,
their area taken together measuring not less than 1 sq. m per landing on the
external wall;
(b) an opening with a minimum area of 1 sq. m in any habitable room including a
kitchen, and 0.3 sq. m with one dimension of 0.3 m for any bathroom, water closet
or store/prayer Room;
(c) all the walls, containing the openings for light and ventilation fully exposed to an
exterior open space either directly or through a balcony not exceeding 2m. in width
provided that a room meant for non-residential user shall be considered as
adequately lighted and ventilated if its depth from the side abutting the required
open space does not exceed 12 m and in case centrally air-conditioned building may
be allowed to be exceeded up to 20 m.
(2) Artificial ventilation shaft- A bathroom, water closet, staircase or
store/prayer room may abut on the ventilation shaft, the size of which shall not be
less than the values given below:
Height of buildings in Cross-section of ventilation Minimum dimension
metres.(m) shaft in sq. m of one side of shaft
in metres (m).
Upto12 2.8 1.2
Upto18 4.0 1.5
Upto24 5.4 1.8
Upto30 8.0 2.4
Above 30 9.0 3.0
Mechanical ventilation system shall invariably be installed in such ventilation
shafts. Further, such ventilation shaft shall be adequately accessible for
maintenance.
(EP-139)
(3) (2) Artificial Lighting & Mechanical Ventilation- Where lighting and ventilation
requirements are not met through day-lighting and natural ventilation, they shall
be ensured through artificial lighting and ventilation in accordance with the
provisions of Part VIII, Building Service Section I, Lightning and Ventilation,
National Building Code.
(4) (3) In any residential hotel where toilets are provided with a mechanical
ventilation system, the size of the ventilation shaft prescribed in this Regulation
may be suitably relaxed by the Commissioner
41. Open Spaces within Building Plots/ Layout
(1) (a) Open spaces separate for each building or wing. -The open spaces required
under these Regulations shall be separate or distinct for each building and where a
building has two or more wings, each wing shall have separate or distinct open
spaces as required under these Regulations;
Provided that if one of the wings does not depend for light and ventilation on the
open space between the two wings, the said open space shall be the one required
for the higher wing or one required for deriving the light and ventilation whichever
is higher.
Open spaces to be provided for the full consumption of FSI-The open spaces to be
left at the sides and rear shall relate to the height necessary to consume the full
FSI permissible, for the occupancy in the zone.
(b)Manner of computing front open space/setback where the street is to be
widened-If the building plot abuts any road which is proposed to be widened
under the Development Plan or because of the prescription of regular lines of
streets under the Mumbai Municipal Corporation Act, 1888, the front open space
/road-side set back shall be measured from the resulting road widening line.
(c) The front open space shall be measured perpendicular to the road line. The
open spaces for light and ventilation shall be measured perpendicular to the
building line. The open spaces for dead wall shall be measured perpendicular to
compound wall.
(2) Side and rear open space in relation to the height of the building for light and
ventilation-
(i)Residential and Commercial Zones-
(a)The open spaces on all sides except the front side of a building shall be as
follows:
Table A
Sr. Ht. of Side & rear marginal open space Side & rear marginal open
No. Building space
(H) Plot up to 1000 sq. m or where Plot size more than 1000 sq.
average width/depth of plot is m or more and average
less than 20 m width/depth of plot more 20
m
Light & Dead wall Light & Dead
ventilation ventilation wall
1 Up to 32 m Min - 3.6 in case 3.6 m Min - 3.6 in case 3.6 m
of Residential of Residential
building & 4.5 m building & 4.5 m
in case of in case of
commercial commercial
building subject building subject
to H/5 to H/4
2 More than H/5 subject to 6 m H/4 subject to 6m
32 m & up maximum 12 m maximum
to 12 m
70 m
3 More than H/4 or 16 m Max. 9 m
70m & up ---------------------
to 120 m
4 More than ------------------ 20 m 9 m
120 m
Provided further that due to site constraint and where demonstrable hardship is
caused the open spaces as specified in table A above may be allowed to be relaxed
as per table B below, by commissioner by charging premium at 10% of ASR Rate of
the developed land (for FSI 1). The premium so collected shall be used for the
development of infrastructure to mitigate the strain on infrastructure caused due to
such relaxation. The deficient area for the payment of premium shall not exceed the
total BUA of building/s: -
Table B
Sr. Ht. of Side & rear marginal open space Side & rear marginal open
No. Building space
(H) Plot up to 1000 sq. m or where Plot size more than 1000 sq.
average width/depth of plot is m and average width/depth
less than 20 m of plot more 20 m
Light & Dead wall Light & Dead
ventilation ventilation wall
1 Up to 32 m Min - 3.6 in case 3.6 m Min - 3.6 in case 3.6m
of Residential of Residential
building & 4.5 m building & 4.5m in
in case of case of
commercial commercial
building subject building subject
to H/6 to H/5
2 More than 10 m or H/6 6 m 12 m or H/5 6m
32 m & up whichever is less whichever is less
to
70 m
3 More than 14 m or H/5 or 9m
70m & up --------------------- whichever is less.
to 120 m
4 More than ------------------ 18 m 9m
120 m
Provided further that due to site constraint and where demonstrable hardship is
caused the open spaces as specified in table A above may be allowed to be relaxed
as per table C below, by commissioner by charging premium at 25% of ASR Rate of
the developed land (for FSI 1). The premium so collected shall be used for the
development of infrastructure to mitigate the strain on infrastructure caused due to
such relaxation. The deficient area for the payment of premium shall not exceed the
total BUA of building/s:
Table C
Sr. Ht. of Side & rear marginal open space Side & rear marginal open
No. Building space
(H) Plot up to 1000 sq. m or where Plot size more than 1000 sq.
average width/depth of plot is m and average width/depth
less than 20 m of plot more 20 m
Light & Dead wall Light & Dead
ventilation ventilation wall
1 Up to 32 m Min - 3.6 in case 3.6 m Min - 3.6 in case 3.6m
of Residential of Residential
building & 4.5 m building & 4.5m in
in case of case of
commercial commercial
building subject building subject
to H/7 to H/6
2 More than 9 m or H/7 6 m 12 m or H/6 6m
32 m & up whichever is less whichever is less
to
70 m
3 More than 14 m or H/6 or 9m
70m & up --------------------- whichever is less.
to 120 m
4 More than ------------------ 16 m 9m
120 m
Provided further that due to site constraint and where demonstrable hardship is
caused, the open spaces as specified in table A above may be allowed to be relaxed
further with the special permission of Commissioner by charging premium. The
premium so collected shall be used for the development of infrastructure to
mitigate the strain on infrastructure caused due to such relaxation. The deficient
area for the payment of premium shall not exceed the total BUA of building/s.
(EP-140)
Note i) Provision of glass facade without construction of dead wall inside the facade
shall be treated as side deriving Light & Ventilation.
ii) In case of residential building Glass façade shall be permissible in the portion,
which does not derive light and ventilation.
iii) In case of High Rise building with height more than 32 m the requirements of Fire
Safety as specified in these Regulations/Fire Brigade Authorities shall be fulfilled.
Provided further that;
1. the open space for separation between any building and a single storeyed
accessory building need not exceed 1.5 m.
2. the marginal open space(distance)between building and ROS LOS in the same
lay-out shall not be less than 3 m.
In respect of tolerated Buildings/Approved buildings, additional BUA in lieu of
the subsequent set back created due to prescription of Regular Line under MMC
Act 1888/due to proposed widening of road by Appropriate Authority, after
issuance of development permission/Commencement Certificate, may be
permitted at upper floors with step-back to make up for deficiencies in the open
space in case of new development as required under these Regulations subject
to fulfillment of structural requirements or else TDR in lieu of subsequent set
back area as provided under these regulations may be allowed.
(b) Step-back at upper level- The Commissioner may permit smaller step-backs at
upper levels and also permit additional floor area up to a limit of 10 sq. m over
the permissible FSI to avoid structural difficulties or hardship but so as not to
affect adversely the light and ventilation of an adjoining building or part thereof.
(c)Tower-like structures- Notwithstanding any provision to the contrary, a tower-
like structure may be permitted only with 6 m open space at the ground level
and one step-back at the upper levels provided that the total height does not
exceed 32m. If it exceeds 32m but does not exceed 70m, the minimum open
space at ground level shall be 6 m on rear and one side and 9 m on another side
accessible from road. In case of building exceeding the height of 70 m minimum
open space at ground level shall be 9 m and two step-back at upper level up to
the height of 70 m and for the height more than 70 m and up to 120 m three
step-backs and for the height beyond 120 m four step-backs may be allowed. The
step-backs shall be provided in such a way that the required open spaces as per
the provisions of Regulation No. 41(1)(a), 41(2)(i)(a) & 43(1) are maintained at
upper level. The terrace created by the step-back shall be accessible through a
common passage and /or common staircase only.
Provided further that such step backs as stated above may also be allowed on
one or more sides, and however on other sides than the step back, shall have to
maintain the regular open spaces as per these regulations.
(ii)Industrial Zone-
(a) Buildings up to 4 storeys or 16 m in height - The minimum width of the open
space around each building shall be 6m.
(b)Building more than 4 storeys or 16 m in height- The open space dimension
prescribed in (a) above shall be increased by at least 0.25m for every 1 m of
height or part thereof, above 4 storeys or 16 m.
Provided that no such increase in open spaces is necessary if (i) it is a front margin
or (ii) when only store rooms and stairways derive light and ventilation from the
open space.
(3) Provisions in marginal open spaces if the height of the building is restricted-
(a) Notwithstanding the provisions of sub-regulations (2) of this Regulation, the
minimum open spaces in plots in residential and commercial zones may be
relaxed to the values quoted in Table No 17 below, if the number of storeys are
restricted to Ground and one upper floor or Stilt and two upper floors
Table No 17
Provisions in Open Spaces for Plots in Residential and Commercial Zones
Serial Plot Area Type of Minimum open spaces
No. (Sq. m.) Development (in meters)
(4)
(2) (3) Front Rear Side
(1)
21 and above but less than 30 Row 0.75 1.5 …..
(ii)
30 and above but less than 40 Row 0.75 2.25 ….
2.
(ii)
40 and above but less than 60 Row/Semi- 1.00 2.25 1.0 (i)
3.
detached (ii)
60 and above but less than 125 Row/Semi- 1.5 3.0 1.0 (i)
4.
detached
125 and above but less than 250 Row/Semi- 3.0 3.0 1.5 (i)
5.
detached/De
tached
Explanation to Table No 17:
(i) Such side open space will not be required for row housing, but will be required
for semi-detached structure which will have open spaces around the entire
structure. Such side open space shall not be reckoned as the main source of light
and ventilation for habitable rooms of the structure.
(ii) In plots, less than 60 sq. m in area, no front open space need be provided if the
means of access serving such plots is at least 3 m in width.
(iii) A row housing scheme developed as a block shall not be more than 45 m in
length and the distance separating two such blocks shall not be less than 1.5 m.
(iv) Where the amenity open space is accessible from all the lay-out plots and has no
exclusive means of access, the rear marginal open space in plots abutting such
amenity open space shall not be less than 3 m
(b) In case of redevelopment in Gaothan/Koliada/Adivasi Pada with the height
restricted to 4 storeys or maximum 14 m, the ground coverage of the structure shall
not be more than 75% of the plot area and open spaces left at side and rear shall be
as to consume the FSI as permissible and not to affect adversely the light and
ventilation of adjoining buildings and to provide proper drainage facilities.
(4) Front Set-backs from the Street Line/Plot Boundary and set-backs from the
zonal boundary in the different zones shall be as in Table No 18 hereunder.
Table No 18
A. Front set-back from Street Line/Plot Boundary (in meters)
Location of plot Residenti Commercial Industrial
Serial
(2) al Zone Zone
No.
Zone (4) (5)
(1)
(3)
On express highways or roads wider 6.0 6.0 22.5
than 52 m
Areas located in
-island city 3.0 4.5 **
-elsewhere 4.5 4.5 **
Away from road-
-island city 4.5 4.5 4.5
-elsewhere 4.5 4.5 6.0
For plots in
gaothans/Koliwadas/Adiwasi pada, in
suburbs extended suburbs smaller than
250 sq. m.
i) streets less than 6 m NIL N.A. N.A.
ii)streets 6m and more and less than 9m 1 N.A. N.A.
iii)streets 9m and more 1.5 N.A. N.A.
On island city roads listed below* 4.5 4.5 Not
applicable
** Refer to sub-Regulations (2) 41(ii)of this Regulations.
*Gopalrao Deshmukh Marg (Pedder Road), Bhulabhai Desai Road, Babasaheb
Dahanukar Marg (Carmichael Road), Salebhoy Karim Barodawalla Marg (Altamount
Road), Gamadia Road (Walkeshwar Road), Bal Gangadhar Kher Marg (Ridge Road),
Laxmibai Jagmohandas Marg (Nepean Sea Road), Nyayamurti Sitaram Patkar Marg
(Hughes Road), Chowpatty Sea-Face Road, LalaLajpatrai Marg (Hornby Vellard), Dr.
Annie Besant Road, Maulana Abdul Kalam Azad Road, Swatantrya Veer Sawarkar
Marg (Cadell Road), Senapati Bapat Marg, Dr. Ambedkar Road from Byculla Bridge to
Sion Causeway, Rafi Ahmed Kidwai Road.
NOTE: With the approval of the Corporation, the Commissioner may add, alter or amend this
list of roads. For high rise buildings front marginal distance shall be as per Regulation No.43.
B. Segregating distance from Zonal/plot Boundary in Industrial Zones (in meters)
Location of plots Type of building Set-back in zones(m)
Serial
No.
(2) (3) (4)
(1)
Island City Industrial building 6 m
Island City Residential building, if permitted, 9 m
due to conversion of zone.
Island City Other permissible non-industrial (i) 6.00 m up to 32 m in
user if permitted in industrial height
zone. (ii) For heights, more than
32 m,6.00 plus 0.25m for
every meter or part thereof
Suburbs, extended Industrial Building- 6 m
suburbs and new (a) If zone boundary coincides and 22.50 m in case of
reclamation areas with the boundary of hazardous building
at Wadala Salt Pans permanent public open space
such as P.G. Garden, Park etc.
(b)Otherwise 9 m
and 52.50 m in case of
hazardous building
Do. Residential building if permitted 9 m & 52.50 m (For
due to conversion of zone. obnoxious or hazardous
industries adjacent to
residential development.)
Do. Other non-industrial users (i) 6m up to 32min height.
permitted. (ii) For height, more than 32
m, 6 m plus 0.25m for every
meter or part thereof.
Explanation to Table B-
(i) The minimum segregating distance between different zones shall be the distance
as measured from the opposite edge of the road/Nalla/Watercourse (existing or
proposed) in which the zone happens to abut.
(ii)These segregating distances from the adjoining plot as stated above shall not be
insisted upon where non-industrial development has already been permitted by
conversion of zone in the said adjoining plot situated in Industrial zone.
(iii) In the case of residential development and other non-industrial development
permitted in the industrial zone, the area within the segregating distance as
provided in the Table 18-B shall be planted with tress at the rate of not less than 5
per 100 sq. m of such area.
(5) Provisions in open spaces for plots in Reconstruction/Redevelopment Schemes
under the Maharashtra Housing and Area Development Authority Act, 1976, Slum
Rehabilitation Authority and Redevelopment Scheme of municipal tenanted
properties; in case of DCR 33(5), 33(6), 33(7),33(7)(A),33(7)(B), 33(9),
33(9)(A),33(9)(B), 33(10), 33(10)(A), 33(11), 33(15) and 33(20)(A).
The following provisions shall only be applicable in case of rehab and composite
building. Composite building in Rehab scheme is the building where the rehab
component is equal to or more than 50%.
(a) Notwithstanding the provisions contained in sub-Regulations (2) of this
Regulation,
(i) For a building up to height 32 m the front open space shall be 3.0 m.
(ii) For a building, up to height 32 m, side and rear marginal open spaces may be
reduced to 3.0 m.
(iii) for a building with height more than 32 m but up to 70 m the side and rear
marginal open spaces shall not be less than 6 m and for a building with height more
than 70 m the side and rear marginal open spaces shall not be less than 9 m and 12
m beyond 120 m subject to fulfillment of fire safety requirement as specified in
these Regulations.
(6). Open spaces for various types of buildings-
(a) Educational buildings, hospitals, mental hospitals, maternity homes, house of
correction, assembly buildings, mangal karyalaya, markets, stadia, petrol filling and
service stations:
A minimum space 6 m wide shall be left open on all sides from the boundaries of the
plot.
(b) Cinemas/theatres:
(i) Front open space- A minimum open space 12 m wide from edge of the road
or 37 m from the centre of National Highway/State Highway/Major District road,
whichever is more is required. Provided that if adequate parking is provided, and
then with the special permission of the commissioner, minimum front open space
may be reduced to 6 m wide from edge of the road without charging premium.
(EP-141)
Provided further that in case the cinema theater is proposed along with other
permissible uses in building then open spaces as per requirement of special building
will be considered deemed to be sufficient where waiting area for patron is provided
within the building
(ii) Side and rear open space- The side and rear marginal distances to be left open
shall not be less than 6 m wide.
(c) For high rise and special buildings, the provisions as stipulated in Regulation No.
47(1) shall apply.
(7). Provisions regarding relaxation in open spaces in narrow plots-
(a) Narrow plots in residential and commercial zones, viz those less than 15 m wide
or deep will be permitted the relaxation shown in column 3 of Table No 19
hereunder subject to the restrictions in column 4 thereof.
Table No: 19
Open Space Relaxation in Narrow plots in Residential and Commercial Zones.
Plot size/dimension Relaxation Restrictions on building
Serial
No.
(2) (3) (4)
(1)
Depth less than 15 m Rear open space may be No room except store-room and
reduced to 3 m staircase derives light and
ventilation from reduced open
space.
Width less than 15 m Side open space may be No room except store-room and
but more than 11.5 m r e d u c e d to 3 m staircase derives light and
ventilation from reduced open
space.
Depth less than Front open space may be (i) Depth of the building not to
11.5 m but more than reduced to 3 m and rear exceed 5.5 m
9 m open space reduced to (ii) Height not to exceed, 5 storeys
1.8 m or 15 m.
Width less than 11.5 One side open space may (i) Width of the building not to
m but more than 9 m be reduced to 3 m and the exceed 5.5m
other side open space may (ii) Height not to exceed 5 storeys
be reduced to 1.8 m or 15 m
Depth or width less Semi-detached structure (i) Depth of the building not to
than 11.5 m on adjoining plots with exceed 5.5 m
open spaces as at (ii) Height not to exceed 5 storeys
Sr. Nos. 3 or 4 above. or 15 m
Depth or width less Open space may be Only ground floor or stilt + one
than 9 m reduced to 1.5 m all structure.
around
Explanation to Table No 19
1. No dimension of any building in a narrow plot shall exceed 30 m.
The relaxation in Table No 19 shall not apply to any narrow plot where in
reconstruction/redevelopment scheme under the Maharashtra Housing and Area
Development Authority Act, 1976 and Slum Act is undertaken
2. In areas when the majority of the plots is less than 11.5 m in width or depth,
the Commissioner may prescribe building lines in which row houses would be
permissible.
3. For the purpose of this regulation plot area shall be reckoned after deduction
of ‘area of the plot to be handed over to MCGM/Appropriate Authority’ under these
Regulations.
(b) Narrow plots in industrial zones, viz. those having one dimension smaller than 16
m will be allowed the relaxation subject to the restrictions in Table No 20
hereunder.
Table No: 20
Open Space Relaxation in Narrow Plots in Industrial Zones
Relaxation Width Depth Width between Depth Width Depth
Sr.
granted in less less than 10.5 m. up to between between between
No
or condition than 10.5 m 12 m 10.5 m. up 12m up to 12m up
imposed on 10.5 m to 18 m to 18 m
12 m
(2) (3) (4) (5) (6) (7) (8)
(1)
Open space Side Rear open (i) May be May be One side Rear
... open space reduced on one reduced at open space open
space may be side to 4.5 m. the rear to may be space
may be reduced (ii) The other side not less reduced to may be
reduced to may be reduced than 1.8 m 1.8 m reduced
to 1.8 m 1.8 m to 1.8m 1.8 m
Building
dimensions,
2.
etc.-
(i) Maximum 6 m 30 m 6 m 30 m 30 m
6 m
width
(ii)
Maximum 30 m 6 m 30 m 6 m 30m 6 m
depth
(iii)Maxim-
um height 4.5 m 4.5 m 8 m 8 m 8 m
8 m
(iv)No. of
storeys One One Two Two Two
Two
(v) Walls Dead Dead wall Dead wall 40 cm Dead wall Dead
Dead wall
walls 40 40 cm thick facing the 40 cm thick wall 40
40 cm thick
cm thick thick on reduced open facing the cm thick
facing the
on both the rear space, as in Serial rear side. facing
reduced
sides. side. No.(i), (ii)above of the rear
open
this column. side.
space.
Note: - i) The restriction in Table No 20 shall not apply to any narrow plot where in
reconstruction/redevelopment scheme under the Maharashtra Housing and Area
Development Authority Act, 1976 and Slum Act is undertaken.
ii) For the purpose of this regulation plot area shall be reckoned after deduction of
‘area of the plot to be handed over to MCGM/Appropriate Authority’ under these
Regulations.
(8) Interior open spaces (chowks)-
(a) Inner chowk-Unless it abuts on a front, rear, or side open space, the whole/part
of one side of every room other than a habitable room shall abut on an interior
open space, courtyard or chowk, whose minimum width shall be 3 m. Such interior
space, courtyard or chowk shall be accessible at least on one side at ground floor
level through a common passage or space. Further, the inner chowk shall have an
area at all its levels of not less than the square of one fifth of the height of the
highest wall abutting the chowk:
Provided further that the maximum dimension of an inner chowk may not be
insisted more than the required open spaces as stipulated in this regulation.
Provided further that when any room (excluding the stairway bay, the bathrooms
and water closet) depends for its light and ventilation on an inner chowk, the
dimension shall be such as is required for each wing of the building.
(b) Outer chowk. - The minimum width of an outer chowk (as distinguished from its
depth) shall be 2.4 m, but if the depth exceeds the width, the open space between
the wings shall be regulated by Regulation 41(2)(i)(a), when any habitable room
depends on light and ventilation on such outer chowk. A recess less than 2.4 m
wide shall be treated as a notch and not as a chowk.
(9). Open spaces to be unencumbered- Every open space whether interior or
exterior shall be kept free from any erection thereon and shall remain open to the
sky except the feature covered by the next Regulation 42.
42. Features permitted in open spaces
Certain features may be permitted in the prescribed open spaces (except in case of
high rise buildings where minimum 6 m clear marginal open space shall be observed from
two side) as enumerated below:
(EP-142)
(i) Permitted in the side or rear marginal open spaces:
(a) Where the facilities in an existing building are inadequate, a sanitary block (i)
not exceeding 3 m in height and 4 sq. m in carpet area. (ii) at least 7.5 m from the
road line or the front boundary and 1.5 m from other boundaries and (iii) at least
1.5 m away from the main building.
(b) Covered parking spaces at least 7.5 m away from any access road, subject to
Regulation No. 44 (6)(d)
(c) Suction tank, pump room, electric meter room or sub-station, garbage
shaft/refuse chute, facility for treatment of wet waste in situ, space required for fire
hydrants, electrical and water fittings, water tank, dust-bin, etc.
(ii) Other features permitted in open space:
(a) A rockery, well and well structures, plant nursery, water pool, or fountain
swimming pool (if uncovered and only beyond the required open space as required
under these Regulations), platform around a tree, tank, bench, gate, slide, swing,
ramp, compound wall without affecting maneuverability of vehicles;
(b) A cantilevered and unenclosed canopy over each entrance and staircase not
more than 5.5 m long may be permitted as specified in Regulation No 37(2119)
(c) An unenclosed porch open on three sides, not more than 5.5 m in length parallel
to the main building in front of common entrance only and except rear open space
with level difference of 0.3 m in relation to the floor level as specified in Regulation
No. 37 (2018). No part of such porch shall be less than 1.5 m from the plot
boundary.
(d) A balcony may be permitted as specified in Regulation No. 37(2220).
(e) (i) A chajja, cornice, weather shade, sun-breaker; at lintel level, only and Vertical
fins (excluding columns) projecting not more than 1.2 m from the face of the
building. No chajja, cornice, weather shade, sun-breaker etc. shall reduce the width
of the required open space to less than 2.5 m. further. Further chajja, cornice,
weather shade, sun breaker or other ornamental projections etc. shall be
permissible up to 0.60 m in Gaothan area for the plots admeasuring up to 250 sq. m.
However, in case of redevelopment scheme under Regulation No. 33(7) where
marginal distances are less, chajja projection maximum up to 0.45 m may be
allowed.
(ii) The ornamental projection, flower beds, etc. projecting not more than 1.2 m
from the face of the building. No ornamental projection, flower beds, etc. shall be
permissible, which will reduce the width of the required open space to less than 2.5
m
(iii) Platform of width not more than 0.45 m and length 2.0 m at the height not less
than 0.60 m above floor level for installation of Air-conditioning split unit not
reducing the open spaces as per above
(f)(i) A chajja, cornice, weather shade, sun-breaker over a balcony or gallery, its
projection not exceeding 0.75 m from the balcony or gallery face with a level
difference of 0.6 m in relation to the floor level. However, in case of redevelopment
scheme under Regulation No. 33(7) where marginal distances are less, chajja
projection maximum up to 0.45 m may be allowed.
(ii) The Ornamental projection, flower bed etc. over a balcony or gallery, its
projection not exceeding 0.75 m. from the balcony or gallery.
(iii) Platform of width not more than 0.45 m and length 2.0 m at the height not less
than 0.60 m above floor level for installation of Air-conditioning split unit not
reducing the open spaces as per above.
(g)Watchman's booth not over 3 sq. m in area.
Note:-At least 1% of the cost of construction of the building, shall be utilized for
enhancing the aesthetical look and aesthetical features in case of Public buildings.
43. Heights of Buildings
(1) Height vis-à-vis the road width- The height of a building shall not exceed two
three times the total of the existing or prescribed width of the street on which it
abuts and the required front open space. The restrictions of height of the building
spelt out in this Regulation shall however, cease to apply in case where the plot
fronts on road having width as specified in Regulation No.19 and where front
marginal open space of minimum 9m in case of abutting road having width up to 9m
&12 m in case of abutting road having width more than 12 m or more is available,
provided that open spaces as on other sides are made available as required from the
fire safety point of view.
Explanation- (i) "Prescribed width" here means the width prescribed in the DP or
the width resulting from the prescription of a sanctioned regular line of the street
under the MMC Act, whichever is larger.
(ii) If a building abuts two or more streets of different widths, it shall be deemed for
the purpose of this Regulation to abut the wider street
Provided however, that restrictions on height spelt out in this Regulations shall
not be applicable for reconstruction and redevelopment undertaken under
Regulations 33(5), 33(6), 33(7), 33(7)(A), 33(8), 33(9), 33(9)(B),33(10), 33(10) (A),
33(11), 33(15) and 33(20) (A) of these Regulations.
(2) Buildings intended for hazardous godowns, storage of inflammable materials or
storage of explosives shall be single-storeyed structures only.
(3) The height and character of an industrial chimney in the area for which clearance
of the Civil Aviation Authorities is required under these Regulations shall be
prescribed by the Civil Aviation Authorities.
44. Parking Spaces
Wherever a property is developed or redeveloped, parking spaces at the scale laid
down in these Regulations shall be provided. When additions are made to an
existing building, the new parking requirement will be reckoned with reference to
the additional space only and not to the whole of the building and to the area where
the use is changed.
(1) General Space Requirement-
(i) Types-The parking spaces mentioned below include parking spaces in basements,
parking floor, and podium or on a floor supported by stilts, or on upper floors,
covered or uncovered spaces in the plot.
(ii) Size of Parking Space-The minimum sizes of parking spaces to be provided shall
be as shown below-
Type of Vehicle Minimum size/Area of parking space
(a) Motor vehicle 2.5 m x 5.5 m
(b) Scooter, Motor-cycle 3 sq. m (Least dimension shall be minimum1.2 m)
(c) Bicycle 1.4 sq. m
(d) Transport Vehicle 3.75 m x 7.5 m
Note- In the case of parking spaces for motor vehicles, up to 50 per cent of the
prescribed space may be of the size of 2.3 m x 4.5 m.
(iii)Marking of Parking Spaces-Parking spaces shall be paved and clearly marked for
different types of vehicles.
(iv)Maneuvering and other ancillary spaces- Off-street parking space must have
adequate vehicular access to a street, and the area shall be exclusive of drives,
aisles and such other provisions required for adequate maneuvering of vehicles.
(v)Ramps for Basement Parking-Ramps for parking in basements shall conform to
the requirements of sub-regulations (1816) of Regulation 37.
(2) Quantitative Requirements-Four wheeled auto-vehicles-Parking spaces for four
wheeled auto vehicles shall be provided as in Table No 21 below, any fractional
space of more than half resulting from the ratios in column (3) thereof being
rounded off upward to the nearest integer.
Provided that the Government may change parking requirements, as per the
recommendations of the committee constituted by the Government in this regard.
Table No: 21
Off Street Parking Spaces
Occupancy Parking Space required
Sr.
No.
(2) (3)
(1)
(i)Residential In the Island City areas, Suburbs and Extended
Suburbs;
One parking space for every.
a) 4 tenements having carpet area up to 45 sq.
m each.
b) 2 tenements with carpet area exceeding 45
sq. m but not exceeding 60sq.m each.
Provided further that in case of (a) & (b), at the
option of owner/developer, may provide one
parking for each tenement.
Occupancy Parking Space required
Sr.
No.
(2) (3)
(1)
c) 1 tenement with carpet area exceeding 60
sq. m but not exceeding 90 sq. m
d) 1/2 tenement with carpet area exceeding 90
sq. m
In addition to the parking spaces specified in
(a), (b), (c) & (d) above, parking for visitors
shall be provided to the extent of 25 per cent
of the number stipulated above, subject to
minimum of one.
Provided that for the redevelopment under
Regulation 33(5), 33(6), 33(7),
33(7)(A),33(9),33(9)(B), 33(10) 33(10) (A),
33(11) (A),33(15) & 33(20) (A) the parking shall
be as follows.
One parking space for every.
a) 8 tenements having carpet area up to 45 sq.
m each
b) 4 tenements with carpet area exceeding 45
sq. m but not exceeding 60 sq. m each
c) 2 tenements with carpet area exceeding 60
sq. m but not exceeding 90 sq. m each.
d) 1 tenement with carpet area exceeding 90
sq. m
In addition to the parking spaces specified in
(a), (b), (c) & (d) above, parking spaces for
visitors shall be provided to the extent of 25
per cent of the number stipulated above,
subject to minimum of one
(ii)For five, four and three One parking space, for every 75- 100sq. m of
star hotels. For all starred total floor area.
category hotels
(iii)For lodging
One parking space, for every 120-sq. m of total
establishments.
floor area of a lodging establishment.
iv) For Hotels
One parking space for every 75- 100 sq. m of
total floor area of a lodging establishment
b) For hotels and eating houses, one parking
space for every 30-25 sq. m of restaurant
including hall, dining room, pantry & bar
Educational One Parking space for 35 sq. m carpet area of
Occupancy Parking Space required
Sr.
No.
(2) (3)
(1)
the administrative office area and public
service area.
Assembly and assembly
3 a) One parking space for 12 seats / persons.
halls or auditorium
b) Without fixed seats, one parking space for
(including those for
every 15-sq. m of floor area.
educational uses and
c) For canteen, bar and restaurant additional
hostels)
parking required under these Regulations for
other permissible users as per provisions made
herein for such purposes shall be provided.
Government or semi- One parking space for every 37.5 sq. m of
public or private office office space up to 1500 sq. m and for every 75-
business buildings sq. m of additional space for areas exceeding
1500 sq. m in other areas.
Mercantile (Markets,
5 One parking space for every 40-sq. m of floor
Departmental stores,
area up to 800 sq. m and one parking space for
Shops and other
every 80-sq. m of space for areas exceeding
commercial uses). (I.T.
800 sq. m provided that no parking space need
Parks)
to be provided for floor area up to 50 sq. m
Industrial One Parking space for every 150-sq. m thereof
subject to a minimum of two spaces
Storage One Parking space for every 150-sq. m thereof
subject to a minimum of two spaces
Hospitals and Medical One parking space for every 150-sq. m of total
Institutions floor area, except that it would be one parking
space for every 600-sq. m of the total floor
area in the case of Govt. and Municipal
hospitals and Medical institutions. In addition,
one parking space for ambulance parking
measuring 10 m x 4 m for hospitals or medical
institutions with bed strength of 100 or more.
Cinemas and theatres Parking spaces equivalent to eight per cent of
9.
the total number of seats with additional
parking as otherwise also required for other
permissible users in conjunction with that of
cinema/theatre.
Shopping/Convenience One parking space for every 150-sq. m of total
10.
Shopping (not included floor area in the case of shopping user with
under Mercantile each shop up to 20 sq. m in area and one
Occupancy Parking Space required
Sr.
No.
(2) (3)
(1)
Occupancy) parking space for every 50-sq. m of total floor
area for shops each over 20 sq. m area.
Stadia and Clubs (included One parking space for every 100 seats plus
under Assembly additional parking as in these Regulations for
Occupancy) occupancies like those of restaurants, etc.
within such stadia or clubs
Note:
(i) In gaothan/koliwada/Adivasi pada areas and on narrow plots up to 9 m in width,
the requirement of parking spaces may not be insisted upon. Further in case of
addition/alteration/reconstruction/redevelopment of Heritage Grade I & II
structures where plinth/façade of building is required to be retained, requirement
of additional parking spaces as per this Regulation, over and above the existing
parking shall not be insisted.
(ii) The provision of parking spaces in case of redevelopment schemes under DCPR
33(5), 33(6), 33(7), 33(7)(A),33(9), 33(9)(B), 33(10),33(10) (A),33(11),33(15) &
33(20) (A) where sale component is proposed in separate building or in case of
non-composite building, may be allowed as per the regular development.
(iii) In case of uses of Data Centre, Data ware houses the requirements of the parking
to the extent of 50% as stated in this regulation shall be permissible. Provided that
in future if change of user/activity is sought in such case then provision of parking
requirement as per this regulation will have to be provided.
(EP-143)
(3) Other vehicles- For all non-residential, assembly and non-assembly
occupancies, 10 per cent additional parking spaces, subject to a minimum of two
spaces shall be provided in addition to what is prescribed in these Regulations.
(4) Two wheeled motor cycle - Two wheeled motor cycle parking space one for
every two residential tenements may be provided. For other occupancies, two
wheeled motor cycle parking space equal to the required number of four wheeled
parking spaces may be provided. If such parking for two wheeled motor cycle is
proposed, the same may be distinctly shown in the plan.
(5) Transport Vehicles- In addition to the parking spaces provided for
mercantile (commercial) buildings like offices, markets, departmental stores and
for industrial and storage buildings, parking spaces for transport vehicles shall be
provided at the rate of one space for each 2000 sq. m of floor area or part thereof
exceeding the first 400 sq. m of floor area. The space shall not be less than
3.75mx 7.5 m in size and more than 6 spaces need not be insisted upon.
(6) Parking Spaces: Where to be accommodated-The parking spaces including
mechanical/automated may be provided-
(a) Underneath the building, in basements, podiums, within its stilted portion, or
on upper parking floors or in separate structures if exclusively used for parking.
Note:
(i) The deck parking inclusive of car lifts & passages thereto shall be counted in FSI.
Moreover, in Mall, the provision of parking can be made at the floor level wherein
shopping has been proposed, separated by the construction of shear wall with a
gap of 1.5 m. between Mall building and parking floor.
(ii)Additional parking spaces beyond the parking spaces as stipulated in this
regulation at the option of developer is proposed then the construction area for
the additional parking to the extent of 25% shall be allowed on payment of
premium at the rate of 25% of ASR of open land (for FSI 1), beyond 25% and up to
50% on payment of premium at the rate of 50% of ASR of open land (for FSI 1) and
beyond 50% on payment of premium at the rate of 100% of ASR of open land (for
FSI 1). For this purpose, maximum area of construction per car parking space shall
be considered at 25 sq. m excluding the area required for effective maneuvering,
passages, slopes/ramps columns, car lifts etc. and 40 sq. m including the area
required for effective maneuvering, passages, slopes/ramps columns, car lifts etc.
(iii) Where entire parking is proposed by mechanical/automatic means, additional
parking to the extent of 10% of the required parking shall be permitted free of FSI
as vehicle holding area.
(b) In the side and rear open spaces, but not in the amenity open spaces, if-
(i.) they are unenclosed but uncovered except as provided in (d) below;
(ii.) they do not consume more than 50 percent of the open space;
(iii) a minimum distance of 3 m around the building is kept free of parking for
proper maneuverability of vehicles;
(iv) they are at least 7.5 m from the road boundary in case of detached covered
garages;
(v) the parking layouts meet the requirements of the Chief Fire Officer in the case
of multistoried, high rise and special buildings.
(c) in a residential zone, beyond the compulsory side and rear open spaces
stipulated in Sr. No g of Regulation 28 of, if other conditions under sub-rule (b)
above are satisfied. Here the parking space may be an unenclosed covered space.
(d) in a residential zone, with covered parking garages with open type enclosures
of a size of 2.5 m x 5.5 m with a height of 2.75 m above ground level, at the rate of
one covered garage for every 400-sq. m or part thereof of plot area, in side or rear
open spaces, at a distance of not less than 7.5 m from any street line or the front
boundary of the plot:
Provided that the same is 1.5 m from the building and the condition in (b) (v)
above is complied with.
(7) Cinemas, Theatres and Assembly Halls-Subject to the provisions of sub
regulation (6) above, in sites of cinemas, theatres, auditoria and assembly halls,
one row of uncovered parking may be allowed in the front margin space of 12 m or
more, if the clear vehicular access way is not reduced to less than 6 m
(8) Common Parking Space if the total parking space required by these
Regulations is provided by a group of adjoining property owners for their mutual
benefit, such use of this space may be construed as meeting the off-street parking
requirements under these Regulations subject to the approval of the
Commissioner. If such common parking space is proposed for a group of
buildings, the owners of such buildings shall submit a parking layout thereof and
also a registered undertaking stating that the area earmarked for the parking
space will not be built upon.
45. Restrictions on Development in certain areas
Height and other restrictions in certain areas
(A) Funnel of Vision
(a) In areas around the Nehru Centre.-
Notwithstanding anything contained in these Regulations, the height of any
building proposed for erection, re-erection or development in the area
surrounding the Nehru Centre Complex bounded on the South and East by
Keshavrao Khadye Marg (Clerk Road), from the east side of Haji Ali Junction, on
the north-east by Dr. E. Moses Road (extended to the north-east of the Race
Course) (up to the east side of Dr. Annie Besant Road meeting its junction up to
Haji Ali); shall not exceed a height of 18.3 m. above the average surrounding
ground level.
Provided however that, restrictions on height spelt out in this Regulation in
areas around the Nehru Centre building shall not be applicable for the buildings to
be constructed for implementation of slum Rehabilitation Scheme under
Regulations No. 33 (10) & 33 (11) of these Regulations, as well as for
reconstruction and redevelopment of old buildings undertaken under
Regulations 33(7), 33(9), and for development under Regulation 33(3) of the said
Regulation for proposed buildings of Government, Semi-government and public
sector undertaking.
However the height of buildings so constructed shall always be less by 6.0
m than the height of existing Nehru Centre Building.
(EP-144)
(a) (b)Preserving the view from the Phiroz shah Mehta Garden-
Notwithstanding anything contained in these Regulations, to preserve the
western view from the Phiroz shah Mehta Garden on Malabar Hill, two funnels of
visions have been marked on the land use(Development)plan of “D’’ Ward.
(i) No development will be permitted in the inner funnel of vision, and
(ii) a building within the outer funnel of vision shall not be erected or raised above
Reduced Level 75.44; with reference to Town Hall Datum.
(b). (c)Preserving the eastern and southern view of the Backbay Area, Marine
Drive-
Notwithstanding anything contained in these Regulations, to preserve the eastern
and southern view of the Backbay and the Marine Drive area from Kamla Nehru
Park on Malabar Hill, a funnel of vision has been marked on the land
use(development) plan of “D’’ Ward.
No building shall in this funnel of vision shall be raised or erected to the height of
more than 21.35 m or such lesser height as the Commissioner may prescribe which
would include the terrace, staircase or lift room, elevated water storage tank or
any other building feature.
Provided that the Commissioner may, with the prior approval of the Government,
permit a building more than 21.35 m high after due consideration of the contours
of the area, surrounding developments and plot location, the objective being not
to obstruct the view within the funnel of vision
(c) (d)The Commissioner may, for reasons to be recorded in writing, prescribe for
any building or structure a maximum height, which may be less than that
permissible otherwise under these Regulations.
(d) (e) The height restriction as in clauses (a) and (b)(c) above will apply only to a
the portion of plot falling entirely within the lines of the funnel of vision as
marked on the DP
(B)Height restrictions in the vicinity of aerodromes
(I)For structure, installations or buildings including installations in the vicinity of
aerodromes,
a) The height shall be restricted to permissible top elevation as mentioned on
Colour Coded Zoning Maps (CCZM) prepared by the Airport Authority of India (AAI)
published on its web site.
b) For the any additional height beyond that mentioned in a) above, prior NOC
from AAI shall be submitted.
c) For the areas depicted in red colour on CCZM the prior NOC from AAI shall be
submitted.
Note-
The height permitted by CCZM is indicated Above Mean Sea Level i.e AMSL
Building height permitted i.e. Above Ground level (AGL) shall be calculated as
CCZM height minus the site elevation of the plot.
Height of building (AGL)=CCZM height – site elevation.
Explanation (I) Irrespective of their distance from the aerodrome, even beyond the
20-km limit from the aerodrome reference point, no building, radio masts or
similar installation exceeding 150 m in height shall be erected without the
permission of the Civil Aviation Authorities.
(II) The location of a slaughter house/abattoir/butcher house or other areas for
activities like depositing of garbage which may encourage the collection of high
flying birds, like eagles and hawks, shall not be permitted within 10 km from the
aerodrome reference point.
(C)Building sites abutting railway track boundary- Subject to the requirements of
set-backs from roads and side and rear marginal open spaces under the relevant
Regulations, no new construction of a building or reconstruction of an existing
building shall be allowed within a distance of half the height of the said building
from the railway track boundary, and in any case not within a distance of 3 m from
such boundary.
Building sites situated within 30 m from Railway Track Boundary:
No Objection Certificate from the concerned railway shall be insisted upon before
granting Commencement Certificate for the proposed building between the
railway track boundary and the distance of 30 m from it. The development of such
plot shall be carried out as per terms and conditions stipulated by the Railway
Authority.
No NOC from Railway Authority will be required wherever any construction is
undertaken beyond 30 m from the Railway land track boundary subject to the
condition that no part of building shall project within 30 m from the Railway land
track boundary.
(D). Distance from electricity lines- No verandah, balcony or the like shall be
constructed/reconstructed or any additions or alterations shall be made to a
building on a site within the distance stated below from any overhead electric
supply line:
Vertically Horizontally
(a) Low and medium voltage lines and service 2.5 m 1.2 m
lines
(b) High voltage lines up to and including 3.7 m 2.0 m
33,000 V.
(c) Extra High voltage beyond 33,000 V. 3.7 m 2.0 m
(Plus 0.3 m for (Plus 0.3 m
every additional for every
33,000 V or part additional
thereof) 33,000 V or
part
thereof)
Explanation- (i) the minimum clearance as above shall be measured from the
maximum sag for vertical clearance and maximum deflection due to wind pressure
for horizontal clearance.
(ii) In the development of plot affected by overhead transmission electric lines the
portion of plot under overhead electric supply lines may be used as LOS as
required under Regulation No 27 by observing all safety measures without
allowing any habitable construction in the said LOS under said Regulation and shall
be free of encumbrances.
(iii) The Electric Company shall phase out removal of these overhead electric
supply lines in time bound manner. The electric company shall phase out removal
of these overhead electric supply lines in time bound manner as per prevailing
section of Central Electricity Authority Regulations, 2010.
(EP-145)
(E) Other restrictions in height- For the purpose of operational requirement of
buildings, structures or installations or for the purpose of telecommunications or
other forms of communications of the Departments of the Government of India or
the State Government or public sector undertakings, the Commissioner may for
reasons to be recorded in writing, restrict the height of any building in the vicinity
of such buildings, structures or installation, and may also permit the prescribed
heights to be exceeded for such buildings, structures or installations themselves or
for any other statutory communication requirement.
(F) Restriction on Development of sites of existing Fuel Station-
Notwithstanding anything contained in these regulation, in In the redevelopment
sites of existing filling and service station of Petrol, Diesel, Compressed Natural
Gas or any other Motor Vehicle Fuel, change of use shall not may be permitted by
retaining minimum area required as per these Regulations for existing filling and
service station of Petrol, Diesel, Compressed Natural Gas or any other Motor
Vehicle Fuel, for the uses as permissible under these Regulations with separate
plot & access subject to NOC from Controller of Explosive and CFO.
(EP-146)
(G) Structures not included in reckoning height-
The following appurtenant structures shall not be included in reckoning the height
of a building except while considering the requirement of Civil Aviation Authorities
and other statutory communications requirements:
Roof tanks and their supports, ventilation/air-conditioning shafts, lift-rooms and
similar service equipment, stair covers, chimneys and parapet walls, architectural
features not exceeding 1.5 m in height, television antenna, booster antenna, IT
Equipment and wireless transmitting and receiving towers.
Note: Provided that if due to the aforesaid restrictions, the Zonal (Basic)
FSI/Protected BUA as per Regulation No. 30 (C) cannot be consumed fully, then
the unconsumed Zonal (Basic) FSI/Protected BUA can be availed in the form of
TDR.
Govt. will prepare a separate policy. (Kept in Abeyance)
46. Signs and Outdoor Display Structures
(1) National Building Code to apply- The display of advertising signs and outdoor
display structures on buildings and land shall be in accordance with the policy of
MCGM if any or otherwise it shall be in accordance with Part X-Signs and Outdoor
Display Structures, National Building Code of India as amended from time to time.
(2) Residential/Commercial/Industrial Building-The following non-flashing and
neon signs with illumination not exceeding 40 Watt light-
(a) One name plate with an area not exceeding 0. 1 sq.m for each dwelling
unit/unit.
(b) For other uses, permissible in the zone, one identification sign or bulletin
board with an area not exceeding 10 sq. m provided the height of the sign does
not exceed 1.5 m.
(c)"For sale" or "For rent” signs for real estate, not exceeding 2 sq. m in area
provided they are located on the premises offered for sale or rent.
(3) No advertising sign or outdoor display structures shall be permitted on
buildings of architectural, aesthetical, historical or heritage importance as may be
decided by the Commissioner, or on Government buildings, save that in the case of
Government buildings only such advertising signs or outdoor display structures
may be permitted that relate to the activities of the said buildings and related
programs.
(4) In no case, the sign/display structure erected on buildings shall exceed the
height of topmost part of the Building/height prescribed by the Civil Aviation
Authority
(5) No signs /display structure shall obstruct the light and ventilation of the
building.