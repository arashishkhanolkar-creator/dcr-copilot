# Part III: Land Uses and Manner of Development

13. Development Stipulations.
(1) General: In every case of development/re-development of any land, building
or premises, the intended use shall conform to the use zones, purpose of
designation, allocation or reservation as the case may be, unless specified
otherwise.
(2) Development of the designation existing amenity/reservation/partly
designated existing amenity /partly reserved/amenity Plot:
a) Development of the designation existing amenity: Where a building on a
site comprises a designation existing amenity, the development of such land
shall necessarily comprise minimum BUA equal to the existing designation
existing amenity. Any balance permissible BUA, thereafter, may be put to use
in conformity with development otherwise permissible in these Regulations.
In Development Plan if plot is designated existing amenity for a public
purpose with plus (+) sign, then existing authorized BUA which is being used
for the said public purpose shall be maintained during
reconstruction/redevelopment of said plot.
Provided that where the Commissioner with special written permission,
decides that the said designated existing amenity is no longer required in
view of the available amenity in the vicinity, then the amenity shall be
developed for other public purpose considering the deficiency in the
administrative ward.
Provided further that, on surrender of tenancy by MCGM/Appropriate
Authority in a private designated existing amenity plot, the designation
existing amenity on the said plot shall be deemed to be lapsed. The use of
the existing amenity on the private land is stopped with due permission from
competent authority. Such private land can be developed with the special
permission of the Commissioner for the permissible land uses in the said
zone.
If schools which have been developed on unreserved plots and are now
designated existing amenity in RDDP 2034 considering their land use, desire
to redevelop in future with the additional benefits of FSI available in DCPR,
they shall comply with all other regulations of DCPR/ terms & conditions /
policy of Govt. regarding schools issued from time to time. By virtue of
showing the existing land use as designation existing amenity in respect of
school will not give the status of authorization unless it is constructed
authorisedly as per the then prevailing DCR/ terms & conditions / policy of
Govt.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
(EP-19)
Provided further that if a land is designated existing amenity and such
designation existing amenity is spread over a number of adjoining plots as
per DP 2034 and if any of such plot has not contributed towards its
reservation as per DP 1991 now forming designation existing amenity, such
plot will be deemed to be reserved for such purpose and shall be developed
as per Regulation No 17.
Exception: Traffic Islands constituting part of the road may be merged with
carriageway in order to improve the traffic movement with the special
written permission of Commissioner.
(EP-20)
b) Development of Reservations: Land reserved in the DP shall be developed as
per the provisions of Regulation No.17, Table No.3, 4 & 5 for land use and
manner of development.
c) Development of land partly designated/reserved/partly of existing
amenity: Where a building exists on a site shown as designation existing
amenity or reservation in the DP, only its appropriate part of land as used for
such designation existing amenity or reservation, shall be used for the said
purpose and the remaining part of the land/building of the developable land
may be put to use in conformity with the purpose of development as
otherwise permissible in these Regulations.
d) Development of Amenity plot: Wherever lands are received by the Planning
or Appropriate Authority as an amenity plot as per the provisions of these
Regulations, such entire plot shall be used exclusively for public purpose as
decided by the Municipal Commissioner, without applying provisions of
Accommodation Reservation (AR) under Regulation No. 17, unless otherwise
specifically allowed.
(3) Combination of public purposes/uses in reserved sites: Where the Corporation
or the Appropriate Authority proposes to use land/building/premises reserved
for a specific public purpose/purposes, for a different public purpose/purposes,
it may do so, with the previous approval of the Government, provided that the
combination of such different uses conform to these Regulations and the
permissible use in the zone in which the site falls. Provided further that this
shall not apply
(a) to any site being developed for education, wherein a branch of a
bank/ATM may be allowed,
(b) to any site being developed for health, wherein shops of pharmacists
or chemists / ATM may be permitted,
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
(c) to any site encumbered by another non-educational user and being
redeveloped for educational purposes, in which case the existing non-
educational uses may be allowed to continue without any increase in
the net floor area covered by them, and
(d) to any site Public Open Space(POS)
(4) Reservation for Multiple Public Purposes: Where land is reserved for multiple
public purposes in the DP, the distribution of land area/BUA under reservation
for each public purpose shall be preferably equal.
Provided further that, if the plot is reserved for some public purpose with plus
(+) sign, then at least 50% of the plot area shall be developed for the purpose
for which it is reserved in DP and rest of the plot can be developed for other
purposes related to plus (+) sign as per the deficiency in that ward.
(EP-21)
Provided further that where specific percentages of multiple public purposes are
specified in DP, the said percentage shall prevail.
Provided further that where reservations for public amenities are proposed on
plots already designated (with developed amenity, but with potential of the land
not fully utilized), then in such cases, the areas of reservation/s will be as
decided by the Municipal Commissioner, if not defined by DP.
(5) Area of reserved land: The area of the reservation shall be considered after
deduction of area under proposed DP Road/Sanctioned Prescribed Regular
line/Existing Municipal Road affecting the reservation.
(6) Shifting and/or interchanging the purpose of designations existing amenity
/reservations: In the case of specific designations existing amenity /reservations
in the DP, the Commissioner, with the consent of owners may shift, interchange
the designation existing amenity /reservation in the same or on, adjoining
lands/buildings in the same zone, provided that the relocated designation
existing amenity/reservation abuts a public street of same width or more as per
DP and shall have the same amount of visibility from the road and it is not
encumbered and the area of such designation existing amenity /reservation is
not reduced.
The Municipal Commissioner shall pass the reasoned order for the aforesaid
changes and intimate the same alongwith plan to the Director of Town Planning,
Pune & State Govt.
Provided that no such shifting of designation/reservation shall be permissible
(a) if the reservation proposed to be relocated is in parts;
(b) beyond 200 m. of the location in the DP;
(c) beyond the same holding of the owner in which such reservation is located;
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
(d) unless the alternative location and size at least similar to the location and
size of the DP as regards to access.
(e) Balance part of the reservation shall have sufficient area and proper access.
(EP-22)
(7) Art and Culture: The Commissioner may permit temporary use of POS such as
Gardens, Leisure Parks, multi-purpose community centers, libraries, reading
rooms, public halls, Heritage area and Heritage Precincts, educational
complexes, parking lots, institutional areas and the like for the purpose of Art
and Culture including circus, jatra, folk dance, meditation and related activities
in defined time slots, when the primary functions and uses of such spaces are
not being performed. In allowing such user, under no circumstance, the
activities of the primary user shall be compromised or impaired. In allowing
such use, it should be ensured that the primary use is not compromised/
impaired.
(8) Temporary Vending Zone: The Commissioner may, through special permission,
allow certain designated existing amenity lands or premises, as determined by
the Commissioner, such as public parking lots, to be brought under vending
zone. During such time slots (not more than one to four hours per week on
weekends), the primary user of the designated existing amenity land/premises
shall remain temporarily suspended. However, the normal functioning of the
primary user, under no circumstance, shall be compromised or displaced. In
allowing such use, it should be ensured that the primary use is not
compromised/ impaired.
(9) Art & Culture, Temporary Vending Zone/Bajar-hat/Athawadi Bazar/Equal
Street: The Commissioner shall identify and provide space for Art & Culture,
Recreational/Play area/Temporary Vending Zone or Bazar-hat/Athawadi
Bazar/Equal Street, on street/road, on weekend/holidays etc. On such days, as
specified by Commissioner, such streets/roads or stretch of streets/roads, can
be used as recreational/play area & space for activity as stated herein. The
Commissioner shall also identify public spaces, including roads for night bazar to
be conducted.
(EP-23)
14 Amenities and Facilities
(A) In Plots/lay-outs of the land admeasuring 4000 sq. m or more:
In case of development of land admeasuring 4000 sq. m and more (excluding the
area under Road set back/DP Road) in Residential and Commercial Zones,
amenity areas as specified below shall be fronting, a public road or shall be
provided with a perpetual independent right of way. Such amenity area shall be
exclusive of area under perpetual independent right of way.
(i) Development of plots with area 4,000 sq. m and more and up to 10,000 sq. m
shall require handing over 5% of plot area to MCGM as POS.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
(ii) Developments of plot with area exceeding 10,000 sq. m shall require handing
over of 500 sq. m plus 10% of plot area in excess of 10000 sq. m to MCGM as
public amenity space. 50% of such public amenity space shall be used
exclusively for POS and the balance 50% shall be used for provision of such
amenities as education, health, social and other amenities as approved with
the special permission of the Commissioner. In determining the amenity, the
Commissioner shall give due regard to amenity deficits in the ward.
(iii) Such public amenities or facilities (i) and (ii) above shall be deemed to be
designations or reservations in the DP thereafter.
Provided further that, in cases where DP has provided any reservation on the
plot under development excluding the D P Road /Road set back, the following
criteria would be applicable:
a) If the area under DP reservation to be handed over to MCGM (excluding the
DP Road/Road set back) is less than the required area of public amenity space
as per this Regulation, then only the additional area required shall be
provided for public amenity space.
b) If the area under DP reservation to be handed over to MCGM (excluding the
DP Road/Road set back) is more than the required area of public amenity
space as per this Regulation, then the provision for public amenity space shall
not be necessary.
c) Such amenity areas shall not be deducted from the plot for the calculation of
FSI permissible on the balance plot.
d) These areas will be in addition to the Layout Recreational Open Space (ROS
LOS) as required under Regulation No. 27.
e) The minimum dimension of any side of such amenity space shall not be less
than 7.5 m and if the average width of such amenity space is less than 16.6 m,
the length thereof shall not exceed 2 1/2 times the average width.
Note: No amenity plot will be carved out of any land entirely reserved for public
purpose.
(B) Conversion of Industrial Zone to Residential or Commercial Zone for the
allow the Uses permissible in Residential or Commercial Zone
With the previous approval of the Commissioner, any open land in the
Industrial Zone, (I- Zone) (including industrial estates), excluding lands of
cotton textile mills, may be permitted to be converted into Commercial or
Residential zone for permissible uses in the Residential Zone (R- Zone) or
Commercial Zone (C Zone) The area for conversion shall be considered after
deduction of area under proposed DP Road/Sanctioned Prescribed Regular
line/Existing Municipal Road affecting the plot/s.
Such conversion shall be subject payment of the premium at the rate of 20%
of Annual Schedule of Rates (ASR rate) of developed land (for FSI 1) and subject
to the following:
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
(a) Conversion of Industrial Zone to Residential/Commercial Zone in respect of
closed industries shall be permitted subject to NOC from Labour
Commissioner, GoM. Provided that where conversion has been permitted on
the basis of this certificate, Occupation Certificate will not be given unless a
no dues certificate is granted by the Labour Commissioner.
(b) However, in respect of any open land in the Industrial Zone where industry
never existed, NOC from Labour Commissioner will not be required.
(c) If the land under such conversion admeasures
(i) less than 2000 4000 sq. m, 5% of built up area worked out at Zonal (basic) FSI
shall be handed over to MCGM free of cost in the form of residential or
commercial premises. Such areas shall be over and above the FSI permissible
on the plot. BUA in lieu of cost of construction of built up amenity to be
handed over shall be as per the provisions of Regulation number 17(1) note
1(d).
(ii) Equal to 2000 4000 sq. m or more amenity space area to be handed over to
MCGM shall be as detailed below-
Sr. % of land area as Amenity space
Plot Area for conversion Condition
No to be handed over to MCGM
1 2000 4000 sq. m or more, but less 10 Entire amenity space shall be
than 2 ha designated as POS
2 2 ha or more, but less than 5 ha 20 2000 plus 20% of plot area in excess At least 50% of the amenity n
of 2 ha shall be designated as POS
reservation.
3 5 ha or more 25 8000 plus 25% of plot area in excess
of 5 ha
Developer shall have an option to provide constructed amenity as decided by the
Commissioner on the plot to be handed over and Commissioner shall give due regard to
amenity deficits in the ward. In such cases, BUA in lieu of cost of construction of built up
amenity to be handed over shall be as per the provisions of Regulation number 17(1)
note 1(d).
(EP-24)
(d) These areas will be in addition to the ROS LOS as required to be provided under
Regulation No. 27.
(e) The required segregating distance as prescribed under these Regulations shall be
provided within such land intended to be used for residential or commercial purposes.
(f)Such residential or commercial development shall be allowed within the permissible
FSI of the adjoining Residential or Commercial Zone.
(g)Such provisions for public utilities, amenities and open space shall be considered to be
reservations in the DP.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
(h) Public utility and amenity plots shall not be developed under AR as per Regulation
No.17. The entire plot of public amenity land shall be developed entirely for the
purpose of public amenity or POS alone.
Note:
I. Conversion from industrial zone to residential/commercial zone shall be applicable
to the part area of land holding subject to the condition that total area of the entire
land holding shall be considered for deciding the payment of premium and
percentage of and to be reserved of the said part area of land for public amenity
spaces, as per this Regulation. However necessary segregating distance shall be
provided from industrial use.
II. In the event of DP having provided a reservation/reservation on a plot desiring
conversion from Industrial Zone to Residential/Commercial Zone, the following shall
apply:
a. If the area under DP reservation to be handed over to MCGM (excluding the areas
under DP roads/ road setback) is less than the required area of public amenity space
as per this Regulation, only the additional land area shall be provided for public
amenity spaces.
b. If the area under DP reservation to be handed over to MCGM, (excluding the areas
under DP roads/ road setback), is more than the required area of public amenity
spaces as per this Regulation, then the provision for public amenity spaces is not
necessary.
c. In case plot area under conversion is less than 2000 4000 sq. m, land component of
built up amenity shall be considered (i.e.5% of plot area under conversion) for the
purpose of calculation of amenity space as per note (a) and (b) above.
III. Out of the total floor area proposed to be utilized for residential development, 20%
of the same shall be built for residential tenements, each having BUA up to 50 sq. m
(without fungible compensatory area) or 67.50 sq. m inclusive of fungible
compensatory area.
(EP-25)
IV. If the development is already in progress and if full Occupation Certificate has not
been granted to any of the buildings in the layout, then the land owner/developer
may convert the proposal in accordance with the provisions of this Regulation
subject to the following conditions:
Conditions:
a) The revised provisions will be applicable in totality. The benefit of both old and
revised Regulations shall not be allowed.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
b) The benefit of revised Regulations will be applicable only in cases where (a) full
Occupation Certificate has not been granted to any of the buildings in the layout and
(b) required public amenity space or DP reservation, if any, has not been handed
over to the Corporation.
15. Inclusive Housing (IH)
In case of any residential development partially or fully consisting of sub-
division/amalgamation/layout or single plot of land having gross plot area
admeasuring 4000 sq. m. or more (excluding the area under Road set back/DP
Road/designation existing amenity/reservation) shall have the provision of IH as
described below:
1 a) For construction of EWS/LIG tenements, minimum 20% of the plot area (excluding
the area under Road set back/D P Road/designation existing amenity
/reservation) shall be handed over to MCGM free of cost. The FSI of the plot handed
over to MCGM shall be allowed to be utilized on the remaining plot.
b) The aforesaid plot shall be handed over to MCGM within twelve 24 months from
the date of approval /approval of the layout. The FSI of such plot can be utilized on
remainder plot only after handing over of such plot to MCGM or before availing Zonal
(basic) FSI beyond 50% 75% of gross plot area or granting Occupation Certificate to
last 25% of Zonal (basic) FSI in to any of the building, whichever is earlier. The
ownership of such plot shall be transferred in the name of MCGM in Revenue records
before seeking occupation to last 25% of admissible FSI in any of the buildings in the
layout other than IH.
c) MCGM after receipt of such plot shall immediately formulate a scheme of
development for IH wherein the size of tenement shall have carpet area for EWS/LIG
Housing as decided by the Housing Department, Government of Maharashtra, from
time to time. between 27.88 25 sq. m. and 42 27.88 sq. m. Further, such plots shall
not be used for any other purpose.
Provided that in case the Landowner/Developer desires not to utilize such FSI in the
same land, fully or partly, then he shall be eligible for TDR in lieu of such unutilized FSI.
The utilization of this TDR shall be subject to the prevailing provisions of DCR and as
per the following formula.
Formula:
X= (Rg/Rr) *Y
Where, X = Utilization of Development Right (DR) on the receiving plot.
Rg = Land Rate in Rs. per sq. m as per the Annual Schedule of Rates (herein after
referred to as “ASR") of generating plot in the year when project is sanctioned
IOD/IOA is issued.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
Rr = Land Rate in Rs. per sq. m as per ASR of the receiving plot of the same year of
generating plot.
Y = Unutilized FSI.
d) In case the owner/developer opts to utilize the FSI on the remainder plot/within
layout, the permissibility of the FSI for the purpose of development on balance plot
shall be considered on the gross plot area including the area to be handed over to
MCGM for IH.
OR
2) EWS/LIG Housing in the form of tenements of size ranging between carpet area as
decided by the Housing Department, Government of Maharashtra, from time to time.
shall be 27.88 25 sq. m. and 42 27.88 sq. m (hereinafter referred to as 'IH tenements')
and shall be constructed at least to the extent of 20% of the Zonal(basic) FSI. Such
housing shall preferably be in separate wing/building subject to the following
conditions: -
(a) The BUA of the EWS/LIG IH tenements constructed under the scheme shall not be
counted towards FSI and such built up area shall be allowed over & above the
permissible BUA under these regulations.
(b) The Landowner/Developer shall construct the stock of IH tenements in the same
plot and the Planning Authority shall ensure that the Occupation Certificate for the
rest of the development under the said Scheme is not issued till the Occupation
Certificate is issued for IH tenements under the said Scheme and handed over to
MCGM.
“Provided that the BUA of IH i.e. 20% of the Zonal (basic) FSI of the plot can also be
provided at some other location (s) within the same Administrative Ward of the
Municipal Corporation and the same shall be proportionate to the stamp duty ready
reckoner of such respective lands. Such construction shall be free of' FSI to the extent
of 20% 40% of Zonal (basic) FSI over & above of the permissible BUA of' such
plot/alternative plot.
(EP-26)
Built up Area B= Built up Area A X (RR-A / RR-B)
Where:
Built up Area A= BUA of IH units proposed to be transferred from plot A
Built up Area B= BUA of IH units to be handed over to MCGM at plot B in lieu of BUA
of plot A
Where plot A and plot B are situated in the same Municipal Ward
RR-A= Ready Reckoner Rate for BUA at Plot A
RR-B = Ready Reckoner Rate for BUA at Plot B
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
c) The completion of IH tenements under the said Scheme, along with necessary
particulars, including a copy of the Occupation Certificate granted by the Planning
Authority in respect thereof, shall be immediately intimated by the
Landowner/Developer to concerned department of MCGM. The disbursement of such
20 % IH tenements shall be as under:
i) 20% of such tenements shall be allotted to PAPs of vital infrastructure projects,
preferably from the same ward.
ii) Balance 80% of such tenements shall be allotted to EWS/LIG/MIG households on
outright sale. The allotment of tenements shall be as per the lottery system
adopted by MHADA.
If MCGM does not require tenements as per sr. no (i) above within six months from
the date of receipt of such intimation, then the same may be sold as per sr. no ii)
above.
iii) Money so received from proceeds of the sale shall be utilized by MCGM for
implementation of DP.
iv) The developer/owner shall be entitled for the BUA in lieu of cost of construction
of tenements as stated below:
BUA in lieu of cost of construction of IH = 1.50 1.25 [Rate of construction per sq.
m as per ASR rate/Rate of developed land per sq. m as per ASR (for FSI 1)]* BUA
of IH
This BUA shall be subject to maximum 40% of the BUA of IH handed over to
MCGM
(EP-27)
Note:
1) BUA in lieu of cost of construction of IH shall be allowed over and above the
permissible FSI as specified in Regulation No. 30, table 12 or can be adjusted against
permissible TDR/Additional FSI on payment of premium.
2) Commencement Certificate in lieu of BUA of IH can be granted only after handing
over of such BUA to MCGM or before availing Zonal (basic) FSI beyond 50% 75% of
gross plot area or granting Occupation Certificate to last 25% of admissible FSI in to
any of the building, whichever is earlier.
3) For arriving at number of tenements, ratio of BUA to carpet area shall be
considered as 1.2 (including requirements as per provision of these Regulations). No
separate compensation shall be given for areas under Regulation No.31 (1). BUA
for the construction of staircase/lift/staircase and lift lobby & other areas as per 31(1)
shall not be counted in BUA to be handed over and shall be without charging premium
for the provision of IH tenements.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
“Provided that there shall be no obligation to construct IH tenements in the
redevelopment project of any Co-operative Housing Society/federation of
societies/association/condominium/apartment owner’s association in which the
carpet area of all existing individual residential tenements does not exceed 80 sq. m.
Provided further that, if existing carpet area of some of the residential tenements, in
Co-operative Housing Society/federation of societies/association/condominium/
/apartment owners association is more than 80 sq. m, then the obligation to hand
over the BUA in the form of IH tenements/plot area would be proportionate to the
ratio of BUA of such tenement having carpet area more than 80 sq. m and existing
BUA, otherwise required as per this Regulation considering plot area.
(EP-28)
This provision shall not apply to redevelopment of individual bungalows in Bungalow
Scheme. However, this provision shall be applicable if redevelopment in Bungalow
Scheme or plot having area more than 4000 sq. m. under layout is proposed,
There shall be no obligation to construct IH tenements in accordance with these
provisions in any redevelopment project under Regulation No.
33(2),33(3)(A),33(5),33(6),33(7),33(8), 33(9), 33(9)(A), 33(9)(B), 33(10), 33(10)(A),
33(11), 33(20), development under Regulation No 35 and specified under Regulation
No.35(3) and 14(B) as well as any Housing scheme or residential development project
wherein owing to the relevant provisions of the DCRs, more than 20% of the Zonal
(basic) FSI is required to be utilized towards construction of residential EWS/LIG
tenements and development of land situated in NDZ SDZ as per the regulation no 34
.3.4 33(8) and also for the development/redevelopment of any land owned by the
Govt. or any Semi-Govt. Organization, provided such development I redevelopment is
undertaken by Govt. or Semi-Govt. organization itself or through a
developer/contractor under public private partnership.
Provided that in cases of development of reservation for Rehabilitation &
Resettlement (R & R)/Affordable Housing (AH)and the construction of EWS/LIG
tenements under the provisions of any other Act, this provision shall not be
applicable.
(3) Amalgamation of IH plots/IH tenements shall not be allowed.
(4) After layout approval, the area may be further subdivided if necessary to earmark
separate plots for the IH component and the other component. The Plot area and the
BUA in terms of square meters on the said plot shall be separately mentioned in the
lease agreements and Record of Rights. The CTSO/SLR, of the district on payment of
such fees as may be decided by the Govt. ensure that the City Survey sheet and
property cards are corrected accordingly and fresh property cards are opened for each
of the plots giving details regarding the area of the plots and the total area of the
floors of the built-up property and TDR given that is, the FSI used on that plot.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
16. Road /Road Widening
The permissible BUA shall be on the gross plot area including the area required for
road widening or roads proposed under the DP or the MMC Act, 1888, as
stipulated in Regulation No 30 of these Regulations only if the Owner hands over
the same entirely to the MCGM free of cost and free of encumbrances by
leveling the land to the surrounding ground level and after constructing 1.5 m. high
compound wall leaving the setback area as directed by the Commissioner.
Thereafter, the road land shall be transferred in the Revenue records in the
name of the Corporation and shall vest in it becoming part of a public street
as defined in sub-section (3) of section 288 of the MMC Act, 1888.The
additional BUA equal to area of plot so surrendered to MCGM free of cost
and free of encumbrances shall be permissible over and above the
permissible BUA as specified in Regulation No.30 (A) except in respect of
proposal processed under Regulation No
33(5),33(7),33(7)(A),33(8),33(9),33(9)(A),33(9)(B),33(10),33(10)(A),33(20)(A),
33(21).
In case where the development of plot/layout is already completed in all
respects and the road is proposed to be widened subsequently as per the
sanctioned road line prescribed under MMC Act 1888, plot owner shall be
entitled for BUA as per the Zonal (basic) FSI/TDR of plot so surrendered to
MCGM/ Appropriate Authority free of cost and free of encumbrances or
monetary compensation as decided by the Competent Authority.
Herein after, wherever bridges are constructed by Govt./MCGM/Appropriate
Authority, the same shall be provided with noise barriers as explained in
Regulation No. 2(IV) (87).
17 (1) Development of Reserved land for Public Purposes
Reservations which shall be exclusively developed by the MCGM or the
Appropriate Authority (acquired by way of monetary compensation or TDR or any
other means), or by owner, wherever permissible, entirely for the intended
purpose are described in Table Nos. 4 & 5 with appropriate conditions or allow
owner to develop under Accommodation Reservation (AR) subject to
conditions mentioned below & further as described in Table No.5
Conditions for Development of reserved land under Accommodation Reservation (AR)
1) For plot having reservation area 1000 2000 sq. m. or more
i. The owner will be allowed to develop the land if he agrees to construct BUA
equivalent to ‘X’% of Basic (zonal) FSI and agrees to hand it over to
MCGM/Appropriate Authority in lieu of FSI/TDR, as specified in this regulation along
with ‘Y’% of area of reserved plot, free of cost as per the designs, specifications,
terms and conditions duly approved by the Commissioner.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
ii. The owner will be entitled to avail the full permissible BUA of the entire reserved
plot for other permissible uses in the zone under these Regulations on the remaining
land [(100- ‘Y’) % of the land]
iii. The values of ‘X’ and ‘Y’ for the respective reservations as mentioned in Sr. No. I
and ii above are given in Table No.5 below.
iv. The construction of built up amenity (with all requirements as per the provisions of
these Regulations) to be handed over to MCGM along with the land as stated above
under AR may be allowed to be developed in independent building/semi-
detached to the structures of other permissible development on the same plot or
layout proposed by the owner/developer on the remaining land. The ownership of
such plot or BUA to be handed over to MCGM shall vest with MCGM. Immediately
an application to Revenue Authority for making a mutation entry shall be submitted by
owner/developer. Thereafter, Commissioner shall also take up the matter with
Revenue department for the necessary mutation entry. Revenue department shall
enter in other rights column a mutation entry of plot or BUA handed over to MCGM
and correct the revenue records accordingly on receipt of such intimation and on
payment of such fees by owner as may be decided by the Government. A separate
property register card in words & figures thereof in the name of MCGM shall be
submitted by owner before seeking Occupation Certificate for any part of
building/buildings beyond 50% 75% of permissible BUA as per Zonal (basic) FSI, or
granting Occupation Certificate to last 25% of admissible FSI in to any of the building,
whichever is earlier other than amenity.
2) For plot having reservation area less than 1000 2000 sq. m
i) (a) The owner may exercise the option to construct BUA equivalent to ‘X’% of
Basic (zonal) FSI and agrees to hand it over to MCGM/Appropriate Authority in lieu
of FSI/TDR, as specified in this regulation along with ‘Y’% of area of reserved plot,
free of cost as per the designs, specifications, terms and conditions duly approved by
the Commissioner as per 1) above.
or
(b) The owner will be allowed to develop the land if he agrees to construct BUA
equivalent to ‘X’% of Zonal (basic) FSI and agrees to hand it over to MCGM without
insistence of separate plot as mentioned in the table no 5 subject to payment of
premium at the rate as specified in this regulation note no. 23(i) below table 5 or at
the rate as decided by Government and amended time to time, for the optional non
handing over Y% of area of reserved plot and following conditions ii) and iii).
(EP-29)
ii) The construction of built up amenity (with all requirements as per the provisions of
these regulations) to be handed over to MCGM as stated above under
accommodation reservation may be allowed to be developed in independent
building/wing/semi-detached to the structures/in the building premises of other
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
permissible development proposed by the owner/developer, preferably with
independent access.
iii) The ownership of such BUA to be handed over to MCGM shall vest with MCGM.
Immediately an application to Revenue Authority for making a mutation entry shall be
submitted by owner/developer. Thereafter, Commissioner shall also take up the
matter with Revenue department for the necessary mutation entry. Revenue
department shall enter in other rights column a mutation entry of BUA handed over to
MCGM.
The mutation entry in respect of built up area to be handed over to MCGM shall be
made in property register card/Revenue records. On receipt of such intimation and
on payment of such fees by owner as may be decided by the Government, Revenue
department shall correct the revenue records accordingly. The owner shall submit
property register card with the mutation entry before seeking Occupation Certificate
for any part of building/buildings beyond 50% 75% of permissible BUA as per Zonal
(basic) FSI, or granting Occupation Certificate to last 25% of admissible FSI in to any of
the building, whichever is earlier.
3) The Commissioner may entrust the operation and maintenance of such developed
amenity to an appropriate agency as per the prescribed guidelines.
4)In cases, where proposals are already approved as per the provisions of
Regulations in force prior to these Regulations, the lands/BUA which are required to
be handed over to MCGM or the Appropriate Authority, as the case may be, for
public purpose, as per the provisions of regulations in force prior to these
Regulations, such lands/BUA shall be deemed to be reservations/ designations
existing amenity of DP and shall be developed for the intended purposes, even if
such reservations/ designations existing amenity /amenities are not reflected on the
DP.
5) Constructions required for ingress and egress of passengers using Public Mass
Transit Facilities shall be permitted on any land reserved/ designated existing
amenity for any public purpose irrespective of its permissibility given in any land use
classification.
Table No: 3
Common set of conditions for development of Reservations and Authority/Person who
may develop Reservation
Symbol Applicable Conditions for Development
1 The Corporation or Appropriate Authorities may entrust the development,
operation and maintenance of the entire reservation to an appropriate agency
2 The Owner will be allowed to develop the reservation only for its intended
purpose
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
3 The Owner will be allowed to develop the reservation on Accommodation
Reservation basis.
Za Maximum % of plot area that can be used for ancillary uses.
Zb Maximum % of permissible built up area at Zonal (basic) FSI of the built-up
reservation area that can be used for ancillary users.
X Maximum % of development rights, permissible at Zonal (basic) FSI, of the
reservation area affecting the plot, to be constructed as built-up
amenity/amenity for reservation under AR.
Y Maximum % of reserved plot to be set aside for built-up amenity developed
under AR and to be handed over to MCGM, along with the built-up amenity.
Table No: 4
Reservations to be developed for the intended purposes along with permissible uses &
ancillary activities.
Sr. Reservati Reservation Sub Users Permitted Applicable
No on main Category conditions
Category for
Code Name Permissible uses Ancillary Activities development
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
secapS
nepO
cilbuP
ROS1.2 Promenades Coastal Road, Promenade Watchman cabin,
/Promenades Gardener chowky,
along periphery of water toilet block, Art and
body/river/sea/pipeline culture related uses,
Public Toilet
facilities
Ancillary compatible
uses with the special
2 ROS2.3 Zoo Zoo, Aquarium with
permission of the
permissible FSI of 0.025
Commissioner
Sports Complex for various Open air stage,
or individual sports activity, cafeteria,
Enclosed Sports Facility for restaurant, rest
indoor games, Facility for rooms, changing
3 ROS2.4 Municipal Indian sports, Gymnasium, rooms, welfare
Sports Swimming Pool, Drama activities, social and
1, Zb=15
Complex Theater, Public Toilet cultural
facilities, Changing Rooms, activity\amenities,
Locker Room Art and culture
related uses, hostel
rooms and other
ancillary facilities
Sr. Reservati Reservation Sub Users Permitted Applicable
No on main Category conditions
Category for
Code Name Permissible uses Ancillary Activities development
watchman’s cabin,
gardener’s chowky,
instrument room,
Sport Store/Shop
etc.
Sports Complex for i) Hostel rooms and
various or individual other ancillary
sports activity, Enclosed facilities, welfare
Sports facility for indoor activities, social and
4 Sports games, Gymnasium, cultural activity\ 1 or 2,
Complex/S Swimming Pool amenities,
ROS2.5
tadium watchman’s cabin,
gardeners chowky, a) Za= 25
instrument room, b)Zb= 50
Art and culture
related uses, etc.
ii) Banks,
Restaurants rest
rooms, Sport
Store/Shop.
Green belt / Promenades Watchman cabin,
and Substation, Gardener chowky,
5 4 ROS2.7 Green Belt 1,
Distribution Facility toilet block. (at
suitable location)
5 ROS2.8 Botanical Botanical Garden Watchman cabin, 1,
Garden Gardener chowky,
toilet block. (at
suitable location
RR1.2 Police Staff Police Staff Quarters with 1
Quarters Police Station
RR1.3 Government Govt. Staff Quarters, Govt. 1
Staff Quarters Office
Housing RR1.6 Police Police Housing 1
Housing
RR1.7 Government Government Housing, 1
Housing Staff Quarters, Guest
House/ Hostel
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
Sr. Reservati Reservation Sub Users Permitted Applicable
No on main Category conditions
Category for
Code Name Permissible uses Ancillary Activities development
10 Art and Culture
RR3.1 Koli Housing Koli Housing 1
related uses,
Fuel filling station with Administrative 1 or 2
vehicle washing, City gate building, area,
11 6 Fuel Station
station, Gas distribution Ancillary uses of
RPU2.1 Za=10
station and battery ATM, book shop,
charging facility. cafeteria, canteen Zb=10
(without cooking
with open flame)
with subject to
Public NOC from CFO
Utility and NOC from
and controller of
Facilities
Explosive.
Police station, Police 1, Zb=10
Chowky, Lock up Facility,
RPU 3.1 Police Station Branch of Bank, Bill
Canteen, Toilet Blocks,
payment Kiosk
Rest Rooms, Residential
Quarters
Police Police chowky, Toilet 1
Chowky Blocks, Rest Rooms
13 RPU 3.2
Correction Jail, Juvenile Home, Bank ATM, Ancillary 1
Facilities Police Station etc.as uses as decided by
14 RPU3.3 Za= 10
decided by Appropriate Appropriate
Zb=10
Authority Authority
Police Station, Police Canteen, branch of
chowky, Lockup Facility, a bank, stationary
Canteen, Toilet Blocks, shop, meeting
Rest Rooms, Residential rooms for lawyers,
RPU3.4 Police Quarters, Marching photo copying shop, 1
Facilities ground, court, Fuel Ancillary uses as
Zb=15
Station for Police decided by Police
Facilities Authority
Court, along with other Branch of a bank, 1 ,Zb=10
uses if any, such as stationary shop,
16 RPU 3.5
Library, Canteen, Meeting cafeteria,
Courts
Rooms for Lawyers, Photocopying shop,
Administrative Office book store
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
Sr. Reservati Reservation Sub Users Permitted Applicable
No on main Category conditions
Category for
Code Name Permissible uses Ancillary Activities development
Electricity Sub Station, Receiving
17 Transmission station, Bill Collection 1,
RPU5.2
&Distribution Centres, Administrative
Facility Office
Government Government Office along ATM of a Bank,
Office with other uses if any, Information Kiosk,
18 RO2.1 1,
such as Staff Quarters CFC, police chowky,
Zb =10
electric/ telephone
bill payment center
etc.
RSA3.5 Museum Museum, Art Gallery, Auditorium, Drama 1 or 2
Exhibition Hall, Display Theatre
19 Zb=30
Hall
Cemetery, Cremation Storage for Wood,
Ground, Burial Ground, Facilities for
20 1
Electric/gas Cremation Mourners, For
RSA4.8 Cemetery Zb=15
Unit, Pyre shed Performing
Rituals, Prayer
Hall, Religious
Facility, Water
Body etc
Exhibition Center cum Branch of a Bank,
Convention Hall, along ATM, Information
with other uses if any, Kiosk, CFC, police
7 RSA5.1 Exhibition
such as, Organizers office, chowky, etc.
Centre
Protocol Lounge, VIP 1 or 2
Lounge, Press Lounge,
Zb=10
Registration Area, Pre-
Social function Area, Canteen
Amenities cum refreshment area,
surveillance and security
rooms, strong room, first
aid and emergency
response room with
supporting activities as
Hotels not less than 3-Star
category, Food court, fine
dining, restaurant area,
shopping, ATM, recreation
area, Art and culture
related uses, Indoor
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
Sr. Reservati Reservation Sub Users Permitted Applicable
No on main Category conditions
Category for
Code Name Permissible uses Ancillary Activities development
games area, fitness
center, fire services
22 RSA 7.1 Film Studio/ Film Studio/ TV ATM, shops, 1 or 2
TV Studio Studio/Dubbing Dispensary,
8 Zb=10
&Recording Studio/ Canteen,
Preview Theater with
administrative office, Art
and culture related uses
23 RSA 8.1 Animal Animal shelter, shed for Chowky & toilet 1 or 2
shelter animals with animal block
9 Zb=10
eating & drinking facilities
Refuse Shed, Solid Waste 1
Sorting Center, Refuse
24 RMS3.1 Solid Waste
Transfer Station, Municipal
management
Chowky, Municipal Office,
Facilities and
Municipal Store, Refuse
Allied Activity
Compactor, Rest Rooms,
Workers or Rag Picker
Shed and PSC Block
RMS3.2 Land Fill Site Solid Waste Disposal, 1,
Facility, Land Fill Site
25 Za=10
10 Zb=10
Sewage Sewerage Treatment Canteen, Dispensary 1,
Treatment Plant, Aerated Lagoons, Unit, Branch of a
26 RMS4.1 Za = 10,
Plant/Facilitie ETP & Allied Services along Bank, Ancillary Uses
11 Zb = 10
s with other uses if any, as Decided by the
such as Municipal Chowky, Commissioner
Municipal Store, Municipal
Office, Workshop with
Staff Quarters
Sewage Pumping Station Canteen, Dispensary 1,
along with other uses if Unit, Branch of a
27 Sewage Zb=10
any, such as, Municipal Bank, Ancillary Uses
Pumping
12 RMS4.3
Chowky, Municipal Store, as Decided by the
Station
Municipal Office, Commissioner
Municipal Workshop, Staff
Quarters
Water Reservoir, Canteen, Dispensary
Overhead Service Unit, Branch of a
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
Sr. Reservati Reservation Sub Users Permitted Applicable
No on main Category conditions
Category for
Code Name Permissible uses Ancillary Activities development
13 RMS5.1 Reservoir Reservoirs, Garden and Bank, Ancillary Uses 1,
Play Ground Pumping as decided by the
Zb=10
Station along with other Commissioner
uses if any, such as,
Municipal Office,
Municipal Chowky,
Municipal Store, Staff
Quarters
Water Pumping Stations Canteen, Dispensary 1,
along with other uses if Unit, Branch of a
29 Water Zb=10
any, such as, Municipal Bank, Ancillary Uses
Pumping
14 RMS5.2
Office, Municipal Chowky, as decided by the
Stations
Municipal Store and Staff Commissioner
Quarters.
Municipal
Water Treatment Facility Canteen, Dispensary
Services
and Allied Services, Unit, Branch of a
30 Water 1,
Municipal Chowky, Bank, Ancillary Uses
Treatment
15 RMS5.3 Zb=10
Municipal Store, Municipal as decided by the
Plant
Office, Staff Quarters. Commissioner
RMS6.1 Storm Water Storm Water Pumping 1,
Pumping Station
31 Zb = 10
Station
Primary RP1.1 Fish & Net Fish & Net Drying yards, Art and culture 1 or 2
Activities Drying yards fish drying related related uses,
32 a) Za= 15
industries along with other Footstalls/
b) Zb=15
uses if any, such as, diesel Restaurant, Bank
storage, Fish Godown, Branch
Fishing Related Industry
RT1.2 State State Transport Depot Branch of a bank, 1,
along with other uses if Ancillary uses as
33 Transport Zb=10
any, such as Tracks for decided by the
Depot
Vehicle Testing, Regional Appropriate
Transport Office, Staff Authority.
Quarters, Canteen.
Water Transport Station Canteen, ATM of
Parking Lot for Public, Bus bank, other
34 RT2.1 1,
Stops, Sheds, Helipads, ancillary uses with
18 Zb=15
Repairing Facilities, facilities for staff
Transport Water Rickshaw and Taxi Parking and visitors as
Transport decided by the
Appropriate
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
Sr. Reservati Reservation Sub Users Permitted Applicable
No on main Category conditions
Category for
Code Name Permissible uses Ancillary Activities development
Terminal Authority
Jetty, along with other Other ancillary uses
uses if any, such as, Office, with facilities for
35 1,
Parking, Emergency staff and visitors as
19 RT2.2 Jetty Zb=15
Medical Centre decided by the
Appropriate
Authority
RT3.1 Metro/Mono Metro/Mono Car Shed, As may be decided
Rail Car along with other uses if by MMRDA or
36 1
shed any, such as, Material Appropriate
Depot Store, Workshop, Authority
Office.
RAM Reservation Social/Education/Health 1
Amenity services & facilities as
decided by Municipal
Commissioner considering
21 deficiency in Amenity in
ward/ Appropriate
Authorities
(EP-30)
Table No 5
Reservations to be developed for the intended purposes or as per Accommodation
Reservation.
Sr Reservatio Reservation Sub Users Permitted Applicable
No n main Category conditions
Category for
developm
Code Name Permissible uses Ancillary Activities
ent
Primary school, Other non- 1 or 2 or 3
Secondary School, educational Zb = 10
RE1.1 Higher Secondary compatible uses In case of
School, High School, such as branch of a 3
Municipal
College, Integrated Bank, Stationery a) X= 50
School
School with hostel, Pre- Shop, Dispensary, b) Y=50
School Centre, Nursery Canteen,
or other educational
purposes Auditorium, art
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
Sr Reservatio Reservation Sub Users Permitted Applicable
No n main Category conditions
Category for
developm
Code Name Permissible uses Ancillary Activities
ent
and culture related users
After hours of principal
uses, other educational /
permitted uses including
Aadhar Kendra with skill
development centre,
Yogalaya, welfare centre
as decided by the
Commissioner.
Primary Primary School, Other non- 1 or 2 or 3
and Secondary School, educational Zb = 10
2 Secondary Higher Secondary compatible uses
School School, High School, such as branch of a In case of
RE1.2
College, Integrated Bank, Stationary 3
School with hostel, Pre- Shop, Dispensary, a) X= 50
School Centre, Nursery Canteen, b) Y=50
or other educational
purposes Auditorium
and art and culture
related users. After
hours of principal uses,
other educational /
permitted uses including
Aadhar Kendra with skill
development centre,
Yogalaya, welfare centre
as decided by the
Commissioner.
Institute for Differently Other non- 1 or 2 or 3
abled, hostel or other educational Zb = 10
educational purposes, compatible uses
Education Auditorium. Other such as branch of a In case of
Special
facilities for children Bank, Stationary 3
School
with special needs, such Shop, Dispensary, a) X= 50
RE1.3
as soft play areas, Canteen. b) Y=50
sensory rooms or
swimming pools which
are necessary for
treating students with
certain conditions. After
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
Sr Reservatio Reservation Sub Users Permitted Applicable
No n main Category conditions
Category for
developm
Code Name Permissible uses Ancillary Activities
ent
hours of principal uses
other educational /
permitted uses including
Aadhar Kendra with skill
development centre,
Yogalaya, welfare centre
as decided by the
Commissioner.
Primary School, High Sports Center, 1 or 2 or 3
School, Bachelors and Gymnasium, Zb = 20
higher degree colleges Canteen,
4 RE2.1 Higher including Technical, Banks, Post Office, In case of
Education Medical, Architecture, Dispensary, Shops. 3
Management a) X= 50
Institutions with/without b) Y=50
hostel, or other
educational purposes
auditorium and art and
cultural related users.
After hours of principal
uses, other educational /
permitted uses including
Aadhar Kendra with skill
development centre,
Yogalaya, welfare centre
as decided by the
Commissioner.
Primary School, Secondary Sport Center, 1 or 2 or 3
School, Higher Secondary Gymnasium, Zb = 20
School, High School, Canteen, In case of
5 RE3.1 Other College, Integrated School Banks, Post Office, 3
Education General College Dispensary, Shops. a) X= 50
Vocational Training b) Y=50
Institutes Training
Centre, Industrial
Training Institute, etc.,
Medical College
(Including General
Hospital), Sports School,
Skill Development
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
Sr Reservatio Reservation Sub Users Permitted Applicable
No n main Category conditions
Category for
developm
Code Name Permissible uses Ancillary Activities
ent
Center, Hostel, or other
educational purposes,
Auditorium and art and
culture related uses.
After hours of principal
uses other educational /
permitted uses including
Aadhar Kendra with skill
development centre,
Yogalaya, welfare centre
as decided by the
Commissioner.
RE 4.1 Urban Planning, Sports Center, 1 or 2 or 3
6 Environmental Planning Gymnasium, Zb = 20
and other related Canteen, In case of
Institutes Viz. Banks, Post Office, 3
Urban Transportation, Housing, Dispensary, Shops. a) X=50
Planning Public Policy, b) Y=50
Institute Infrastructure Planning,
GIS and Geography
with/without hostel
facilities and art and
culture related uses
RE 4.2 Institutes for Medical Sports Center, 1 or 2 or 3
7 Institutions Education as Gymnasium, Zb = 20
defined by Medical Canteen, In case of
Medical
Council of India Banks, Post Office, 3
Institute
with/without hostel Dispensary, Shops. a) X=50
facilities, and art and b) Y=50
cultural related uses
Institutes devoted to the Sports Center, 1 or 2 or 3
8 study of Financial, Gymnasium, Zb = 20
Financial Economics and such Canteen, In case of
RE 4.3
Institute other field with/without Banks, Post Office, 3
hostel facilities and art Dispensary, Shops. a) X=50
and culture related uses b) Y=50
Institutes for Art, Sports Center, 1 or 2 or 3
9 Culture, Fine Arts, Social Gymnasium, Zb = 20
Other
RE 4.4 education with/without Canteen, In case of
Institutes
hostel facilities and art Banks, Post Office, 3
and culture related uses Dispensary, Shops. a) X=50
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
Sr Reservatio Reservation Sub Users Permitted Applicable
No n main Category conditions
Category for
developm
Code Name Permissible uses Ancillary Activities
ent
b) Y=50
Dispensary, Health Post, Nurses Quarter 1 or 2 or 3
Municipal Urban Primary Health Post-Partum Zb =30
10 RH1.1 D ispensary Centre, Urban center, Recovery In case of
/ Health Community Health centers, Generic 3
Post Centre, Pathology Lab, Medicine a) X= 50
Physiotherapy etc. dispensing facility. b) Y=40
Medical
Stores/Shops,
Public toilet
facilities
Hospital, Dispensary, Nurses and other 1 or 2 or 3
Maternity Home, staff Quarters, Zb =30
Municipal Health Facility, Night Care taker
RH1.2 H ospital Diagnostic centre, Shelters, Generic In case of
11 Rehabilitation Centre, Medicine 3
Peripheral / General dispensing facility a) X= 50
Hospital, Specialty and built up area b) Y=40
Hospital, Multi-specialty of commercial
/ Tertiary Hospital, uses such as
Peripheral / Branch of a bank,
Health Intermediate Hospital, Medical
Dharmashala. Stores/Shops,
Public toilet
facilities shall not
exceed 10% of the
Zonal(basic) or 5%
of permissible FSI
whichever is more
Maternity Hospital, Nurses and other 1 or 2 or 3
Dispensary, Post-Partum staff Quarters, Zb =30
Municipal Centre, Recovery Centre, Night Care taker
Maternity Rehabilitation Centre, Shelters for staff, In case of
12 RH1.3 Home Physiotherapy Centre. Generic Medicine 3
dispensing facility a) X= 50
and built up area b) Y=40
of commercial
uses such as
Medical
Stores/Shops&.
Public toilet
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
Sr Reservatio Reservation Sub Users Permitted Applicable
No n main Category conditions
Category for
developm
Code Name Permissible uses Ancillary Activities
ent
facilities shall not
exceed 10% of the
Zonal (basic) FSI
Rehabilitation Centre, Nurses and other 1 or 2 or 3
Dispensary, Health Post, staff Quarters, Zb=20
Rehabilita Physiotherapy Centre Generic Medicine
tion Sanitarium, Hospice etc. dispensing facility, In case of 3
13 RH3.1 Centre Commercial uses
a) X=50
such as Medical
Stores/Shops&
b) Y=40
Public toilet
facilities.
Other compatible 1 or 2 or 3
14 RH3.4 Veterinary Veterinary hospital uses, Medical Zb=20
Hospital Stores/Shops In case of 3
a) X=50
b) Y=40
Art and culture 1 or 3
Play Play Ground related uses,
In case of
15 Public ROS1.4 Ground Vipassana/ yoga
3, Y=70
Open meditation,
and
Spaces Watchman cabin,
minimum
Gardener chowky,
area of
toilet block.
reserved
plot shall
be 1000
sq. m.
ROS 1.5 Garden/ Garden, Parks, Botanical Art and culture 1 or 3
16 Park Garden, Children Park related uses,
In case of
with Waking Track, Vipassana/ yoga
3, Y=70
Wooded Areas Water meditation,
and
Body Watchman cabin,
minimum
Gardener chowky,
area of
toilet block.
reserved
plot shall
be 1000
sq. m
ROS2.1 Club/ Club/ Gymnasium/ Art and culture 1 or 2 o 3
17 Gymkhana Yogalaya, swimming pool related uses, In case of
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
Sr Reservatio Reservation Sub Users Permitted Applicable
No n main Category conditions
Category for
developm
Code Name Permissible uses Ancillary Activities
ent
Vipassana/ yoga 3
meditation, a) X=50
Watchman cabin, b) Y=40
Gardener chowky,
toilet block.
Sports Complex for i) Hostel rooms 1 or 2 or 3
various or individual and other ancillary
a) Za= 25
sports activity, Enclosed facilities, welfare
Sports b) Zb= 50
Sports facility for indoor activities, social
18 Complex/
games, Facility for Indian and cultural In case of
Stadium
sports, Gymnasium, activity\ 3
ROS2.5
Swimming Pool, amenities,
Y=70 and
Changing Rooms, Locker watchman’s cabin,
minimum
Room gardeners
area of
chowky,
reserved
instrument room.
plot shall
Art and culture
be 50000
related uses, etc.
sq. m.
ii) Banks,
Restaurants rest
rooms, Sport
Store/Shop.
RR1.1 Municipal Municipal Staff Quarters, 1 or 3,
Staff Municipal chowky, Zb=10
18 Housing Quarters Municipal Office In case of
19 Administrative area 3
a) X=50
b) Y=40
1 or 3,
RR1.2 Police Staff Police Staff Quarters
20 Zb=10
Quarters with Police Station
In case of
a) X=50
b) Y=40
1 or 3,
RR1.3 G overnment Govt. Staff Quarters,
21 Zb=10
Staff Govt. Office
In case of
Quarters Administrative Area
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
Sr Reservatio Reservation Sub Users Permitted Applicable
No n main Category conditions
Category for
developm
Code Name Permissible uses Ancillary Activities
ent
a) X=50
b) Y=40
RR 1.5 Municipal Municipal Housing/ 1 or 3,
19 Housing Municipal facilities, In case of
22 Rehabilitation of PAPS 3
a) X=50
b) Y=40
23 1 or 3,
RR1.6 Police Police Housing
In case of
Housing
a) X=50
b) Y=40
24 1 or 3,
RR1.7 Government Government Housing,
In case of
Housing Staff Quarters, Guest
House/ Hostel
a) X=50
b) Y=40
20 Rehabilitati 1 or 3,
25 on & Rehabilitation In case of
Resettlemen Tenements. 3
RR2.1 t a) X=50
b) Y=40
1 or 3,
21 RR2.2 Affordable Affordable Housing In case of
26 Housing 3
a) X=50
b) Y=40
1 or 3,
In case of
27 Koli Art and Culture 3
RR3.1 Koli Housing
Housing related uses, a) X=50
b) Y=40
22 Fire Brigade Station, As may be decided 1 or 3,
28 RPU 1.1 Fire Training center, staff by the In case of
Station quarters, Municipal Commissioner 3
Public office. a) X=50
Utilities & b) Y=50
29 Facilities.
Police station, Police Branch of Bank, Bill 1 or 3
Chowky, lock up Facility, payment Kiosk Zb=10
RPU 3.1 Police
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
Sr Reservatio Reservation Sub Users Permitted Applicable
No n main Category conditions
Category for
developm
Code Name Permissible uses Ancillary Activities
ent
Station Canteen, Toilet Blocks, In case of
Rest Rooms, Residential 3
Quarters a) X=50
b) Y=40
30 1 or 3,
Police Police chowky, Toilet
In case of
Chowky Blocks, Rest Rooms
RPU 3.2
a) X=50
b) Y=40
Correction Jail, Juvenile Home, Bank ATM 1 or 3
Facilities Police Station etc.
RPU3.3 Za= 10
Zb=10
In case of
a) X=50
b) Y=40
Police Station, Police Canteen, branch of 1 or 3
chowky, Lockup Facility, a bank, stationary Zb=15
Canteen, Toilet Blocks, shop, meeting
In case of
Rest Rooms, Residential rooms for lawyers,
RPU3.4 Police Quarters, Marching photo copying
a) X=50
Facilities ground, court, Fuel shop
b) Y=40
Station for Police
Facilities
Court, along with other Branch of a bank, 1 or 3,
uses if any, such as stationary shop, Zb=10
RPU 3.5
Library, Canteen, cafeteria,
3 subject
Courts
Meeting Rooms for Photocopying shop,
to NOC
Lawyers, Administrative book store
from Law
Office, judicial quarters
and
Judiciary
Departme
nt.
In case of
a) X=50
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
Sr Reservatio Reservation Sub Users Permitted Applicable
No n main Category conditions
Category for
developm
Code Name Permissible uses Ancillary Activities
ent
b) Y=40
34 1 or 3,
RPU4.1 Post & Post & Telegraphic ATM of a Bank,
Zb =10
Telegraphi Office along with other Information Kiosk,
In case of
c Office uses if any, such as Staff CFC, police chowky,
Quarters electric/telephone
a) X=50
bill payment center
etc. b) Y=40
Emergency/essentia 1 or 3
l staff quarters
Zb=20
In case of
Electricity
Sub Station, Receiving a) X=50
Transmissio
station, Bill Collection b) Y=40
RPU5.2 n &
Centres, Administrative and
Distribution
Office minimum
Facility
area of
reserved
plot shall
be 1000
sq. m
Service industrial users, 1 or 3,
23 Service shop/commercial user In case of
36 RPU 6.1 Industrial permitted in service 3
Estate industrial Estate a) X=50
b) Y=40
Municipal Office along ATM of a Bank, 1 or 3,
24 RO1.3 M unicipal with other uses if any, Information Kiosk, Zb =10
37 Public Office such as Staff Quarters, CFC, police In case of
Offices Disaster Management chowky, electric/ 3
Facility telephone bill a) X=50
payment center, b) Y=40
Public toilet block.
38 1 or 3,
Government Government Office along ATM of a Bank,
Zb =10
Office with other uses if any, Information Kiosk,
RO2.1
In case of
such as Staff Quarters CFC, police
chowky, electric/
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
Sr Reservatio Reservation Sub Users Permitted Applicable
No n main Category conditions
Category for
developm
Code Name Permissible uses Ancillary Activities
ent
telephone bill a) X=50
payment center b) Y=40
etc.
RO3.1 Disaster Administrative Office, Canteen, 1 or 3,
25 Managem Storage facility for dispensary, ATM, Zb =10
39 ent materials/goods, Fire Public toilet In case of
Facility Station, Medical aid, any facilities. 3
ancillary/ Training a) X=50
Centre for Disaster b) Y=40
Management/Municipal
/Govt. office/Home
guard station & facilities
thereof
Markets for fruits and Municipal office, 1 or 3.
26 vegetables, Flower, Fish, Police chowky, Zb =30.
40 Municipal weekly Markets, Drama theatre, In case of
Market Organized informal reading rooms, 3,
RSA1.1 with Market and Shops for Branch of Bank, a) X = 50
Vending Rehabilitation of PAP's if Refuse shed, b) Y = 40
Zone required (Min. 15% Public toilet 50
vending area of which facilities.
50% for women)
Reading rooms, 1 or 2 or
27 Markets for Fruits and Branch of Bank, 3.
Retail
41 vegetables, Flower, Fish Public toilet Zb =20.
Market
and Shops for facilities In case of
RSA1.2 w ith
Rehabilitation of PAP's if 3,
Vending
required (Min. 15% a) X = 50
Zone
vending area of which b) Y = 40
50% for women) 50
Community Centre, Art and cultural 1 or 2 or 3
28 Student Hostel, related users, Zb =30
42 Multi- Dormitories, Library, Banks, In case of
Purpose reading Rooms, Study Restaurants, bill 3
RSA2.1
Community Rooms for Students, payment kiosk, a) X= 50
Centre Public toilets, Citizen Facilitation b) Y= 40
Community hall, Centre 50
exhibition hall
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
Sr Reservatio Reservation Sub Users Permitted Applicable
No n main Category conditions
Category for
developm
Code Name Permissible uses Ancillary Activities
ent
Other non- 1 or 2 or 3
28 Social RSA2.7 Students educational Zb =30
Students Hostel including
43 Amenities Hostel compatible uses In case of
quarters for faculty and
such as branch of a 3
staff
Bank, Stationary a) X = 50
Shop, Dispensary, b) Y = 40
Canteen 50
RSA2.9 Homeless Night Shelter, Home for Dispensary, 1 or 2 or 3.
30 Shelter Destitute, Dormitory with Watchman's cabin Zb = 10
44 toilet facility & other In case of
ancillary Facility 3
a) X= 50
b) Y= 40
Cultural Cultural Centre/Drama Recording rooms, 1 or 2 or 3
RSA3.3 Centre/ Theatre Open Air dubbing rooms, Zb=30
31 Drama Theatre, Art Gallery, restaurant, café,
45 Theatre/ Aquarium, Auditorium Reading halls, In case of
Theater along with other uses if Library, hostel 3
any, such as rest room, rooms for artists a) X=50
make-up room, welfare b) Y=40 50
activity center, welfare
activity center, Parking
Lot
RSA3.5 Museum Museum, Art Gallery, Auditorium, Drama 1 or 2 or 3
Exhibition Hall, Display Theatre
Zb=30
Hall
In case of
a) X = 50
b) Y = 40 50
32 Art and cultural facilities Public Toilet 1 or 2 or 3
47 RSA3.6 Art facilities. ATM Zb=10
Gallery In case of
a) X=50
b) Y=40 50
Garden, Semi Open 1 or 3
33 RSA3.7 Leisure areas, Food stalls with Watchman cabin, In case of
48 Park temporary roofing Gardener chowky, 3
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
Sr Reservatio Reservation Sub Users Permitted Applicable
No n main Category conditions
Category for
developm
Code Name Permissible uses Ancillary Activities
ent
facility, Food courts with Public toilet Y=70
temporary roofing facilities.
facility, Open spaces,
Children play area, Art
display area, Cultural
spaces, Amphitheaters,
water sports facility etc.
Cemetery, Cremation Storage for Wood, 1 or 3
Ground, Burial Ground, Facilities for
Zb=15
Electric/gas/Diesel/Petrol Mourners, For
RSA4.8 Cemetery In case of
Cremation Unit, Pyre shed Performing Rituals,
49 3, Y=70
Prayer Hall,
and
Religious Facility,
minimum
Water Body etc.
area of
reserved
plot shall
be 1000
sq. m.
34 RSA4.9 Old Age Dormitories along with Branch of a bank, 1 or 2 or 3
50 Home other uses if any, Health ATM, shops, Zb=10
Clinic, Canteen, Dispensary, In case of
Recreational Area, 3
Office, Day Care Centre a) X=50
For Elders, Geriatric Care b) Y=40
Centre, Activity Room,
Day Care for Children
35 RSA5.2 Multi- Hostel, Dormitories and ATM, shops, 1 or 2 or 3
51 Purpose guest rooms for working Dispensary, Zb=10
housing women, for women in In case of
for distress, single 3
working Women/Student, a) X=50
Women dormitories for women, b) Y=40
activity room.
Balwadi, Day Care for
children, Old Age people,
Counseling Centre, Care
centre shall not be more
than 10% of the zonal
basic FSI.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
Sr Reservatio Reservation Sub Users Permitted Applicable
No n main Category conditions
Category for
developm
Code Name Permissible uses Ancillary Activities
ent
36 RSA6.1 Care Care centre for Children ATM, shops, 1 or 2 or 3
52 Centre and Women, Children Dispensary Zb=10
Play area, Reading area, In case of
activity area 3
a) X=50
b) Y=40
37 RSA6.2 Adhar Women Skill Art and culture 1 or 2 or 3
53 Kendra with Development Centre & related uses, ATM, Zb=10
skill Livelihood Centre, CFC In case of
developmen Municipal Purpose 3
t centre a) X=50
b) Y=40
RSA6.3 Public Public Toilet, Toilet for 1 or 2 or 3
38 Convenienc Women, Rest Rooms, In case of
54 e Drinking Water Hubs 3
a) X= 50
b) Y = 40
RMS1.1 Road Municipal Material Public Toilet 1 or 3,
39 Depot Depot, Municipal Labour facilities In case of
55 Chowky, Store, 3
Workshop, Municipal a) X=50
Office b) Y=40
RMS1.2 Municipal Municipal Labour Public Toilet 1 or 3,
40 Chowky Chowky, Material Depot, facilities In case of
56 Store, Workshop, 3
Municipal Office a) X=50
b) Y=40
RMS1.3 Municipal Municipal Workshop, Public Toilet 1 or 3,
41 Municipal Facilities Municipal Central Store facilities In case of
57 Services Municipal Labour 3
Chowky, Material Depot, a) X=50
Store, Municipal Office b) Y=40
RMS2.1 Transport Transport Garage, Repair Auto-parts shop, 1 or 3,
42 Garage Garage, Store, Related ATM of bank, Za= 10
58 Municipal Office, canteen, municipal Zb=10
Municipal Chowky., store, Public Toilet In case of
Municipal Office, facilities Ancillary 3
Workshop uses as decided a) X=50
with the special b) Y=40
permission of the
Commissioner
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
Sr Reservatio Reservation Sub Users Permitted Applicable
No n main Category conditions
Category for
developm
Code Name Permissible uses Ancillary Activities
ent
Solid Waste Refuse Shed, Solid Waste 1 or 3
Manageme Sorting Center, Refuse
RMS3.1 In case of
nt Facilities Transfer Station,
and Allied Municipal Chowky,
Y=60 and
Activity Municipal Office,
minimum
Municipal Store, Refuse
area of
Compactor, Rest Rooms,
reserved
Workers or Rag Picker
plot shall
Shed and PSC Block
be 1000
sq. m.
RMS3.3 Scrap Scrap Yard ATM of bank, 1 or 3,
Yard canteen, store, Za= 10
43 Ancillary uses as Zb=10
60 decided with the In case of
special permission 3
of the a) X=50
Commissioner b) Y=40
RMS5.5 Hydraulic Municipal Store, ATM, Information 1 or 3
44 Engineering Municipal Office, Kiosk, CFC, Public Za= 10,
61 Store/Office Municipal Chowky, Toilet facilities Zb=10
Pumping station, In case of
Workshop with staff 3
quarters a) X=50
b) Y=40
RP1.1 Fish & Net Fish & Net Drying yards, Art and culture 1 or 2 or 3
Drying fish drying related related uses,
a) Za= 15
yards industries along with Footstalls/
b) Zb=15
other uses if any, such Restaurant, Bank
as, diesel storage, Fish Branch In case of
Primary
Godown, Fishing Related 3, Y=70
Activity
Industry and
minimum
area of
reserved
plot shall
be 1000
sq. m.
63 RP2.1 Dhobi Art and culture related Public Toilet 1 or 2 or 3
Ghat uses facilities Za= 10,
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
Sr Reservatio Reservation Sub Users Permitted Applicable
No n main Category conditions
Category for
developm
Code Name Permissible uses Ancillary Activities
ent
Zb=10
In case of
a) X=50
b) Y=40
46 RP3.1 Cattle Animal shelter, shed for Chowkie & toilet 1 or 3
Pound animals with animal block Za= 10,
eating & drinking Zb=10
facilities In case of
a) X=50
b) Y=40
RT1.1 Truck Truck Terminus, along Restaurant, 1 or 2 or 3,
Terminus with other uses if any, Branch of Bank, Za= 10
such as Workshop, Store, ATM, Information Zb=10
47 Garage, Dormitory with Kiosk, CFC, Police In case of
64 toilet and bath Chowky, PSC 3
a) X=50
Transport b) Y=40
RT1.4 BEST Bus BEST Bus Depot, BEST Cafeteria, 1 or 3,
Facilities Bus Station, Parking Lot Canteen, Police Zb=10
48 for Public, Bus Stops, Chowky, CFC, ATM In case of
65 Sheds, Helipads without of a Bank, 3
affecting traffic, a) X=50
Essential staff quarters b) Y=40
for operational uses
Rickshaw and Taxi
Parking and
Administrative office,
fuel station
RT1.6 Parking Parking Lot, Municipal PSC Security 1 or 3
49 Lot Chawky Chowky Zb=10
66 In case of
X=100 125
67 Industrial ITI as per the Norms Art and culture, 1 or 3
Training prescribed by the Cafeteria, Canteen, Zb=10
Institute/ concerned Technical ATM of a Bank In case of
Centre Authority (Inclusive of 3
provision for required a) X= 50=%
parking space) for the b) Y=40%
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
Sr Reservatio Reservation Sub Users Permitted Applicable
No n main Category conditions
Category for
developm
Code Name Permissible uses Ancillary Activities
ent
designated amenity. Conditions
:
(EP-31)
Note: -
1 a) The plot area to be handed over to MCGM under AR shall not be deducted from the
gross plot area for the purpose of calculation of full permissible BUA under these
regulations and may be utilized on the balance plot. Additional BUA equal to area of
the plot so surrendered to MCGM free of cost and free of encumbrances shall be
permissible over and above the permissible BUA or TDR as specified in the
Regulation No.30(A)except in respect of proposal processed under Regulation No
33(5), 33(7), 33(7)(A), 33(8), 33(9), 33(9)(A), 33(9)(B), 33(10), 33(10) (A), 33(20)
(A),33(21).
b) The BUA handed over to MCGM shall be free of FSI and balance plot will be
allowed to be developed as per these Regulations, without taking into account
said BUA so handed over
c)BUA of staircase, lift &lift lobby and BUA permissible free of FSI as per the
provisions of Regulation no 31(1) shall not be counted in BUA to be handed over
to MCGM and the same shall be without charging premium for the provision of
built up amenity under AR.
d)The developer/owner shall be entitled for the BUA in lieu of cost of
construction of built up amenity under AR as follows:
BUA in lieu of cost of construction of built up amenity handed over under AR
= 1.50 1.25 (Rate of construction per sq. m as per ASR rate /Rate of developed
land per sq. m as per ASR) * BUA of constructed built up amenity handed over
under AR.
This BUA shall be subject to maximum 40% of the BUA of amenity handed over to MCGM
In case of Sr. No. 49 66(PPL), the incentive BUA shall be 50% of the above cited BUA
as calculated above.
i) No separate compensation shall be given for areas under Regulation No.31
(1). BUA for the construction of staircase/lift/staircase and lift lobby & other
areas as per 31(1) shall not be counted in BUA to be handed over and shall
be without charging premium for built up amenity under AR. In case of
residential amenity for arriving at number of tenements, ratio of BUA to
carpet area shall be considered as 1.2
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
ii) The applicable rate of ASR shall be ASR rate of the year in which amenity is
handed over to MCGM IOD/IOA is issued.
iii) The constructed built up amenity along with plot to be handed over to
MCGM under AR shall have structural provisions for vertical extension in
order to consume additional FSI permissible as per provisions of these
Regulations in future.
a) The Owner/Developer shall be eligible for grant of TDR against unutilized BUA
including that of Zonal (basic) FSI.
Or
2) If the land is reserved as per the DP and owner desires to hand over the land
without any encumbrances to MCGM/ Appropriate Authority, then he shall be
entitled for the grant of TDR as per Regulation No 32.
Or
3) If the land reserved as per the DP is acquired by MCGM/Appropriate
Authority, the Owner shall be entitled for the grant of TDR as per Regulation No
32 or monetary compensation.
4) The owner shall give advanced possession of the land wherever applicable
(to be handed over) to MCGM/Appropriate Authority at the time of seeking
Approval for Development of plot. It shall be responsibility of the land owner to
clear all the encumbrances and complete the formalities towards transferring
the land in the name of MCGM/Appropriate Authority. Proforma of possession
receipt shall be as per Appendix V.
5) The area of built up amenity shall be counted in FSI initially and after
handing over of said built up amenity the area of built up amenity shall be
allowed free of FSI. Commencement Certificate in respect of BUA in lieu of the
built-up amenity handed over to MCGM under AR can be granted only after
handing over of such built up amenity or before availing Zonal (basic) FSI
beyond 75% of gross plot area or before seeking Occupation Certificate to any
part of building/ buildings beyond 50% 75% of permissible admissible BUA as
per Zonal (basic) FSI, other than the built-up amenity.
6) In case where Principal and Ancillary users are not reflected in the above
table but are compatible to the reservation development, such uses shall be
permissible with the special permission of the Commissioner.
7) In case of development of the plot reserved for Public Open Spaces under AR
as per Serial No. 15, 16 & 33 48 of Table No 5, the provisions of Regulation
No.27 may not be insisted.
8) In case a reserved plot under Sr No.1 of Table No 5 (Municipal School) is
developed and run entirely by the private owner, then conditions, including
admissions, stipulated by the Municipal Commissioner shall be applicable.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
9) Where a private plot is notified by GOM or reserved in DP for infrastructure
related facilities in respect of public transportation authorities (such as MRVC,
MMRDA, BEST etc.), the said authority shall have the option of acquiring part
plot under AR where 50% of plot shall be handed over to the authority. The
balance plot will be available for development for the Owner as permissible
under these regulations.
Provided further that notwithstanding anything contained in these Regulations,
if such plot is situated in NDZ, then the maximum permissible FSI shall be 0.8
on the gross plot area to be utilized on the remainder plot.
10) In case of social amenities, the built-up amenities received under AR will be
made available by the MCGM to GOM for operation, either through its own
departments or through other institutions, only for the intended purpose on
terms & conditions as decided by GOM. MCGM shall have the option of running
such facility wherever it decides to do so, by formulating the guidelines for the
implementation.
11) In case of development, of unreserved plot, for the purposes mentioned in
Table No 4 & 5, the ancillary activity as specified in Table No 4 & 5 shall be
permissible.
12) Structures constructed in designated POS, with due sanction of Competent
Authority, before coming into force of these regulations stand protected.
However such protected structures, shall earmark an exclusive space/area of 8
sq. m to serve as Baby Feeding Room.
13) Designated POS, with encumbered structures shall be cleared of the
encumbrances and shall be maintained entirely for the intended purpose only
and cannot be developed under any redevelopment scheme.
14) Existing Play Ground attached to Educational and Medical
Institutions/Museum/Trust and under same ownership, shown as designation in
DP, shall not be subject to mechanical acquisition and shall be for the use of
that Educational and Medical Institution/ Museum/Trust.
15) In case of development of plot affected by reservation under AR and where
Appropriate Authority is other than MCGM, then NOC/remarks of the
concerned Appropriate Authority shall be insisted before allowing development
under AR. List of Appropriate Authorities is enclosed in Annexure 24
16) In the case of development or redevelopment of land of Department of
Police, Police Housing Corporation, and Home guard, commercial user
permissible under D.C. Regulations; may be permitted up to 40% of the Zonal
(basic) FSI.
17) Sites reserved and designated for BEST Bus Facilities and BEST Quarters may
be developed by the BEST Undertaking for the specified purpose coupled with
commercial use, subject to the following conditions:
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
a) The BUA of such commercial uses shall not exceed 30% of the permissible FSI,
out of such permissible commercial uses BUA not exceeding 50% of the total
permissible commercial uses may be permitted on the ground floor, while
remaining BUA for commercial uses may be permitted on the upper floor.
b) Extent of BUA proposed to be used for commercial purpose shall be such that it
does not adversely affect the principle uses.
c) Considering the strategic location of reserved sites with reference to the
volume and nature of the traffic in the vicinity of the reserved site, Municipal
Commissioner shall have right to prescribe additional condition as deemed fit and
also restrict the commercial area to the justifiable extent.
d) Provision for separate parking shall have to be provided as per prevailing
norms in such a way that it does not affect movement of BEST buses as well as the
traffic of road.
e) The above commercial uses shall be permitted on plot having area of 2000
sq. m. & above.
f) If there is any storage of diesel/ petrol or any explosive material on the plot,
then the above commercial uses is permissible by maintaining segregating
distance between them as decided by the Chief Fire Officer and license from PESO
shall be obtained for such storage if exceeds above the permissible limit of 2500
lit.
18) Public Open Spaces in K/E Ward:
In accordance with, Govt. of Maharashtra, Urban Development Department
notification no TPB4392/4716/CR-181/92/UD-11(RDP) dated 12.11.1992: -
50% of the lands of Hotels from CTS Nos 1483, 1491, 1495, 1496, 1497, 1500,
1503, CTS Nos 1420, 1437, 1445, 1448, 1439, 1457, 1443, 1485 and S
No.110(pt.),117(pt.),118(pt.),122(pt.),123(pt.) of Village Sahar be reserved for the
Park not to be acquired, as shown on DP and remaining 50% of the land be
deleted and included in C Zone only for Hotel plus commercial purpose subject to
condition that the parties should develop and maintain the parks and shall keep
them it open permanently for general public during restricted hours before
undertaking development of the Hotels.
(19) Development of reservation on the plot of land situated in SDZ II shall be
allowed as per the table No 5 of Regulation No 17(1). If the owner of plot opts for
the development of reservation under AR and hands over the plot, then the plot
automatically deemed to be situated in R/C Zone and shall be eligible for the
additional BUA equal to plot area surrendered to MCGM/Appropriate Authority
along with cost of construction of built up amenity as per Note 1(d) of Regulation
No 17(1). ‘TDR’ or ‘Additional FSI on payment of premium’ as per Regulation No
30 (1) (A) along with fungible compensatory area as per Regulation No. 31(3), shall
be permissible on this piece of land. TDR in lieu of unconsumed BUA may be
granted as per the Regulation No 32. Moreover, additional FSI as per the
applicable Regulation 33 may be availed if permissible.
(20) Green belt (ROS 2.7) shall not be treated as reservation but it’s the nature of
restriction and shall not be subjected to acquisition.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
(21) Play Ground reservation attached to Educational Institutions shown as reservation in
DP, and owned by such educational Institution, shall not be subject to acquisition and shall
be used as 40 % play ground required for the existing Educational Institutions. Provided it
shall also be accessible to the general public as per the policy of corporation.
(22) On development of the land as per accommodation reservation and on handing over
and transferring the land along with the built up amenity to MCGM/Appropriate Authority
then the area of the plot along with the built up amenity shall be deemed to be existing
amenity in the DP and the remaining land of the owner shall fall in the land use zone
without any reservation/ existing amenity.
Provided that when the development is composite where the plot is not handed over to
MCGM in such cases entire area shall be deemed to be marked as existing amenity with the
+ sign indicating other uses on the said plot.
(23) General conditions to allow development under above regulations:-
i) If the area of reservation is not adequate to construct independent building as mentioned
above OR When it is not possible to handover individual plot along with public amenity,
then in such cases Municipal Commissioner may allow composite building on said land
subject to condition that the built up area mentioned as above may be allowed to be
handed over to the Planning Authority or Appropriate Authority, as the case may be,
preferably on ground floor and subject to premium at the rate of 35% and 40% of ASR of the
develop land for the zonal (basic) FSI (In case of suburbs where FSI is 1 it shall be as per ASR
of the developed land and in case of City it shall be 1.33 times of ASR of the developed land)
for AH/R&R and for other reservations respectively or as may be decided by Government
from time to time. If ground floor is utilised for parking, then on stilt/first floor with
separate entry & exit from public street. In such cases, built-up area along with
proportionate undivided share of land shall be handed over to the Planning Authority or
Appropriate Authority, as the case may be. In such cases no compensation of proportionate
undivided land share shall be permissible.
ii) It shall be obligatory on Planning Authority to make registered agreement with the
developer /owner at the time of granting the development permission subject to terms and
conditions as it deem fit. Occupancy Certificate shall be issued only after compliance of all
terms & conditions and getting possession of the constructed amenity.
iii) The above permissions for development of reservations shall be granted by the
Municipal Commissioner as per the norms mentioned in these regulations.
iv) The area / built-up area to be handed over to the Planning Authority under these
Regulations shall be earmarked on the sanctioned building plan clearly mentioning the
same, and registered agreement to that effect shall be executed. After completion of
construction, the said amenity shall be handed over by executing the deed of transfer in this
respect and expenses thereon shall be borne by the owner. The occupation certificate to the
construction belonging to owner shall be granted only after handing over said amenity to
the Planning Authority. The constructed amenity shall be made available to the general
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
public by the Municipal Commissioner within 3 month from possession as per the condition
as Commissioner deem fit.
v) In cases, where permission for development under accommodation reservation principle
is already granted as per earlier regulations, the same shall continue to be valid till
completion of construction.
vi) Provisions of Regulations of Inclusive Housing, Amenity Space if any, shall not be
applicable for development under this Regulation.
vii) Not withstanding anything contained in these regulations, there shall be no cap for
utilization of available in-situ FSI/and TDR potential of the entire plot on the remaining plot
viii) Once sanction is granted under this regulation, the owner /developer shall have to
complete the development and hand over the developed reservation to Planning Authority
within the period as specified by Planning Authority. Thereafter Planning Authority may levy
penalty for any delay.]
ix) The TDR generated of any reservations in lieu of accommodation reservation can be
utilized plot in same layout belonging to the same owner subject to following conditions.
a) The plot should be under one ownership.
b) The plot cannot be sub-divided in revenue records.
c) Necessary entry has to be made in the development plan sheet that there is no balance
FSI potential on such plot.
d) It should be communicated to the Revenue Department to make necessary entry in the
P.R. card to that effect.
(EP-32)
17 (2) Redevelopment of authorisedly closed designated/allocated
existing Cinema/Theater:
Notwithstanding anything contained in these Regulations, designated/existing
authorisedly closed cinema/theater shall be redeveloped in the following manner:
1. In case of redevelopment of an existing cinema/Theater on designated/allocated
plot, the user for the cinema/ theater may be permitted in combination with the
permissible uses in Residential/Commercial zone excluding the uses of
Bakery/confectionery, coal & firewood shops, maternity home, hospitals,
schools, trade school & colleges, or any other uses as may be deemed fit by the
Municipal Commissioner.
In case of redevelopment of an existing cinema/theater on designated/allocated
plot in addition to other uses which are to be permitted, cinema/Theater having
seating capacity to the extent of 33% of the last licensed number of seats in the
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
old existing cinema/Theater and in any case not less than 150 seats or as may be
decided by GOM from time to time shall be provided.
Further for Cinema/Theater having number of seats 1000 or more mentioned in
the last license, in the old existing cinema/Theater may be developed with at
least 300 seats without insisting provision of 33% of the number of seats
mentioned in the last license, in the old existing cinema/Theater.
Existing one screen cinema/Theater can be converted into multiple screens
subject to observing above conditions and these Regulations.
Provided further that if development of cinema/theater along-with other uses
except residential use is proposed in single building then the open space
requirement shall be considered as required for the special building. The
residential uses shall be permitted in separate building/separate wing with
separate access. Or
2. The Owner/Developer may develop the entire designated/ allocated plot for the
purpose of entertainment of general public such as Drama Theater/Opera
theater/Mini-theater/Multiplex or for Production facilities/studio/s for cinema/
Tele-serial /Dubbing & Recording studio/Preview Theater etc.
Or
3. i)The designated/allocated plot of the cinema/theatre can be developed at par
with AR. For the plot area, up to 10002000 sq. m, 40 % of BUA as per Zonal
(basic) FSI and incase of the plot area more than 10002000 sq. m, 40 % plot area
&built up amenities to the extent of 50% of the Zonal (basic) FSI of the plot shall
have to be handed over to MCGM free of cost & free of FSI.
ii) The Built-up amenity shall be in the form of the activity related to the public
entertainment as decided by the Commissioner such as Opera theater/Mini-
theater/Production studio for cinema & or Tele-serial/Dubbing & Recording
studio/ Preview theater. In case of plots up to 10002000 sq. m, such activity shall
preferably be located in a separate wing and with the separate access.
iii) The owner shall be entitled for the development of the balance potential as
per the provision of Regulation No 17(1) and uses permissible in
residential/commercial zones. Provided further that residential use shall be
allowed in a separate building.
iv) The owner shall be entitled for the development of the balance plot as per
the provisions of these Regulations.
(EP-33)
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
17(3) Notwithstanding anything contained in these Regulations Development of
Reserved land falling under the development under the various provisions of
Regulation No. 33 shall be as under:
(A)Development of reservation in Development/Redevelopment of Housing Schemes of
Maharashtra Housing & Area Development Authority (MHADA) under Regulation No.
33(5)
All the reservations excluding open space reservation which are actually layout
Recreational Open Spaces (LOS) as per the approved MHADA layout, may be
developed as per the provisions of Regulation No. 17. All reservation to be developed
entirely for intended purpose.
(EP-34)
(B)Development of reservation in Reconstruction or redevelopment of cessed buildings in
the Island City by Co-operative Housing Societies or of old buildings belonging to the
Corporation under Regulation No. 33(7)
(1) Redevelopment/reconstruction in any zone shall be allowed on site without
going through the process of change of zone. For the Industrial user, the existing
segregating distance shall be maintained from the existing industrial unit.
(2) Notwithstanding anything contained in these regulations, in case of
redevelopment of plot/(s) having cessed structure/s and having reservation in the
DP, the land component of the said cessed structure as per Zonal (basic) FSI shall be
deemed to have been automatically deleted from reservation. However,
reservation area beyond the land component of cessed structure/s shall have to be
developed entirely for the intended purpose only.
(2) Notwithstanding anything contained in these regulations, in case of redevelopment of
plot/(s) having cessed structures/s and having reservation in the DP, the land component of
the said cessed structure as per Zonal (basic) FSI shall be deemed to have been
automatically deleted from reservation.
The reservation area beyond the land component of cessed structures/s may be
developed as per provision of Regulation 17(1) under the principle ‘Accommodation
Reservation’ for the intended purposes. Provided that the 25% land component of non-
cessed structures as describe in clause 19 of Regulation 33(7) will be eligible for FSI as per
Regulation 33(7) only and shall not be eligible for Zonal (basic) FSI.”
(3) In case of reconstruction/redevelopment of building of Corporation, for the area
of plot having no reservation or having designation of Municipal Housing, then the
BUA equal to 25% of such plot area as per Zonal (basic) FSI in the form of
tenements of size as decided by commissioner shall be made available to MCGM.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
The developer/owner shall be entitled to BUA in lieu of cost of construction against
handing over of built up amenity as per Note (d) of Regulation 17(1) in case of
above.
(4) Notwithstanding anything contained in any of these Regulations
reconstruction/redevelopment of buildings of Corporation existing prior to 30.09.1969,
falling under reservation contemplated in Development Plan shall be permitted as under
(i) Any plot/layout having area under non-buildable/open space reservations admeasuring
up to 500 sq. m shall be cleared by shifting the existing tenants from that site.
(ii) Where the area of site having non-buildable/open space reservation/Cemetry, is more
than 500 sq. m & if the land component of existing structures is more than or equal to 67%,
70% such sites may be allowed for the redevelopment subject to condition that the ground
area of the land so used shall not be more than 67%, 70% of the reservation and leaving
33% 30% rendered clear thereafter for the reservation. If the land component of existing
structures is less than 67%, 70% such sites may be allowed for the redevelopment subject
to condition that the ground area of the land so used shall not be more than land
component of existing structures and leaving balance reservation land rendered clear
thereafter for the reservation.
(iii) Existing structures on lands reserved for Municipal School (RE 1.1)/ Primary and
Secondary School (RE1.2) or a Higher Education (RE2.1) may be developed subject to the
following:
(a) In case of land reserved for Municipal School (RE 1.1), Primary and Secondary School
(RE1.2) in the DP, a building for accommodating such number of students as may be decided
by the Municipal Commissioner, but in any case, for not less than 500 students, shall be
constructed. The BUA occupied by the constructed building shall be excluded for the
purpose of FSI computation. Thereafter, the land may be allowed to be redeveloped with
the full permissible FSI of the plot according to this Regulation.
(b)In the case of lands affected by reservation of a Higher Education (RE2.1) in the DP, a
building for accommodating such number of students as may be decided by the Municipal
Commissioner, but in any case for not less than 800 students, shall be constructed. The BUA
occupied by the constructed building shall be excluded for the purpose of FSI computation.
Thereafter the land may be allowed to be redeveloped with full permissible FSI of the plot
according to this Regulation.
(iv) In case of the plot reserved for the Parking Lot, 100% 125% BUA as per Zonal (basic) FSI
of such reserved area shall be constructed.
(v) Existing structures on lands reserved for Rehabilitation & Resettlement (RR 2.1) shall be
treated as sites for development of such structures and shall be allowed for redevelopment
according to this Regulation.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
(vi) For other buildable reservations excluding (ii),(iii), (iv) & (v) above and reservations as
reflected in the table no 4 of Regulation No 17(1), BUA equal to 25 percent of the area
under that reservation in that plot, shall be constructed.
(EP-35)
(C) (I)Development of reservation in Reconstruction or redevelopment of Cluster(s) of
Buildings under Cluster Development Scheme(s) under Regulation No. 33(9):
a. Redevelopment/reconstruction in any zone shall be allowed to be undertaken
without going through the process of change of zone. However, for the industrial
user, the existing segregating distance shall be maintained from the existing
industrial unit.
b. Any land under non-buildable/open space reservations, admeasuring up to 500
sq. m may be cleared by shifting the existing tenants from that site.
c. If the area under a non-buildable/ open space reservation is more than 500 sq.
m, minimum 50% of the area under reservation shall be developed for the same
purpose and handed over to MCGM, subject to a minimum of 500 sq. m and the
remaining land shall be allowed for development.
d. All the reservations in the DP shall be rearranged, if necessary, with the same
area and the same width of access road or as required under DCPR, whichever is
more.
e. For the reservation of parking lot on a land included in CDS, BUA equivalent to
Zonal (basic) FSI for the area under reservation in that plot shall be made available
free of cost to the MCGM or to any other Appropriate Authority. Such BUA to be
handed over shall be free of FSI.
f. For other buildable reservations on land, BUA equal to 60% of the Zonal (basic)
FSI under such reservations or existing BUA of the amenity(designation) whichever
is more, on that plot shall be made available free of FSI and free of cost to the
MCGM or the Appropriate Authority. The reservations of compatible nature can be
preferably constructed in one or more separate blocks, depending on the area and
nature of such reservations and Municipal Commissioner may permit composite
development of reservations in case of such reservations. However, if the
HPC/Planning Authority requires BUA under any designation/reservation in excess
of the Zonal (basic) FSI, then such excess area shall be considered as rehabilitation
FSI, and incentive FSI as admissible under this Regulation shall be permissible.
Provided that in case of development of reservations of Rehabilitation &
Resettlement under the UDS, BUA equal to 30% of the Zonal (basic) FSI shall be
handed over to the MCGM free of FSI and free of cost, in addition to the
rehabilitation of the existing tenements or users if any.
In case of reconstruction/redevelopment of building of Corporation, for the area of
plot having no reservation or having designation of Municipal Housing, then the
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
BUA equal to 30% of such plot area as per Zonal (basic) FSI in the form tenements
of size as decided by Commissioner shall be made available to MCGM.
The developer/owner shall be entitled to BUA in lieu of cost of construction against
handing over of built up amenity as per Note (d) of Regulation No. 17 (1), in case of
(d), (e) & (f) above.
g. Where a proposed DP Road or Regular line of street passes through the UDS area,
the entire FSI admissible under this Regulation for the area of the road may be
given in the same Scheme.
The location of and the area under DP road/ existing roads falling in the UDS may
be allowed to be rearranged based on the comprehensive traffic study without
affecting the continuity of the existing traffic movement and without reducing the
total area of the existing road & DP Road. The existing roads may be realigned or
relocated as per provisions of MMC Act.
h. No premium shall be charged for the fungible compensatory area admissible as
per Regulation 31(3) for rehabilitation component of an UDS as sanctioned by HPC
and for the tenements to be handed over to MHADA and for the areas of
reservation to be handed over to MCGM/Appropriate Authority. This fungible
compensatory area admissible to the rehabilitation tenements shall be utilized for
rehabilitation component only. Its utilization for Sale Component under the UDS
shall not be permissible.
(EP-36)
(C)(II) Development of reservation in Reconstruction or redevelopment of Cluster of BDD
chawls at Naigaon, Worli, N.M.Joshi Marg and Shivdi under Urban Renewal Scheme(s)
under Regulation No. 33(9)(B).
Construction or reconstruction of slums/buildings falling under Reservations
contemplated in the Development Plan shall be permissible as under –
a. Redevelopment / reconstruction in any zone shall be allowed to be undertaken
without going through the process of change of zone. However, for the industrial user, the
existing segregating distance shall be maintained from the existing industrial unit.
b. Any land under non-buildable reservations, admeasuring only up to 500 sq. m may be
cleared by shifting the existing tenants from that site.
c. If the area under a non-buildable reservation is more than 500 sq. m., minimum 50% of
the area under reservation shall be developed for the same purpose and handed over to
Planning Authority, subject to a minimum of 500 sq. m and the remaining land shall be
allowed for development.
d. All the reservations in the Development Plan shall be rearranged/relocated, if necessary,
with the same area and the same width of access road or as required under DCPR,
whichever is more.
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
e. For the reservation of parking lot on a land included in URC, BUA equivalent to Zonal
(basic) FSI for the area under reservation in that plot shall be made available free of cost to
the Officer appointed by the Planning Authority. Such BUA to be handed over shall be free
of FSI.
f. For other buildable reservations on land, built up area equal to 60% of the Zonal (basic)
FSI under such reservations or existing built up area of the amenity whichever is more, on
that plot shall be made available free of FSI and free of cost to the Planning Authority. The
reservations of compatible nature can be preferably constructed in one or more separate
blocks/plot depending on the area and nature of such reservations and Officer appointed
by the Planning Authority may permit composite development of reservations in case of
such reservations. The vacant plot of DP reservation shall be allowed for residential
development, if the BUA of DP reservation is amalgamated and constructed on one or
more block/plot. However, if the Empowered Committee requires BUA under any
designation /reservation in excess of the Zonal (basic) FSI, then such excess area shall be
considered as rehabilitation F.S.I, and Free sale FSI as admissible under this Regulation
shall be permissible.
g. Where a proposed Development Plan Road or Regular line of street passes through the
Urban Renewal Scheme area, the entire FSI admissible under these Regulations for the area
of the road may be given in the same Scheme.
(EP-37)
(D) Development of reservation in Redevelopment for Rehabilitation of Slum Dwellers
under Regulation No. 33(10)
(a) Slums in Residential/Commercial Zone
(1) Slums situated in lands falling under Residential/Commercial Zone and affected by the
reservation in the DP shall be developed in accordance with the following provisions.
(2)(i) Any plot/layout having area under non-buildable/open space reservations
admeasuring up to 500 sq. m shall be cleared by shifting the slum-dwellers from that site.
(ii) Where the area of site having non-buildable/open space reservation, is more than 500
sq. m such sites may be allowed to be developed for slum redevelopment subject to
condition that the ground area of the land so used shall not be more than 67% 65% of the
reservation and leaving 33% 35% rendered clear thereafter for the reservation.
(3) Existing slum structures on lands reserved for Municipal School (RE 1.1)/ Primary and
Secondary School (RE1.2) or a Higher Education (RE2.1) may be developed subject to the
following:
(i) In case of land reserved for Municipal School (RE 1.1), Primary and Secondary School
(RE1.2) in the DP, a building for accommodating such number of students as may be decided
by the Municipal Commissioner, but in any case, for not less than 500 students, shall be
constructed by the owner or developer at his cost according to the size, design, specification
and conditions prescribed by the Municipal Commissioner. The BUA occupied by the
constructed building shall be excluded for the purpose of FSI computation, and where it is
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
intended for a Municipal School (RE 1.1) Primary and secondary school (RE1.2), the building
or part thereof intended for the school use shall be handed over free of cost and charge to
the Corporation. Thereafter, the land may be allowed to be redeveloped with the full
permissible FSI of the plot according to this Regulation
(ii)In the case of lands affected by reservation of a Higher Education (RE2.1) in the DP, a
building for accommodating such number of students as may be decided by the Municipal
Commissioner, but in any case for not less than 800 students, shall be constructed by the
owner or developer at his cost according to the size , design, specification and conditions
prescribed by the Municipal Commissioner, the BUA occupied by the constructed building
shall be excluded for the purpose of FSI computation. The constructed building shall be
handed over to the Corporation free of cost and charge and the Municipal Commissioner
may hand over the same or part thereof intended for the School use to a recognized and
registered educational institution for operation and maintenance on terms decided by him.
Thereafter the land may be allowed to be redeveloped with full permissible FSI of the plot
according to this Regulation.
(iii) In case area under reservation of Municipal School (RE 1.1)/ Primary and secondary
school (RE1.2) or a Higher Education (RE2.1) is spread on adjoining plot and the plot under
development, then in such cases Commissioner with special permission may insist upon
construction of Municipal School (RE 1.1)/ Primary and Secondary School (RE1.2) or a Higher
Education (RE2.1) in proportion to the area under reservation affecting the plot under
development. Requirements of Play Ground as per Regulation No 38 (I) (2) of these
regulations may not be insisted for (i) above.
(4) For other buildable reservations excluding Municipal School (RE 1.1)/ Primary and
Secondary School (RE1.2) or a Higher Education (RE2.1) on lands under slum, BUA equal to
25 percent of the area under that reservation in that plot, shall be demanded free of cost by
the Slum Rehabilitation Authority for the Municipal Corporation or for any other
appropriate Authority.
(5) In case of the plot reserved for the Parking Lot, 100% BUA as per Zonal (basic) FSI of
such reserved area shall be handed over to MCGM.
The developer/owner shall be entitled for the Built-Up Area (BUA) in lieu of cost of
construction against handing over of built up amenity as per Note (d) of Regulation 17(1) in
case of clause 3,4 & 5 above.
(6) Existing slum structures on lands reserved for Rehabilitation & Resettlement (RR 2.1)
shall be treated as sites for development of slum structures and shall be allowed for
redevelopment according to this Regulation.
Note: (a) However, reservation area beyond the slum structures shall have to be developed
entirely for the intended purpose only.
(2) In case where LOI/IOA was issued by CEO (SRA) prior to sanction of DP 2034 in respect
of plot affected by reservations as per SRDP 1991, then those reservations shall remain in
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
force as per DCR 1991 even after the sanction of DP 2034 and shall be developed as per
DCR 1991.
In case of conversion/revision of LOI as per this regulation and where plot is reserved for
different/same public purpose for equal or more area of reservation in DP 2034 than DP
1991, then development shall be as per this regulation. The DP road shall be reckoned with as
per DP 2034.
(EP-38)
(b) Slums in Industrial Zone (I)
(1) Slums in Industrial Zone (I) shall be allowed to be redeveloped in-situ without going
through the process of change of zone. In the free-sale component in any zone, in addition
to residential uses, all the uses permitted for the original zone shall be permitted. For
industrial uses, the segregating distance shall be maintained from the existing industrial unit
(2) Any plot/layout having area excluding area under DP Road/ prescribed RL as per MMC
Act as mentioned in the table below, may be allowed to be developed under this Regulation
by insisting handing over of amenity as detailed below:
Plot Area Under Development
Sr. No excluding area under DP Road/ BUA of built up amenity to be handed over
prescribed RL as per MMC Act
1 Up to 2000 sq. m BUA equal to 16% of plot area under
development
2 More than 2000 sq. m, but up to 1 BUA equal to 14% of plot area under
ha development
3 More than 1 ha, but up to 2 ha BUA equal to 12% of plot area under
development or 10% of plot directly accessible
from public road or an uninterrupted means of
access as per this regulation from the public road
4 More than 2 ha, but up to 5 ha BUA equal to 10% of plot area under
development or 8% of plot directly accessible
from public road or an uninterrupted means of
access as per this regulation from the public road.
5 More than 5 ha, but up to 10 ha BUA equal to 8 % of plot area under development
or 6% of plot directly accessible from public road
or an uninterrupted means of access as per this
regulation from the public road
6 More than 10 ha BUA equal to 5 % of plot area under development
or 3% of plot directly accessible from public road
or an uninterrupted means of access as per this
regulation from the public road
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
(3) Requirement of LOS as per the provisions of Regulation No.27 (1)(a) shall be insisted.
(4) In the event of DP having provided reservation/reservations on a plot where
development under Regulation No 33(10) is proposed, the following shall apply:
a. If the area under DP reservation to be handed over to MCGM (excluding the areas under
D P roads/ road setback) is less than the land component of built up amenity required as per
this Regulation, only the additional land area shall be provided for amenity.
b. If the area under DP reservation to be handed over to MCGM, (excluding the areas under
DP roads/ road setback), is more than the land component of built up amenity required as
per this Regulation, then the provision for amenity is not necessary.
5) The owner shall give advanced possession of the land wherever applicable (to be
handed over) to MCGM/Appropriate Authority at the time of seeking Approval for
Development of plot. It shall be responsibility of the land owner to clear all the
encumbrances and complete the formalities towards transferring the land in the name of
MCGM/Appropriate Authority. Proforma of possession receipt shall be as per Appendix V.
6) The area of built up amenity shall be counted in FSI initially and after handing over of
said built up amenity the area of built up amenity shall be allowed free of FSI.
Commencement Certificate in respect of BUA in lieu of the built-up amenity handed over
to MCGM can be granted only after handing over of such built up amenity or before
availing zonal (basic) FSI beyond 75% of gross plot area or before seeking Occupation
Certificate to any part of building/ buildings beyond 75% of admissible BUA, other than
the built-up amenity.
(7) The developer shall be entitled to the cost of construction of development of buildable
amenity as per provision of regulation 17(1) Note (d).
(EP-39)
(c) Slums in Special Development Zone –I (SDZ-I)
Slums situated in lands falling under SDZ 1 in the DP, shall be developed in accordance with
the following provisions
(1) Any plot/layout having area admeasuring up to 4000 sq. m excluding area under DP
Road/ prescribed RL as per MMC Act shall not be allowed to be developed under this
Regulation and be cleared by shifting the slum-dwellers from that site.
(2) Any plot/layout having area admeasuring more than 4000 sq. m excluding area under DP
Road/ prescribed RL as per MMC Act may be allowed to be developed under this Regulation
by insisting handing over of amenity as detailed below:
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
Plot Area Under
Development excluding
% of land area as Amenity to be BUA of built up amenity to
Sr. No area under DP Road/
handed over to MCGM as POS be handed over
prescribed RL as per MMC
Act
1 More than 4000 sq. m, 15 BUA equal to 13% of plot
but up to 2 ha area under development
2 More than 2 ha, but up to 15 BUA equal to 10 % of plot
5 ha area under development.
3 More than 5 ha, but up to 15 BUA equal to 8 % of plot
10 ha area under development
4 More than 10 ha 15 BUA equal to 5 % of plot
area under development
(3) Requirement of ROS as per the provisions of Regulation No. 27 (1)(a) shall be insisted
and shall not be reduced than the required.
(4) In the event of DP having provided reservation/reservations on a plot desiring
development under Regulation No 33(10), the following shall apply:
a. If the area under DP reservation to be handed over to MCGM (excluding the areas under
D P roads/ road setback) is less than the required area of POS plus land component of built
up amenity as per this Regulation, only the additional land area shall be provided for
amenity and POS.
b. If the area under DP reservation to be handed over to MCGM, (excluding the areas under
DP roads/ road setback), is more than the required area of POS plus land component of built
up amenity as per this Regulation, then the provision for amenity and POS is not necessary.
5) The owner shall give advanced possession of the land wherever applicable (to be
handed over) to MCGM/Appropriate Authority at the time of seeking Approval for
Development of plot. It shall be responsibility of the land owner to clear all the
encumbrances and complete the formalities towards transferring the land in the name of
MCGM/Appropriate Authority. Proforma of possession receipt shall be as per Appendix V.
6) The area of built up amenity shall be counted in FSI initially and after handing over of
said built up amenity the area of built up amenity shall be allowed free of FSI.
Commencement Certificate in respect of BUA in lieu of the built-up amenity handed over
to MCGM can be granted only after handing over of such built up amenity or before
availing zonal (basic) FSI beyond 75% of gross plot area or before seeking Occupation
Certificate to any part of building/ buildings beyond 75% of admissible BUA, other than
the built-up amenity.
(7) The developer shall be entitled to the cost of construction of development of buildable
amenity as per provision of regulation 17(1) Note (d).
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai
(EP-40)
(E) Metro Station interchanges:
The buildable reservations if any, on plots abutting Metro Station interchanges shall cease to exist
on identification of such Metro Station interchanges to that extent, subject to condition that
minimum 20% of plot area shall be kept reserved for parking lot, which can be developed under
accommodation reservation policy under regulation 17(1). However the non-buildable (open spaces)
reservations shall be implemented to the full extent.
(EP-41)
Development Control and Promotion Regulation-2034 Municipal Corporation of Greater Mumbai