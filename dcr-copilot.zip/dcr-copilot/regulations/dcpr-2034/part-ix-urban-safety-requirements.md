# Part IX: Urban Safety Requirements

47. Fire Protection Requirements
(1) General: The planning, design and construction of any building shall be such as to
ensure safety from fire. For this purpose, unless otherwise specified in these Regulations,
Fire Protection Chapter, National Building Code as amended time to time shall apply.
For high rise and special buildings, additional provisions relating to fire protection
contained in Appendix I shall also apply,
(A) For proposal under regulations 33(5), 33(6), 33(7), 33(7)(A), 33(7)(B), 33(9), 33(9)
(A),33(9)(B), 33(10), 33(10)(A), 33(11), 33(15), and 33(20)(A),33(20)(B)
In case of rehabilitation/composite buildings having height more than 32 m, at least
one side other than road side, shall have clear open space of 6 m at ground level,
accessible from road side.
Provided, if the building abuts another road of 6 m or more, this condition shall not be
insisted upon. Provided, however, if podium is proposed it shall not extend 6 m beyond
building line so as to have clear open space of 6 m beyond podium for height up to 70
m & 9 m beyond 70 m.
Provided further, where podium is accessible to firefighting appliances (fire engines and
other equipment) by a ramp, the above restriction shall not apply
(B) For the proposals, other than (A) above
(a) Buildings having height more than 32 m up to 70 m, at least one side, accessible from
road side, shall have clear open space of 9 m at ground level.
Provided, if the building abuts another road of 6 m or more, this condition shall not be
insisted upon.
Provided, however, if podium is proposed it shall not extend 6m from 2 sides beyond
building line so as to have clear open space of 6m beyond podium.
Provided that, if the building abuts 9 m. or more wide road then 6 m. open space from
one side will be adequate.
Provided, further, where podium is accessible to firefighting appliances (fire engines
and other equipment) by a ramp, the above restriction shall not apply.
(EP-147)
(b) Buildings having height more than 70 m, at least two sides, accessible from road side,
shall have clear open space of 9 m at ground level.
Provided however, if podium is proposed it shall not extend 6 m beyond building line so
as to have clear open space of 9 m beyond podium. No ramps for the podium shall be
provided in these side open spaces.
Provided further, where podium is accessible to firefighting appliances (fire engines and
other equipment) by a ramp, the above restriction shall not apply.
(c) Courtyard/ramp/podium accessible to firefighting appliances (fire engines and other
equipment) shall be capable of taking the load up to 10 Kg/cm2.
(d) These open spaces shall be free from any obstruction & shall be motorable.
Note- The additional fire safety requirements shall be as per fire manual approved by
Municipal Commissioner based on the Fire Act and Fire Protection Chapter of NBC
amended time to time.
(2) Construction Materials:
a) All construction material used in stairways, corridors and façades shall be non-
combustible/fire resistance.
b) Materials used for interior finishes shall not have a flame spread ability rating
exceeding Class I, section 3.4.15.2 and 3.4.15.3 of Part 4 of National Building Code &
amended from time to time.
(3) Exits: Every building meant for human occupancy shall be provided with exits
sufficient to permit safe escape of its occupants in case of fire or other
emergency for which the exits shall conform to the following:
(i) Types: Exits should be horizontal or vertical. A horizontal exit may be a door-
way, a corridor, a passage-way to an internal or external stairway or to an
adjoining building, a ramp, a verandah or a terrace which has access to the
street or to the roof of a building. A vertical exit may be a staircase or a ramp,
but not a lift.
(ii) General requirements: Exits from all the parts of the building, except those not
accessible for general public use, shall-
(a) provide continuous egress to the exterior of the building or to an exterior
open space leading to the street;
(b) be so arranged that, except in a residential building, they can be reached
without having to cross another occupied unit;
(c) be free of obstruction;
(d) be adequately illuminated;
(e) be clearly visible, with the routes reaching them clearly marked and signs
posted to guide any person to the floor concerned;
(f) be fitted, if necessary, with firefighting equipment suitably located but not
as to obstruct the passage, clearly marked and with its location clearly
indicated on both sides of the exit way;
(g) be fitted with a fire alarm device, if it is either a high-rise, high-use or a
special building so as to ensure its prompt evacuation;
(h)remain unaffected by any alteration of any part of the building so far as
their number, width, capacity and protection thereof is concerned;
(i) be so located that the travel distance on the floor does not exceed the
following limits: -
(i) Residential, educational and institutional: 22.5 and 30 m with sprinklers in
passages and Corridors.
(ii) Assembly, starred category hotels business, mercantile, industrial,
hazardous occupancies and storage buildings: 30m
Note- The travel distance to an exit from the dead end of a corridor shall not
exceed half the distance specified above. When more than one exit is
required on a floor, the exits shall be as remote from each other as possible:
Provided that, in case of high rise and special buildings, a minimum of two
enclosed type staircases shall be provided, at least one of them opening
directly to the exterior, to an interior open space or to any open place of
safety.
(iii)Number and width of exits
The width of an exit, stairway/corridor and exit door to be provided at each
floor in occupancies of various types shall be as shown in columns 3 and 5 of
Table No 22 here under. Their number shall be calculated by applying to
every 100-sq. m of the plinth or covered area of the occupancy, the relevant
multiplier in columns 4 and 6 of the said Table, fractions being rounded off
upward to the nearest whole number.
Table No: 22
Width and Number of Exits for various Occupancies
Serial Type of Occupancy Stairway/Corridor Door Minimum Exit
width in m
No. Minimum Multiplier Multiplier
width in m
(5)
(1) (2) (3) (4) (6)
1 Residential Dwellings 1.2 0.145 ….
0.053
row-housing/Duplex Flats 0.750.90 0.213
(2 storeys)
1.5 0.107
hotels
2 Educational-
-up to 32m high 1.5 0.333 …. 0.667
-over 32 m high 2.0 0.250 ….
3 Institutional i.e. Hospitals-
-up to 10 beds
-over 10 beds 1.5 .089* …. 0.044
2.0 .067* 0.044
4 Assembly** …. …. 1.0 ….
-fixed seats or loose seats
and dance floor.
2.0 0.694 …. 0.926
-no seating facilities and
dining rooms
2.0 0.278 …. 0.370
5 Mercantile-
-street floor and basement 1 . 5 0.222 …… 0.222
-upper sales floors
1.5 0.111 0.111
6 Business, Industrial 1.5 .067 …. 0.067
7 Storage 1.5 .022 …. 0.022
8 Hazardous 1.5 .133 …. 0.125
*For the dormitory portions of homes for the aged, orphanages, mental hospitals,
etc., these multipliers shall be doubled.
**The plinth or covered area shall include, in addition to the main assembly rooms
or space, any occupied connecting room or space in the same storey or in the
storey above or below where entrance is common to such rooms and space and
they are available for use by the occupants of the assembly place.
No deductions shall be made in the gross area of the corridors, closets or other
sub-divisions. All space serving the particular assembly occupancy shall be
reckoned.
48. Requirements of Exits
The detailed requirements of individual exits at each floor are given below:
(1) Corridors:
(a) Exit corridors shall be of a width not less than the total required width of exit
doorways leading from them in the direction of travel to the exterior/stairway.
(b) Where stairways discharge through corridors, the height of the corridors shall not
be less than 2.4 m.
(c) Where there is more than one staircase serving a building, there shall be at least
one smoke-stop door in the space between the staircases.
(2) Doorways:
(a) Every exit doorway shall open into an enclosed stairway, a horizontal exit or a
corridor or passageway providing continuous and protected means of egress;
(b) An exit doorway shall open outwards i.e. away from the room, but shall not
obstruct the travel along any exit. No door, when opened, shall reduce the
required width of a stairway or landing to less than 90 cm.
(c) An exit door shall not open immediately upon a flight of stairs; a landing equal to
at least the width of the door shall be provided in the stairway at each doorway;
the level of the landing shall be the same as that of the floor which it serves.
(d) Exit doorways shall be open able from the side which they serve, without the use
of a key.
(3) Revolving doors:
(a) Revolving doors shall not be used as required exits except in residential, business
and mercantile occupancies; they shall not constitute more than half the total
required door width.
(b) When revolving doors are considered as required exit ways-
(i) the multiplier in Table 22 shall be increased by 33 1/3 per cent, and;
(ii) revolving doors shall not be located at the foot of a stairway. Any stairway served
by a revolving door shall discharge through a lobby or foyer.
(4) Internal stairways-
(a) Stairways shall be constructed of non-combustible materials throughout.
(b) Any interior staircase shall be constructed as a self-contained unit with at least
one side adjacent to an external wall and shall be completely closed.
(c) A staircase shall not be arranged around a lift shaft unless the latter is entirely
enclosed by a material of fire resistance rating as that for type of construction
itself. For high rise and special buildings, the staircase location shall be to the
satisfaction of the Chief Fire Officer.
(d) In high rise and special buildings, access to main staircases shall be gained through
at least half-an-hour fire-resisting automatic closing doors, placed in the enclosing
walls of the staircases. They shall be swing type doors opening in the direction of
the escape.
(e) No living space, store or other space, involving fire risk, shall open directly into a
staircase.
(f) The external exit door of a staircase enclosure at ground level shall open directly
to the open space or should be accessible without passing through any door other
than a door provided to form a draught lobby.
(g) In high rise and special buildings, exit signs with arrows indicating the escape
route shall be provided at a height of 1.5 m from the floor level on the wall and
shall be painted with fluorescent paint. All exit way signs should be flush with the
wall and so designed that no mechanical damage to them can result from the
moving of furniture or other heavy equipment.
(h) Where a building has a single staircase, it shall terminate at the ground floor level,
and the access to the basement shall be by a separate staircase. Where the
building is served by more than one staircase, one of the staircases may lead to
the basement level, by either a ventilated lobby or a cut-off screen wall without
opening, having a fire resistance of not less than 2 hours with discharge point at
two different ends or through enclosures. It shall also be cut-off from the
basement area at various basement levels by protected and ventilated
lobby/lobbies. Staircase leading from basement shall be staggered at ground floor
and then diverted to upper floors
(5) (A) Additional Staircase:
(a) In case of high-rise Residential buildings of 70 m or less, additional staircase shall
be necessary.
Provided, however, it will not be necessary, if,
(i) Travel distance does not exceed that mentioned in sub regulation (3)(ii)(i)(i&ii)of
regulation 47 and;
(ii) If floor area on any floor does not exceeds 500 sq. m
Note: These staircases shall be of enclosed type having minimum width of 1.5 2.0
m.
(b) Buildings having height 70 m or more, shall be provided with two enclosed type
staircases, each having width not less than 1.5 2.0 m.
(c) Whenever two staircases are necessary, both the staircases shall open & terminate
at ground floor or to any other place of safety. The staircases shall be as remote as
possible from each other
(d) Staircase leading from basement shall be staggered at ground floor and then
diverted to upper floor
(e) The fire escape staircase other than one required per building/wing shall be free
of FSI without charging premium.
(B) In case of Institutional/Special Buildings, non-residential high-rise buildings
minimum two staircases shall be necessary.
(6) Fire Escape Balcony:
(a) For industrial buildings, a fire escape balcony not exceeding 1.5 m in width shall be
provided at the periphery of every floor level and shall be connected to staircase
and shall have a railing / parapet of 1.1 m height on external sides.
(b) Requirement of Fire Escape Balcony
(i) It shall always be kept free from obstructions & no partitions shall be erected.
(ii) It shall be provided with wall type sprinklers at every floor level.
Note: Fire Escape balcony shall be counted in FSI.
(7) Ramp:
(a) All the requirements of sub regulation (4) of this Regulation shall apply to any
ramp as they apply to a staircase.
(b) Ramps shall lead directly to outside open spaces at ground level or courtyards or
other safe places.
(c) In a high rise and special building, access to ramps from any floor shall be through
a smoke-stop door.
(8) Refuge area
(a) (i) The refuge area shall be preferably provided within building line at floor level.
(ii) In case of high rise buildings having height more than 32 m, first refuge area shall be
provided at 24 m or at 1st habitable floor, whichever is higher. Thereafter, the refuge area
shall be provided at every 7th habitable floor. The refuge area shall be 4% of the habitable
floor area it serves, and will be free of FSI. With the permission of Commissioner due to
planning constraints it may be allowed to be exceeded up to maximum limit of 4.25%. If it
exceeds 4.25%, the excess area shall be counted in FSI.
(b) For buildings having height up to 70 m, as an alternate, Refuge areas can be provided as
RCC cantilever projections at the alternate mid-landing levels of staircase, free of FSI. Each
refuge area at mid-landing shall have a minimum width of 3.0 m, and minimum area of
10.0 sq. m for residential and 15 sq. m for non-residential buildings.
(c) In case of buildings up to 32 m height, the terrace floor of the building shall be treated as
the refuge area.
(9) Fire Escape Chutes/ Controlled Lowering Device for evacuation-
(A) (i) High rise building having height more than 70 m shall necessarily be provided with fire
escape chute shaft/s for every wing adjacent to staircase.
(ii) Walls of the shaft shall have 4 hours’ fire resistance.
(iii) One side of the shaft shall be at external face of the building with proper ventilation.
(iv) The dimension of the shaft shall not be less than 2.5 m x 1.5m.
(v) The access to the fire escape chute’s shaft shall be made at every floor level from lobby
area or from staircase mid-landing with self-closing door having fire resistance of at least
one hour.
(vi) The fire chute shall be of staggered type with landing of each section at the vertical
height of not more than 21 m.
Alternatively,
(B) For High rise building having height more than 70 m, “Controlled Lowering Device for
Evacuation” or “External Evacuation System” as approved by CFO shall be provided.
(C) Fire Check Floor
A high rise building having height more than 70 m, shall be provided with fire check floor
(entire floor) at every 70 m level.
Height of the fire check floor shall not be more than 1.8 mts.
The fire check floor shall not be used for any purpose and it shall be the responsibility of
the owner/occupier to maintain the same clean and free of encumbrances and
encroachments at all times.
Periphery of the Fire Check floor shall not be enclosed.
Fire Drenchers shall be provided at the periphery of the each fire check floor externally.
(EP-148)
49. Structural Safety and Services
(1) Structural Design:
(a) The structural design of foundations, elements made of masonry, timber, plain
concrete, reinforced concrete, pre-stressed concrete and structural steel shall
conform to the provisions of Part VI Structural Design Section1- Loads, Section 2-
Foundation, Section 3-Wood, Section 4-Masonry, Section5-Concrete, Section 6-
Steel, National Building Code of India and as per relevant I S code.
(b) The structural design shall comply with Indian Standard Codes of structural
design for structural safety, seismic safety and against cyclone/wind storms as
listed below and as amended up to date:
a. Indian Standard Code of Practice for Earthquake Resistant Design IS1893,
IS4326
b. Indian Standard Seismic Code of Practice for Seismic Design IS1893(Part1):2002
c. Indian Standard Code of Practice for Wind Pressure (IS:1875Part3-1987)
d. IS Code as would be made applicable by Bureau of Indian Standard from time to time
(2) Structural Safety for Protection of Buildings against Natural Hazard:
In Natural Hazard, prone areas viz, Earth quake Prone areas as per IS: 1893, the
cyclone prone areas as per IS: 875 Part-3 and flood prone areas as per the Flood
Atlas prepared by the Central Water Commission and/or the Disaster Management
-
TRAP
Department of MCGM, development shall be regulated to ensure special
protection from hazards for any type of development irrespective of use of zones.
The supervision certificate and the completion certificate of every such building
shall contain a certificate recorded by the Structural Engineer and
Architect/Licensed Surveyor that the norms of IS: 1893-2002 have been followed
in the design and construction of buildings for making the buildings resistant to
earthquake and compliance with other structural safety and fire safety
requirements
(3) Quality of materials and workmanship:
i. The quality of all materials and workmanship shall conform to accepted
standards and Indian Standard Specifications and Codes as included in Part V
Building Materials and Part-VII Constructional Practices and Safety, National
Building Code of India.
ii. All burrow pits dug in the course of construction and repair of buildings, roads,
embankments, etc., shall be deep and connected with each other in the
formation of a drain directed towards the lowest level and properly stepped for
discharge into a river, stream, channel or drain, and no person shall create
any isolated burrow pit which is likely to cause accumulation of water that may
breed mosquitoes.
iii. Alternative materials, method of design and construction and tests:
The provisions of these Regulations are not intended to prevent the use of any
material or method of design of construction not specifically prescribed in
them provided that any such alternative has been approved. Nothing in the
provisions of these Regulations is intended to prevent the adoption of
architectural planning and layout conceived as an integrated development
scheme. The Commissioner may approve any such alternative if it conforms to
the provisions of the relevant parts of the National Building Code regarding
material, design and construction, and the material, method, or work offered
is, for the purpose intended, at least equivalent to that prescribed in these
Regulations in terms of quality, strength, compatibility, effectiveness, fire and
water resistance, durability and safety. Site supervisor and Architect/Licensed
Surveyor shall submit the Completion Certificate in the format as stated in
Annexure 16 and 18
(4) Tests:
Whenever there is insufficient evidence of compliance with the provisions of
these Regulations or evidence that any material or method of design or
construction does not conform to the requirements of these Regulations, in
order to substantiate claims for alternative materials, designs or methods of
construction, the Commissioner may require tests, sufficiently in advance, as
proof of compliance. These tests shall be made by an approved agency at the
expense of the owner as follows:
(1) Test Methods: Test method shall be as specified by these Regulations for
the material or design or construction in question. If there are no appropriate
test methods specified in these Regulations, the Commissioner shall determine
the test procedure. For methods of tests for building materials, reference shall
be made to the relevant Indian standards as given in the National Building Code
of India published by the Bureau of Indian Standards.
(2) Test Results: Copies of the results of all such tests shall be submitted to the
Commissioner.
50. Building services
(1) Electrical installation: The planning, design and installation of electrical air-
conditioning and heating work shall conform to the provisions of Part VIII Building
Service Section 2- Electrical Installations. Section 3- Air-conditioning and Heating
National Building Code of India.
(2) Lifts:
(a) Planning and design: The planning and design of lifts including their number,
type and capacity depending on the occupancy of the building, the population
on each floor based on occupant load and the building height shall be in
accordance with section 5- Installation of lifts and Escalators, National
Building Code of India.
(b) Maintenance:
(i) The lift installation should receive regular cleaning, lubrication, adjustment
and adequate servicing by authorized competent persons at such intervals as
the type of equipment and frequency of service demand. In order that the lift
installation is maintained at all times in a safe condition, a proper maintenance
schedule shall be drawn up in consultation with the lift manufacturer and
rigidly followed. A log book to record all items relating to general servicing and
inspection shall be maintained. The electrical circuit diagram of the lift with
the sequence of operation of different components and parts shall be kept
readily available for reference by persons responsible for the maintenance and
replacement, where necessary, to the satisfaction of the competent authority
i.e., Lift Inspector of the Government of Maharashtra.
(ii) Any accident arising out of operation or maintenance of the lifts shall be
duly reported to the competent authority i.e., Lift Inspector of the Government
of Maharashtra.