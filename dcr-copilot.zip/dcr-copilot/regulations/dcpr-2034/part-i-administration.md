# Part I: Administration

1. Short title, extent and commencement
(I) Title: These Regulations shall be called the “Development Control and
Promotion Regulations for Greater Mumbai, 2034” (hereinafter called “these
Regulations”).
(II) Jurisdiction: These Regulations apply to building activity and development
work in areas under the entire jurisdiction of the Municipal Corporation of
Greater Mumbai (hereinafter called "the Corporation"). If there is a conflict
between the requirements of these Regulations and those of any other rules or
byelaws, these Regulations shall prevail.
Provided, however, that in respect of areas included in a finally sanctioned
Town Planning Scheme, if there is a conflict between the requirements of
these Regulations and the Town Planning Scheme Regulations, the provisions
of these Regulations shall prevail. , except provisions regarding access, where
Town Planning Scheme Regulations shall prevail.
Provided further that, these regulations shall not apply to the Manori-Gorai-Uttan
Notified area.
(EP-1)
(III)Protection: Any a Action of the Commissioner in respect of the implementation
of Development Plan in accordance with the provisions of these Regulations, grant
of permissions, and action against violations, etc. shall be deemed to have been
done in good faith. No suit, prosecution or other legal proceedings shall lie against
any person for any thing which is in good faith done or intended to be done under
the MR&TP Act or any rules or regulations made their under.
(EP-2)
(IV)Date of coming into force: These Regulations shall come into force on from the
date of publication in Maharashtra Government Gazette sanction by the
Government under section 31 of Maharashtra Regional and Town Planning Act,
1966 (Mah. Act No. XXXVII of 1966) and shall replace the existing Development
Control Regulations for Greater Mumbai framed under the MR &TP Act, 1966.
(V) Transitional arrangement: Section 46 of the MR&TP Act, 1966 provides that
“The Planning Authority in considering application for permission shall have due
regard to the provisions of any draft or final plan or proposal published by means
of notice submitted or sanctioned under this Act.”
Notwithstanding such provision, it is clarified that from the date of publication of
Revised Draft Development Plan 2034 (RDDP) of Greater Mumbai under Section 26
of the said Act till its sanction under Section 31 of the said Act, the following
transitional provisions shall apply.
1. Land Use Zones: The stringent of Land Use Zones of DP 1991 and RDDP
shall prevail.
2. Development of Land Reserved for Public Purposes: The reservations
from SRDP 1991 including those proposed to be deleted in the RDDP will
continue to be in force. The reservations as reflected in RDDP shall be
considered as reservations. However, the land reserved for public
purpose shall be developed as per provisions of DCR 1991 till its sanction
under section 31 of the said Act. Reservations if any, not reflected in DP
1991, but reflected in the RDDP, and where there is no provision in DCR
1991 for the development of such reservations, shall be developed as
per RDDP. The permissibility of FSI, however, shall be as per DCR 1991.
Provided further that, if the plot is reserved for a different public
purpose in DP 1991 than the proposed reservation in RDDP, then the
reservation as per DP 1991 shall prevail till the sanction of RDDP 2034.
3. Control of other Development: All other aspects of development shall
continue to be governed by the DCR 1991 including payments for
premium as amended up to date till the RDDP is sanctioned.
(EP-3)
2 Definitions of Terms and Expressions
(I) General: In these Regulations, unless the context otherwise requires, the terms
and expressions shall have the meaning indicated against each of them.
(II) Meaning as in the Acts, Rules, etc.: Terms and expressions not defined in these
Regulations shall have the same meanings as in the MR&TP Act, 1966 or the
Mumbai Municipal Corporation Act, 1888 (Mumbai Act No. III of 1888) or any
other Act and the rules or bye-laws framed thereunder, as the case may be,
unless the context otherwise requires.
(III) Terms and expressions neither defined in these Regulations nor defined in (I) and
(II) above shall be interpreted with reference to the latest National Building Code
in the relevant context.
(IV) Definitions.
(1) “Access” means clear approach to a plot or a building.
(2) "Accessory building" means a building separated from the main building on a
plot, and put to one or more accessory/ancillary use.
(3) "Accessory/Ancillary use" means use of the building, subordinate and
customarily incidental to the principal use.
(4) “Accommodation Reservation” means a land instrument enabling a Planning
Authority to acquire part of the reserved land and/or developed amenity in
accordance with these Regulations. plot of land reserved for public purpose,
where land owner has an option of handing over the part of land and/or
developed amenity to MCGM, for the intended public purpose and developing
balance land with permissible Development Right (DR) for the entire plot with
the provision of these regulations.
(5) "Act" means-
(i) The Maharashtra Regional and Town Planning Act, 1966 (Mah. Act No. XXXVII of
1966); or
(ii) The Mumbai Municipal Corporation Act, 1888 (Mumbai Act No. III of 1888)
(6) "Addition and/or alteration" means change from one occupancy to another, or a
structural change, such as addition to the area or height, or the removal of part
of a building, or a change to the structure, such as the construction or cutting
into or removal of any wall or part of a wall, partition, column, beam, joist, floor
including a mezzanine floor or other support, or a change to or closing of any
required means of ingress or egress, or change to fixtures or equipment, as
provided in these Regulations.
(7) "Advertising sign" means any surface or structure with characters, letter or
illustrations applied thereto and displayed in any manner whatsoever out of
doors for the purpose of advertising or giving information regarding or to
attract the public to any place, person, public performance, article or
merchandise, and which surface or structure is attached to, forms part of, or is
connected with any building, or is fixed to a tree, or to the ground or to any
pole, screen, fence or hoarding or displayed in space or in or over any water
body included in the limits of Greater Mumbai i.e. Island City, Suburbs or
extended Suburbs as defined in section 3 of the Mumbai Municipal Corporation
Act, 1888, and area specified in Part II to IV of Schedule `A` to the Greater
Mumbai Laws and Mumbai High Court (Declaration of Limits) Act,1945.
However, advertising sign shall not include hoarding displaying details of the
project as per IOD/IOA condition, at the site of the project.
(8) “Affordable Housing” means social housing in the nature of housing meant for
economically weaker section, lower income group, middle income group and
which also includes rental housing.
(8)(9) "Air-conditioning" means the process of treating air to control simultaneously
its temperature, humidity, cleanliness and distribution to meet the requirement
of an enclosed space.
(9)(10)“Alcove” means a cooking place with direct access from the main room without
a communicating door.
(10) “Amenity Space” means a statutory space provided in any layout/plot to be
used for any of the amenities/utilities specified in these regulations space for
public amenities such as Recreational Open Spaces, Markets, Welfare Centres,
AdharKendras, Police Chowkies, Public Sanitary Conveniences, Municipal
Library, Reading Rooms, Gymkhanas/Gymnasium, Municipal Chowkies, Shelter
for Destitutes, Multi-purpose Housing for Working women, Homeless Shelters,
Old Age Homes, Pumping Stations, Citizen Facility Centres, Municipal
Dispensaries, Schools, Facility for Solid Waste Management, Fire Station, Fuel
Stations, Electric Sub Station, etc. either for single facility or for multiple
facilities as specified in these Regulations.
(EP-4)
(11)(11) "Architect" means a person who is an associate or corporate member of the
Indian Institute of Architects or who holds a degree or diploma which makes
him eligible for such membership for such qualifications listed in Scheduled XIV
of the Architects Act, 1972 and being duly registered with the Council of
Architecture under the said Act.
"Architect" means a person registered as an architect under the provisions of
the Architects Act, 1972.
(12) “Atrium” means the area comprised of entrance lobby or common entrance hall
of the building or common area at any floor level which serves as a Common
Open Spaces for more than one floor.
(12)(13) "Automatic sprinkler system" means an arrangement of pumps, pipes and
sprinklers, set to activate automatically on detection of fire inside the building
and spray water under force to douse fire, simultaneously setting an audible
alarm.
(13)(14) "Balcony" means a horizontal projection, including a parapet, hand-rail
balustrade, to serve as a passage or sitting out place.
(14)(15) "Basement or cellar" means the lower storey of a building below, or partly
below the ground level.
(15)(16) “Biotechnology Unit” means and includes Biotechnology units which are
certified by the Development Commissioner (Industries) or any other officer
authorized by him on his behalf.
(16)(17) "Building” means a structure, constructed with any materials whatsoever
for any purpose, whether used for human habitation or not, and includes-
(i) Foundation, plinth, walls, floors, roofs, chimneys, plumbing and building
services, fixed platforms;
(ii) Verandahs, balconies, cornices, projections;
(iii) part of a building or anything affixed thereto;
(iv) any wall enclosing or intended to enclose any land or space, signs and outdoor
display structures;
(v) tanks constructed for storage of chemicals or chemicals in liquid form;
(vi) all types of buildings defined in (a) to (q) below; but tents, shamianas and
tarpaulin shelters erected for temporary purposes for ceremonial occasions,
with the permission of the Commissioner, shall not be considered to be
"buildings".
(a) "Assembly building" means a public building or part thereof where groups of
people congregate or gather for amusement, recreation, social, religious,
patriotic, civil, travel and similar purposes. "Assembly buildings" include
buildings of drama and cinema theatres, drive-in-theatres, assembly halls, city
halls, town halls, auditoria, exhibition halls, museums, mangal karyalayas,
skating rinks, gymnasia, stadia, restaurants, eating or boarding houses, places of
worship, dance halls, multipurpose hall, clubs, gymkhanas, malls, road, air, sea
or other public transportation stations, and recreation piers. Public for this
purpose shall mean use open for public at large.
(b) "Business building" means any building or part thereof used for transaction of
business and/or keeping of accounts and record therefor; offices, banks,
professional establishments, IT establishments, call centers, offices for private
entrepreneur, court houses, provided their principal function is transaction of
business and/or keeping of books and records.
(c) "Detached building” means a building with walls and roofs independent of any
other building and with open spaces on all sides.
(d) "Educational building" means a building exclusively used for a school or college,
recognized by the appropriate Board or University, or any other competent
authority involving assembly for instruction, education or recreation incidental
to educational use, and including a building for such other uses incidental
thereto such as a library, multipurpose hall, auditorium or a research
institution. It shall also include quarters for essential staff required to reside in
the premises, and a building used as a hostel captive to an educational
institution whether situated in its campus or not.
(e) "Hazardous building" means a building or part thereof used for-
(i) storage, handling, manufacture or processing of radioactive substances or of
highly combustible or explosive materials or products which are liable to burn
with extreme rapidity and/or producing poisonous fumes or explosive
emanations;
(ii) storage, handling, manufacture or processing which involves highly
corrosive, toxic or noxious alkalis, acids, or other liquids, gases or chemicals
producing flame, fumes and explosive mixtures or which result in division of
matter into fine particles capable of spontaneous ignition.
(f) "Industrial building" means a building or part thereof wherein products or
material are fabricated, assembled or processed, such as assembly plants,
laboratories, power plants, refineries, gas plants, mills, dairies and factories as
approved and certified by the Development Commissioner (Industries).
(g) "Institutional building" means a building constructed or used by Government,
Semi-Government organisations or registered Trusts or persons and used for
education, health, research and such other activities, multi-purpose
housing/hostel for workingwomen/persons/students, but not for lodging or for
an auditorium or complex for cultural and allied activities or for an hospice, care
of persons suffering from physical or mental illness, handicap, disease or
infirmity care of orphans, abandoned women, children and infants,
convalescents, destitute or aged persons and for penal or correctional detention
with restricted liberty of the inmates ordinarily providing sleeping
accommodation, and includes dharamshalas, hospitals, sanatoria, custodial and
penal institutions such as jails, prisons, mental hospitals, houses of correction,
detention and reformatories.
(h) “Information Technology Building” means a building used for the purpose of
business of developing either software or hardware or providing IT enabled
services as defined in IT policy amended from time to time.
(h)(i) "Mercantile building" means a building or part thereof used as shops, stores or
markets for display and sale of wholesale or retail goods or merchandise,
including office, storage and service facilities incidental thereto located in the
same building.
(i)(j) "Office building" (Premises), means a building or premises or part thereof
whose sole or principal use is for an office or for office purposes or clerical
work. "Office purposes" includes the purpose of administration, clerical work,
handling money, telephone, telegraph and computer operation and such other
activities; and "clerical work" includes including writing, book-keeping, sorting
papers, typing, filing, duplicating, data processing, drawing of matter for
publication and editorial preparation of matter for publication and such other
activities.
(j)(k) “Public Building” means a building used or intended to be used either
ordinarily or occasionally by the public such as;
(a) offices of Central or State Government or any Public-Sector Undertaking or
Statutory Authority or Local Authorities
or (b) buildings such as;
i. temple, mosque, church, chapel, or any place of public worship.
ii. public or private college, school, library, or places of educational facilities.
iii. cinema, public concert hall, drama theatre, auditorium, sports complex, sports
facility, theatre for cultural activities.
iv. public hall, welfare centre, exhibition hall, Museum or any other place of
assembly.
v. hospital, maternity home etc. or any other place of medical facility.
vi. market, shopping centre, departmental store or mall with or without multiplex
or any other place of retail and wholesale merchandise.
vii. railway station, metro/mono rail station, bus station, airport or any other
public transport terminal.
viii. public or private hospital
(k)(l) "Residential building" means a building in which sleeping accommodation is
provided for normal residential purposes, with or without cooking or dining
facilities, and includes one or more family dwellings, lodging or rooming houses,
hostels, dormitories, apartment houses, flats, and private garages of such
buildings.
(l)(m) “Semi-detached building" means a building detached on three sides.
(m)(n) “Special building" means-
(i) a building solely used for the purpose of a drama or cinema theatre, a drive-in-
theatre, an assembly hall or auditorium, an exhibition hall, theatre museum, a
stadium, a "Mangal Karyalaya", exceeding built-up area of 1000 sq. m. or where
the built-up area of such a user exceeds 1000 sq. m in the case of mixed
occupancies;
(ii) an industrial building;
(iii) a hazardous building;
(iv) a building of wholesale establishment;
(v) Educational, Institutional and residential hotel building or centrally air-
conditioned building which exceeds
(a) 15m in height, or
(b) a total built-up area of 1000 sq. m.
(n)(o) "Storage building" means a building or part thereof used primarily for storage
or shelter of goods, wares or merchandise, warehouse, cold storage, freight
depot, transit shed, store house, public garage hangar, truck terminal, grain
elevator and barn.
(o)(p) “Temporary Building/structure” means any building/structure of whatever
size and of whatever material which the Commissioner has allowed to be built
as a temporary measure in accordance with Regulation No 57.
(p)(q) "Unsafe building" means a building which-
(i) is structurally unsafe,
(ii) is insanitary,
(iii) is not provided with adequate means of egress,
(iv) constitutes a fire hazard,
(v) is dangerous to human life,
(vi) in relation to its existing use, constitutes a hazard to safety or health or public
welfare by reasons of inadequate maintenance, dilapidation or abandonment.
(q)(r) "Wholesale establishment" means an establishment wholly or partly engaged
in wholesale trade and manufacturers wholesale outlets, including related
storage facilities, warehouses and establishments engaged in truck transport,
including truck transport booking agencies.
(17)(18)"Building line" means the line up to which the plinth of a building extends in
any development.
(18)(19)"Built-up area" means the area covered by a building on all floors including
cantilevered portion, if any, but excluding cladding and the areas specifically
exempted under these Regulations for the purpose of computation of FSI.
(19)(20)"Cabin" means a non-residential enclosure constructed of non-load bearing
partitions.
(20)(21)“Canopy” means a cantilevered projection over any building entrance.
(21)(22) "Carpet area" means the net usable floor area of a unit within a building
excluding that covered by the walls or any other areas specifically exempted
from floor space index computation in these Regulations.
"Carpet area" would have the same meaning as defined in Real Estate
(Regulation and Development) Act, 2016.
Provided further that in case of redevelopment schemes under the provision of DCPR
33(5), 33(7), 33(7) (A), 33(9), 33(9)A, 33(10), 33(10)A for the purpose of rehabilitation
area and incentive thereon only, "Carpet area" means the net usable floor area
within a building excluding that covered by the walls or any other areas
specifically exempted from floor space index computation in these Regulations.
(EP-5)
(22)(23) "Chimney" means a construction by means of which a flue is formed for the
purpose of carrying products of combustion to the open air and includes a
chimney stack and the flue pipe.
(23)(24) "Chajja" means a structural overhang provided over openings on external
walls for protection from the weather.
(24)(25) "Chowk" means a fully or partially enclosed space permanently open to the
sky within a building at any level; inner chowk being enclosed on all sides and
an outer chowk having one unenclosed side.
(25)(26) "Chute" means a vertical system passing from floor to floor provided with
ventilation and inlet openings for receiving refuse from successive floors with or
without sprinklers for cleaning and ending at the ground floor on the top of the
collecting chambers.
(26)(27) “Cluster” means any defined area with proper access comprising dwelling
units, buildings, chawls, etc.
(27)(28) "Combustible material" means that material which when burnt adds heat to
a fire when tested for combustibility in accordance with the IS: 3808-1966
Method of Test for combustibility of Building Materials, National Building Code.
(29) Commissioner means Municipal Commissioner of Greater Mumbai or any other
officer designated by him.
(28)(30)"Contiguous holding" means contiguous piece of land under one ownership
irrespective of separate property register cards.
(29)(31) “Conversion” means the change of occupancy or premises to any occupancy
or use requiring development permission.
(30)(32) "Convenience shopping,” means shops, each with a carpet area not
exceeding 50 30 sq. m except where otherwise indicated and comprising those
dealing with day to day requirements, as distinguished from wholesale trade or
shopping, provided on the ground and/or first floor of building with internal
means of access. It includes-
(EP-6)
(i) Food grain or ration shops,
(ii) Pan shops.
(iii) Shops for collecting and distribution of clothes and other materials for cleaning
and dyeing establishments.
(iv) Tailor or darner shops.
(v) Groceries, confectioneries, wine and general provision shops
(vi) Hair dressing saloons and beauty parlours.
(vii) Bicycles hire and repair shops.
(viii) Vegetable and fruits shops.
(ix) Milk and milk products shops.
(x) Medical and dental practitioners’ dispensaries or clinics, pathological or
diagnostic clinics and pharmacies, each with a carpet area not exceeding 100sq.
m.
(xi) Florists.
(xii) Shops dealing in ladies’ ornaments such as bangles, etc.
(xiii) Shops selling bakery products.
(xiv) Newspaper magazines stalls and circulating libraries.
(xv) Books and stationery shops or stores.
(xvi) Cloth and garment shops.
(xvii) Plumbers', electricians, radio, television and video equipment repair shops and
video libraries.
(xviii) Restaurants and eating houses of area not exceeding 100150 sq. m
(xix) Shoes and sports shops each with a carpet area not exceeding 100 sq. m.
(xx) Coaching Classes with a carpet area not exceeding 100 sq. m.
(xxi) Gymnasium not exceeding 150 sq. m.
(xxii) Any other shop covered under the definition of convenience shopping, to whom
license under the shops and establishment has been issued under the MMC Act.
With the approval of the Corporation special permission, the Commissioner may
from time to time add to, alter or amend the above list.
(31)(33) "Corridor” means a common passage or circulation space including a
common entrance hall.
(32)(34) "Courtyard" means a space permanently open to the sky within the site
around a structure or surrounded by structure and may be paved/concreted.
(33)(35) “Curb Cut” means a small solid (usually concrete) ramp that slopes down
from the top surface of a side walk or footpath to the surface of an adjoining
street. It is designed for ease of access for pedestrians, bicyclists and differently
abled people.
(36) “Demonstrable Hardship” Demonstrable hardship means plot under development/
redevelopment affected due to Nalla, Nallah/river buffer, road widening, height
restriction due to statutory restriction as per these Regulations such as railway buffer,
height restrictions in the vicinity of Airport, height restriction in the vicinity of defence
establishments, and/or any other restrictions as per the provisions of these Regulations
affecting the project, odd shape plot, rehabilitation of existing tenants/occupants on
small size plot/s . This list is illustrative & not exhaustive.
(EP-7)
(34)(36) “Designation” means a public amenity provided or aided by an Appropriate
Authority on a parcel of land.
(35)(37) “Developer/Builder/Project Proponent” means the person who is legally
empowered to carry out the development.
(36)(38) "Dharmashala" means a building used as a place of religious assembly, a
rest house, a place in which charity is exercised with religious or social motives,
or a place where in a certain section of people have a right of, or are granted,
residence without payment or on nominal payment.
(37)(39) "Drain" means a system or a line of pipes, with their fittings and accessories
such as manholes, inspection chambers, traps, and gullies, floor traps used for
drainage of buildings or yards appurtenant to the buildings within the same
curtilage. A drain includes an open channel for conveying surface water or a
system for the removal of any liquid.
(38)(40) “Dwelling Unit/Tenement” means an independent housing unit with
separate facilities for living, cooking and sanitation.
(41) “Eating House” means any premises where any kind of food is prepared or
supplied for consumption of public for the profit or gain of any person owning
or having an interest in or managing such premises.
(39)(42) "Enclosed staircase" means a staircase separated by fire resistant walls and
door from the rest of the building.
(43) “Energy Efficient Building” means the building (having connected load 100 KW or
greater and having conditioned area of 1000 sq. m or more) compliant with the
provisions of ECBC code.
(40)(44) “Escalator” means a power driven, inclined, continuous stairway used for
ascending or descending between floors or bridge over the road/railway line.
(41)(45) "Escape route" means any well ventilated corridor, staircase or other
circulation space, or any combination of the same, by means of which a safe
place in the open air at ground level can be reached.
(42)(46) "Existing building" means a building or structure existing authorisedly
before the commencement of these Regulations.
(43)(47) "Existing use” means use of a building or a structure existing authorisedly
before the commencement of these Regulations.
(44)(48) "Exit" means a passage channel or means of egress from any building,
storey or floor area to a street or other open space of safety; horizontal, outside
and vertical exits having meanings at (i), (ii) and (iii) respectively as under:
(i) "Horizontal exit" means an exit which is a protected opening through or around
a fire wall or a bridge connecting two or more buildings.
(ii) "Outside exit" means an exit from a building to a public way, to an open area
leading to a public way or an enclosed fire resistant passage leading to a public
way.
(iii) "Vertical exit" means an exit used for ascending or descending between two or
more levels, including stairways, smoke-proof towers, ramps, escalators and fire
escapes.
(45)(49) "External wall" means an outer wall of a building not being a partition wall
even though adjoining a wall of another building and also means a wall abutting
on an interior open space of any building.
(46)(50) "Fire and/or emergency alarm system" means an arrangement of call points
or detectors, sounders and other equipment for the transmission and indication
of alarm signals, activated automatically or manually in the case of fire or other
emergency.
(47)(51) "Fire Booster pump" means a mechanical/electrical device installed at
intermittent level to boost up the water pressure so as to achieve the required
pressure of 3.2 kg/cm2 at the top level of high rise building or at the nearest
point.
(48)(52) "Fire lift" means a special lift designed for the use of fire service personnel
in the event of fire or other emergency.
(49)(53) "Fire proof door" means a door or shutter fitted to a wall opening, made of
fire resistant material to prevent the transmission and spread of heat and fire
for a specified period.
(50)(54) "Fire Pump" means a machine, driven by external power for transmitting
energy to fluids by coupling the pump to a suitable engine or motor, which may
have varying outputs/capacity but shall be capable of having pressure of 3.2
kg/cm2 at the topmost level of a high rise building.
(51)(55) "Fire resistance" means the duration of time which a fire resistant material
i.e. material having a certain degree of fire resistance, fulfills its function of
contributing to the fire safety of a building when subjected to prescribed
conditions of heat and load or restraint. The fire resistance test of structures
shall be done in accordance with IS: 3809-1966 Fire Resistance Test of
Structure.
(52)(56) "Fire separation" means the distance in meters measured from any other
building on the site or from another site, or from the opposite side of a street or
other public space to the building.
(53)(57) "Fire service inlet" means a connection provided at the base of a building
for pumping up water through in-built fire-fighting arrangements by fire service
pumps in accordance with the recommendations of the Chief Fire Officer.
(54)(58) "Fire tower" means an enclosed staircase which can only be approached
from the various floors through landings or lobbies separated from both the
floor area and the staircase by fire-resisting doors and open to the outer air.
(55)(59) “Fitness centre/Yogalaya in a building” means and includes the built-up
premises including toilet facilities provided in the building including gymnasium
for the benefit of its inmates and for the purpose of fitness, physical exercises,
yoga, reading and such other activities as may be permitted by the
commissioner from time to time
(56)(60) "Floor" means the lower surface in a storey on which one normally walks in
a building, and does not include a mezzanine floor. The floor at ground level
with a direct access to a street or open space shall be called the ground floor;
the floor above it shall be termed as floor 1, with the next higher floor being
termed as floor 2, and so on upwards.
(57)(61) "Floor space index (FSI)" means the quotient of the ratio of the combined
gross floor area of all total covered area on all floors combined gross floor area
of all floors, excepting areas specifically exempted under these Regulations, to
the gross area of the plot, viz.:
Total covered area on all floors
Floor Space Index (FSI) = ---------------------------------------
Gross Plot area
(EP-8)
(58)(62) "Footing" means a foundation unit constructed in brick work, stone
masonry or concrete under the base of a wall or column for the purpose of
distributing the load over a large area.
(59)(63) "Foundation" means that part of the structure which is in direct contact
with and transmitting loads to the ground.
(60)(64) "Front Open Space" means the space between the boundary line of a plot
abutting the means of access/road/street and the building line. Plots facing two
or more means of accesses/roads/streets shall be deemed to front on all such
means of accesses/roads/streets.
(65) “Fungible Compensatory Area” means any built-up area permitted over and
above the admissible FSI by a special permission of the Commissioner in
accordance with the Regulation No. 31(3).
(66) “Irrevocable Consent” means any consent given by the eligible
tenants/occupants/slum dwellers/members of society etc. independently or
collectively in the form of legal instrument, duly registered as per the relevant
provisions of the Regulation are of irrevocable in nature and the same cannot
be withdrawn on one or other pretext subsequently and however such
withdrawal can be accepted by the certifying department on being satisfied
such consents were given on misrepresentation and/or such consent/s are not
tenable on valid grounds.
(61)(67)(66) "Gallery" means an intermediate floor or platform projecting from a
wall of an auditorium or a hall, providing extra floor area, and/or additional
seating accommodation. It also includes the structures provided for seating in
stadia.
(62)(68) (67) “Gaothan” means portion of the land shown as such in the Revenue
Records.
(63)(69) (68) "Garage-Private" means a building or a portion thereof designed and
used for the parking of vehicles.
"Garage" means a place within a project having a roof and walls on three sides
for parking any vehicle, but does not include an unenclosed or uncovered
parking space such as open parking areas.
(64)(70) (69) "Garage-Public" means a building or portion thereof, designed other
than as a private garage, operated for gain, designed and/or used for repairing,
servicing, hiring, selling or storing or parking motor-driven or other vehicles.
(65)(71) (70) “Grey Water” means waste water from kitchen sink, bathrooms, tubs,
showers, wash basins, washing machines, and dish washers excluding the waste
water from water closet (W.C.).
(66)(72) (71) "Habitable room" means a room occupied or designed for occupancy
for human habitation and uses incidental thereto, including a kitchen if used as
a living room, but excluding a bath-room water closet compartment, laundry,
serving and storing pantry, corridor, cellar, attic, store-room, pooja room, and
spaces not frequently used.
(67)(73) (72) "Hazardous material" means-
i) radioactive substances;
ii) material which is highly combustible or explosive and/or which may produce
poisonous fumes or explosive emanations or storage, handling, processing or
manufacturing of which may involve highly corrosive, toxic or noxious alkalis or
acids or other liquids;
iii) other liquids or chemicals producing flame, explosive, poisonous, irritant or
corrosive gases or which may produce explosive mixtures of dust or fine
particles capable of spontaneous ignition.
(68)(74) (73) "Height of a building" means the vertical distance measured, in the
case of flat roofs, from the average level of the ground around and contiguous
to the building to the top of topmost terrace level and, in the case of pitched
roofs, up to the point where the external surface of the outer wall intersects the
finished surface of the sloping roof, and, in the case of gables facing the road,
the mid-point between the eaves level and the ridge.
(69)(75) (74) "Height of a room" means the vertical distance measured, from the
finished floor surface to the finished ceiling/soffit of slab. The height of a room
with a pitched roof means the average height between the finished floor surface
and the bottom of the eaves and the bottom of the ridge.
(70)(76) (75) “High Rise Building” means a building having height more than 32m
above the average surrounding ground level.
(71)(77) (76) "Home occupation" means customary services provided to the
general public other than that of eating or a drinking place, by a member of the
family residing on the premises without employing hired labour, and for which
there is no display to indicate from the exterior of the building that it is being
utilised in whole or in part for any purpose other than a residential or dwelling
use, and in connection with which no article or service is sold or exhibited for
sale except that which is produced therein, which shall be non-hazardous and
not affecting the safety of the inhabitants of the building and the neighborhood,
and provided that no mechanical equipment is used except that as is
customarily used for purely domestic or household purposes and/or employing
licensable goods. If motive power is used, the total electricity load should not
exceed 0.75 KW. "Home Occupation" may also include such similar occupations
as may be specified by the Commissioner and subject to such terms and
conditions as may be prescribed.
(72)(78) (77) Information Technology Establishment means an establishment
which is in the business of developing either software or hardware or providing
IT Enabled services.
(79) "Layout/Plot Recreational Ground/Open space,” means an area forming an
integral part of a site left open to the sky and used for recreation, excluding
terraces.
(80) (78) “Ledge” or “Tand” means a shelf- like projection supported in any manner,
except by vertical supports, within a room itself but without a projection of
more than half a meter.
(73)(81) (79) "Licensed Surveyor/Engineer/Structural Engineer/Supervisor" means
a qualified surveyor, engineer, structural engineer or supervisor, licensed by the
Commissioner.
(74)(82) (80) "Lift or Elevator" means an appliance designed to transport persons
and materials between two or more levels in a vertical or substantially vertical
direction by means of guided car or platform etc.
(75)(83) (81) "Loft" means a structure providing intermediate space in between
two floors with maximum height of 1.50 m, without having permanent access.
(76)(84) (82) “Mall” means a large enclosed area comprising shopping,
entertainment, eating facilities and facilities incidental thereto.
(77)(85) (83) “Marginal Open Space/Distance” means the minimum distance
measured between the front, rear and sides of the building line and the
respective plot boundaries
(78)(86) (84) “Multiplex/Multiplex Theatre Complex (MTC)” means a place of public
entertainment for the purpose of exhibition of motion picture with multiple
screens and or dramas and other social or cultural programs as described in
Bombay Entertainment Duty Act 1923.
(87) (85) “Noise barrier” means an exterior structure/part of structure designed to
protect inhabitants of sensitive land use areas from noise pollution.
(86)"Non-combustible" means not liable to burn or add heat to a fire when tested for
combustibility in accordance with the IS-3808-1966 Method of Test for
Combustibility of Building Materials.
(79)(88) (87) “Non-Conforming User” means any lawful use/building existed on the
site but which does not conform to the zoning shown in the Development Plan.
(80)(89) (88) "Occupancy" or "Use" means the principal occupancy or use for
which a building or a part of it is used or intended to be used, including
contingent subsidiary occupancies; mixed occupancy buildings being those in
which more than one occupancy are present in-different portions of the
buildings.
(81)(90) (89) "Owner" means a person who receives rent for the use of the land or
building or would be entitled to do so if it were let, and includes:
(i) an authorised agent or trustee who receives such rent on behalf of the owner;
(ii) a receiver, executor or administrator, or a manager appointed by any court of
competent jurisdiction to have the charge of or to exercise the rights of the
owner;
(iii) an agent or trustee who receives the rent of or is entrusted with or is concerned
with any building devoted to religious or charitable purposes; and
(iv) a mortgagee in possession.
(82)(91) (90) "Parapet" means a low wall or railing built along the edge of the roof
or a floor.
(83)(92) (91) "Parking space,” means an enclosed or unenclosed, covered or open
area or area provided by mechanical means sufficient in size to park vehicles.
Parking spaces shall be served by a driveway connecting them with a street or
alley and permitting ingress or egress of vehicles.
(84)(93) (92)"Partition" means an interior non-load bearing barrier, one storey or part
storey in height.
(85)(94) (93)"Permanent open air space" means air space permanently open;
(i) if it is a street,
(ii) if its freedom from encroachment is protected by any law or contract ensuring
that the ground below it is either a street or is permanently and irrevocably
appropriated as an open space.
In Determining the open-air space required for construction of a building, any
space occupied by an existing structure may, on its planned demolition to
become a permanently open air space, be treated as if it were already such a
place.
(86)(95) (94) "Permission” means a valid permission or authorisation in writing by the
competent authority to carry out development or a work regulated by the
Regulations.
(87)(96) (95) "Plinth" means the portion of a structure between the surface of the
surrounding ground and surface of the floor immediately above the ground or
basement or any storey level.
(88)(97) (96)"Plinth area" means the built-up covered area measured at the plinth
level.
(89)(98) (97) "Porch" means a covered surface supported on pillars or otherwise for
the purpose of a pedestrian or vehicular approach to a building.
(90)(99) (98) “Podium” means a one or more floors of a building extending beyond
building line/s used for parking, providing other services and incidental
purposes as prescribed under these Regulations.
(91)(100) (99) “Professionals on Record” means the persons educationally, technically
and experientially qualified to perform a designated skilled job and who are
appointed by the Owners/Developers and are responsible for the work carried
out by his/her subordinates or team, such as Architects, Town Planner, Licensed
Surveyors, Engineers, Structural Engineers, Fire Protection Consultants, etc.
registered with the Competent Authority wherever applicable and under taking
the responsibility for the particular work as prescribed by the Appropriate
Authority in these Regulations.
(92) "Recreational Open space,” means an area forming an integral part of a site left
open to the sky and used for recreation, excluding terraces.
(93)(101) (100) “Refuge Area” means an area within the building for a temporary use
during egress. It generally serves as staging area which is protected from the
effect of fire and smoke. area where persons can gather and await instructions
or assistance for evacuation during fire.
(94)(102) “Reservation” means plot of land proposed to be developed for a public
purpose and so depicted on the Development Plan or as provided under these
Regulations.
(95)(103) (101) "Retention activity" means an activity or use which is allowed to
continue, notwithstanding its non-conforming nature in relation to the use
permitted in the adjoining or surrounding area.
(96)(104) (102) "Road/Street" means any highway, street, lane, pathway, alley,
stairway, passageway, carriageway, footway, square, place or bridge, tunnel,
underpass, elevated road whether a thoroughfare or not, over which the public
have a right of passage or access or have passed and had access uninterruptedly
for a specified period, whether existing or proposed in any scheme, and includes
all bunds channels, ditches, storm-water drains, culverts, sidewalks, traffic
islands, road-side trees, hedges, retaining walls, fences, barriers and railings
within the street lines.
(97)(105) (103) "Road/Street level or grade" means the officially established elevation
or grade of the centre line of the Street upon which a plot fronts, and if there is
no officially established grade, the existing grade of the street at its mid-point.
(98)(106) (104) "Road/Street line" means the line defining the side limits of a
road/street.
(99)(107) (105) "Road width" or "Width of road/street" means the whole extent of
space within the boundaries of a road when applied to a new road/street, as
laid down in the city survey or development plan or prescribed road lines by any
act or law and measured at right angles to the course or intended course of
direction of such road.
(100)(108) (106) "Row housing" means a row of houses with only front, rear and
interior open spaces.
(101)(109) (107) “Sanctioned or Approved Plan” means the set of plans in connection
with a development which are duly approved and sanctioned by the Planning
Authority.
(102)(110) (108) "Service road" means a road/lane provided at the front, rear or side
of a plot for service purposes.
(103)(111) (109) "Site/Plot" means a parcel or piece of land enclosed by definite
boundaries.
(104)(112) (110) "Site, Corner" means a site at the junction of land fronting on two or
more roads or streets.
(105)(113) (111) "Site, Depth of” means the mean horizontal distance between the
front and rear site boundaries.
(106)(114) (112) "Site with double frontage" means a site having a frontage on two
streets other than a corner plot.
(107)(115) (113) "Site, Interior or Tandem" means a site access to which is by a
passage from a street whether such passage forms part of the site or not.
(108)(116) (114) "Smoke-stop door" means a door for preventing or checking the
spread of smoke from one area to another.
(117) (115) “Solar Energy System” means a device to heat the water or generate power
using solar energy.
(109)(118) (116) "Stair–cover/Stair case Room" means a structure with a covering roof
over a staircase and its landing built to enclose only the stairs for the purpose of
providing protection from the weather and not used for human habitation.
(110)(119) (117) “Stilt” means a space within framework of columns, beams and slabs
without enclosure of walls over which the building rests. It is used for parking
purposes/other services as provided under these Regulations.
(111)(120) (118) "Storey" means the portion of a building included between the
surface of any floor and the surface of the floor next above it, or if there be no
floor above it, then the space between any floor and the ceiling next above it.
(121) (119) "Sub-station" means a station for transforming or converting electricity for
the transmission or distribution thereof and includes transformers, converters,
switchgears, capacitors, synchronous condensers, structures, cable and other
appurtenant equipment and any buildings used for that purpose and the site
thereof.
(122) (120) “Tenement” means an independent dwelling unit with a kitchen or a
cooking alcove.
(112)(123) (121) "Theatre" means a place of public entertainment for the purpose of
exhibition of motion picture and or dramas and other social or cultural
programs.
(113)(124) (122) "Tower-like structure" means a structure in which the height of the
tower-like portion is at least twice that of the broader base.
(114)(125) (123) "Travel distance" means the distance from the entrance/exit of the
remotest Apartment/office/unit/Premises point on a floor of a building to a
place of safety be it vertical exit or a horizontally exit or an outside exit
measured along the line of travel.
(115)(126) (124) "Volume to plot ratio (V.P.R.)" means the ratio expressed in meters of
the volume of a building measured in cubic meters to the areas of the plot
measured in square meters.
(116)(127) (125) "Water closet (W.C.)" means a privy with an arrangement for flushing
the pan with water, but does not include a bathroom.
(117)(128) (126) "Water course" means a natural channel or an artificial channel
formed by training or diversion of a natural channel meant for carrying storm
and waste water.
(118)(129) (127) "Water course, Major" means a water course which carries storm
water discharging from a contributing area of not less than 160 hectares, the
decision of the Commissioner on the extent of the contributing area being final.
A minor water course is one which is not a major one.
(119)(130) (128) "Window" means an opening other than a door, to the outside of a
building which provides all or part of the required natural light, ventilation or
both to an interior space.
(120)(131) (129) “Wing of a building” means part of a building with independent
access, staircase & lift connected to other parts with common basement/stilt/
podium/terrace/common wall/connecting passages.
3. Applicability
(1) Development and construction: Except as hereinafter otherwise provided, these
Regulations shall apply to all development, redevelopment, erection and/or re-erection
of a building, change of user etc. as well as to the design, construction or reconstruction
of, and additions and alterations to a building.
(2) Part construction: Where the whole or part of building is demolished or altered or
reconstructed/removed, except where otherwise specifically stipulated, these
Regulations shall apply only to the extent of the work involved.
(3) Change of occupancy: Where the occupancy of a building is changed, except where
otherwise specifically stipulated, these Regulations apply to all parts of the building
affected by the change.
(4) Reconstruction: The reconstruction in whole or part of a building which has ceased
to exist due to an accidental fire, natural collapse, or demolition or voluntary
demolition. having been declared unsafe or which is likely to be demolished by or under
an order of the Corporation or the Bombay Housing and Area Development Board and
for which the necessary certificate has been given by either the said Corporation or the
Board shall be allowed subject to the Regulation no 33(6).
(5) Exclusions: Nothing in these Regulations shall require the removal, alteration or
abandonment or prevent the continuance of the lawfully established use or occupancy
of an existing building or its use unless, in the opinion of the Commissioner, such a
building is unsafe or constitutes a hazard to the safety of adjacent property.
4. Interpretation
(1) In these Regulations, the use of the present tense includes the future tense,
the masculine gender includes the feminine and neuter genders, the singular number
includes the plural number and plural number includes singular number. The word
"person" includes a corporation as well as an individual; "writing" includes printing,
typing, e-communication and "signature" includes e-signature, digital signature and
thumb impression of a person unable to sign, provided that his name is written below
such impression.
(2) Sizes and Dimensions: Wherever sizes and dimensions of rooms and spaces
within buildings are specified, they mean the clear dimensions, unless otherwise
specified in these Regulations.
(3) If any question or dispute arises with regard to interpretation of any of these
Regulations the matter shall be referred to the State Government which, after
considering the matter and, if necessary, after giving hearing to the parties, shall give a
decision on the interpretation of the provisions of these Regulations. The decision of
the Government on the interpretation of these Regulations shall be final and binding on
the concerned party or parties.
(4) In the case of provisions of other Acts/Rules/Regulations which are
incorporated in these Regulations wherever applicable, the amendments made
subsequently in parent Acts/Rules/Regulations, will automatically be applicable to
these Regulations.
(5) If there is a conflict in interpretation of any clause between English & Marathi
versions of these Regulations, then the interpretation of English version shall prevail
5. Delegation of powers
Except where the Commissioner's special permission is expressly stipulated, the powers
or functions vested in him by these Regulations may be delegated to any municipal
official under his control, subject to his revision if necessary and to such conditions and
limitations, if any, as he may prescribe. In each of the said Regulations, the word
"Commissioner" shall, to the extent to which any municipal official is so empowered, be
deemed to include such official.
In conformity with the intent and spirit of these Regulations, the Commissioner
may: -
(i) decide on matters where it is alleged that there is an error in any order,
requirement, decision, determination made by any municipal officer under
delegation of powers in application of the Regulations or in interpretation
of these Regulations:
(ii) interpret the provisions of these Regulations where a street layout
actually on the ground varies from the street layout shown on the
development plan;
(EP-9)
6. Discretionary powers
(a) In conformity with the intent and spirit of these Regulations, the Municipal
Commissioner may: -
(i) modify the limit of a zone where the boundary line of the zone divides a plot,
village boundary, CS/CTS No. as per records of revenue by a special permission;
and
(ii) authorize the erection of a building or the use of premises for a public service
undertaking, Government, Semi-Government, Local Bodies for public utility
purposes only, where he finds such an authorization to be reasonably necessary
for public convenience and welfare, even if it is not permitted in any land use
classification/zone by a special permission.
(iii) decide on matters where it is alleged that there is an error in any order,
requirement, decision, determination made by any municipal officer under
delegation of powers in application of the Regulations or in interpretation of
these Regulations:
(iv) interpret the provisions of these Regulations where a street layout actually on
the ground varies from the street layout shown on the development plan;
(b) In specific cases where a clearly demonstrable hardship is caused, the
Commissioner may for reasons to be recorded in writing, by special permission
permit any of the dimensions prescribed by these Regulations to be modified,
except those relating to floor space indices unless otherwise permitted under
these Regulations, provided that the relaxation will not affect the health, safety,
fire safety, structural safety and public safety of the inhabitants of the building
and the neighborhood.
(c) Any discrepancy/error in regard to location/size/use of designations and any
relocation of reservation approved by the competent authority along with its
development at its relocated position if not reflected in this Development Plan and
that are brought to the notice of the Development Department of MCGM may,
after due enquiry, be corrected with the approval of the special permission of the
Municipal Commissioner.
Provided that the Municipal Commissioner shall issue a well-reasoned order of such
correction, along with the authenticated part plan showing the location under his seal and
signature, with a copy to the Govt., Director of Town planning, Maharashtra State, Deputy
Director of Town Planning, Greater Mumbai for information and record purpose. The
proposal of Development Plan shall stand modified to that effect.
7. Power to delegate
The State Government may, by notification in the Official Gazette delegate by a
general or special order any of its powers under these Regulations, subject to such
conditions as it may consider appropriate, to any officer of the State Government not
below the rank of Deputy Secretary, except those relating to any matter which is
required to be dealt with under the special permission of the Commissioner.
8. Amendment/modification to Appendices/Annexures
Except where the same are prescribed in Mumbai Municipal Corporation Act, 1888, or
Maharashtra Regional and Town Planning Act, 1966 or the rules or bye-laws framed
thereunder, the Commissioner may, from time to time, add to, alter or amend
Appendices and Annexures appended to these Regulations.