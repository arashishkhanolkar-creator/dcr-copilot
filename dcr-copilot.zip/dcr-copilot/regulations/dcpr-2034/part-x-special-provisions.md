# Part X: Special Provisions

51. Parking Authority
MCGM, with approval of General Body of the Corporation in consultation with GoM, shall
constitute a Parking Authority at MCGM level to plan, regulate and manage all on/off
street parking and public parking places under the physical jurisdiction of Greater Mumbai.
The constituted Parking Authority, inter alia, will fix and promulgate parking fees as well as
penalties for various areas/zones in MCGM.
Parking Authority shall be under the chairmanship of Municipal Commissioner, MCGM,
with members as Transport Commissioner, General Manager (BEST), Joint Commissioner of
Police (Traffic), three members of Improvement Committee preferably one Corporator
each from City, Western Suburbs and Eastern Suburbs and two experts in this field other
than from MCGM and Ch.E.(Roads) as member secretory.
The General Functions of the Parking Authority:
1) The Parking Authority shall have the responsibility of providing adequate, safe, convenient,
and affordable parking spaces within physical jurisdiction of Mumbai.
2) The Parking Authority shall make guidelines for governing, managing and regulating all on-
street parking, off-street parking & public parking lot under the physical jurisdiction of
Greater Mumbai.
3) The Parking Authority shall identify the area for on-street parking & time slot for such
identified areas. The space for on-street parking shall be selected in such a way that traffic
movement is least affected.
4) Parking Authority shall identify the location for the parking of buses, school buses, taxis,
radio taxi including ola/uber etc. and transport vehicles such as HCV/trucks, MCV/tempo,
LCV etc.
5) The Parking Authority shall identify on-street & off-street parking places including public
parking lot and where the Night parking can be made available.
6) The Parking Authority shall have dedicated staff with quasi-judicial authority/traffic police
for implementing parking guidelines prepared by Parking Authority.
7) The Parking authority shall prescribe;
a) Restriction on the location for parking,
b) Procedure for establishing parking zone & restricted areas,
c) Guidelines for short term, long term, night parking privileges & fees associated with it,
d) Parking violations & schedules of penalties,
e) Differential parking rates for different locations based on traffic congestions, locality,
size & category of vehicles etc.
8) The Parking Authority shall have access to the database of ownership of vehicles within
jurisdiction of Mumbai/MMR & shall have the information available on digital platform for
effective implementation.
9) Support system backed by IT shall be developed for all on road pay and park lots/public
parking lots, monitoring performance of the service providers, parking hrs for vehicles,
revenue collection by credit cards, special transport cards, the equipment to read with
provisions for audit and accounting and disbursements to service providers etc.
10) All the parking places shall be digitized with real time information of available parking
spaces for information of the consumers/persons for efficient management.
11) The Parking Authority shall identify new location, areas where parking facility can be
constructed by MCGM/Appropriate authority, based on the parking requirement of areas
& availability of space for such public parking lot including construction of such places.
12) Locational clearance for Public Parking Lot shall be given by the Parking Authority.
13) The board and marking should be prominent, large and distinct, with a powerful logo.
There cannot be any parking lot without such a board.
14) To ensure that parking spaces are marked with either yellow lines or small yellow squares
of 3 inch by 3 inch.
15) All such pay & park spaces should be serially numbered.
16) There should be wide publicity campaign to accompany this “parking pilot” explaining
about the new on-road parking regulations.
17) Provision of dedicated lane for ambulance, public transport, fire brigade on the roads
having width more than27.45 m shall be made.
(EP-149)
52. Conservation of Heritage
1. Definition:
(i) “Conservation” means all the processes of looking after a place so as to retain its
historical and/or architectural and/or aesthetic and/or cultural significance and includes
maintenance, preservation, restoration, reconstruction and adoption or a combination of
more than one of these.
(ii) “Preservation” means and includes maintaining the fabric of a place in its existing state
and retarding deterioration.
(iii)“Restoration” means and includes returning the existing fabric of a place to a known
earlier state by removing accretions or by reassembling existing components.
(iv) “Heritage Site” means the area within the boundary / extent of the heritage building /
Precinct / natural area included in the heritage list and as shown on the map.
(v) ”Natural heritage site” shall include, natural sites or precisely delineated natural areas
which are of outstanding value from the point of view of science, heritage conservation or
natural beauty; geological and physiographical formations and precisely delineated areas
which constitute the habitat of threatened species of animals and plants and are of
outstanding value from the point of view of ecology or conservation; natural features
consisting of physical and biological formations or groups of such formations, which are of
outstanding (special) value from the aesthetic or scientific point of view.
(EP-150)
2. Applicability:
This Regulation shall apply to those buildings, artefacts, structures and/or precincts of
historical and/or aesthetical and/or architectural and/or cultural value the heritage list as shall
be notified by GoM from time to time (hereinafter referred to as Listed Heritage
Buildings/Structures/Precincts/Sites) and to any draft Heritage List (s) as published by the
GoM. /Municipal Commissioner.
3. Restriction on Development/Redevelopment/Repairs, etc.:
(i) No development or redevelopment or engineering operations or additions, alterations,
repairs, renovation including the painting of buildings, replacement of special features or
demolition of the whole or any part thereof or plastering of said listed/heritage buildings or
listed/Heritage precincts shall be allowed except with the prior written permission of the
Commissioner. The Commissioner shall act on the advice of/in consultation with the Mumbai
Heritage Conservation Committee to be appointed by Government (hereinafter called
MHCC). Development, additions / alterations, repairs, restoration, in respect of graded
heritage buildings or buildings in heritage precincts or heritage sites shall be in accordance
with the provisions mentioned at 9 (C & D) of this regulation.
(ii) Provided that in In exceptional cases, for reasons to be recorded in writing, using his
powers of special permission, the Commissioner, may overrule the recommendation of the
MHCC. The decision of the Municipal Commissioner shall not be subject to challenge by the
MHCC thereon shall be final.
Provided that the power to overrule the recommendations of the MHCC shall not be
delegated by the Municipal Commissioner.
(EP-151)
(iii)In relation to religious buildings in the said List, the changes, repairs, additions,
alterations and renovations required on religious grounds mentioned in sacred texts or as
a part of holy practices laid down in religious codes shall be treated as permissible,
subject to their being in accordance and consonance with the original structure and
architecture designs, aesthetics and other special features thereof. Provided that before
arriving at his decision, the Commissioner shall take into consideration the
recommendations of the Mumbai Heritage Conservation Committee.
(iv) (a) Provisions of this Regulation shall be applicable only in Grade I &II category of
heritage Buildings for reconstruction and redevelopment undertaken under these
Regulations.
(b) In case of reconstruction and redevelopment of heritage building/sites from Grade-
III and precincts, special permission from the Commissioner, Municipal Corporation of
Greater Mumbai may be obtained, if the height of the building to be
reconstructed/redeveloped exceeds 32.0 m.
(c) Repairs to existing structures in vistas/surroundings of Grade-I structure and in
precincts shall be permissible with the special permission from the Commissioner.
(EP-152)
4. Preparation of list of Heritage Buildings and Heritage Precincts:
The said heritage list of Heritage Buildings/Structures/Precincts to which this Regulation
applies shall not form part of this Regulation for the purpose of Sections 37 & 46 of the
MR&TP Act, 1966. This List may be supplemented, altered, deleted or modified from time
to time by Government on receipt of proposals from the Commissioner or by the
Government suo-motu, provided that objections and suggestions from the public be
invited and duly considered by the Commissioner and/or by GoM before notification.
Provided that any draft list which is published and pending for the approval of GoM shall, in the
interim period, be deemed to be part of the heritage list and provisions of this regulation shall
be applicable to the said draft list.
Provided that this Regulation shall not be applicable to any published draft Heritage List till
notified by GoM.
5. Grant of Transferable Development Rights in case of loss of Development Rights
If any application for development of Heritage Building/s is refused under this Regulation
and conditions are imposed while permitting such development which deprive the
owner/lessee of any unconsumed Development Rights, the said owner/lessee shall be
compensated by grant of Development Right Certificate in terms of TDR as provided in
these Regulations.
Owners of heritage buildings, structures, sites will, on application for preservation
/conservation/restoration of the heritage buildings/structures/sites or if any application for
development of Heritage Building/s is refused under this Regulation and conditions are
imposed while permitting such development which deprive the owner/lessee of any
unconsumed DRs will be entitled for grant of DRC in terms of TDR as provided in these
Regulations. The extent of TDR permissible will be the difference between Zonal (basic) FSI
plus area of plot and the consumed BUA of the Heritage structure. The grant of TDR shall
be subject to a contract between the owner/lessee and MCGM binding the owner/lessee
to conserve the heritage building in the prescribed manner as recommended by MHCC and
approved by Municipal Commissioner. In such cases the potential of the plot shall be
perpetually reduced to the extent of existing BUA of the Structure.
The TDR may be given in two stages
i. An appropriate % of the available DRC at the time of submission/ after approval of
plans for the conservation of the heritage structure will be granted by the Municipal
Commissioner on the recommendations of the MHCC.
ii. After getting completion certificate for the conservation of the heritage structure
from the appropriate authority and on recommendation of the MHCC, whatever is
considered appropriate of the residual or entire residual DRC will be granted by the
Municipal Commissioner.
(EP-153)
6. Maintaining Sky-Line:
Buildings included in listed/published draft Heritage Precincts shall, as far as possible, maintain
the sky-line in the precincts as may be existing in the surrounding area within the Precinct
boundary excluding any high-rise new development. or as may be decided by the
Commissioner in consultation with the MHCC so as not to diminish or destroy the value and
beauty of the said listed Heritage buildings/Heritage Precincts. The development within the
precincts shall be in accordance with respective Precinct guidelines as formulated by the MHCC
and approved by the Municipal Commissioner in consultation with MHCC or as may be decided
by the Municipal Commissioner, shall require sanction by Government. the guidelines framed
by the Commissioner in consultation with MHCC. Guidelines for display of hoarding, sinage,
advertisement boards, street furniture, pavement shall be formulated by the MHCC.
7. Restrictive Covenants:
Restriction existing as on date of this notification imposed under covenants, terms and
conditions on the leasehold plots either by the State Government or by Mumbai Port Trust
or by Municipal Corporation of Greater Mumbai shall continue to be imposed in addition
to these Regulations. However in case of any conflicts with heritage preservation interest,
this Regulation shall prevail.
8. 7.Repair Fund: Heritage Conservation Fund:
Non-cessed buildings included in the said list shall be repaired/restored by the
owners/lessees of the said buildings themselves or if they are cessed buildings, those can
be repaired/restored by MHADA or by the owner or by the Co-operative Society of the
owners and/or occupiers of the building. With a view to give monetary help for such
repairs/restoration, a separate fund may be created, which would be kept at the disposal of
the Commissioner, who may consult Heritage Conservation Committee while disbursement
of such funds. Provisions for such a fund may be made through District Planning and
Development Council Budget or any other budget.
9. 8. Development Plan Reservation:
If there are any DP Reservations on listed heritage structure and due to development of
such site if adversely affects its character, then Municipal Commissioner on
recommendation of MHCC shall initiate the process of modification/deletion of such
reservation following due procedure.
10. 9. Grading of the Listed Buildings/Sites & Listed Precincts:
In the last column of the said list of Heritage Building, Heritage precincts, “Grades” such as
I, II, or III have been indicated. The chart showing definition meaning of these Grades and
basic guidelines for development permissions and Precincts, objectives, scope for changes
and procedure for obtaining development permission are as follows
Grade – I Grade – II Grade – III/ PRECINCT
A. Definition – A. Definition – A. Definition –
Heritage Grade – I Heritage Grade - II Grade – III
comprises buildings, and comprises building/ Heritage Grade -III
precincts sites of national precincts, of regional or Comprises buildings and
or historical importance, local importance, precincts of importance for
embodying excellence in possessing special townscape, they evoke
architectural style, design, architectural or aesthetical architectural aesthetic or
technology and material merit or cultural or sociological interest though
usage; they may be historical value, though of not as much as in Heritage
associated with a great a lower order than that of Grade – II. These contribute
historical event, Heritage Grade - I. They to determine the character
personality, movement or are local landmarks of the locality, and can be
institution. It may also contributing to the image representative of a life style
comprise natural sites of and identity of the city. or a particular community
heritage value eg. They may be the work of or region and may also be
Waterfronts, creeks, master craftsmen or may distinguished by setting on
mangroves, Hillocks, forest
be models of proportion a street line or special
lands, open spaces, etc. They
and ornamentation, or character of the façade and
have been and are the
designed to suit particular uniformity of height, width
prime landmarks of the
Grade – I Grade – II Grade – III/ PRECINCT
City. climate. and scale.
Vista of Grade I : Heritage Grade - II PRECINCT
buildings within the A. Definition –
An area within 100 m.
premises (open
Periphery or as may be A heritage precinct is an area
space/compound) of of heritage value and cultural
delineated on plan by the
which significance. Such area within
Municipal Commissioner in
independent/separate a specified boundary may
consultation with MHCC shall
additional building(s) possess a setting reminiscent
be considered as the vista of
/structure(s) may be of significant urbanscape /
a Grade – I structure/entry. townscape attributes and
permitted to be
comprising a number of
constructed, owing to the
buildings and spaces, within a
availability of adequate
structure of streets / roads
surrounding open space
and other landscapes and
and unconsumed FSI,
qualifies to have cultural or
have been assigned
heritage significance worthy of
Grade- IIB. The remaining recognition and conservation.
Grade- II buildings have
Such area espouses special
been assigned Grade –IIA. quality of cohesiveness (mass,
scale, style, architecture etc.)
between its various elements,
lending a unique sense of
place and cultural setting.
B. Objective– B. Objective— B. Objective—
Heritage Grade – I richly Heritage Grade – II Grade – III
deserves careful deserves intelligent Heritage Grade -III Deserves
preservation. conservation. protection of unique
features and attributes.
PRECINCT
Precincts deserve sensitive
development in terms of mass,
scale, setting and require
conservation of its heritage
and cultural significance.
C. Scope for Changes – Scope for development --- Grade – III
i)No interventions would Grade - II A: In addition to External and internal
be permitted either on the the scope for development changes and adaptive reuse
exterior or interior unless permissible for Grade –I, would generally be allowed.
it is necessary in the internal changes, and Changes can include
interest of strengthening adaptive reuse may be extensions / additional
and prolonging the life of generally allowed. In buildings in the same plot
the buildings or precincts certain circumstances, or compound provided that
or any part or features extension of a Grade - IIA extension / additional
Grade – I Grade – II Grade – III/ PRECINCT
thereof. For this purpose, heritage building may also building is in harmony with
absolutely essential and be allowed; provided that and does not detract from
minimum changes would such extension shall be in the existing heritage
be allowed and they must harmony with (and shall building / precincts
be in accordance with the not detract from) the especially in terms of height
original. Grade - II A heritage and/or facade.
Repairs shall follow building concerned or Reconstruction may be
conservation norms based precinct, especially in allowed when the building
terms of height and/or is structurally weak or
on proven standards with
façade. External changes unsafe or when it has been
use of like to like or similar
too may be permitted, affected by accidental fire
material.
subject to strict scrutiny. or any other calamity or if
ii) Additional buildings
Care should be taken to reconstruction is required
/new interventions in a
ensure the conservation of to consume the permissible
Grade-I complex shall be
all special aspects/features FSI and no option other
permitted only if the
of Grade – II A building than reconstruction is
development does not
concerned. available.
mar the grandeur, scale,
Grade –II(B): Reconstruction/
setting and view of the
In addition to above, Redevelopment may also be
main Grade-I structure
additional building(s) in allowed with the special
and the new development
the same plot or permission from the
is in harmony with the
compound may, in certain Commissioner, Municipal
main heritage structure.
circumstances, be Corporation of Greater
iii) Development in allowed; provided that, Mumbai, if the height of the
surrounding area/vista :
such additional building(s) building to be reconstructed
shall be in harmony with /redevelopedexceeds 32.0
All the development
(and shall not detract m.
(excluding repairs) in the
from) the Grade-IIB Reconstruction may be
vista of a Grade - I heritage,
heritage building(s) or allowed in those buildings
within 100 m. Periphery or
precinct, especially in being repaired /
as may be delineated on
terms of height and/or reconstructed by MHADA.
plan, shall be regulated and
façade and such building However, unless absolutely
controlled ensuring that it
shall be termed as Grade- essential, nothing should
does not mar the grandeur
II (B). spoil or destroy any special
of or views from Heritage
features or attributes for
Grade – I.
which it is placed in the
Development permission Heritage List.
may be granted within this
ii) Reconstruction /
regulated area provided that
redevelopment shall be
the proposed development
allowed with the permission
does not mar the grandeur,
of Commissioner as detailed
scale and setting of, or view
below.
of or from Heritage Grade-I.
PRECINCT
Grade – I Grade – II Grade – III/ PRECINCT
In case of world Heritage i) Sensitive additions,
sites, the directives given alterations, extensions,
by the Govt. from time to interior renovations shall be
permissible but these should
time will be applicable.
not alter the character of the
precinct. The new
interventions could be
contemporary but subtle or
inspired by the original
character but should not be a
pastiche/ tasteless imitation of
it.
ii) Essential structural and non-
structural repairs shall be
allowed for structural stability
while retaining the original
architectural features.
iii) Reconstruction /
redevelopment shall be
allowed with the permission of
Commissioner as detailed
below.
D. Procedure
Development permission for Development permission Grade – III
the changes would shall be would shall be given by the
Development permission
given by the planning Commissioner in
would be given by the
authority Commissioner in consultation with/taking
Commissioner but in
consultation with/taking into into consideration the
consonance with guidelines
consideration the recommendation of the
which are to be laid down
recommendation of the MHCC.
by Government in
MHCC
Consultation with MHCC or
Repairs to existing
as per this Regulation.
structures in delineated
vista of a Grade-I structure a) In respect of
shall be permissible as per minor/structural repairs,
these Regulations/policy periodic maintenance (e.g.
without insisting NOC of Waterproofing, repairs to flat/
MHCC. sloping roof, existing
plumbing, re-plastering),
interior renovation / furniture
work etc. in respect of a
Grade-III heritage structure;
approval may be granted by
Commissioner as per these
Regulations/ policy without
insisting NOC of MHCC by
ensuring that the intended
Grade – I Grade – II Grade – III/ PRECINCT
minor works do not affect the
original façade, fenestration
pattern /bands/cornices,
ornamental features, railings ,
window grid & pattern etc. as
the case may be.
b) In case of reconstruction or
redevelopment of Grade – III
heritage buildings, height up
to 32 m. shall be permitted by
Commissioner. If the height of
the building to be
reconstructed/redeveloped
exceeds 32 m. special
permission from the
Commissioner shall be
obtained.
However, before allowing
demolition of a Grade-III listed
heritage building/structure,
complete documentation of
facade elevations/material
specifications, detailing etc.
should be prepared by the
owner through an architect and
shall be submitted to
Commissioner along with any
reconstruction/redevelopment
proposal so that cognizance of
any special features etc. can be
taken while finalising the
design/elevations of the new
building.
PRECINCT
a)In respect of minor/structural
repairs, periodic maintenance
(e.g. Waterproofing, repairs to
flat / mangalore tiled roof,
existing plumbing, re-
plastering), interior renovation
/ furniture work etc. in respect
of buildings in Precincts;
approval may be granted by
Commissioner as per these
Regulations/ policy without
insisting NOC of MHCC by
ensuring that the intended
Grade – I Grade – II Grade – III/ PRECINCT
minor works do not affect the
original façade, fenestration
pattern/bands/cornices,
ornamental features , railings ,
window grid & pattern etc. as
the case may be.
b) In case of reconstruction or
redevelopment of buildings in
heritage Precincts, height up to
32 m. shall be permitted by
Commissioner. If the height of
the building to be
reconstructed/redeveloped
exceeds 32 m., special
permission from the
Commissioner may be
obtained, who may take into
consideration guidelines if any
in respect of listed Precincts.
c)However, before allowing
demolition of a Precinct
building / structure , complete
documentation of faced
elevations / material
specifications , detailing etc.
should be prepared by the
owner through an architect and
shall be submitted to approving
authorities along with any
reconstruction /
redevelopment proposal so
that cognizance of any special
features etc. Can be taken
while finalising the design /
elevations of the new building.
It shall be ensured that external
appearance, elevation shall be
in harmony / consonance with
the characteristics of listed
Precinct.
E. Vistas/Surrounding
Development - All the
development in the areas
surrounding Heritage
Grade – I within 100 m
periphery or as may be
delineated on plan shall be
Grade – I Grade – II Grade – III/ PRECINCT
regulated and controlled ,
ensuring that it does not
mar the grandeur of or
views from Heritage Grade
– I.
(EP-154)
53. Under Ground Public Utility/Conveniences/Amenity Provision
Subject to the conditions as may be prescribed by the Commissioner, MCGM, Sewage
Treatment Plant, storage and allied facilities as per design and specification and at location
as may be considered necessary by the Commissioner for treatment of sewage/effluent,
water pumping station and storage facility, Electric Substation/Distribution/Receiving
Station, underground parking and shopping shall be allowed below existing or proposed DP
Roads and below lands reserved for Playground/Gardens/Parks and Public Open Spaces
both existing and proposed and to be used at one or two levels below the ground. Provided
no such uses will be allowed below the following.
Oval Maidan, Cross Maidan, Azad Maidan, Shivaji Park, all parade grounds, Nare Park,
Jambhori Maidan, Five Gardens and the POS reflected in list of Heritage sites and Recreational
Ground opposite Scottish School, Dadar, Cadell Road (Veer Sawarkar Marg) situated to the
north of Hinduja Hospital.
And provided further that the area to the extent of 10 m along the road side below the
surface within the boundary of the aforesaid Maidans/Parks/Gardens/Public Open Spaces
may be used for the purpose of ingress and egress to the underground area.
54. Uses Permissible below Flyovers:
Following uses may be permitted below the flyovers:
(1) Garden, park, Promenades
(2)Electricity Distribution Stations;
(3)Municipal chowkies, road depot, municipal store, public toilet;
(4)Police chowky, RTO vehicle chowky, pay and park facility/bus stands/taxi stands/auto-
rickshaw stand;
(5)Homeless shelters, welfare centres for street children/activities centers for destitute
(6) BEST street light chowky, BEST electricity bill & cash collection centre, BEST relief
shelter with toilet block for bus operation staff.
Provided further that the plantation/green space of width not less than 1.0 m shall be
developed all along the edge of carriageway below the flyover or central median with
width not more than width of pillar, except the accesses wherever necessary or as may be
required by the Commissioner.
55. Alignment of Metro/Mono/ Coastal Road /Elevated Corridors/Corridors of
Mass and Rapid Transport System
Any alignment modifications introduced in Metro/Mono /Coastal Road /Elevated
Corridors/Corridors of Mass Rapid Transport System, including BRTS, by the Appropriate
Authority and sanctioned by Government shall stand automatically amended on the
Development Plan as modified.
Furthermore, any new “Transport Corridor” such as Metro/Mono/Coastal Road
/Elevated Corridors/Corridors of Mass Rapid Transit System, including BRTS, proposed by
Appropriate Authority and sanctioned by Government, shall stand automatically added on
to Development Plan.
After finalization of site for Metro Car shed by the Competent Authority, the The portion of
land reserved/earmarked for the Metro Car Shed in DP, if not required by the Competent
Authority subsequently, will fall automatically in the Zone prevailing on land adjoining to
land under reservation of Metro Car Shed.
(EP-155)
56. Lands allotted to Forest Department
Land allotted to Forest Department may be used for the designated purpose and related
forest activity, including resettlement of the original inhabitants of the forest (adiwasis) to
satisfy a larger environmental purpose.
Forest Land
Development in the forest land which has been designated as Natural Area in DP will be
governed by the notifications issued by the Ministry of Environment and Forest as
amended from time to time.
In case of the land owned by Forest Department and reserved for public purpose shall have
to be developed with the special permission of the Commissioner as per the provisions of
Forest Act.
(EP-156)