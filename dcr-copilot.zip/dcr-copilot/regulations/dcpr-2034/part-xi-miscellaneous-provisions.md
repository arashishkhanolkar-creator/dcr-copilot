# Part XI: Miscellaneous Provisions

57. Temporary Constructions
The Commissioner may grant permission for temporary construction of a period
not exceeding six month at a time and in the aggregate, not exceeding a period of
three years. Such permission may be given by him for the construction of the
following, namely:
(i) Structures for protection from the rain or covering of the terraces during
the monsoon only;
(ii) Pandals for fairs, ceremonies, religious functions, circus, jatra, folk dance
etc;
(iii) Structures for godowns /storage of construction materials within the site;
(iv) Temporary site offices and watchmen chowkies and labourer hutments with
crèche, sales office/sample or show flat within the site only during the phase of
construction of the main building;
(v) Structure for exhibitions/circuses, etc.;
(vi) For factories in industrial lands, structures within the site for storage of
machinery before installation;
(vii) Structures for ancillary works for quarrying operations in conforming zones;
(viii) Milk booths and telephone booths;
(ix) Transit accommodation for persons to be rehabilitated in a new
construction:
(x) Structures for educational and medical facilities within the site of the
proposed building during the phase of planning and constructing the said
permanent buildings:
(xi) On site, Ready Mix Concrete (RMC) plant for the use at site under
development/construction.
Provided that temporary construction for structures, etc. mentioned at (iii), (iv),
(vi), (ix), (x) and (xi) may be permitted to be continued temporarily by the
Commissioner but in any case, not beyond completion of construction of the main
structure or building, and that structure in (viii) may be continued on annual
renewable basis by the Commissioner beyond a period of three years.
58. Common Antenna for Television Transmission Reception/
Telecommunication/ Digital Communication/Service: -
In every Building the provision for
(1) Installation of common Television Transmission Reception/Antenna and
Ducting for telecommunication lines and optical fiber cable for Digital Data
communication /transmission shall be made.
(2) Ducting for laying of piped gas connection service in the surrounding of
building.
59. Special Purpose NOCs
Wherever necessary, special purpose NOCs shall be required to be submitted for
the development of plot/s depending upon the location & type of work as
specified in these Regulations. Observance of requirements of these and all other
NOCs shall be the responsibility of Owner/Developer/Project Proponent. The
Commissioner may grant permissions/approvals for development based on an
undertaking by the Owner/Developer/Project Proponent that he shall comply with
all the requirements of special NOCs, Laws, and Regulations that are applicable
from time to time. The illustrative list of special purpose NOC’s is mentioned in
Appendix III
60. Repairs to Existing Building
The structural/extensive repairs to the existing buildings, which have been
constructed with the approval from the competent authority or were in existence
prior to 17.04.1964 in respect of residential structures and 01.04.1962 in respect
of non-residential structures and which are in need of structural/extensive repairs,
may be allowed without change in footprint/planning. Under the guise of repairs,
addition/alterations/vertical & horizontal extension to the existing structures shall
not be permissible. The structural /extensive repairs to the existing buildings may
be allowed as described in Appendix IV.
60(A). Approvals of Building Permission on Fast Track based on Risk Based
categorization
Notwithstanding anything contained in DCR/DCPR of the respective said
Authority, the Regulations regarding approval of Building Permission by the
Architect/L.S./Engineer at the stage of Commencement, Plinth checking and
Completion cum Occupancy shall be as per Risk Based Classification of
Building given in Table below:-
Sr. Parameters to be Risk Category
No. consider for Risk Low Risk Category Moderate Risk Category
Base.
1 Plot Area Buildings on a plot Buildings on a plot area
considered for area upto150 sq. m. between 151 sq m and
Risk Based up to 200 sq.m.
Assessment.
2 Permissibility In Residential Zone, Residential Zone,
Development Commercial zone and Commercial zone and
Plan Zone Public-Semi-public Public-Semi-public Zone
Zone
3 Plot status The plot should be The plot should be
vacant. The Plot vacant. The Plot Status,
Status, Plot criteria Plot criteria and
and permissibility in permissibility in above
above land use zone land use zone shall be
shall be as per as per respective
respective DCR/DCPR. DCR/DCPR.
4 Type of building Residential and other Residential and other
buildings as per buildings as per
DCR/DCPR DCR/DCPR
5 Proposed G.F. / P+1 G.F.+1/P+2
Structure of RCC./Load Bearing RCC./Load Bearing
Building/Storey
6 Front and side As per the provisions As per the provisions of
open spaces, of Development Development Control
Provision of Control Regulations. Regulations.
Basement,
Parking
requirement and
other
requirements.
7 Tree cutting/ Not permitted. Not permitted
Tree replantation.
8 Experience As per Appendix-C of As per Appendix-C of the
Criteria for the respective DCR / respective DCR / DCPR
Architect DCPR regarding regarding licensing and
/L.S./Engineer for licensing and qualifications of the
self-certification qualifications of the technical person.
and all approval technical person.
mentioned in this
regulation.
9 NOCs and Wherever required as Wherever required as per
Documents per the respective the respective DCR /
DCR / DCPR DCPR
10 Site inspection No site inspection is Site inspection at Plinth
and Computer necessary by the level is necessary by the
based allocation Planning Authority at Planning Authority.
of inspector for any stage. Approval Approval Procedure is to
site inspection. Procedure is to be be followed as mentioned
followed as mentioned in Point No.11 including
in Point No.11 point no 11 (c).
excluding point no 11
(c).
11 Procedure for Building Permission
Architect/ License Surveyor (L.S.)/Engineer (Architect registered with Council of
Architecture & License Surveyor & Engineer registered with Planning Authority)
are empowered to grant provisional approval with self-certification to the
building proposal plans categorized as Low Risk & Moderate Risk in Table
given above, subject to the following:-
Building Permission/Commencement Certificate:-
a) Submission of Proposal:-The proposal shall comprise of application u/s
44/69 of MR&TP Act, 1966, in format prescribed by Municipal
Commissioner/Chief Officer/Chief Executive Officer, along with documents and
undertakings required for the proposal as per regulation & required by the
Municipal Commissioner/Chief Officer/Chief Executive Officer from time to time.
All the required documents shall be certified and signed by the Architect
/L.S./Engineer confirming with the original documents. The documents required
shall be as per the DCPR of the said Authority.
b )Commencement Certificate (CC) :-After receipt of the application, the
Demand Note regarding payment of Scrutiny Fee, Development Charges and
other Charges based on the proposed Plans/Drawing submitted shall be given
by the concern Engineer of the authority within 10 days. The owner / Architect
/L.S./Engineer shall deposit the Charges as demanded. Upon deposit of such
Charges with the Planning Authority, the concerned Architect/ License
Surveyor (L.S.)/Engineer are empowered to grant provisional approval in the
form of self-certification certifying that the plan / entire building proposal is
strictly in conformity with the DCR/DCPR. This self-certification shall be treated
as Commencement for the construction work.
The owner/concern Architect/License Surveyor (L.S.)/Engineer
shall submit the said self-certified plan to the Authority within 10 days. Upon
such submission, The Junior most Officer/Junior Engineer at ward level,
authorized by Municipal Commissioner/Municipal Chief Officer shall countersign
the plans without any scrutiny and issue Commencement Certificate Under
Section-45 of Maharashtra Regional and Town Planning Act, 1966 within 10
days from the receipt of such plan. The Scrutiny at Authority level need not
be necessary. Concern Architect/L.S./Engineer is empowered/Authorized to
issue the copies of such approved plans &Certificates with his signature.
c)Plinth Checking For Moderate Risk building proposal:-The concern Architect
/L.S./Engineer shall apply for certificate of plinth checking in prescribed
application for Moderate Risk building proposal only. The inspection shall be
done by the concern Junior Engineers. The inspection report shall be prepared
and uploaded within 48 hours. The Plinth checking certificate shall be grant
within the period of 7 days from the receipt of the application, if found as per
the sanctioned plan.
d)Building completion certificate :-On completion of work, the concern
Architect/L.S./Engineer shall issue the Building completion certificate and
Occupation certificate, as required as per the provision of DCR / DCPR to the
completed building/structure and submit two set of completion plan along with
the required certificate and all site inspection report to the authority. The
concerned Junior Engineer / Ward Officer authorized by Municipal
Commissioner / Chief Officer shall countersign the said Completion Plan along
with Occupancy Certificate within 10 days without any scrutiny and site
inspection.
12 Responsibility of the Architect/L.S./Engineer
a)The work shall be supervised by the concerned Architect/L.S./Engineer who
will ensure that the same is carried out strictly as per the approval.
Confirmation of ownership of land / plot area and land boundaries in the name
of applicant shall be jointly responsibility of concerned Architect/L.S./Engineer
and the owner.
b)It will be the responsibility of the concern Architect /L.S/Engineer, Site
Supervisor & Structural Engineer appointed for the proposed development,
jointly or severally to ensure thatall plans shall be in consonance with
provisions of Development Control Regulations. All the requirements of the
DCR / DCPR shall have to be complied with due care and the work is carried
out as per the approval only. Any deviation required during the construction
shall be approved by Architect/L.S./Engineer before execution. The concerned
Architect /L.S./Engineer shall be empowered for any amendments in the plan in
process of construction within the purview of DCR.
c) Frequency of Inspection By the Architect/L.S./Engineer:-
The Architect/L.S./Engineer shall inspect and submit the site inspection report
along with photographs/video clips, at stages while submitting the building
proposal, after completion of plinth work, and finally at the time of Building
completion certificate to the authority. Such inspection reports shall be
submitted and uploaded within 48 hours from the date of inspection.
d)After submitting the application or during the construction of building if the
Architect/L.S./Engineer are changed, he shall intimate the competent authority
immediately that he is no longer responsible for the project from the date of
intimation. The construction work shall have to be suspended until the new
Architect/L.S./Engineer as the case may be appointed by the owner. Owner’s
intimation regarding change of licensee shall be considered to be final. After
intimation of the new appointed licensee shall then undertakes and start the
project.
13 Authorisation to Authority:-
a) In case of any deviations/irregularities noticed in the process or after
completion, the Planning Authority may immediately issue notice to the
owner and or to the concerned licensee to suspend the further work and
rectify the deviations/irregularities. Only after satisfaction of rectification made
by the owner or concerned licensee, the Planning Authority issue intimation
to start the work. In major violations, the Planning Authority shall authorise
to take appropriate action against Architect/L.S./Engineer as the case may
be, as per the DCR or as per respective Acts and Laws.
b) Municipal Commissioner/Chief Officer, as the case may be, of the respective
Authority are authorised to prepare common application forms, proformas,
affidavit etc. wherever required for the smooth implementation of this
regulation.
c) The above procedure shall be integrated with the Online Building Permission
Management System (BPMS) by the concerned Authority.
14 Exceptions from this Procedure:-The above Procedure for Building Permission
shall not bar the owner/ Architect/L.S./Engineer to obtain development
permission as per Regular provisions of the DCR/DCPR. Also this Directives
shall not be applicable to the proposals who desired to obtain Development
Permission as per Type Design Pattern which was issued by Government vide
TPS-1813/3200/CR 520/13/UD 13, Dated 03/01/2015.