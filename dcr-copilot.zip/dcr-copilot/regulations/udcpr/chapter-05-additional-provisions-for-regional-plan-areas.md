# Chapter 5: Additional Provisions for Regional Plan Areas

CHAPTER - 5
ADDITIONAL PROVISIONS FOR REGIONAL PLAN AREAS
5.0 GENERAL
In addition to the provisions mentioned in these Regulations, following additional provisions
shall be applicable for the areas of the Regional Plans / Authorities mentioned herein under.
These provisions shall prevail over the provisions, if any, mentioned in this Development Control
and Promotion Regulations to that extent.
5.1 FOR ALL REGIONAL PLAN AREAS
5.1.1 Development Permissible Adjacent to Gaothan.
For the villages in the area of Regional Plans (excluding the area of Local Bodies and SPA
where Development Plan or planning proposal is sanctioned) where no specific residential zone
is shown, for such villages, development permissible in residential zone, may be permitted :-
i) within a belt of 2.00 km. from the boundaries of Municipal Corporation, 1.00 km. from the
boundaries of Municipal Council and 0.50 km. from the boundaries of Nagar Panchayat,
where zone plans are (1) prepared or not prepared in the Regional Plan for such area;
(1) However the proposed development within such belt shall be guided by the road network
of published / sanctioned zone plans or elsewhere proper road network plan prepared and
approved by the Director of Town Planning within 6 months or within such time limit as
extended by Government.
ii) within a belt of 500 meters from the gaothan limits of settlements having a population of
less than or equal to 5000 as per the latest Census and;
iii) within a belt of 1500meters from the gaothan limits of settlements having a population of
more than 5000 as per the latest Census;
iv) in the case of settlements of both the categories mentioned (1) in (ii) and (iii) above, falling
in the planning areas / Zone Plans of Regional Plans, such distance from the gaothan limits
shall be 500 meters only;
v) in the case of village settlements in the Western Ghat hilly area (eco sensitive zone) in
Regional Plan of Satara, Pune, (1) Ahmednagar, Dhule, Kolhapur, Nashik, Nandurbar,
Sangli, Sindhudurg, Thane, Palghar and Raigad District or as notified by Govt. from time
to time such distance shall be 200 m. only
vi) in the case of villages in Regional Plan of Mumbai Metropolitan Region and Raigad, such
distance shall be 500m. only.
Provided that such development shall be permitted only on payment of premium of the total
area of land. Such premium shall be calculated considering 15%rate of the said land as
prescribed in the Annual Statement of Rates of the year granting such developments. This
rate of premium shall be subject to orders of the Government from time to time;
Provided further that, for the areas which are converted into Municipal Councils / Nagar
Panchayats within the Regional Plan (under the provision of Maharashtra Municipal
Councils, Nagarpanchayats and Industrial Townships Act, 1965), such premium shall be
calculated considering 5% rate of the said land as prescribed in the Annual Statement of
Rate for the year while granting such residential development (without considering the
guidelines therein).
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
Provided further that, no such premium shall be applicable for development of an
individual house of an owner or farm house on owner's land.
Provided further that no such premium shall be applicable for revised permission on the
land where development/ Layout permission is granted prior to sanction of the respective
Regional Plan, more specifically mentioned in Regulation No. 5.1.3.
Provided further that where more than 50 percent of area of the Survey Number/ Gut
Number is covered within the above peripheral distance, the remaining whole of such
Survey Number/ Gut Number within same ownership shall be considered for development
on payment of premium as above.
Provided further that the criteria of "distance from gaothan" shall also be applicable to the
lands from the nearest gaothan of any village.
Provided further that this provision shall not bar development permission for the uses,
otherwise permissible, in agricultural zone as per UDCPR within specified distance from
gaothan mentioned in this regulation.
Provided also that this regulation shall also be applicable to all declared / Notified Gaothan
under MLRC whether shown on Regional Plan or not.
Provided further that in respect of Ratnagiri-Sindhudurg Regional Plan, this provision shall
be subject to provisions mentioned in Regulation No. 5.3.
5.1.2 Regulations for Development of Tourist Resorts / Holiday Homes / Township in Hill
Stations Type Areas under Hill Station Policy.
The developments under the Hill Station Policy shall be governed by the Special Regulations as
sanctioned by Government vide notification No.TPS-1893/1231/C.R.123/96/UD-13, dated
26/11/1996and its amendments by the Government from time to time.
5.1.3 Committed Development
i) Any development permission granted or any development proposal for which tentative or
final approval has been recommended by the concerned Town Planning Office and is
pending with the concerned Revenue Authority for demarcation or for final N.A.
permission before publication of draft RP (date of resolution of the RP Board for
publication) shall be continued to be valid for that respective purpose/use irrespective of
approved Floor Space Index. Provided that, it shall be permissible for the owner either
continue with the permission in toto as per such earlier approval or apply for grant of
revised permissions under these regulations. However, in such cases of revision, the
premium, if any, shall not be applicable, for approved permissions (including tentative).
This provision shall not cover the cases mentioned in 5.1.3 (iii) below.
ii) The layout already approved/ development permission already granted for residential
purpose and which are valid as per the provisions of UDCPR shall be entitled for
development subject to use of earlier permission. This shall also be applicable to cases
where sale permission for N.A. use has been granted prior to the date of sanction of these
Regulations, for the same use as the one for which sale permission was granted.
iii) The layout already approved/ development permission already granted for the uses
permissible in agricultural or such restrictive zone and which are valid as per the provisions
of UDCPR shall be entitled for development subject to use and FSI of respective use
granted in earlier permission.
5.1.4 Rectification of draftsman's error.
i) Draftsman's errors, which are required to be corrected as per actual situation on site/ or as
per Survey Records, sanctioned layout etc. shall be corrected by the concerned District
Collector, after due verification and prior approval of concerned Divisional joint Director of
Town Planning.
ii) Drafting errors, if any, regarding Private Lands shown by mistake in the restrictive zone
such as defence zone, forest zone, command area etc. shall be corrected after due
verifications of records and situation on ground by the concerned Authority with prior
approval of Divisional Joint Director of Town Planning. In such case Private Lands will be
included in the adjacent zone.
iii) The boundaries of the designated or Notified Eco-Sensitive Zone in respect of Bird
Sanctuary, Wildlife Sanctuary and other project shown on Regional Plan shall be as per the
final notification issued under Environment (Protection) Act, 1986. All conditions
regarding development including Buffer Zone in pursuance of the provisions of the said Act
shall be applicable.
5.1.5 Highways notified by State/ Central Government.
If any highway/ ring road/ express way and any other classified road is notified by State/ Central
Government Highway Authority under the provisions of relevant act, then the alignment of such
notified road shall be deemed to be the part of Regional Plan and for this, procedure under
section 20 of MRTP Act, 1966 shall not be necessary.
5.1.6 Station Area Development.
The development (1) in agriculture zone around (1) any functional railway station upto a distance
of 500 m. shall be permitted by charging premium at 30% rate of the said land as mentioned in
the ASR on total area of land under development, subject to following.
i) Within a 100 m. distance from periphery of the station, the users related to railway station
and other users (excluding Residential) shall be permitted.
ii) In remaining distance within 500 m., all users permissible in Residential Zone shall be
permitted.
iii) The rate of premium shall be subject to Government's order from time to time.
5.1.7 Modification proposals already sanctioned.
All the modification proposals from Regional Plan already sanctioned by the State Government
under section 20(4) of Maharashtra Regional and Town Planning Act, 1966 but not shown in
respective zone in Regional Plan shall be treated as included in respective Zone as per the
modification sanctioned by the State Government.
5.1.8 Provision of Amenity Space.
i) In any layout or sub-division of land for residential purpose admeasuring more than 0.4 Ha.
(excluding the area of R.P. roads, road widening and designations) amenity space shall
have to be provided for the areas and specified percentages mentioned in the table below.
Area of Land Amenity Space to be provided.
upto 4000 Sq.m. Nil.
more than 4000 Sq.m. 10%
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
ii) For calculating the area for Amenity Space, area covered under the development proposal
submitted to the Authority shall only be considered.
iii) The owner shall be entitled to develop the Amenity Spaces as per the uses permissible in
the Amenity Space.
iv) If owner agrees to handover and the Authority agrees to take over the amenity space, then
such Amenity Space shall be deemed to be reservation in the plan and floor space index
(FSI) in lieu thereof (1)subject to maximum receiving potential prescribed in these
regulations may be made available in-situ on remaining land. The calculation of this in-situ
FSI shall be shown on the layout/ building plan. In the areas where TDR regulations are
applicable and if the owner desires to have TDR against it, instead of in-situ FSI, then he
may be awarded TDR. The in-situ FSI or TDR shall be granted only after transfer of the
Amenity Space to the Authority. The generation of TDR or in-situ FSI shall be equivalent
to the quantum mentioned in Regulation of TDR.
v) (1) Proviso of Regulation No. 3.5.1, (1) (--) shall be applicable to this regulation.
5.1.9 Residential Zone with payment of Premium
Wherever such zone is proposed in sanctioned Regional Plan, provisions related to such zone
will continue to that extent.
5.2 FOR THANE - RAIGAD-PALGHAR REGIONAL PLAN
(***) Development around Tarapur Atomic Power Station in Tarapur-Boisar Area
5.2.1 The development within the area of 5 km. to 16 km. radius of Tarapur Atomic Power Station
shall be governed by following regulations.
5.2.1.1 Provisions mentioned in Regulation No. 6.23 shall be applicable with following changes.
Side and Rear Marginal Distances for building of Height more than mentioned in Table
No.6D/6E of Regulation No. 6.2.1 and 6.2.2:- The marginal distances on all sides, except the
front side, of building shall be minimum 6.0 m. or H/5, whichever is more.
(Where H = Height of building above ground level) Provisions mentioned in Regulation No.6.2.4
shall be applicable
5.2.1.2 Provisions mentioned in Regulation No. 6.10 shall be applicable with following changes :-
Distance between Two Buildings :- The distance between two buildings shall be 6.00 mt. or H/5
of the taller building between the two adjoining buildings, whichever is more.
(Where H-Height of building above ground level)
5.2.1.3 Provisions mentioned in Regulation No. 6.10 shall be applicable with following changes :-
Height of Building:-
The maximum permissible height of building, including parking floor. shall be 24 mt.
5.2.1.4 Permissible FSI -
a) Provisions mentioned in Regulation No. 6.1 and 6.3 shall be applicable with following
changes :-
The permissible Basic Floor Space Index shall be 1.10. In to basic permissible FSI, 0.30
FSI shall be permissible on payment of premium.
(1)
Inserted / Substituted / deleted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
(***)
Inserted vide Directives u/s 154 & Notice Published u/s 20 (3) No. CR 421/16, dt. 21st December, 2021.
(***) If the land is affected by proposed road or road widening and if the owner hand over
the land under such proposed road or road widening of very said plot, free of cost and free
from all encumbrances, to the Authority, such FSI can be used instead of FSI on payment
of the premium to the maximum extent of 0.30 or 0.30 FSI over and abovel.1. Basic FSI,
may be allowed to be utilized partly from road widening FSI of very said plot and partly
from premium FSI.
Provided that, above provision of FSI shall also be permissible for earlier sanctioned
proposals within the limits of maximum permissible FSI of 0.75 or 1.00, as the case may
be, subject to the marginal distances and Distance between Two building as prescribed
above.
b) Provisions mentioned in Regulation No.7.7.2 shall be applicable with following changes:-
Development of Housing for EWS/LIG - proposed in Agriculture Zone as per Regulation
No.7.7.2-FSI permissible shall be 1.0.
c) Provisions mentioned in Regulation No. 4.11 shall be applicable with following changes:-
FSI for users permissible in Agriculture Zone shall not exceed the FSI as prescribed in
Regulation No. 4.11.
However, if FSI on payment of premium is permissible over and above the FSI allowed
without payment of premium to certain user in Regulation No. 4.11, then the maximum FSI
on payment of premium for such user shall be permissible to the extent of such permissible
FSI on payment of premium or 0.40, whichever is minimum,
d) Provisions mentioned in Regulation No. 6.4 shall be applicable with following changes:-
The permissible basic Floor Space Index shall be 1.00. In addition to the basic permissible
FSI, 0.40 FSI shall be permissible on payment of premium.
e) Provisions mentioned in Regulation No. 6.1 and 6.4 shall be applicable with following
changes :- Notwithstanding anything mentioned in various provisions of Unified
Development Control and Promotion Regulation, Ancillary FSI shall not be permissible in
this area..
5.2.1.5 Excepting the Regulation mentioned above, all other Regulations in Unified Development
Control and Promotion Regulation shall be applicable for the area.
5.3 FOR RATNAGIRI-SINDHUDURG REGIONALPLAN.
The Development Control Regulations sanctioned for Ratnagiri-Sindhudurg Regional Plan shall
cease to operate and following provisions shall be applicable.
5.3.1 Area within Ratnagiri District -
The zoning of lands within local authorities‘ area/ special planning authorities‘ areas shall be
governed by zoning/ proposals shown in the Development Plan/ Planning proposal/ Plan.
Remaining area of the district where such plan is not sanctioned shall be treated as Agricultural
zone. All the provisions of this UDCPR shall be applicable with following additions.
Residential development or development permissible in Residential zone shall be permitted in
Agriculture zone within a distance of 200 m. from pada, with payment of premium as mentioned
in Regulation No.5.1.1. However, such premium shall not be applicable for individual housing
or bungalow, not exceeding two units.
(***)
Inserted vide Directives u/s 154 & Notice Published u/s 20 (3) No. CR 421/16, dt. 21st December, 2021.
5.3.2 Area within Sindhudurg District -
The Development Control Regulations sanctioned by the Government in respect of Sindhudurg
Tourism Plan vide Notification No. TPS-1997/355/C.R.99/UD-12, dt.15/10/2004 shall cease to
operate and following provisions shall be applicable.
Following land use zones are shown on the Regional Plan of Sindhudurg district area.
i) Exclusive Tourism Zone shall include :
Existing Municipal Council, Nagar Panchayat area and area under New Town
a) T-1
Development Authority.
Within Urban Centers, Tourism Growth Centers and area in the Vicinity but T-2
b)
outside Municipal Council, Nagar Panchayat area having development potential.
Along National and State highways. T-3
c)
d) Hill Stations. T-4
e) Coastal Area (excluding T1 and T2) T-5
ii) Other Zone shall include
a) Industrial Zone.
b) Forest Zone.
c) Agricultural and Horticultural Zone.
iii) For T-1 zone in the Regional Plan, all provisions of UDCPR shall be applicable as per
zoning in the respective Development Plan or Planning Proposals.
iv) T-2 and T-3 zone in the Regional Plan shall be treated as Residential Zone and all
provisions of UDCPR shall be applicable. However, height of building shall not exceed
16m.
v) For zone plans approved under the MLRC and included in the Regional Plan, all provisions
of UDCPR shall be applicable according to zone in the said zone plans.
vi) For T-4 zone, following uses shall be permissible.
Sr. User Min. Plot Max. Max
No. Area FSI Height m.
Residential 500 0.30 12.00
Commercial 500 0.50 12.00
Hotel, Boarding Houses.
a) Below 3 Star 1000 0.25 12.00
b) Above 3 Star 4000 0.25 16.00
Public, Semi-public like Education, 2000 0.20 12.00
Hospital etc. and Assembly
building including Cinema Theater.
Note -
a) All other uses permissible in Agricultural zone shall be permitted in T-4 zone subject to
maximum FSI of 0.50 and height of building up to 12 m.
b) The FSI limit mentioned above in Sr. No. 1, 3 and 4 of the table may be allowed to be
exceeded up to 0.50 subject to payment of premium as mentioned in Regulation No. 4.11.
c) Reconstruction/ Redevelopment of existing building are permitted without considering
minimum area of plot and FSI shall be as per above table or FSI utilized for the existing
authorized structure.
d) Minimum plot size norms shall not be applicable to "Bread and Breakfast Scheme"
approved by MTDC.
vii) For T-5 zone, following uses shall be permissible.
Sr. User Min. Plot Max. Max
No. Area FSI Height m.
1 Residential / Commercial 500 0.50 12.00
2 Hotel, Boarding Houses. 1000 0.75 12.00
3 Public, Semi-public like Education, 2000 0.50 12.00
Hospital etc. and Assembly
building including Cinema Theater.
Note -
a) The FSI mentioned in the above table shall be allowed to be exceeded up to 1.00, with the
payment of premium at the rate of 30% of rates mentioned in ASR, without following
guidelines therein.
b) The development permissible shall be subject to provisions of Coastal Regulation Zone
Notification No. G.S.R. 37(E), dated 18th January, 2019 as amended or replaced from time
to time.
c) All other uses permissible in Agricultural zone shall be permitted in T-5 zone subject to
maximum FSI of 0.50 or mentioned in the said regulations in agricultural zone, whichever
is minimum and height of building up to 12m.
d) Reconstruction / Redevelopment of existing building are permitted without considering
minimum area of plot and FSI shall be as per above table or FSI utilized for the existing
authorized structure.
e) Minimum plot size norms shall not be applicable to "Bread and Breakfast Scheme"
approved by MTDC.
viii) Following villages are identified as Tourism growth centers -
Kunkeshwar-Mithbav, Hindale, Achara, Tondavali, Mahapan, Shiroada-Aravali, Amboli
and Phonda.
"Tourism Growth Centers" shown on the Regional Plan are for the purpose of showing
places of tourist interest.
ix) The places of "Konkan Tourism Village" and "Day Visit Points" shown on the plan are also
places of tourist interest.
x) Development in Industrial Zone, Forest Zone, Agricultural / Horticultural zone and other
zone, if any, shall be governed by the provisions mentioned in this UDCPR. However, in
such case FSI and height of building shall not exceed 0.50 and 12.00 m. respectively.
xi) Natural expansion of gaothan shall be allowed within 200 m. from the gaothan boundary
and regulations of Residential Zone shall apply. The villages which are not having notified
gaothan the residential and other non-agricultural development shall be permitted only
along the existing public roads upto a plot depth of 45 m. from the road boundary and
regulations of Residential Zone shall apply. For this development premium shall be
applicable as per Regulation No. 5.1.1. However, such premium shall not be applicable for
individual housing or bungalow, not exceeding two units. The provisions in proviso to
Regulation No.5.3.1 shall also be applicable.
5.4 FOR KOLHAPUR REGIONAL PLAN.
5.4.1 Committed Development.
Instead of Regulation No. 5.1.3 (i) and (ii), following regulations shall be applicable for
committed development.
i) Regarding Committed Development outside previously Sanctioned Regional Plan of
Kolhapur - Ichalkaranji Region :- All development permissions/ layout approval granted by
the District Collector / Concerned Revenue Authority or any development proposal for
which tentative or final approval has been recommended by the concerned Town Planning
Office and is pending with the concerned Revenue Authority for demarcation or for final
NA Approval on 12/09/2016 i.e. the date of board resolution for publication of draft R.P.
shall continue to be valid for that respective purpose along with approved Floor Space
Index.
Provided that it shall be permissible for the owner to either continue with the permission in
toto as per such earlier approval and for that limited purpose, erstwhile regulation shall
apply or apply for grant of revised permission under the new regulations. However, in such
revision of cases, the premium if any shall not be applicable, for the originally approved
land use and FSI only.
ii) Regarding Committed Development within the ambit of previously sanctioned Regional
Plan of Kolhapur-Ichalkaranji Region.
The development permission / layout approval granted by the District Collector/ concerned
Revenue Authority within the ambit of the sanctioned Regional Plan of Kolhapur-
Ichalkaranji prior to the publication of the Draft Regional Plan, Kolhapur and if the said
Development permission/ layout is as per the provisions of sanctioned Regional Plan of
Kolhapur-Ichalkaranji Region then such permission/ layouts shall be treated as valid
permission for the respective sanctioned use. These permissions/ layouts, if submitted for
revised approval, then it should be corrected as per the present sanctioned regulations of the
Regional Plan of Kolhapur Region.
a) The development permission/ layout approval granted by the District Collector/
concerned Revenue Authority within the ambit of the sanctioned Regional Plan of
Kolhapur-Ichalkaranji and if the said development permission/ layout approval is
contradictory or adverse to the provisions of sanctioned Regional Plan of Kolhapur -
Ichalkaranji Region or Draft Published Regional Plan of Kolhapur Region then such
permission/ layout shall be treated as illegal and to be cancelled with immediate effect.
Note: - The layouts which are approved before publication of the Regional Plan but not fulfilling
the requirements of the then DCR such as road width, open space etc. but saved as per
above special regulation, in such cases the building permission shall be granted with 75%
of FSI permissible in such zones.
5.5 FOR SATARA REGIONAL PLAN
5.5.1 Regulations for proposed Buffer Zone up to 2.5 km. aerial distance around Mahabaleshwar
Panchgani Region.
The following Regulations is applicable for the proposed Buffer Zone :-
Proposed Land-use Zone Permissible Users. Permissible FSI
Lands falling within 50 m. No development shall be allowed.
distance from the boundary
of Mahabaleshwar-
Panchgani Region.
Agriculture/ No All users a) Maximum permissible FSI shall be
Development Zone permissible in 0.75 for the lands falling within
Agriculture Zone as permissible peripheral distance from
per Regulation No. the gaothan.
4.11. b) Maximum permissible FSI shall be as
per regulation No. 4.11 from the
lands falling beyond such permissible
distance.
Forest The development as may be required by the Ministry of Forest
or its Authorities as per the requirements shall only be
permissible on the lands owned and possessed by the Ministry
of Environment and Forest or its Authorities.
Eco-Sensitive Area Users permissible a) Maximum permissible FSI shall be
shall be as per 0.75 for the lands falling within
MOEF Notification permissible peripheral distance from
dt.27/02/2017. the gaothan.
b) Maximum permissible FSI shall be as
per regulation No. 4.11 from the
lands falling beyond such permissible
distance.
Core and Buffer Zone of Permissible users For gaothans in Buffer Zone.
Sahyadri Tiger Project and FSI shall be as
a) Maximum permissible FSI shall be
per the
0.75 for the lands falling within
Development
permissible peripheral distance from
Control
the gaothan.
Regulations being
b) Maximum permissible FSI shall be
prepared for this
as per regulation No. 4.11 from the
Zone by the Local
lands falling beyond such permissible
Advisory
distance.
Committee headed
by Divisional
Commissioner,
Pune. Till such
Regulations are
framed, for the
peripheral area of
the gaothans falling
in Buffer Zone, the
users permissible in
the Agriculture
Zone shall be
allowed with the
approval of
Competent
Authority of the
Forest Department.
In the Core Zone,
no development
shall be
permissible.
Area of Growth Centre / As per the Land use 0.75 FSI shall be permissible for the
Urban Complex falling proposed in such proposed Residential Land use Zone and
within the Buffer Zone. Growth Centre / for the proposed Agriculture/ No
Urban Complex Development Zone, the FSI for users
Plan. permissible shall be as per Regulation No.
4.11
5.5.2 Conservation Zone in Satara Region.
The Government in Urban Development Department has sanctioned regulations for Conservation
Zone vide Notification No.TPS-1919/436/C.R.83/19/Sec.20(4)/UD-13, dt.23/12/2021 as under.
Appendix - L
REGULATIONS FOR CONSERVATION ZONE IN SATARA REGION
PART-I
ADMINISTRATION
1.0 SHORT TITLE, EXTENT AND COMMENCEMENT
i. Title: -These Regulations shall be called as Regulations for Conservation Zone in Satara
Region.
ii. Extent:-These Regulations shall apply to the area earmarked as Conservation Zone, more
specifically shown in green verge on the maps appended herewith as Appendix - "M" and
illustratively listed in the Appendix - "N".
iii. Commencement - These Regulations will come into force after it is sanctioned by
Government.
If there is any conflict between any Regulations sanctioned for Regional Plan Area for
Satara Region and these Regulations, these Regulations shall prevail.
2.0 Definition
Conservation Zone
Areas of ecological importance such as, fragile and ecologically sensitive habitats, sites with
large number of rare, threatened, endemic flora and fauna, breeding sites, colonies of endemic
and threatened species, rare geological formations etc., and environmental importance such
as, sensitive water catchments, hydrological systems, nutrient catchments, those providing water
nutrients, pollinator support, fodder and natural resource necessary for rural livelihood activities,
other than Forest Department owned or forested lands necessarily required to be protected and
conserved .
At present the ecological habitat of the following plateau cluster have been identified and are
proposed to be conserved and protected as a Conservation Zone;
a. Kas Pathar; an UNESCO Natural World Heritage Site
b. Chalkewadi Pathar; and
c. Sadavaghapur Pathar
Each cluster in the Conservation Zone comprises of
A. A. Core Zone
B. The top of Plateau commonly known as tableland, and more specifically shown in Blue colour on
the plan appended herewith as Appendix - "M"; and
C. B. Buffer Zone
D. The area consisting mainly the slopes around the Core Zone having ecological importance due to
its water shed and more specifically shown in Green colour on the plan appended herewith as
Appendix - "M"
The activities in these Zones shall be regulated keeping with the goals of protecting Regional
Biodiversity, Supporting & Enhancing the Ecological Conservation values and maintaining the
healthy functioning of ecosystem services of the area. The regulation for conservation zone shall
be as mention in part II below.
PART-II
1.00 LAND USE CLASSIFICATION AND PERMISSIBLE USES
A. Core Zone of Conservation Zone:
In respect of lands owned by the Forest Department, the Conservation and Restoration activities
according to Conservation Management Plan prepared by Forest Department and / or State
Biodiversity Authority shall prevail. While following regulations shall apply to allow
development permissions and/or activities in the remaining area falling in this zone.
a. i. The Unified Development Control and Promotion Regulations as otherwise applicable to
the land situated within Gaothans in Sanctioned Regional Plan, Satara along with the
modifications made in it from time to time shall be applicable to the Gaothans shown as
existing on Village Maps & Gaothans/extension of Gaothans subsequently declared by
Revenue Department under the provisions of Maharashtra Land Revenue Code, 1966.
ii. Development permissions and/or activities except conservation activities shall not be
permitted outside the Gaothan area.
iii. Activities of restoration of local biodiversity in the Conservation Zone shall be
permissible with the prior permission of the Maharashtra State Biodiversity Board.
b. i. Windmills: - New windmills shall not be permissible. However, repowering of existing
windmills may be allowed with prior approval of MEDA. Existing foot print of allied
buildings for windmills shall be maintained as far as possible and used to its potential.
Provided that, in case of repowering of existing windmills, appropriate measures to
safeguard the biodiversity of the platue be undertaken by the proponent in consultation
with the State Biodiversity Authority. No further expansion of existing windmills for
land shall be permitted.
ii. Solar Farms: - Solar Farms shall not be permissible.
c. Mining and quarrying activities for rocks, laterite, mud, soil etc. or digging for any
purpose shall not be permitted.
d. Roads :-
i. All existing tarred roads on the plateau shall be maintained at same width as all-
weather roads.
ii. Non-tarred roads to be identified and demarcated and shall be maintained as un-
tarred with the existing width and length. However, this shall not be applicable to
the existing roads connecting to the existing Villages / Wadis / Talukas and District
Head Quarters.
iii. No new roads shall be permitted.
iv. No widening of existing internal road/s shall be permissible.
v. a) Roads and Bridges, Railway, Ropeway, Underground Pipelines, Cables and
like purpose in any zone. If any Road / Ring road / Express way declared by
the State or Central Highway Authority, the alignment of such declared road
shall deemed to be the part of the Regional Plan and for this, procedure under
section 20 of the M.R. & T.P Act, 1966 shall not be necessary.
b) All projects of public interest undertaken by Central and State Government
bodies or Public Authorities controlled by the Government.
e. Plantations/Afforestation shall not be permitted.
f. Any activity restricting /obstructing Natural water flows shall not be permitted.
g. New man made water bodies as well as expansion of existing water bodies shall not be
permitted.
h. Tourism and related infrastructure :-
i. Riding of animals or manual/automated vehicles or any animal drawn carts for the
purposes of entertainment shall be prohibited.
ii. Water sports, golf, balloon rides, paragliding, ropeway etc. shall not be allowed.
iii. Use of area for entertainment, sports, film shooting shall be prohibited.
iv. Forest guest house and Interpretation centre by Forest Dept. blending with nature
shall be allowed with ground floor only.
v. No parking of any sort by the tourist shall be allowed in the core zone as well as
peripheral distance of 1.5 km. from the boundary of core zone. However, there
shall be no restriction on the provision of required parking as per prevailing
regulations, in the individual premises.
vi. Restoration and expansion of existing Temples and sacred groves shall be
governed by the Heritage regulations applicable for the Satara Regional Plan.
B. Buffer Zone of Conservation Zone:-
The following uses shall be permissible in the Buffer zone of the Conservation Zone:-
a. All agricultural uses including stables of domestic animals, piggeries, poultry farms
accessory building, tents.
b. Garden, forestry, nursery, public parks, play fields, summer camps for recreation of all
types.
c. Storage and drying of only organic manure.
d. L.P.G. Godown subject to the following conditions:-
Minimum plot size and area of the plot shall be as given below
Sr. No. Qty. of LPG Total area Safety Preferable size of
in Kgs requirement for Clearance land with parking
storage shed required all area of 6 m. wide on
around in front side
(Sq. M.)
Meters
1 5000 55 6 21 m. x 26 m.
2 8000 88 7 25 m. x 30 m.
3 10000 110 8 28 m. x 33 m.
4 12000 132 9 31 m. x 36 m.
Conditions :-
i) Land should be free from live overhead power transmission or telephone lines.
ii) The length of the storage shed should not be more than 1.5 times of width of
storage shed.
iii) The land should not be situated in low lying area.
iv) The land should not be situated in congested area or gaothan.
e. Public utility establishments such as electric sub-stations, receiving stations, sewage
disposal water works along with residential quarters for essential staff for such works.
f. Farm house: - subject to following conditions:-
i. Minimum plot area under above use shall be 0.4 Ha.
ii. The land in which it is to be constructed is actually put under agricultural,
Plantation, horticulture, floriculture, nursery etc. use.
iii. Farm house shall be permitted by the Authority/Collector only after the requisite
permission for farm house is obtained by the owner from the Authority/Collector
under the provisions of Maharashtra Land Revenue Code, 1966 and attested
certified copy of such permission is attached with the application under Section
44 of the Maharashtra Regional and Town Planning Act, 1966.
iv. The FSI shall not exceed 0.0375 subject to a maximum built up area of 160 Sq.m.
in any case. Only ground floor structure with or without stilt shall be permissible
with sloping roof.
g. Swimming pools/sports and games, health clubs, cafeteria, canteen, tennis courts, etc.
h. Mobile Phone Towers with ancillary equipment.
i. Raisin/Processing units for Local Agriculture Produce.
j. No extension for Mining and quarrying operations shall be permitted beyond expiry of
valid period.
k. Ancillary service industries for agriculture produce marketing and management,
Ancillary service uses for agro related products like flowers, fruits, vegetables, poultry
products, marine products related collection centres, auction hall, godowns, grading
services and packing units, knowledge parks, cold storages, utility services (like
banking, insurance, post office services) as service industries for agriculture produce
marketing on the land owned by individuals/organizations, with construction up to a
maximum of 20 % (FSI=0.20)of the net plot area.
l. Petrol Pump/LPG Pump/CNG Pump :- Petrol Pump, LPG Pump, CNG Pump shall be
permissible subject to following conditions:-
i. The minimum size of plot shall be,
(a) 30.50 m x 16.75 m. in the case of Petrol/LPG/CNG Filling Station with
kiosk without service bay;
(b) 36.50 m x 30.50 m. in the case of Petrol/LPG/CNG Filling Station with
service bay.
ii. Plot shall be located /fronting on National Highway, State Highway, Major
District Road, Other District Road or Village Road or other road with minimum
width of 12 m. or more.
iii. Permission from Government of India, Petroleum Ministry and Chief
Controller of Explosives shall be necessary.
iv. NOC from Public Works Department and other related departments shall be
obtained as per the prevailing rules. As regards service road / building
line/control line, the Government Resolution, Public Works Department, No.
RBD-1081/871/Raste-7, dated 09 March, 2001and the circulars issued in this
regard from time to time shall be observed.
As also instructions contained in Government of India, Ministry of Road
Transport and Highways letter dated 25/09/2003 and 17/10/2003 and its
enclosures as amended from time to time shall be observed.
v. The plot on which a petrol filling station with or without service bays is proposed
shall be an independent plot on which no other structure shall be constructed.
vi. Petrol/LPG/CNG station shall not be permitted within a distance of 90 m. from
junction of roads having minimum width of 12 m. each. Also Petrol station shall
not be sited within a distance of 90 m. from the nearest premises of school,
hospital and theatre, place of assembly or stadium.
vii. In the case of kiosks and other buildings for sales office, snack bars etc. within
the plot for Petrol/LPG/CNG filling stations, the setbacks from the boundaries
shall be 4.50 m. Further the other clearances for the installations shall be as per
the Petroleum Rules of 1937.
m. Solid waste management, bio-gas plants, power generation from waste and non-
conventional sources of energy.
n. Wayside amenities such as motels, way-side restaurants, service stations, service
godowns, factory outlets, along with public conveniences like toilets, food stall / stalls
upto 15 Sq.m. carpet area each, within basic permissible FSI of 0.10. Maximum FSI upto
0.50 on gross plot area shall be permissible for all above wayside amenities.
Provided that, FSI above the basic permissible 0.10 FSI upto 0.50 may be granted by the
Authority / Collector on payment of premium at the rate of 30% of the land rate of the
said land mentioned in the Annual Statement of Rates (ASR) for the year in which such
additional FSI is granted. Such premium shall be deposited in the office of the Authority /
District Branch of the Town Planning Directorate; having maximum 9 m. height and G +
1 or Stilt + 2 structure in independent authorized plot abutting existing classified roads
including ODR, MDR or on any road not less than 18.0 mtrs. width shall be Permissible.
It shall be mandatory for all Wayside Amenities to provide hygienic toilet facilities and
decentralized MSW treatment and disposal facilities.
o. Development of buildings of health resort, educational and medical activities, with G + 1
or Stilt + 2 structure, subject to plantation of indigenous trees at the rate of 5 trees per
‗are‘ on the plot within basic permissible FSI of 0.10. Maximum FSI upto 0.20 on gross
plot area shall be permissible for all above development.
Provide that, minimum plot area required for Health Resort shall be 0.40 Ha., whereas it
shall be 1.0 Ha. for Educational and Medical activities.
Provided further that, FSI above the basic permissible 0.10 FSI up to 0.20 may be granted
by the Authority / Collector on payment of premium at the rate of 20% of the land rate of
the said land mentioned in the Annual Statement of Rates (ASR) for the year in which
such additional FSI is granted. Such premium shall be deposited in the office of the
Authority / District Branch of the Town Planning Directorate.
p. The layout / development permission already granted under erstwhile regulations before
28th March, 2017 (i.e. the date of resolution of the RP Board to publish Draft R.P.) shall
be valid and continue to be so valid, unless otherwise specified in these regulations.
q. Residential and Compatible development within & adjacent to Gaothan in Rural area:
i. Residential and Compatible development within Gaothan in Rural area:
The development control and Promotion regulations as otherwise applicable to
Gaothans in Sanctioned Regional Plan, Satara along with the modifications made
in it from time to time shall be applicable to the Gaothans shown as existing on
Village Maps & Gaothans / extension of Gaothans subsequently declared by
Revenue Department under the provisions of Maharashtra Land Revenue Code,
1966.
ii. Residential and Compatible development adjacent to Gaothan in Rural area:
Residential and/or Compatible development shall be allowed within 200 m. from
Periphery of the Gaothan Boundary with following conditions-
Such development may be permitted as per the prevailing regulations applicable
to other such peripheral areas in Sanctioned Regional Plan, Satara along with the
modifications made in it from time to time on payment of premium of the total
area of land. Such premium shall be calculated considering 15% rate of the said
land as prescribed in the Annual Statement of Rate of the year granting such
developments. Such premium shall be deposited in the concerned
Authority/Branch Office of the Town Planning Department for crediting the same
in to the Government Treasury.
Provided that, where more than 50 % of area of the Survey Number / Gat
Number is covered within the above peripheral distance then the remaining whole
of such Survey number/Gat number within one ownership shall be considered for
development on payment of premium as above.
Provided further that, such payment of premium shall not be applicable in cases
where development permissions already granted or layout is already approved
before 28th March, 2017 (i.e. the date of resolution of the RP Board to publish
Draft R.P.) shall be entitled for development /FSI of respective use /zone by the
authority/ Collector.
Such premium shall also be not applicable for revision of such already approved
permissions.
r. Development in Gairan Lands / Government Lands:-
Development / Construction in Gairan Lands / Government Lands is permissible for any
public purpose for Central & State Government/ Departments Projects including
rehabilitation in any zone.
Note 1 :- The premium charges mentioned in the above regulation shall not be applicable,
if the work is undertaken by Central or State Govt. or public authorities controlled by it.
Note 2 :- The development in command area shall be permissible subject to payment of
restoration charges, if any to Irrigation Department.
s. Regulation for development of tourism and hospitality services under Community Nature
Conservation around wild life sanctuaries and National parks:-
Applicability :- These regulations shall apply to the privately owned (not applicable to
forest land) lands situated within 5 km or the distance as shown in the STR Conservation
Plan, whichever is more, from the boundaries of wild life sanctuaries and national parks.
The provisions of existing Regional Plans / Development Plans will prevail over these
regulations, wherever lands are marked for urbanisable zones in such plans.
Regulation :- For the lands situated within 5 km distance from the boundaries of wildlife
sanctuaries and national parks, if the land owner applies for development permission, for
Development of eco-tourism, nature tourism, adventure tourism, same may be allowed;
provided the land under consideration has minimum area of one hector in contiguous
manner.
Permissible uses and built up area :-
The uses permissible shall be as follows :-
i. Agriculture, Farming, development of wild animal shelters, plantation and allied
uses.
ii. Tourist homes, Resorts, Hotels etc. with Rooms/ suites, support are as for
reception, kitchen, utility services etc. along with ancillary structures like
covered parking, Watchman‘s quarter, guard cabin, landscape element sand only
one observation tower per tourist resort up to the height of 15 m. with platform
area up to 10 sq. m. in permanent/ semi-permanent structural components.
The norms for buildings will be as follows :-
(a) The maximum permissible total built up area shall not exceed 10% of
gross area with only G+1 or Stilt + 2 structure having height not more
than 9m. and it should blend with surroundings.
(b) The Fencing/fortification may be permissible for only 10% of total land
area around built up structures in the form of chain link without masonry
walls thereby keeping the remaining area free for movement of wildlife.
(c) Tourism infrastructure must conform to environment friendly, low height,
aesthetic architecture, natural cross ventilation; no use of asbestos, no air
pollution, minimum outdoor lighting and merging with the surrounding
landscape. The owner shall establish the system for captive energy
generation using non- conventional energy sources like solar, wind
biogas etc. so as to make the development self-sufficient.
(d) The owner shall establish effective sewage disposal and recycling system
during the construction and operational phase of the development. No
amount of sewage shall go into the natural stream; failing which the
resort shall be closed down within 48 hours.
(e) The owner shall establish effective systems for collection, segregation
composting and/or reuse of different types of solid waste collected during
the construction and operational phase of the development.
(f) The plastic components used within the area shall be recycled; failing
which the resort shall be closed down within 48 hours.
(g) Natural stream/slopes terrain shall be kept as it is, except for the built-up
area.
(h) On the area other than 10% area, only indigenous trees shall be planted
and only natural vegetation shall be allowed.
(i) For the developments existing prior to the publishing of the Regional
Plan, condition no.(ii) above shall be applicable retrospectively to the
extent of restricting the fencing and keeping the remaining area free for
movement of wildlife.
(j) While allowing such development, principles given in the National Tiger
Conservation Authority, New Delhi Notification No. 15-31/2012-NTCA,
dated 15/10/2012 published in the Gazette of India Ext. pt. III S-4 dated
08/11/2012 and Government of Maharashtra as amended time to time
shall be used as guidelines.
t. Film studios at appropriate location having ground floor structure only with the built up
area not exceeding 4% (o.o4) of the net plot area with the condition that proper
landscaping is done & trees are planted at the rate of 500 indigenous trees per hector.
u. Open Parking lots /Open Parking lay outs shall be allowed at a distance beyond 2.5 Km.
from the boundary of core zone with previous approval of Authority/ Collector.
v. Plantations/ Afforestation: - Plantations shall be undertaken as per illustrative List of
Plantations attached at Annexure - "A"
Any other compatible use not specified above may be permitted by the Authority /
Collector with prior approval of Director of Town Planning, Maharashtra State, Pune.
Notes : i. The permissible FSI for uses in Buffer zone of Conservation zone shall be 0.1 of
the gross plot area, if not specified.
ii. Every structure shall be with sloping roof.
iii. All development proposals shall show the existing contour lines of the land at
3m. intervals, certified by a qualified technical person. NO Development shall be
permissible where slope of land is more than 20º.
iv. The owner/Architect shall mark individual trees, dense tree cover area / forest
alike area However where the tree cluster is too dense for individual trees to be
marked then the area covered by the tree cluster is to be clearly demarcated on
the plans.
v. The District Conservator of Forest (DCF), Satara Division shall inspect all sites
having dense tree cover and Steep Slopes prior to the sanction for the
development permission in order to ascertain and verify the information provided
about tree cover shown in the plans. On such inspection, the DCF, Satara shall
certify whether the area under proposal has dense forest / tree cover or not and if
yes he is required to mention the area covered by such dense forest/ tree cover /
forest alike area.
vi) In furtherance of above the D.C.F. shall give his detailed remarks regarding
tree/s proposed to be cut and/or transplanted if any. However, the number of
trees proposed to be cut or transplant shall not exceed 10 % of the number of
trees existing thereupon.
vii) With prior approval of the Director of Town Planning, Maharashtra State,
Pune; the Authority/Collector may include other items of public interest in
the list which are not covered in the above list.
viii) Dumping of construction material outside the property in forest or in natural
water course is strictly prohibited
5.5.3 Development above 1000 m. Mean Sea Level.
The Government in Urban Development Department has sanctioned regulations for Development
above 1000 m. Mean Sea Level vide Notification No.TPS-1919/436/C.R.83/19/ Sec. 20(4)/UD
13, dt. 23/12/2021 as under.
Appendix - O
REGULATIONS FOR AREAS SITUATED ABOVE 1000 m. OF MEAN SEA LEVEL IN
SATARA REGION.
PART-I
ADMINISTRATION
1.0 SHORT TITLE,EXTENT AND COMMENCEMENT
A. Title :- These Regulations shall be called as Regulations for areas situated above 1000 m.
of Mean Sea Level in Satara Region.
B. Extent :- These Regulations shall apply to the area earmarked as areas situated above
1000 m. of Mean Sea Level and, more specifically shown in Red Contours on the maps
appended herewith as Appendix - "P" and illustratively listed in the Appendix -"Q".
C. Commencement - These Regulations will come into force after it is sanctioned by
Government.
If there is any conflict between any Regulations sanctioned for Regional Plan Area for
Satara Region and these Regulations, these Regulations shall prevail.
PART - II
1.0 LAND USE CLASSIFICATION AND PERMISSIBLE USES
A. All Regulation of Buffer Zone of Conservation Zone shall be applicable while allowing
Development in such areas and more specifically shown on the plan appended herewith
as Appendix - "P"
(Appendix-M (Plan No.TPS-1919/436/ C.R.83/19/Sec.20(4)/Ud-13) and Appendix-N and
Appendix-P (Plan No.TPS-1919/436/C.R.83/19/Sec.20(4)/Ud-13) and Appendix-Q shall be
made available for inspection to the general public during office hours on all working days at the
following offices :-
1) The Director of Town Planning, Maharashtra State, Pune.
2) The Joint Director of Town Planning, Pune Division, Pune.
3) The Collector, Satara.
4) The Assistant Director of Town Planning, Satara Branch, Satara.
5.6 FOR HINGOLI, BULDHANA, WASHIM, YAVATMAL, NANDED REGIONAL PLAN
Following additional regulations shall be applicable for the development in the areas affected by
the LIGO project.
i) Within the distance of 15 km. from the boundary of the site, no New Railway line shall be
proposed.
ii) Within the distance of 5 km. from the boundary of the site, no classified roads, MDR and
above etc. shall be newly proposed. Upgradation of existing roads shall not be treated as
new road.
iii) Within the distance of 5 km. to 30 km., from boundary of the site, no reciprocating activity,
requiring the use of sustained heavy equipments including mining, blasting or such other
similar activities requiring more than 20 HP power, shall be allowed,.
iv) Within the distance of 15 km. from boundary of the site, no Power Plant Machinery, Rock
crushers, Heavy Machinery, Wind Mill shall be allowed. Within the distance of 5 km. from
boundary of site, no non-reciprocating (rotating) power plant machinery and industrial
machinery shall be allowed.
v) Within the distance of 60 km. from the boundary of the site, no New Airport shall be
proposed.
Note -
a) If any more clarification or exemption or certain information is required, then permissions
shall be referred to the LIGO - India authorities (at local office) before final Grant of
permission.
b) The Development Control Regulations as amended from time to time, by the Department of
Atomic Energy, Govt. of India, shall be applicable as it is for this LIGO - India Project.
5.7 FOR RAIGAD REGIONAL PLAN
5.7.1 The development in Nagothane growth centre shall be governed by following regulations.
The lands which fall within the periphery on the north/ south direction of the IPCL project
complex have been designated as low density residential zone in which residential user may be
permitted subject to following conditions.
i) Maximum FSI shall be 0.25.
ii) Only ground floor structure shall be permissible.
5.7.2 The development in wadi lands in the coastal belt, which are marked as such in the Regional
Plan, development shall be subject to the following conditions, only along the existing roads.
i) Plot with frontage on the existing road.
ii) Ground + one floor building within 33 m. from the existing road with permissible set back
from the road.
iii) FSI shall be limited to 0.04 maximum with a maximum built-up area of 150 Sq.m.
Note - Coastal belt is the area within 1 km. from the sea for the purpose of this Regulation.
5.7.3 The development in low density Zone in Rajpuri and Usar growth center shall be subject to 0.5
basic FSI.
5.8 FOR SOLAPUR REGIONAL PLAN
In agricultural zone, residential development for the housing of Economical Weaker Section may
be permitted subject to following conditions.
i) The premium at the rate of 10% of the land rate mentioned in ASR without considering the
guidelines therein shall be paid before granting the permission.
ii) The authority/ collector shall decide the beneficiary persons, who are actually under the
Economical Weaker Section, as per revenue records.
5.9 FOR PUNE REGIONAL PLAN
5.9.1 Regulations for planning areas of growth centres at sector-R -i.e. i) Lonavala-Karla-Malvali And
ii) Kune-Pangaloli-Kurwande and surrounded area which is a part of Pune Metropolitan
Development Authority area, shall be as per the following Regulations.
REGULATIONS FOR LONAVALA-KARLA-MALAVALI PLANNING AREA OF
SECTOR-R OF REGIONAL PLAN OF PUNE REGION
i) No plots in these zones shall be less than 500 Sq.m. provided that smaller plots in these
zones admeasuring not less than 300 Sq.m. existing before the date of publication of
regional plan shall be recognized for the purpose of granting development permissions,
provided further that plots directly abutting on Mumbai-Pune road shall not admeasure less
than 1000 Sq.m. Development in such 1000 Sq.m. plot, shall be governed by development
control rules in Lonavala Development Plan, applicable to 10 are zone. Built up areas,
number of storeys, tenements, marginal open spaces and room sizes, the maximum built up
areas, the maximum number of storeys, the maximum number of tenements, the minimum
marginal open spaces and the minimum room sizes permissible in these zones shall be as
indicated in the statement annexed hereto. As regards rules for layout plots and group
housing schemes and buildings of various users other than residential including industrial,
other items of building construction, such as balcony, sanitation, height, ventilation and
parking etc. and all other such regulations which are not explicitly covered above shall be
governed by development control regulations for these items incorporated in Development
Plan of Lonavala as amended from time to time and subject to these regulations.
Sr. Plot Size Maxi Max. Max. Min. marginal open Min Min. Min sizes
No. no space
group mum no. of Habi- sizes for shops
of
built storeys table for & other
teneme
up room kitchen rooms
nts
area sizes for
commer-
cial use
1 Between 25% Ground 2 3m 2.5m 3m 9.0 7.5 Sq.m. 15 Sq.m.
Sq.m. m m m
300 plus
Sq.m. m with no with no with no
one
and less side less side less side less
floor
than than 3m than than 3m
only
2.5m
500sq.m
2 500 25% Ground 4 4.5 3m 4.5m
m
Sq.m. plus
and
one
above
upper
1) A ground floor on stilts or columns without enclosing walls (except retaining walls,
where such floor is constructed by cutting the sloping ground) intended to be used as
parking space shall not be counted as ground floor.
2) In case of classified roads, the minimum marginal open spaces to be observed
from roads, shall be as prescribed above or as prescribed by Government from time
to time under the ribbon development rules, whichever is more.
3) Sr.No.1 is applicable to the plots existing on or before the date of publication of the
notification of sectioning of regional plan in the official gazette.
ii) REGULATIONS FOR KUNEPANGALOLI- KURWANDE PLANNING AREA OF
SECTOR-R OF REGIONAL PLAN OF PUNE REGION- Development in this area
shall be governed by the regulations applicable to 10 Are zone in the Lonavala
Regional/Development Plan. The maximum built up areas, the maximum number of
storeys, the maximum number of tenements, the minimum marginal open spaces and the
minimum room sizes permissible in these zones shall be as indicated in the statement
annexed hereto. As regards rules for layout plots and group housing schemes and buildings
of various users other than residential including industrial, other items of building
construction, such as balcony, sanitation, height, ventilation and parking etc. and all other
such regulations which are not explicitly covered above shall be governed by development
control regulations for these items incorporated in Development Plan of Lonavala as
amended from time to time and subject to these regulations.
Sr. Plot Size Maximum Max Max. Min. marginal open Min Min.
sizes
No. group built up no. of no of space habitable
for
area storeys tene- room
kitch
sizes
ments en
Road Side Rear
side
1 Between 25% Ground 2 4.5 m 3 m 4.5 m 9.0 Sq.m. 7.5
m Sq.m
500 plus
. m
Sq.m. m with no
one
with
and less side less
floor no
than than 3m
only
side
1000 less
Sq.m. than
2.5 m
2 1000 25% Ground 4 4.5 m 3 m 4.5m 11 Sq.m.
m
Sq.m. m plus
and with no
one
above side less
upper
than 3m
1) A ground floor on stilts or columns without enclosing walls (except retaining walls, where
such a floor is constructed by cutting the sloping ground) intended to be used as parking
space shall not be counted as ground floor.
2) In case of classified roads, the minimum marginal open spaces to be observed from roads,
shall be as prescribed above or as prescribed by Government from time to time under the
ribbon development rules, whichever is more.
3) Sr. No. 1 is applicable to the plots existing on or before the date of publication of the
notification of sanctioning of regional plan in the official gazette.
5.10 CERTAIN REGULATIONS CEASE TO OPERATE IN FUTURE.
The Regulation No. 5.8 shall cease to operate on 1st Jan, 2022 or as decided by the Government
from time to time and thereafter provisions of these regulations shall apply.
(1) 5.11 BOARD OF APPEALS.
Any person aggrieved by an order / communication made by an authority / Collector under these
Regulations may prefer an appeal before the Board of Appeals. The board shall be constituted at
division level consisting of the Divisional Head of Town Planning Department of the concerned
division as President and concerned ADTP / TP of the district as a member.
(2) 5.12 AURANGABAD REGIONAL PLAN
Tourism Development Strip shown in Tourist Complex of Mhaismal Giristhan, Tourist Complex
Sulibhanjan, Tourist Complex Verul, Tourist Complex Doulatabad.
Notwithstanding anything contained in these rules, the following Building users will be
permissible in this Zone -
Conventional Hotels, Including cottages for tourist.
i) Canteens/Restaurants & Tea stalls including pan shops.
ii) Baths & Toilets for camping sites providing for tents/caravans
iii) Public utilities and services like information centre, tourist reception centre, telephone
booths, first aid centre, health farm, gymnasium , indoor game hall and lawn tennis court,
structures for recreation purposes such as Amusement Park, water sports facilities, marine
jitties & pontoons for docking of boats, swimming pools, boat house, and like.
with following restrictions-
a) Minimum plot size should be 100x 50mts irrespective of holdings.
b) 12 mt. service road should be provided
c) Minimum 6 mt. side margin from all side should be provided. Similarly ribbon
development Control Rules should be observed.
d) The permissible FSI shall be 0.2 on gross plot area without payment of premium and upto
1.00 with payment of premium at the rate of 20% of land rate in ASR of said land, without
considering the guidelines therein.
e) Sculpture tree plantation along service road to be carried out with the help of social forest
Department. Plantation at the rate of 300 plants per Hectors to be carried out before
commencement of work.
f) In this strip user of tourist interest is only be permitted.
On the plots, for which regular N.A &/or layouts are sanctioned and which area affected by this
strip, the above said users shall only be permitted, keeping the area & the shape of the plot intact
as per sanction.
(1)
Inserted Vide Addendum No.CR 236/18, dt. 14th January, 2021.
(2)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
-*-*-*-*-*-