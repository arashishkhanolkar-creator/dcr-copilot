# Chapter 8: Parking, Loading and Unloading Spaces

CHAPTER - 8
PARKING, LOADING AND UNLOADING SPACES
8.1 PARKING SPACES
Wherever a property is to be developed or redeveloped, parking spaces at the scale laid down in
these Regulations shall be provided. A parking plan showing the parking spaces along with
manoeuvring spaces/ aisles shall be submitted as a part of building plan. When additions are
made to an existing building, the new parking requirements will be reckoned with reference to the
additional space only and not to the whole of building but this concession shall not apply where
the use is changed. The provisions for parking of vehicles for different occupancies shall be as
given in Table No.8A
8.1.1 General Space Requirements
i) Location of Parking Spaces
The parking spaces include parking spaces in basements or on a floor supported by stilts,
podium or on upper floors, covered or uncovered spaces or in separate building in the plot
and / or lock up garages. The height of the stilt shall not be less than 2.4 m. from the bottom
of beam. In case of stack parking, height up to 4.5 m. may be allowed.
ii) Size of Parking Space
The minimum sizes of parking spaces to be provided shall be as shown below in Table
No.8A
Table No.8A - Parking Space Requirement
Sr.No. Type of Vehicle Minimum size/ area of parking space
1 Motor vehicle 2.5 m. x 5 m.
2 Scooter, Motor Cycle. 1.0 m. x 2.0 m.
3 Transport vehicle / 3.75 m. x 7.5 m.
Ambulance / Mini Bus.
Note :
(1) (a) In the case of parking spaces for motor vehicle, upto 50 present of the prescribed space
may be of the size of 2.3 m. x 4.5 m.
(1) (b) Minimum size of parking space in mechanized / puzzle parking system shall be 2.3 m. x
5.8 m. for big cars and 2.1 m. x 5.0 m. for small cars.
iii) Marking of Parking Spaces
Parking space shall be paved and clearly marked for different types of vehicles.
iv) Manoeuvring and Other Ancillary Spaces
Off street parking space must have adequate vehicular access to a street and the area shall be
exclusive of drives, aisles and such other provisions required for adequate manoeuvring of
vehicles. The width of drive for motor vehicles and scooter, motor cycle shall be minimum
3.00 m. and 2.00 m. respectively.
(1) Inserted Vide Corrigendum / Addendum No.CR 79/2021, dt. 02nd December 2021
v) Composite parking.
The composite parking of vehicles like one car with two scooters may be allowed. Also, six
scooters' parking may be allowed to be converted in one car parking. In such cases, drives or
aisles shall be required taking into consideration entire composite parking.
vi) Bus bay for schools / multiplex /malls/ assembly buildings / group housing.
For these occupancies, being a special building, a bus bay of required size shall be provided
within premise or along main road on which plot abuts. This shall be applicable for housing
scheme having more than 500 flats.
vii) Ramps for Basement Parking:
Ramps for parking in basement should conform to the requirement of Regulation No.9.12
viii) Other Parking Requirements
a) To meet the parking requirements as per these regulations, common parking area for
group of buildings, open or multi-storeyed, may be allowed in the same premises
b) In addition to the parking spaces provided for building of Mercantile (Commercial)
like office, market, departmental store, shopping mall and building of industrial and
storage, loading and unloading spaces shall be provided at the rate of one space for
each 1000 sq. m. of floor carpet area or fraction thereof exceeding the first 200 sq. m.
of floor area, shall be provided. The space shall not be less than 3.75 m. x 7.5 m.
(1) subject to maximum requirement of 4 such parking spaces for office buildings and
6 parking spaces for other buildings. However, in case of office building, such
parking spaces shall not exceed more than 4.
c) Parking lock up garages shall be included in the calculation for F.S.I. calculations.
d) The space to be left out for parking as given in this regulation shall be in addition to
the marginal open spaces left out for lighting and ventilation purposes as given in
these regulations. These spaces may be used for parking provided minimum distance
of 3 m. (6 m. in case of special building mentioned in Regulation No. 2.2.8) around
the buildings is kept free of any parking or loading and unloading spaces, excepting
the building as mentioned in Clause (c) above. Such parking area adjoining the plot
boundary may be allowed to be covered on top by sheet roofing, so as not to infringe
the marginal distance to be kept open as specified above. Further such sheet roofing
shall not include the area adjoining the plot boundary to be used for tree plantation as
mentioned in Regulation No. 3.4.1 (iii), if any.
e) In case of parking spaces provided in basements, at least two separate ramps of
adequate width and slope for entry and exit shall be provided preferably at opposite
ends. One ramp may be provided as specified in Regulation No.9.12.
(1)
(f) Mechanical / Hydraulic / Stack parking / Parking tower may be permitted at 1.5 m. in
side and rear margin under following circumstances.
1. Minimum 6.0 m. drive way shall be kept clear from all kind of obstruction for
easy manoeuvrability of fire and rescue appliances like ambulance. For building
defined as High Rise building and special building in these regulations. 9.0 m.
turning circle around the building shall be maintained.
2. For Non Special building as defined in these regulations, such distance shall not
be less than 3.0 m.
(1)
Inserted Vide Corrigendum / Addendum No.CR 79/2021, dt. 02nd December 2021
(1) 3.Such mechanical / hydraulic / parking tower may be permitted touching the
building on dead wall side. Provided that the dead wall must be 2 hours fire
rated wall.
4. The fire protection arrangement as per storage building will be made applicable
to such parking towers as per Table 7 of Part 4 of NBC 2016.
8.2 OFF STREET PARKING REQUIREMENT
8.2.1 Off-street parking requirement
Off street parking requirement shall be based on Table No. 8B below and factors mentioned in
Table No.8C of Regulation No. 8.2.2 for various cities/ areas. Total parking requirement for a
building shall be worked out as per Table No. 8B, and then factor mentioned in Table No.8C shall
be applied to arrive at required parking for a building.
(1)
Inserted Vide Corrigendum / Addendum No.CR 79/2021, dt. 02nd December 2021
Table No. 8B - Parking Requirements
Sr. Occupancy Size of tenement Parking Spaces Required Remarks
No.
Congested Area Non Congested
Area
Car Scooter Car Scooter
1 Residential For every tenement having carpet area of 2 (1) 1 2 (1) 1 In addition 5% visitor
150sq.m. and above. parking
i) Multi- Family
residential For every tenement having carpet area equal to or 1 (1) 1 1 (1) 1 In addition 5% visitor
above 80 Sq.m. but less than 150 Sq.m. parking
For every two tenements with each tenement 1 (1) 2 1 (1) 2 In addition 5% visitor
having carpet area equal to or above 40 Sq.m. but parking
less than 80 Sq.m.
For every two tenements with each tenement 1 1 1 2 In addition 5% visitor
having carpet area less than 40 Sq.m. but more parking
than 30 Sq.m.
For every two tenements with each tenement 0 (1) 2 0 (1) 2 In addition 5% visitor
having carpet area less than 30 Sq.m. parking
ii) Lodging For every five guest rooms 1 4 1 6 --
establishment's tourist
homes, hotels with
lodging accommodation,
Star Category Hotels.
iii) Restaurants For every 50 Sq.m. of carpet area of restaurant 0 8 1 8 --
including kitchen, pantry hall, dining room etc.
(1)
Inserted vide Notification u/s 37 (1AA)(c)& 20 (4) No. CR 236/18 (Part 4), dt. 28th December 2022.
2 Institutional (Hospitals, For every 10 beds 2 12 3 10 For hospital (special
Medical Institutions) building), space for 1
ambulance per hospital,
shall be provided.
3 Assembly (theatres, For every 40 seats. 4 16 4 16 --
cinema houses, concert
halls, auditoria,
assembly halls including
those of college and
hostels)
Multiplexes For every 40 seats. 5 14 5 14 --
Mangal karyalaya / For every 100 Sq.m. carpet area / lawn area of 1 5 1 5 --
Marriage Halls, Cultural fraction thereof.
Halls and Banquet Hall
Community hall and For every 200 Sq.m. carpet area 1 5 1 5 --
club house in layout
open space (applicable
only for open spaces
having area 4000 Sq.m.
and more)
4 Educational For every 100 Sq.m. carpet area of the 1 4 2 4 --
administrative as well as public service area of the
Schools and the
school.
administrative as well as
public service areas
therein
For every 3 class rooms (1)1) 5 two wheelers for every three
class rooms.
2) The number of mini bus parking
shall be at the rate of bus for
every 40 numbers of students for
50% strength of students may be
provided at the option of owner /
developer.
3) Mini bus parking shall be
permitted on playground except
during school timing.
College and For every 100 Sq.m. carpet area of the 1 12 2 17 --
administrative as well as administrative as well as public service area of the
public service area school.
therein.
For every 3 class rooms 1 24 2 24 --
Coaching Classes / For every 20 students. 1 9 1 9 --
Tuition Classes / Hobby
Classes.
5 Government or semi For every 100 Sq.m. carpet area or fraction 1 12 2 12 In addition 20% visitor
public or private thereof parking
business buildings.
6 Mercantile (markets, For every 100 Sq.m. carpet area or fraction 1 6 2 6 --
departmental stores, thereof
shops and other
Commercials users)
(1)
Inserted vide Notification u/s 37 (1AA)(c)& 20 (4) No. CR 236/18 (Part 4), dt. 28th December 2022.
Whole sale shops not For every 100 Sq.m. carpet area or fraction 1 4 1 5 --
being used for retail thereof
trading.
Hazardous building For every 100 Sq.m. carpet area 0 4 1 3 --
Office and I.T. building For every 200 Sq.m. carpet area or fraction 3 11 3 11 --
thereof.
7 Industrial For every 300 Sq.m. carpet area or fraction 2 9 3 9 --
thereof
8 Storage (any type) For every 300 Sq.m. carpet area or fraction 0 4 1 3 --
thereof
Note -
i) After calculating the parking for entire building, multiplying factor given in Table 8 C shall be applied. Fraction of parking spaces more than 0.5 shall
be rounded to next digit.
ii) In case of independent single family residential bungalows having plot area upto 300 sq. m., parking space need not be insisted separately. Further a
garage shall be allowed in rear or side marginal distance at one corner having minimum dimensions of 2.5 m. x 5.0 m. and maximum dimensions 3 m. x
6 m. i.e. minimum 12.5 Sq.m. and maximum 18.0 Sq.m. built up area.
iii) In the case of shops, row houses on plots upto 100 sq. m., parking space need not be insisted.
iv) Mechanical/Hydraulic / Stack parking / multi-storeyed parking with or without car lift may be allowed to meet the requirement.
v) Parking more than 50% over and above stipulated in table 8 B and 8C, shall be liable for payment of charges at the rate of 10% of land rate mentioned
in the ASR without taking into account guidelines therein. Such charges shall be recovered on the area covered under car / scooter parking over and
above the requirement. However, for public semi-public, hotel, hospital, educational buildings, such charges shall not be leviable.
(1) Parking requirement as stipulated in Table-8 B and Table- 8 C, may be permitted for full permissible potential of the plot even though Building
permission is sought for and sanctioned for only part of the full potential. In such cases the difference between number of parking required for such part
potential and full permissible potential shall be liable for payment of charges as above, at the time of final occupancy certificate for such sanctioned
permission,
Or
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
If the building permission proposal for the balance potential is not submitted before such final occupancy certificate, then such excess parking shall
deemed to be treated as public parking and shall be handed over for the same purpose to the Authority free of cost.
vi) In case of plan for additional built-up area on existing building and where existing built-up is to be retained as per earlier sanction - off-street parking
requirement (number of units) shall be calculated only for the newly proposed additional built-up area as per this regulation and existing parking area
shall be retained as per approved plan. If the additional built-up area alongwith existing built-up area is proposed to be revised as per these regulations
(UDCPR) then total parking requirement shall be calculated as per this regulation and existing parking units are to be deducted to arrive the new number
of parking units required.
(2) vii) Multiplying factor as per regulation No. 8.2.2 Table No. 8 C shall not be applicable for Two Wheeler parking (2) for Sr. No. (i) - Multi Family
residential of Sr. No. 1 - Residential in Table No. 8 B of Regulation No. 8.2.1
(1)
Inserted vide Notification u/s 37 (1AA)(c)& 20 (4) No. CR 236/18 (Part 4), dt. 28th December 2022.
(2)
Inserted vide Corrigendum No. CR 236/18 (Part 4), dt. 12th January, 2023.
8.2.2 Off street parking requirement for various Planning Authorities / areas.
Off street parking requirement for various Planning Authorities/ Areas shall be worked out by
applying multiplying factor given in Table No.8C below. This multiplying factor shall be applied
to the total quantum of parking spaces worked out as per Table No. 8B above.
Table No.8C
Sr. Authority / Area Multiplying Factor
No.
1 Pune, Pimpri-Chinchwad and Thane Municipal 1.00
Corporation area and PCNTDA area.
2 Nagpur, Nashik Municipal Corporation area. 0.9
3 Other Municipal Corporations in MMR area except 0.8
Thane M.C., (1)CIDCO as Planning Authority by
Virtue of NTDA
4 Remaining Municipal Corporations not covered at Sr. 0.7
No. 1 to 3 and 5, Metropolitan Area Development
Authority / Area Development Authority/ SPA area.
5 'D' Class Municipal Corporation area except at 0.6
Sr. No.3
6 'A' Class Municipal Council area. 0.6
7 'B' and 'C' Class Municipal Council area. 0.5
8 Nagar Panchayat, Non Municipal Town Development 0.4
Plan area and areas in Regional Plan.
-*-*-*-*-*-
(1)
Inserted vide Notification u/s 37 (1AA)(c) No. CR 236/18 (Part 6), dt. 12th October 2022.