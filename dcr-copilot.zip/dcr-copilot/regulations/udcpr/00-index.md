# UDCPR Reference Index

Source: UDCPR-2020, as updated upto 30 January 2023 (DRAFT SOURCE - see NOTE below)

> NOTE: this draft was built from a working copy for pipeline testing. Before shipping to customers, replace with text sourced from the PMRDA-hosted consolidated PDF (updated 30.01.2025) and cross-checked against the Directorate of Town Planning and Valuation notification page.

## Chapters

- **Chapter 1: Administration** -> `chapter-01-administration.md`
- **Chapter 2: Development Permission and Commencement Certificate** -> `chapter-02-development-permission-and-commencement-certificat.md`
- **Chapter 3: General Land Development Requirements** -> `chapter-03-general-land-development-requirements.md`
- **Chapter 4: Land Use Classification and Permissible Uses** -> `chapter-04-land-use-classification-and-permissible-uses.md`
- **Chapter 5: Additional Provisions for Regional Plan Areas** -> `chapter-05-additional-provisions-for-regional-plan-areas.md`
- **Chapter 6: General Building Requirements - Setback, Marginal Distance, Height and Permissible FSI** -> `chapter-06-general-building-requirements---setback-marginal-d.md`
- **Chapter 7: Higher FSI for Certain Uses** -> `chapter-07-higher-fsi-for-certain-uses.md`
- **Chapter 8: Parking, Loading and Unloading Spaces** -> `chapter-08-parking-loading-and-unloading-spaces.md`
- **Chapter 9: Requirements of Part of Building** -> `chapter-09-requirements-of-part-of-building.md`
- **Chapter 10: City Specific Regulations** -> `chapter-10-city-specific-regulations.md`
- **Chapter 11: Acquisition and Development of Reserved Sites in Development Plans** -> `chapter-11-acquisition-and-development-of-reserved-sites-in-d.md`
- **Chapter 12: Structural Safety, Water Supply, Drainage, Sanitary Requirements, Outdoor Display and Other Services** -> `chapter-12-structural-safety-water-supply-drainage-sanitary-r.md`
- **Chapter 13: Special Provisions for Certain Buildings** -> `chapter-13-special-provisions-for-certain-buildings.md`
- **Chapter 14: Special Schemes** -> `chapter-14-special-schemes.md`
- **Chapter 15: Regulations for Special Activities and Plans** -> `chapter-15-regulations-for-special-activities-and-plans.md`