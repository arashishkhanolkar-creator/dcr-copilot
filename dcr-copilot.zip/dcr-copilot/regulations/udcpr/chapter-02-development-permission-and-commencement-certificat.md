# Chapter 2: Development Permission and Commencement Certificate

CHAPTER - 2
DEVELOPMENT PERMISSION AND COMMENCEMENT CERTIFICATE
2.1 PERMISSION FROM THE PLANNING AUTHORITY IS MANDATORY
2.1.1 Necessity of Obtaining Permission: No person shall carry out any development work including
development of land by laying out into suitable plots or amalgamation of plots or development of
any land as group housing scheme or to erect, re-erect or make alterations or demolish any
building or cause the same to be done without first obtaining a separate building permit /
development permission / commencement certificate for each such development work/ building
from the Authority. As stipulated in section 18/46 of the Maharashtra Regional and Town
Planning Act, 1966, no such permission shall be in contravention of the Regional Plan,
Development Plan proposals as the case may be.
2.1.2 Permission Not Necessary - No such permission shall be necessary for :-
i) carrying out of works in compliance with any order or direction made by any Authority
under any law for the time being in force.
ii) carrying out of works by any Authority in exercise of its powers under any law for the time
being in force.
iii) the excavation (including excavation of wells) made in the ordinary course of agricultural
operation.
iv) the construction of a road intended to give access to land solely for agricultural purpose.
v) normal use of land which has been used temporarily for other purposes like marriage
pandals or for festive occasions etc. on private land;
vi) provision of safety grills to window/ventilator,
vii) distribution / receiving substation of the electric supply company.
viii) installation of solar panels having base of solar panel at height upto 1.8m. from terrace,
ensuring structural stability from the Licensed Structural Engineer.
ix) providing internal lightweight partitions / cabins in the commercial building/ establishment
with certificate of structural stability from the Licensed Structural Engineer.
x) temporary structures for godowns/storage of construction materials within the site.
xi) temporary site offices, sample flats and watchman chowkys within the site only during the
phase of construction of the main building.
xii) temporary structures for storage of machinery before installation for factories in industrial
lands within the site.
xiii) labour camps for construction sites, provided adequate water supply and sanitation
facilities are provided and safety is ensured;
xiv) construction of temporary sets for film / TV serial / advertisement shooting and like
activities for a period not more than one year, subject to intimation to the authority.
xv) building on plot area upto 150 sq.mt. (low risk category) and on plot area more than
150sq.mts. upto 300 sq.mt.(moderate risk category) subject to compliance as per
APPENDIX K.
xvi) (1)Construction upto 8 rooms for Agro Tourism Centre and allied activities as per Tourism
Policy - 2016 in Agricultural Zone, subject to compliance as per Appendix-K-2
(1)
Inserted vide Government Resolution No. CR 04/022, dt.02nd June, 2022.
2.1.3 Development undertaken on behalf of Government
As per the provisions of Section 58 of the Maharashtra Regional and Town Planning Act, 1966
the office in-charge of the Government Department shall inform in writing to the Authority of the
intention to carry out its purpose along with details of such development or construction as
specified below and as certified by the Government Architect/Architect/Technical personnel:-
i) An official letter by the authorized officer of Government Department addressed to the
Authority, giving full particulars of the development work or any operational construction.
ii) Ownership document and measurement plan issued by the Competent Authority of Land
Records Department.
iii) Development / building plans conforming to the provisions of Development Plan / Regional
Plan and these Regulations for the proposed development work to the scale specified in
these Regulations.
iv) The proposals of the Development Plan or Town Planning Scheme or Regional Plan
affecting the land.
v) A Site Plan (of required copies) of the area proposed to be developed to the scale.
vi) Detailed plan (of required copies) showing the plan, sections and elevations of the proposed
development work to the scale, including existing building specifying either to be retained
or to be demolished.
2.1.4 Operational Constructions
No permission shall be necessary for operational construction of the Government or Government
undertaking, whether of temporary or permanent nature, which is necessary for the operation,
maintenance, development or execution of any of the following services :
a) Railways;
b) National Highway;
c) National Waterway;
d) Airway and Aerodromes and Major Ports;
e) Posts and Telegraphs, Telephones, Wireless, Broadcasting and other like forms of
Communication excluding Mobile Towers;
f) Regional grids, towers, gantries, switchyards, control room, relay room for transmission,
distribution, etc. of electricity;
g) Defence Authorities;
h) Any other essential public service as may be notified by the State/ Central Government;
i) The following constructions for operational purposes of new railway lines or tracks by the
Metro Rail Administration (MRA) / Project Implementing Agency designated by the
Government for the Metro rail and Mono rail / light Rail Transit (LRT) Project.
"Operation Control Centre, Playback Training Room. Administration Building, Stabling
Yards, Maintenance Workshop and Training Centre, Auto Car Wash Plant and Auto Wash
Plant, Auxiliary Rail Vehicle Building, Under Floor Wheel Lathe and Blow Down Plant,
Cooling Tower, Generator Area, Auxiliary Sub-station, Traction Sub-station, Transformer
Area, Water Treatment Plant, Waste Water Treatment Plant, Deport Control Centre, sump
Area, Parking, Check Post, Loading and unloading areas, Fouling Points, DG set Rooms,
Metro and Mono stations (underground and elevated), Viaduct and tunnel, Ventilation
Shaft, Entry/ Exit Blocks, Passages, Underground passage to Station box, Lifts, Staircases,
Escalators, Transit accommodation / Guest rooms, Metro Stations/ Depots on property
owned by it in all Use Zones, Air Handling Unit, Fire staircase, Fire lift and fire passages,
Refuge area, thereto."
j) Facilities & services such as Roads, Water Supply, Sewerage, Storm Water Disposal and
any other essential public services carried out by State/ Central Government or its
undertakings / Bodies or the Local Bodies including: -
(a) maintenance or improvement of highway, road or public street, being works carried
out on land within the boundaries of such highway, road or public street; or
(b) inspecting, repairing or renewing any drains, sewers mains, pipes including gas
pipes, telephone and electric cables, or other apparatus including the breaking open
of any street, or other land for the purpose.
Provided that the concerned authority shall inform the Planning Authority in writing at the
earliest and pay the necessary restoration charges to the Planning Authority within a month. The
restoration charges shall not be more than the expenditure to be incurred by the Authority to
restore the road etc. along with supervision charges, if any.
All such constructions shall, however, conform to the prescribed requirements for the provision
of essential services, water supply connections, drains, etc. to the satisfaction of the Authority.
2.1.5 Constructions Not Covered under the Operational Constructions
The following constructions of the Government Departments do not come under the purview of
operational construction for the purpose of exemption. In such cases intimation to the authority as
mentioned in above regulation shall be necessary.
a) New residential building (other than gate lodges, quarters for limited essential operational
staff and the like), roads and drains in railway colonies, hospitals, clubs, institutes and
schools in case of railways;
b) A new building, new construction or new installation or any extension thereof, in case of
any other services other than those mentioned in these regulations.
2.1.6 Temporary Constructions
Permission shall be necessary for carrying out temporary construction. The Authority may grant
permission for temporary construction for a period not exceeding six months at a time and in the
aggregate not exceeding a period of one year. Such permission may be given by him for the
construction of the following, viz.:-
(i) Structures for protection from the rain or covering of the terraces during monsoon only.
(ii) Pandals for fairs, ceremonies, religious functions, etc. on public land.
(iii) Structures of exhibitions/ circuses etc.
(iv) Structures for ancillary works for quarrying operations in conforming zones.
(v) Government milk booths, telephone booths, MAFFCO stall and ATM Centres.
(vi) Transit accommodation for persons to be rehabilitated in a new construction.
(vii) Structures for educational and medical facilities within the site of the proposed building
during the phase of planning and constructing the said permanent buildings.
(viii) Ready mix concrete plant.
Provided that, necessary documents along with necessary scrutiny fees shall be submitted by the
applicant along with the application for temporary construction.
Provided that, temporary constructions for structures etc. mentioned at (vi), (vii) and (viii) may
be permitted to be continued temporarily by the Authority, but in any case not beyond
completion of construction of the main structure or building and that, structure in (iv) and (v)
may be continued on annual renewal basis by the Authority beyond a period of one year.
Provided further that approval of the Chief Fire Officer of the authority shall be obtained,
wherever necessary.
2.1.7 Repairs to Building
The permission shall not be required for the following types of repairs to existing authorised
building, which do not amount to additions or alternations. Only intimation to the Authority by
the owner alongwith the certificate of licensed personnel shall be given.
i) Changing of doors and windows in the same position.
ii) Strengthening of existing walls, existing roof in the same position.
iii) Any other items similar to above.
2.2 PROCEDURE FOR OBTAINING DEVELOPMENT PERMISSION/BUILDING
PERMISSION/COMMENCEMENT CERTIFICATE
2.2.1 Notice/ Application
Every person who intends to carry out development or redevelopment, erect or re-erect or make
alterations in any place in a building or demolish any building, shall give notice/ application in
writing, through registered Architect, Town Planner or Licensed Engineer / Supervisor, to the
Authority of his said intention in the prescribed form (See Appendix A1 or A2). It will be
mandatory to submit complete information in the form accompanied with Appendix A-1 and A-
2. Such notice shall be accompanied by the payment receipt of required scrutiny fee and any
other fee/ charges prescribed by the Authority from time to time and the plans and statements in
sufficient copies (See Regulation No. 2.2.2), and as per the requirements under Regulation
No.2.2.2 to 2.2.One set of plans shall be retained in the office of the Authority for record after the
issue of permission or refusal. The plans may be submitted in electronic form as may be specified
by the Authority from time to time. The Authority may set a date after which all submissions,
approvals and communication in regard to development permission shall be online.
2.2.2 Information Accompanying Notice/ Application
The Notice/Application shall be accompanied with the ownership title, key (location) plan, site
plan, sub-division layout plan/ building plan, plans for services, specifications and certificate of
supervision etc., as prescribed in these regulations. Ordinarily four copies of plans and statements
shall be made available along with the notice; however, the number of such copies required shall
be as decided by the Authority.
2.2.3 (#) Ownership title and area
Every application for development permission and commencement certificate shall be
accompanied by the following documents for verifying the ownership and area etc. of the land -
i) Latest7/12 extracts or property register card of a date not earlier than six months prior to the
date of submission of development proposal, power of attorney, wherever applicable or
attested copy of lease deed of the concerned lessor authority, enabling ownership of the
document. In case of Ulhasnagar, conveyance deed and/ or sanad issued by the Revenue
Authority may also be considered.
(#)
Clarification issued vide letter - CR 42/21 dt, 14th June, 2021.
ii) Original measurement plan/city survey sheet of the land or lands under development
proposal issued by Land Record Department.
(1) Provided that, where City Survey of the whole gaothan area is not done by the City
Survey Department, in that case the measurement plan authenticated by the Architect
having signatures of adjacent plot / land holders may be acceptable.
iii) Statement of area of the holding by triangulation method/ CADD (Computer Aided Design
and Drafting Software) from the qualified licensed technical personnel or architect with an
affidavit from the owner in regard to the area in the form prescribed by the Authority.
iv) Any other document prescribed by the Authority.
v) In case of revised permission, wherever third party interest is created by way of registered
agreement to sale or lease etc. of the apartment, consent of such interested party/persons as
specified under RERA Act shall be submitted.
vi) A self-attested copy of sub-division/ amalgamation/ layout of land approved by the
concerned authority, if any.
vii) In the case of land leased by the Government or local authorities, no objection certificate of
Government or such authorities shall be obtained if there is deviation from lease conditions
and shall be attached to the application for development permission in respect of such land.
Such no objection certificate shall also be necessary, where, development proposal
proposes to utilise FSI more than mentioned in the lease deed.
2.2.4 Key Plan or location plan
The key plan drawn to a scale of not less than 1:4000 shall be submitted along with the
application for a building permit and Commencement Certificate showing the boundary locations
of the site with respect to neighbourhood landmarks or features within the radius of 200 meters
from the site whichever is more.
2.2.5 (a) Sub-division /layout plan
In the case of development of land, the notice shall be accompanied by the sub-division/
layout plan which shall be drawn to a scale of not less than 1:500, however, for layout
having areas 4.0 ha. and above, the plan shall be drawn at a scale of not less than 1:1000,
containing the following:-
i) Scale including a graphical scale used and north point;
ii) The location within the land of all proposed and existing roads with their existing/
proposed widths and all the proposals of the Development Plan/ Town Planning
Scheme, if any;
iii) Dimension of plots;
iv) The location of drains, sewers, public facilities and services, electrical lines, Natural
water courses, water bodies and streams etc.;
v) Table indicating size, area and use of all plots in the sub-division / layout plan;
vi) The statement indicating the total area of the site, area utilized under roads,
recreational open spaces, playground, amenity space, and development plan
reservation/ roads, schools, shopping and other public places along with their
percentage with reference to the total area of the site proposed to be sub-divided/ laid
out;
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
vii) In case of plots which are sub-divided in built-up areas in addition to the above, the
means of access to each sub divided plot from existing streets.
viii) Contour plan of site, wherever necessary.
(b) Amalgamation Plan
Where two or more plots/ holdings of same or different owners are to be amalgamated, an
amalgamation plan showing such amalgamation drawn to a scale of not less than 1:500
shall accompany the application. Instead of submitting a separate plan, such amalgamation
may be allowed to be shown on building / layout-plan itself.
2.2.6 Site Plan
The site plan shall be submitted with an application for building permission drawn to a scale of
1:500 or more as may be decided by the Authority. This plan shall be based on the measurement
plan duly authenticated by the appropriate officer of the Department of Land Records. This plan
shall have the following details:-
i) Boundaries of the site and of any contiguous land belonging to the neighbouring owners;
ii) Position of the site in relation to neighbouring streets;
iii) Name of the street, if any, from which the building is proposed to derive access;
iv) All existing buildings contained in the site with their names (where the buildings are given
names) and their property numbers;
v) Position of the building and of other buildings, if any, which the applicant intends to erect,
upon his contiguous land referred to in (i) above;
vi) Boundaries of the site and, in a case where the site has been partitioned, boundaries of the
portions owned by others;
vii) All adjacent streets, buildings (with number of storey and height) and premises within a
distance of 12 m. of the work site and of the contiguous land (if any) referred to in (i). If
there is no street within a distance of 12 m. of the site, the nearest existing street with its
name;
viii) Means of access from the street to the building and to all other buildings (if any) which the
applicant intends to erect upon;
ix) Space to be left around the building to secure free circulation of air, admission of light and
access;
x) The width of the street (if any) in front and the street (if any) at the side or near of the
building, including proposed roads;
xi) The direction of north line relative to the plan of the building;
xii) Any existing physical features, such as wells, tanks, drains, pipe lines, high tension line,
railway line, trees, etc.;
xiii) Overhead electric supply lines, if any, including space for electrical transformer / substation
according to these Regulations or as per the requirements of the electric distribution
company;
xiv) Any water course existing on site or adjacent to site;
xv) Existing alignments of water supply and drainage lines;
xvi) Such other particulars as may be prescribed by the Authority.
2.2.7 Building plan
The plans of the buildings and elevation and section to be sent with the application
accompanying the notice shall be drawn to a scale of 1:100. The building plan shall:
i) Include floor plans of all floors together with the built up area clearly indicating the sizes
of rooms and the position and width of staircase, ramps and other exit ways, lift wells, lift
machine room and lift pit details, meter room and electric sub-station and also include
ground floor plan as well as basement plan and shall indicate the details of parking space
and loading and unloading spaces provided around and within the building as also the
access ways and the appurtenant open spaces with projections in dotted lines, distance from
any building existing on the plot in figured dimensions along with accessory building.
These plans will also contain the details of FSI calculations;
ii) Show the statement of carpet area of every apartment or any unit along with areas of
balconies and double height terraces, if any, attached to the said unit;
iii) Show the use or occupancy of all parts of the buildings;
iv) Show exact location of essential services, such as water closet (W.C.), bath, sink and the
like;
v) Include sectional drawings showing clearly the thickness of basement wall, wall
construction, size and spacing of framing members, floors, slabs, roof slabs with the
materials. The section shall indicate the height of the building, rooms and parapet, drainage
and slope of the roof. At least one section should be taken through the staircase.
vi) Show relative levels of street.
vii) Give dimensions of the projected portion beyond the permissible building line
viii) Include terrace plan indicating the drainage and the slope of the roof.
ix) Give indication of the north line relative to the plan.
x) Details of parking spaces provided.
xi) Give dimensions and details of doors, windows and ventilators.
xii) Give the area statement with detailed calculation chart of each floor of the building or area
as per periphery line of construction (P-line) excluding ducts and voids.
xiii) Show the pump rooms, rain water harvesting system, sewage treatment plant, if any;
xiv) Certificate of Structural Engineer about structural and earthquake safety in case of building
above G+2 or stilt +2structure.
xv) Give such other particulars as may be required to explain the proposal clearly as prescribed
by the Authority.
# 2.2.8 Building plans for Special Buildings
The following additional information shall be furnished / indicated in the Building Plans in
addition to the items (i) to (xv) of Regulation No. 2.2.7;
a) Access to fire appliances/vehicles with details of vehicular turning circle and clear
motorable access way around the building of minimum 6 m. width;
b) Size(width) of main and alternate staircases, wherever necessary, along with balcony
approach, corridor, ventilated lobby approach;
c) Location and details of lift enclosures;
(#)
Clarification issued vide Order - CR 236/18 (Part 2), dt. 23rd December, 2021
d) Location and size of fire lift;
e) Smoke stop lobby/door, where provided;
f) Refuge chutes, refuse chamber, service duct, etc.;
g) Vehicular parking spaces;
h) Refuge area, if any;
i) Details of Building Services:-Air-conditioning system with position of fire dampers,
mechanical ventilation system, electrical services, boilers, gas pipes etc.,
j) Details of exits including provision of ramps, etc. for hospitals and buildings requiring
special fire protection measures;
k) Location of generator, transformer and switch gear room;
l) Smoke exhauster system, if any;
m) Details of fire alarm system network;
n) Location of centralized control, connecting all fire alarm systems, built in fire protection
arrangements and public address system etc.;
o) Location and dimensions of static water storage tank and pump room along with fire
service inlets for mobile pump and water storage tank;
p) Location and details of fixed fire protection installations such as sprinklers, wet risers, hose
reels, drenchers, C02 installation etc.;
q) Location and details of first aid, fire-fighting equipment‘s /installations;
r) Certificate of structural engineer about structural and earthquake safety;
s) Clearance certificate from the Chief Fire Officer of the Authority or Director of Fire
services, as the case may be.
2.2.9 Service plan - Plans, elevations and sections of water / grey-water supply, sewage disposal
system and details of building services, where required by the Authority, shall be made available
on a scale not less than 1:100 and for layouts 1:1000.
2.2.10 Supervision
The notice shall be further accompanied by a certificate of supervision in the prescribed form as
given in Appendix B, by Architect / Licensed Engineer / Supervisor /Town Planner, as the case
may be. In the event of the said licensed technical personnel ceasing to be employed for the
development work, further development work shall stand suspended till a new licensed technical
person is appointed.
#2.2.11 Clearance from other Departments
In case of development / construction of buildings requiring clearance from the authorities like
Civil Aviation Authority, Railways, Directorate of Industries, Maharashtra Pollution Control
Board, District Magistrate, Inspectorate of Boilers and Smoke Nuisance, Defence Department,
Maharashtra Coastal Zone Management Authority, Archaeological Department etc., the relevant
no objection certificates from these authorities, whichever applicable, shall also accompany the
application, where such information is not received by the authority as mentioned in Regulation
No. 3.1.13.
In case of building identified in Regulation No.1.3 (93) (xiv), the building scheme shall also be
cleared by the Fire Officer of the authority or in absence of such officer, by Director of
Maharashtra Fire Services or an officer authorised by him.
(#)
Clarification issued vide letter - CR 42/21/UD 12, dt. 14th June, 2021.
2.2.12 (#) Building / Layout Permission Scrutiny Fee
The notice shall be accompanied by a self-attested copy of receipt of payment of building/ layout
permission Scrutiny Fee. These fees shall be as mentioned below and shall be subject to
Government orders, if any. Provided that, such fees shall not be applicable for the development
proposals implemented by Government / Government Departments or Public Authorities of State
or Central Government.
Sr. No. Type of Authority Scrutiny fee for Scrutiny fee for
plotted Layout Building
Constructions.
1 For Pune, Pimpri-Chinchwad, Rs. 2,000/- Rs. 5/-
Nagpur, Nashik, Municipal
per 0.4 hector or part Per Sq.m. of built-up
Corporations in MMR and
thereof . area.
Metropolitan Authorities area.
(2)Special Planning Authorities,
NTDA, ADA within these areas.
2 Remaining all Municipal Rs. 1,500/- Rs. 4/-
Corporations area, A Class
per 0.4 hector or part Per Sq.m. of built-up
Municipal Councils and Mumbai
thereof. area.
Metropolitan Regional Plan area.
3 B and C Class Municipal Councils, Rs. 500/- Rs. 2/-
Nagar Panchayats, Non Municipal
per 0.4 hector or part Per Sq.m. of built-up
Council D.P. and Regional Plan
thereof. area.
areas.
Note -
i) No scrutiny fee shall be levied if the proposal is received after compliance of the
objections raised by the authority.
ii) In case of revised permission, the scrutiny fee shall be applicable.
iii) In case of revised permission, where additional development work is proposed without
disturbing the already approved development work, then the scrutiny fee shall be levied for
additional development work.
iv) The charges mentioned above may be revised by the Authority with prior approval of the
Government.
v) The charges mentioned above shall also be subject to Government orders from time to
time.
2.2.13 (#) Development Charges
Development charges as required under Section 124 A (1) to 124 L of the Maharashtra Regional
and Town Planning Act, 1966 shall be deposited with the Authority before issue of development
permission/commencement certificate. Such charges shall be calculated for area of each land
parcel included in the development permission considering the rates in ASR and provisions
mentioned in the said Act.
(#)
Clarification issued vide Order No. CR 236/18 dt. 23rd December, 2021.
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
(2) Inserted vide Notification No. CR 236/18/(Part 6), dt. 12th October, 2022.
Provided that,
i) in case of revised permission, where no development is carried out in pursuance of the
earlier permission and permission is lapsed, amount of difference of development charges,
if any, shall be levied and recovered.
ii) in case of revised permission, where development is commenced in pursuance of earlier
permission, development charges shall be levied on the land and built-up area, over and
above the area covered in the earlier permission.
iii) no such charges shall be levied for renewal of permission.
iv) in case where minor amendment to the plotted layout approved prior to 10/8/1992 are
proposed or where development charge for land development has already been collected in
past, no development charge should be levied for such amendment of plotted layout
provided no construction was proposed in the said layout i.e. only plotted layout was
approved.
v) construction of compound wall is meant for protection of property and as such no
development charge shall be levied for construction of compound wall or for repairs of
compound wall.
vi) no development charge shall be recovered in respect of maintenance work, internal repairs
of buildings, or for strengthening the existing building provided such works do not involve
consumption of additional floor space.
vii) for any reconstruction work, development charge shall be levied in full which involves
demolition of existing building and reconstruction of new building.
viii) in case a cooperative housing society is authorised by Maharashtra Housing and Area
Development Authority or Bombay Housing and Area Development Board to undertake
reconstruction of old/ dilapidated building (which work would otherwise, have been
undertaken by MHADA), no development charge shall be recovered from that co-operative
housing society, provided the FSI does not exceed the existing or permissible FSI
whichever is lower. Provided further that it accommodates existing tenants only. Further in
reconstruction involving consumption of additional FSI and accommodation of additional
members other than existing tenants, proportionate development charges shall be
recovered.
ix) In case no development work is carried out in pursuance of permission and permission is
lapsed or permission is cancelled on the request of the owner, the development charges
paid, shall be adjusted in permission that may be granted in future.
x) (1) Where development permission is granted and development charges are already collected
by any Authority in their jurisdiction and thereafter such area is included in the jurisdiction
of other Authority in such cases, the provisions mentioned in Sr.No.(i) to (ix) above shall
be applicable mutatis and mutandis, as the case may be.
# 2.2.14 Premium Charges and Fire Infrastructure Charges.
i) Premium Charges - Premium charges as may be required to be recovered under these
regulations shall be paid to the Authority before issue of development permission/
commencement certificate. The 50% Premium share of the Government shall be deposited
by the Authority in a specified head of account of the Government. The amount of
premium collected by the Authority shall be kept in a separate account and it shall be
utilized for development of civic amenities and infrastructure.
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
(#)
Clarifications issued vide letter - CR 42/21/UD 12, dt. 14th June, 2021 & CR 236/18 (Part 2), dt. 23rd December, 2021.
In case of Regional Plan area, 100% premium charges shall be paid to Government through the
District offices of Town Planning and Valuation Department.
The aforesaid premium charges except the premium leviable under Chapter 5 of these regulations
shall be allowed to be paid in the instalments with interest @ 8.5% per annum in the following
manner and subject to following conditions
A) Option - 1
a) Building below 70 m. height.
Initial At the end of Month with interest
Payment 12th 24th 36th 48th
1st Instalment 2nd Instalment 3rd Instalment 4th Instalment 5th Instalment
10% 22.5% 22.5% 22.5% 22.5%
b) Building having height of 70m. and above.
Initial At the end of Month with interest
Payment 12th 24th 36th 48th 60th
1st 2nd 3rd 4th 5th 6th
Instalment Instalment Instalment Instalment Instalment Instalment
10% 18% 18% 18% 18% 18%
B) Option - 2
The instalment of 20% shall be paid at the time of granting development permission /
commencement certificate and remaining 80% amount at the time of occupation certificate.
The remaining amount shall be liable for interest @ 8.5% per annum.
Notes :
i) The instalment shall be granted with the interest at the rate of 8.5% p.a. on reducing
outstanding balance premium.
ii) The owner / developer shall deposit post-dated cheques for instalment amount with an
interest due drawn on scheduled bank, as per the scheduled date of payment.
iii) Occupation Certificate shall be granted in proportion to the payments made.
iv) The first instalment shall not be less than 50 lakhs in case of A, B C, Class Municipal
Corporations and 25 lakhs in case of other areas. In such case, the remaining amount shall
be apportioned in remaining instalments.
v) The aforesaid option 1 & option 2 shall be applicable for the period of 2 years. (1) In addition
to this extension of further 2 years (i.e. upto 2.12.2024) shall be applicable, considering the
lock-down measures and guidelines issued by the Government w.r.t. Pandemic situation.
ii) (#) Fire Infrastructure Charges - These charges shall be decided by the Government from
time to time
2.2.15 Structural Stability Certificate
In case of special buildings, the application shall be accompanied by structural stability
certificate signed by the licensed Structural Engineer to the effect that the building is safe against
various loads, forces and effects including due to natural disasters, such as, earthquake,
landslides, cyclones, floods, etc. as per Part 11 ‗Structural Design‘ and other relevant Codes.
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
(#)
Clarification issued vide Order No. CR 103/2021, dt, 2nd August, 2021.
2.2.16 Signing the Plan
All the plans shall be duly signed by the owner, co-owner, if any, and the Architect or Town
Planner or Licensed Engineer / Supervisor and shall indicate his name, address and Registration /
license number (allotted by the Authority).
2.2.17 Size of Drawing sheets
The size of drawing sheets shall be any of those specified in Table 2A.
Table 2A - Drawing Sheet Sizes
Sr. No. Designation Trimmed Size, mm
1. A0 841 X 1189
2. A1 594 X 841
3. A2 420 X 594
4. A3 297 X 420
5. A4 210 X 297
Note: If necessary, submission of plans on sheets bigger than A0 size is also permissible.
All dimensions shall be indicated only in metric units.
2.2.18 Colouring Notations for Plans
The plan shall be coloured as specified in Table No.2Bgiven below and prints of plan shall be on
one side of the paper only.
Table No.2B - Colouring Notations for Plans
Sr. Item Site Plan Building Plan
No.
White Blue Ammonia White Blue Ammonia
Plan Print Print Plan Print Print
1 Plot lines Thick Thick Thick Black Thick Thick Thick Black
Black Black Black Black
2 Existing street Green Green Green ..... ..... .....
3 Future street, Green Green Green ..... ..... .....
if any dotted dotted dotted
4 Permissible Thick Thick Thick ..... ..... .....
building lines dotted dotted dotted black
black black
6 Existing work Black White Blue Black White Blue
(Outline)
7 Work Yellow Yellow Yellow Yellow Yellow Yellow
proposed to Hatched Hatched Hatched Hatched Hatched Hatched
be demolished
8 Proposed Red filled Red Red Red Red Red
work in
9 Drainage & Red dotted Red Red dotted Red Red Red dotted
Sewerage dotted dotted dotted
work
10 Water supply Black Black Black Black Black Black
work dotted thin dotted dotted thin dotted dotted dotted thin
thin thin thin
11 Deviations Red Red Red hatched Red Red Red hatched
hatched hatched hatched hatched
Note : For land development/Sub-Division/layout/building plan, suitable colouring notations
shall be used which shall be indexed.
2.2.19 Qualification and Competence of the Architect/Licensed Engineer/Structural
Engineer/Town Planner/Supervisor
Architect / Engineer / Town Planner / Supervisor referred to in Regulation No.2.2.16 shall be
registered / licensed by the Authority as competent to plan and carry out various works as given
in Appendix "C". The qualification and procedure for registration and licensing of the Engineer /
Structural Engineer / Town Planner / Supervisor shall be as given in Appendix-"C". An Architect
registered with the Council of Architecture shall not be required to register with the Authority.
2.3 DISCRETIONARY POWERS - INTERPRETATION
In conformity with the intent and spirit of these Regulations, the Authority may by order in
writing-
i) Decide on matters where it is observed that there is an error in any order, requirement
decision, and determination of interpretation made by him or by an Officer authorized by
him in the application of these Regulations.
ii) Decide the extent of the proposal of Development Plan / Regional plan with respect to
S.No. / Gut No. / CTS No. / Block No. /Barrack No. / Unit No., where boundaries shown
on Development Plan / Regional plan varies with the boundaries as per revenue record /
measurement plan / City Survey sheets etc.
iii) Determine and establish the location of zonal boundaries in cases of doubt or controversy;
iv) Decide the alignment of Development Plan road / Regional plan road where the street
layout actually on the ground varies from the street layout as shown on the Development
Plan / Regional plan;
v) Correct the alignment of Blue and Red flood line on Development Plan / Regional plan
where it varies with the said lines given by the Irrigation Department or any other Govt.
institutions dealing with the subject, from time to time;
(#)vi) Modify the limit of a zone where the boundary line of the zone divides a plot. In such
cases, the zone covering area more than 50% shall be considered;
vii) Authorize the erection of a building or use of premises for a public service undertaking for
public utility propose only, where he finds such an authorization to be reasonably necessary
for the public convenience and welfare even if it is not permitted in any Land Use
Classification.
viii) Interpret the provisions of these Regulations where there is clerical, grammatical mistake, if
any.
(#)
Directives issued by Govt. u/s 154 vide Order - CR. No. 236/18(Part 2), dt.26/09/2022. & Clarifications issued vide Order
No. CR 236/18 (Part 2) & Order No. CR 128/22, dt.26/09/2022.
2.4 DISCRETIONARY POWERS - RELAXATIONS IN SPECIFIC CASES
In specific cases where clearly demonstrable hardship is caused, the Authority may permit any of
the dimensions/provisions prescribed by these regulations to be modified provided the relaxation
sought does not violate the health safety, fire safety, structural safety, and public safety of the
inhabitants of the buildings and the neighbourhood. No relaxation in the setback required from
the road boundary or FSI or parking requirements shall be granted under any circumstances,
unless otherwise specified in these Regulations.
While granting permission under these regulations, conditions / restrictions / limitations may be
imposed on size, cost or duration of the structure, abrogation of claim of compensation, payment
of deposit and its forfeiture for non-compliance and payment of premium, as may be prescribed
by the Authority, if required.
In areas of Municipal Councils and Regional plan, such relaxation shall be granted in
consultation with concerned Divisional Joint Director of Town Planning.
Notwithstanding anything contained in any Government Order, Government Resolution,
Government Notification, etc. issued from time to time regarding powers of relaxation in
Development Control and Promotional regulations, the above provision shall prevail.
2.5 (#) DRAFTING ERROR
Drafting errors in Development/Regional Plan which are required to be corrected as per actual
situation on site or as per the city survey record or sanctioned layout etc. may be corrected by the
Authority, after due verification, in case of Municipal Councils Regional Plan areas, this shall be
done after consultation with the Divisional Joint Director of Town Planning.
2.6 GRANT OR REFUSAL OF PERMISSION
2.6.1 General
i) After receipt of the notice/application as mentioned in Regulation No.2.2.1 above, the
Authority may either sanction or refuse the plans or may sanction them with such
modifications or directions as it may deem necessary after having recovered the necessary
charges/fees and there upon shall communicate its decision to the person giving the notice
in the prescribed form given in Appendix D1/D2/D3 and E1/E2, as the case may be.
ii) In the case of special buildings, the building scheme shall also be subject to the scrutiny of
the Chief Fire Officer of the Local/ Planning Authority or Director of Fire Services, as the
case may be, and the sanction development permission shall be issued by the Authority
after the clearance from him.
iii) In the case of land subdivision or plotted layout, tentative layout shall be recommended for
demarcation at first instance. After having demarcated the layout, the owner shall submit
the layout as measured by the Land Records Department for final approval to the Authority.
The Authority shall examine and grant final approval to the measured layout if it conforms
to the regulations and is broadly in accordance with the tentative layout without any
departures of substantial nature. This shall also be mandatory for Group Housing Schemes
where roads in the adjoining layouts/ Development Plan roads / Regional Plan roads are to
be coordinated and/or amenity space/s are to be earmarked.
iv) After the plan has been scrutinized and objections have been pointed out, the owner giving
notice shall modify the plan, comply with the objections raised and resubmit it. The prints
(#)
Clarification issued vide Letter No. CR 18/21, dt. 23rd December, 2021.
of plans submitted for final approval, shall not contain superimposed corrections. The
authority shall grant or refuse the commencement certificate/ building permit within 60
days from the date of resubmission. No new objections may generally be raised when they
are resubmitted after compliance of earlier objections, except in circumstances to be quoted
for additional compliances.
v) After the development permission is granted by the Authority, it shall be displayed
alongwith the plans on the website of the Authority, wherever such website is available.
2.6.2 Deemed Permission
If within sixty (60) days of receipt of the notice, along with necessary permission fees under the
regulations, the Authority fails to intimate in writing to the person, who has given the notice; of
its refusal or sanction or sanction with such modifications or directions, the notice with its plan
and statements shall be deemed to have been sanctioned, provided nothing shall be construed to
authorize any person to do anything on the site of the work in contravention or against the terms
of lease or titles of the land.
Provided that, the development proposal, for which the permission was applied, is strictly in
conformity with the requirements of these regulations or regulations framed in this behalf under
any law for the time being in force and the same in no way violates either provisions of any draft
or final Development/ Regional Plan / Planning Proposal or proposals published by means of
notice, submitted for sanction under the Act. Provided further that any development carried out in
pursuance of such deemed permission which is in contravention of the above provisions, shall be
deemed to be an unauthorized development for purposes of Section 52 to 57 of the Maharashtra
Regional and Town Planning Act, 1966 and other relevant Acts.
Provided further that, upon receipt of intimation of any claim for deemed permission the
Authority shall within fifteen days from the date of receipt of such claim, communicate its
remarks, if any, regarding deemed permission to the applicant, failing which, the proposal shall
be approved and commencement certificate along with one set of duly approved plans for
proposed development shall be issued to the applicant within fifteen days thereafter.
Provided further that, necessary explanation shall be called from the concerned officers of the
Planning Authority for not processing and disposing of the proposal within 60 days and
necessary action as per relevant provisions of Act / Rules shall be initiated against the defaulter
officer.
2.6.3 Approval of Building Permission on Risk Based Classification
Notwithstanding Anything contained in this UDCPR, the approval to the Low or Moderate Risk
category of constructions shall be governed as per the procedure given in Appendix-K.
2.6.4 Display of Sanctioned Permissions on Authority's Web-Site.
After sanction of development permission, the authority shall make available all plans relating to
such permission on its web-site, if available. Such documents shall be kept on web-site till one
month from the date of issuance of last occupation certificate.
2.7 COMMENCEMENT OF WORK
2.7.1 (#) Commencement
The commencement certificate/development permission, as approved, shall remain valid for 4
years in the aggregate but shall have to be renewed every year from the date of its issue. The
application for renewal shall be made before expiry of one year if the work is not already
commenced. Such renewal can be done for three consecutive terms of one year after which
(#)
Clarification issued vide Order No. CR 236/18 dt, 23rd December, 2021.
proposals shall have to be submitted to obtain development permission afresh. If application for
renewal is made after expiry of the stipulated period during which commencement certificate is
valid, then the Authority may condone the delay for submission of application for renewal by
charging (1) fees at the rate of 1/3 of amount as per Regulation No. 2.2.12 per year. but in any
case, commencement certificate shall not be renewed beyond 4 years from the date of
commencement certificate/ development permission.
Provided that, no such renewal shall be necessary if the work is commenced within the period of
valid permission and such permission shall remain valid till the work is completed.
For the purpose of this regulation, "Commencement" shall mean as under :-
For a building work including Upto plinth level or where there is no plinth upto upper
additions and alterations level of lower basement or stilt as the case may be.
For bridges and overhead tanks Foundation and work up to the base floor/ underground
construction floor
For underground works/ Foundation and work upto floor of underground floor.
For layout, sub-division and Final demarcation and provision of water bound
amalgamation macadam roads complete.
2.7.2 Development of Land Subdivision/ Group Housing Schemes
In case of land subdivision / group housing schemes, it shall be the responsibility of the owner /
developer to construct all infrastructure including roads with storm water drains, sewer lines,
water supply lines, development of recreational open spaces etc.
In case of land subdivision, these works shall generally be completed within two years and phase
wise building permission shall be granted depending upon the percentage of infrastructure work
completed. The layout plots should be released for construction in stages according to
infrastructure work completed. The condition to that effect shall be incorporated in the
development permission / commencement certificate.
In case of group housing scheme, these works shall be completed before completion of the
project and occupancy certificate shall be granted phase wise as per completion of infrastructure
work.
After handing over roads and infrastructure to the Authority on completion of scheme, the
responsibility of maintenance of such roads and infrastructure shall lie with the Authority.
However, internal roads and infrastructure in the group housing scheme shall be maintained by
the owner / society.
2.8 PROCEDURE DURING CONSTRUCTION
2.8.1 Owner / Developer / Architect / Town Planner / Engineer / Structural Engineer /
Supervisor or any licensed technical person's Responsibilities in their respective domain.
i) Neither granting of the development permission nor the approval of the drawings and
specifications, nor the inspections, made by the Authority during erection of the building
shall, in any way relieve the Owner / Developer /Architect / Town Planner / Engineer /
Structural Engineer / Supervisor or any licensed technical person, of such building/
development from full responsibility for carrying out the work in accordance with the
requirements of these regulations and safety norms as prescribed by the bureau of Indian
Standards.
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
ii) Every owner / developer shall:
a) permit the Authority or his representative to enter the building or premises for which
the permission has been granted at any reasonable time for the purpose of enforcing
these Regulations.
b) submit the certificate for execution of work as per structural safety requirements and
give written notice to the Authority regarding completion of work.
c) give written notice to the Authority in case of termination of services of a Technical
professional engaged by him.
2.8.2 Results of Test
Where tests of any materials are made to ensure conformity with the requirements of these
regulations, records of the test data shall be kept available for inspection during the construction
of the building and for such period thereafter as may be required by the Authority.
2.8.3 Display Board
As soon as the development / building permission is obtained, the owner / developer shall install
"Display Board" on conspicuous place on site indicating following details:-
i) Name and address of owner, developer, all concerned licensed persons.
ii) Survey number / city survey number of land under reference.
iii) Order number and date of grant of development / building permission / redevelopment
permission issued by the Authority.
iv) Built up area permitted.
v) RERA registration no.
(1) vi) Software QR Code for the Project generated in online building permission.
Such Display Board shall not be required for individual plot holder's individual building.
2.8.4 Plinth Checking
The owner shall give intimation in the prescribed form in Appendix- F to the Authority after the
completion of work upto plinth level. This shall be certified by Architect / licensed Engineer /
Supervisor with a view to ensure that the work is being carried out in accordance with the
sanctioned plans. After such intimation, the construction work shall be carried out further. The
officers of the Authority, who are empowered to grant development permission and subordinate
officers to him, shall each, inspect about 10% of such plinth certified cases.
2.8.5 Deviation During Construction
If during construction of a building, any deviation of a substantial nature from the sanctioned
plans is intended by way of internal or external additions, sanction of the Authority shall be
necessary. A revised plan showing the deviation shall be submitted and the procedure laid down
for the original plans shall apply to all such amended plans. Any work done in contravention of
the sanctioned plans, without prior approval of the Authority, shall be deemed as un-authorised.
However, any changes made within the internal layout of a residential or commercial unit, which
do not violate FSI or other regulations, shall not be treated as unauthorised. Such changes shall
be incorporated in plan along with completion certificate. Provided that revised permission may
also be granted after completion of work before obtaining full occupancy certificate.
(1) Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
2.9 COMPLETION CERTIFICATE
The owner through his Architect / licensed engineer / town planner / supervisor, as the case may
be, who has supervised the construction, shall furnish a building completion certificate to the
Authority in the form in Appendix-G. This certificate shall be accompanied by three sets of plans
of the completed development, the certificate about the operation of the lift from consultant and
certificate of structural stability, wherever necessary.
In case of special buildings, the Completion Certificate shall also be accompanied with the NOC
from Chief Fire Officer of respective Authority or Director of Fire services, as the case may be.
2.10 OCCUPANCY CERTIFICATE
The Authority after inspection of the work and after satisfying himself that there is no deviation
from the sanctioned plans as mentioned in Regulation No. 2.8.5, issue an occupancy certificate in
the form in Appendix-H or refuse to sanction the occupancy certificate in Appendix-I within 21
days from the date of receipt of the said completion certificate, failing which the work shall be
deemed to have been approved for occupation, provided the construction conforms to the
sanctioned plans. One set of plans, certified by the Authority, shall be returned to the owner
along with the occupancy certificate. Where the occupancy certificate is refused or rejected, the
reasons for refusal or rejection shall be given in intimation of the rejection or the refusal The
applicant may request for Deemed Occupancy Certificate, if eligible, as above. The Authority
shall issue the Deemed Occupancy Certificate within 15 (fifteen) days of the application.
In case of Special buildings, the occupancy certificate shall be issued by the Authority only after
the clearance from the Chief Fire Officer regarding the completion of work from fire protection
point of view.
2.11 PART OCCUPANCY CERTIFICATE
When requested by the holder of the development permission, the Authority may issue a part
occupancy certificate for a building, or part thereof, before completion of the entire work as per
development permission, provided sufficient precautionary measures are taken by the holder of
the development permission to ensure public safety and health of the occupants and users of the
said portion of the building. The part occupancy certificate shall be subject to the owners
indemnifying the Authority in the form in Appendix 'J'.
2.12 INSPECTION
The Authority shall have the power to carry out inspection of the work under the provisions of
the Act, at various stages to ascertain whether the work is proceeding as per the provisions of
regulations and sanctioned plan.
2.13 UNSAFE BUILDINGS
All unsafe buildings shall be considered to constitute danger to public safety and hygiene and
sanitation and shall be restored by repairs or demolished or dealt with as otherwise directed by
the Authority. The relevant provisions of the regulations / Act shall apply for procedure of
actions to be taken by the Authority for unsafe buildings.
2.14 OFFENCES AND PENALTIES
i) Any person who contravenes any of the provisions of these regulations, any requirements
or obligations imposed on him by virtue of the Act or these regulations, shall :-
(a) be guilty of an offence and upon conviction, shall be punished as stipulated in
Section 52 of the Act;
(b) be subject to further suitable actions including demolition of unauthorised works, as
stipulated under Section 53and 54of the Act;
(c) where such person is a Licensed Engineer / Structural Engineer / Town Planner /
Supervisor, be subject to suitable action against him which may include cancellation
of license and debarring him from further practice/ business for a period as may be
decided by the Authority. (1) Thereupon such Licensed Engineer / Structural Engineer
/ Town Planner / Supervisor shall be considered debarred for respective district.
(d) where such person is a registered Architect, be subject to action of the Council of
Architecture as per the provisions of the Architects Act, 1972 based on the report of
the Authority and debarring him from further practice/ business for a period as may
be decided by the Authority.
ii) Any person who neglects any requirements or obligations imposed on him including the
maintenance of fire protection services, appliances and lifts in working order or who
interferes with or obstructs any person in the discharge of his duties shall be guilty of an
offence as specified in Section 36 of the Maharashtra Fire Prevention and Life Safety
Measures Act, 2006 and, upon conviction, shall be subject to penalties and other
consequences spelt out in said Act.
2.15 REVOCATION OF PERMISSION
i) Without prejudice to the powers of revocation conferred by Section 51 of the Act the
Authority may, after giving the opportunity of being heard, revoke any development
permission issued under these regulations where it is noticed by it that there had been any
false statement or any misrepresentation of material fact in the application on the basis of
which the development permission was issued and thereupon the whole work carried out in
pursuance of such permission shall be treated as unauthorised.
ii) In the case of revocation of the permission under sub-regulation (i), no compensation shall
be paid.
-*-*-*-*-*-
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.