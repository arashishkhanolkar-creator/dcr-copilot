# Chapter 15: Regulations for Special Activities and Plans

CHAPTER - 15
REGULATIONS FOR SPECIAL ACTIVITIES / PLANS
15.1 QUARRYING OPERATIONS
With the approval of the, Authority Mining or Quarrying operations may be permitted in
Agriculture Zone on following conditions:
1) The quarrying and mining operations shall be permitted outside CRZ and notified eco-
sensitive zone and heritage precinct but only at specific locations decided by the competent
authority. The development permission shall be granted subject to production of order to
carry out these activities from the revenue authority concerned under the Minor Minerals Act
and NOC of the MPCB.
2) The application for Development Permission of quarrying shall include:
a) Original 7/12 extract along with a location plan at 1:5000 scale of the quarry site and an
area upto 500 meters around the quarry site showing important natural and manmade
features and contours;
b) A site plan at 1:500 scale showing site boundaries, contours, all existing natural and
man-made features such as hills, water courses, trees and other important landscape
features, access roads, building and other structures;
c) Proposed excavation plan and cross sections at 1:500 or larger scale showing proposed
phasing; terracing; stepping; benching slopes; locations of process equipment; diversion
of water courses; impounding lake; storage areas for top soil, waste material, quarried
material; workers housing; landscaping including screen planting, mounding and
measures against visual intrusion etc.
d) A restoration plan including landscaping proposals, phasing and proposal for reuse of
the area after quarrying;
e) A report supplementing the excavation and restoration plans, costs and implementation
programme;
f) Scrutiny fee shall be paid by the owner;
g) Development Charge for the land under quarrying shall be paid by the owner, as per the
provisions of section 124B of the MR & TP Act 1966, at 0.50% of the rates of
developed land mentioned in the A.S.R. of the Registration Dept. of the year in which
permission is granted.
3) No quarrying shall commence until the excavation plan is also approved by the Director of
Geology and Mining, Government of Maharashtra.
4) The Restoration Plan approved by the Planning Authority shall be carried out in consultation
with concerned Conservator of Forest or District Forests Officer, and the Revenue Authority.
5) Natural gradient of slope should be maintained during quarrying operations. Slope of the
foot-wall side (Slope in the direction in which mining does not exist) should be properly
organized by planting adequate trees of suitable species so as to have soil binding vegetation.
6) In the case of murum quarrying, entire weathered soil or murum shall not be excavated
exposing hard rock; instead, a capping of at least half a meter be left so that it can support
vegetation and plantation that be done later on. Similarly, these operations shall not cause
depression below the average ground level.
7) Water course, if any from a higher slope, should be properly diverted out of quarry area so
that minimum water flows into the quarry and is safely channelled out of any nearby human
settlement.
8) During quarrying operations, the water should be sprayed at least once in a day over the
roads at quarry sites and nearby area.
9) Kachha road leading to quarry site shall be invariably sprayed by water during the period
when trucks carry murum. In addition, in order to minimize dust pollution, measurers such
as adoption of hoods at transfer points, vulcanizing of conveyer belt joints, under belt
cleaning devices, apart from installation of dust extrication system for conveyance, shall be
adopted. The kachha road leading to the quarry shall have roadside plantation in order to
arrest the dust pollution.
10) No Quarrying and crushing shall be permitted if a highway or public road having width of
30m. or more, railway line or any human settlement is located within 200m. from the
quarrying site. However, for quarrying with blasting operations, the distance shall be at least
500 m.
11) Residences for labourers and related temporary structures should be constructed at least 500
meters away from the place of blasting as well as from the place of quarrying. Heavy
blasting by use of heavy machinery shall be prohibited
12) The development permission for quarrying shall be granted for period of 1 year and may be
revalidated every year for a maximum period of 3 years. After this fresh permission for
further quarrying will be necessary. In granting such fresh permission, the Authority shall
have regard to the applicant‘s performance in observing the approved excavation and
restoration plans, and in carrying out the quarrying operations in accordance with these
guidelines.
15.2 ERECTION OF MOBILE TOWERS
Erection/ setting up Telecommunication Cell Sites/ Base Stations and installation of the
equipment for Telecommunication network shall be permissible as per the norms of Department
of Telecommunication / Information Technology or concerned Department of the Central/ State
Government.
15.3 PREPRATION OF LOCAL AREA PLAN
A local area plan is a plan for comprehensive development of particular area in city/ town, which
may consist of detail provisions than that of development plan addressing the local requirements
of the area. The Authority may prepare such plan consisting of planning requirement at micro
level, local area specific regulations, urban design etc. The local area plan shall be prepared by
following procedure similar to that of section 33 of the Maharashtra Regional and Town Planning
Act, 1966. After approval to this plan by the State Government, it shall come into force. In the
event of provisions of local area plan not consistent with UDCPR, the provisions of local area
plan shall prevail.
15.4 GUIDELINES FOR STREET DESIGN IN CITY / TOWN.
The authority shall ensure complete design of street i.e. streets shall be designed to cater to the
needs of all users and activities like smooth and convenient vehicular movement, safe and
unhampered pedestrian movement for all age groups, safe and easy movement of differently abled
persons, street furniture etc.
APPENDIX A-1: FORM FOR CONSTRUCTION OF BUILDING OR LAYOUT OF BUILDINGS
/GROUP HOUSING
Application for permission for development under Section 18/44/58/69 of The Maharashtra
Regional and Town Planning Act, 1966 read with any other Act governing the Planning Authority*,
if any.
From _________________ (Name of the owner)
To,
The Authority (Name of the Authority )
Sir,
I intend to carry out the under mentioned development in the site/plot of land, on Plot No………
Revenue S.No.……./ Gat No........./ Khasara No........ / City Survey No…………../ Final Plot No.........
Mauje …………situated at Road/ Street ………… Society ………….in accordance with Section
18/44/58/69 of the Maharashtra Regional and Town Planning Act, 1966 read with Section (*)----------- of
--------- Act.
I forward herewith the following plans and statements (Item i to x), wherever applicable, in
quadruplicate, signed by me (Name in block letters) …………..and the Architect/ Licensed Engineer/
Supervisor (License No………….), who has been engaged by me and has prepared the plans, designs
and a copy of other statements /documents as applicable.
i) Key Plan (Location Plan), (to be shown on first copy of the set of plans)
ii) Site Plan showing the surrounding land and existing access to the land proposed to be developed; (to
be shown on first copy of the set of plans)
iii) A detailed building plan showing the plan, section/s and elevation/s of the proposed development
work along with existing structure to be retained/ to be demolished, if any;
iv) Particulars of development in Form enclosed (excluding individual Residential building);
v) Copy of sanctioned layout plan if any;
vi) An extract of record of rights, property register card (any other document showing ownership of land
to be specified)
vii) In case of revised permission, document of consent as per Regulation No 2.2.3 (v).
viii) Attested copy of receipt of payment of scrutiny fees;
ix) Latest property tax receipt;
x) No Objection Certificate(s), wherever required.
I request that the proposed development/ construction may be approved and permission be accorded to me
to execute the work. I hereby undertake that I shall carry out the work according to the approved plan.
Signature of Owner
Name of Owner
Address of Owner.
Contact No.
Dated.
___________
CERTIFICATE
The above mentioned Plans are prepared by me as per UDCPR.
Signature of the Architect /
Licensed Engineer / Supervisor.
Name.
License No.
Contact No.
Dated
(*) Name of the Act of the Planning Authority, if any, be mentioned.
Form giving Particulars of Development
(Item iv of Appendix A-1)
1. (a) (i) Full Name of Applicant
(ii) Address of applicant
(iii) e-mail ID
(iv) Contact / Mobile No.
(i) Name and address of Architect/ licensed Engineer/
Supervisor.
(ii) No. and date of issue of License
2. (a) Is the plot of, a City Triangulation Survey Number,
Revenue Survey Number or Hissa Number of a Survey
Number or a Final Plot Number of a Town Planning Scheme
or a plot of an approved layout?
(b) Please state Sanction Number and Date of Sub-division/
Layout.
(c) Whether the land is situated in Congested Area (Core
Area) or Outside Congested Area?
3. (a) What is the total area of the plot according to the
i) Ownership document?
ii) Measurement plan ?
(b) Does it tally with the Revenue/CTS Record ? Yes / No
(c) What is the actual area available on site measured by
Architect/licensed Engineer/Supervisor?
(The permission shall be based on the area whichever is
minimum.)
(d) Minimum area of 3 (a) (i), (ii) and 3 (c) above
(e) Is there any deduction in the original area of the plot on
account of
Yes / No Area -----------
i) D.P. Roads, or
Yes / No Area -----------
ii) Reservation(s)
Yes / No
If so, are they correctly marked on the site plan?
Please state the total area of such deductions? Total Area -----------
(f) Is there any water stream in the land? State the area of Yes / No Area -----------
such land.
(g) What is the area remained for development after above Area -----------
deduction(s)?
(h) What is the area proposed for recreational open space? Area ---------- Sq.m.
(i) i) Whether amenity space as required under Regulation Yes / No Area -----------
No.3.5 is left? OR
Yes / No Area -----------
ii) Whether amenity space as required under Regulation
No.4.8.1 is left? (applicable in case of I to R provision)
(j) What is the net plot area as per Regulation No. 3.9 ? Area -----------
(excluding (i) above)
4. Are all plans as required under Regulation No.2.2 enclosed? Yes / No
5. (a) In what zone does the plot fall?
(b) For what purpose the building is proposed? Is it -------------
permissible according to the land use classification? Yes / No
6. (a) Is road available as an approach to the land? What is the Yes / No
average existing width of the road? (If the plot abuts on two Existing Width -----------
or more roads, the above information in respect of all roads
should be given)
(b) Is the land fronting on D.P. road? If so, width of the D.P. Yes / No
road Width -----------
(c) Is the land fronting on National or State highway? If so, is
the Building line/ control line maintained? Please state the
distance.
(c)What is the height of the building above the average Height -----------
ground level of the plot?
(d) Is it within permissible limit of height specified in Yes / No
Regulation No. (1) 6.10 ?
(e) Is height approved by Chief Fire Officer/ Director of Fire Yes / No
Services, M.S.? (In case of . (1) Special Buildings mentioned
in Regulation Number 1.3.93(xiv))
7. Is the land subject to restrictions of blue/ red flood line, Yes / No
airport, railway, electric line, land fill sites, archaeology, etc.?
--------
Please state the details along with ‗No objection certificate‘,
if any.
8. (a) If there are existing structures on the plot Yes / No
(i) Are they correctly marked and numbered on the site Yes / No
plan?
(ii) Are those proposed to be demolished immediately and Yes / No
hatched in yellow colour?
(iii)What is the plinth area and total floor area of all existing
structures to be retained?
(Please give details confirming to the plan submitted)
9. (a)Please state the total built up area on the basis of outer line
of construction (including balconies, double height terraces
and deducting voids) ( existing + proposed)
(b) What is the basic permissible F.S.I. of the zone according
to front road width?
(c) What is the premium FSI proposed to be utilised?
(d)What is the area of TDR proposed to be utilised?
(e) What is the additional FSI proposed to be utilised?
(f)Please state the overall F.S.I. utilised in the proposal?
(g)Is carpet area of each apartment mentioned on the plan?
(1)
Substituted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
10. Whether area for inclusive housing is required as per
Regulation No. 3.8? Please state the details.
11. (a) What is the width of the front marginal distance (s)? If the
building abuts two or more roads, does the front marginal
distance comply with Regulation?
13. (a) What is : Permissible Proposed
(i) the front set-back (s) ?
(ii)the side marginal distance (s)?
(iii) the rear marginal distance (s)?
(vi) the distance between buildings?
14. (a)What are the dimensions of the inner or outer chowk?
(b) Is / are room (s) dependent for its light and ventilation on
the chowk? If so, are the dimensions of the chowk as
required?
15. (a)Whether use of every room / part mentioned on the plan?
(b)Whether every room derives light and ventilation required
under the regulations?
16. If the height of the building is more than 15 meter above the
average ground level, is provision for lifts made?
(a) If so, give details of lift. Passenger No. of Lifts
Capacity
(b) Details of Fire Lift. Passenger No. of Lifts
Capacity
17. (a) Does the building fall under purview of Special Building
Regulation No.2.2.8?
(b)If so, is fire escape staircase provided in addition to regular Yes / No
staircase?
(c)Whether the ramps to the basement are provided leaving 6 Yes / No.
m marginal distance for movement of fire fighting vehicle?
(d) If podiums are proposed, does it allow the movement Yes / No.
of fire fighting vehicle properly?
18. (a) What are the requirements of parking spaces under the Required Proposed
Regulation No. 8.0 ? How many are proposed? Car
Scooter
(b) (i) Are loading-unloading spaces necessary?
(ii) If so, what is the requirement?
(iii) How many are proposed?
19. Is the sanitary arrangement provided as per the regulation?
20. Details of the source of water to be used in the construction ?
21. Distance from the sewer line. (if sewerage system is
available)
22. Please explain in detail in what respect the proposal does not
comply with the Unified Development Control and Promotion
Regulations and the reasons there for, attaching a separate
sheet if necessary.
I hereby declare that I am the Architect/ licensed Engineer/ Supervisor employed for the proposed
work and that the statements made in this form are true and correct to the best of my knowledge.
Date : / / Signature of the Architect / licensed Engineer / Supervisor
employed.
Form of Statement 1
(to be printed on plan)
[Sr. No. 8 (a) (iii)]
Existing Building to be retained
Existing Floor No. Plinth Area Total Floor Area of Use / Occupancy of
Building No. Existing Building Floors.
(1) (2) (3) (4) (5)
Form of Statement 2
(to be printed on plan)
[Sr. No. 9 (a) ]
Proposed Building
Building No. Floor No. Total Built-up Area of
floor, as per outer
construction line.
(1) (2) (3)
Total
Form of Statement 3
(to be printed on plan)
[Sr. No. 9 (g) ]
Area details of Apartment
Building No. Floor Apartment Carpet area of Area of Area of Double height
No. No. apartment Balcony terraces attached to
attached to flat.
Apartment
1 2 3 4 5 6
Note : Above statements may vary, wherever required.
Proforma - I: Area Statement
(At Right Hand top Corner of Plans)
PROPOSED ----------------- COMPLEX ON C.T.S. NO./PLOT NO. / S.NO. / GAT Drawing Sheet
NO. /F.P.NO.------- OF VILLAGE MAUJE ----- No.: X/Y
Stamps of Approval of Plans:
AREA STATEMENT
1. Area of plot
(Minimum area of a, b, c to be considered)
(a) As per ownership document (7/12, CTS extract)
(b) as per measurement sheet
(c) as per site
2. Deductions for
(a) Proposed D.P./ D.P. Road widening Area/Service Road / Highway widening
(b) Any D.P. Reservation area
(Total a+b)
3. Balance area of plot (1-2)
4. Amenity Space (if applicable)
(a) Required -
(b) Adjustment of 2(b), if any -
(c) Balance Proposed -
5. Net Plot Area (3-4 (c))
6. Recreational Open space (if applicable)
a) (a) Required -
b) (b) Proposed -
7. Internal Road area
8. Plotable area (if applicable)
9. Built up area with reference to Basic F.S.I. as per front road width
(Sr. No. 5xbasic FSI)
10. Addition of FSI on payment of premium
(a)Maximum permissible premium FSI - based on road width / TOD Zone.
(b) Proposed FSI on payment of premium.
11. In-situ FSI / TDR loading
(a)In-situ area against D.P. road [2.0 x Sr. No. 2 (a)],if any
(b)In-situ area against Amenity Space if handed over
[2.00 or1.85 x Sr. No. 4 (b)and /or(c)],
(c)TDR area
(d) Total in-situ / TDR loading proposed (11 (a)+(b)+(c))
12.Additional FSI area under Chapter No. 7
13. Total entitlement of FSI in the proposal
(a) [9 + 10(b)+11(d)] or 12 whichever is applicable.
(b) Ancillary Area FSI upto 60% or 80%with payment of charges.
(c) Total entitlement (a+b)
14. Maximum utilization limit of F.S.I. (building potential) Permissible as per Road
width {(as per Regulation No. 6.1 or 6.2 or 6.3 or 6.4 as applicable) x 1.6 or 1.8}
15. Total Built-up Area in proposal.(excluding area at Sr.No.17 b)
(a) Existing Built-up Area.
(b) Proposed Built-up Area (as per 'P-line')
(c) Total (a+b)
16. F.S.I. Consumed (15/13) (should not be more than serial No.14 above.)
17. Area for Inclusive Housing, if any
(a) Required (20% of Sr.No.5)
(b) Proposed
Certificate of Area:
Certified that the plot under reference was surveyed by me on__________ and the dimensions of
sides etc. of plot stated on plan are as measured on site and the area so worked out tallies with the area
stated in document of Ownership/ T.P. Scheme Records/ Land Records Department/City Survey records.
Signature
(Name of Architect/ Licensed Engineer/ Supervisor.)
Owner’s Declaration -
I/We undersigned hereby confirm that I/We would abide by plans approved by Authority / Collector. I/We
would execute the structure as per approved plans. Also I/We would execute the work under supervision of
proper technical person so as to ensure the quality and safety at the work site.
Owner (s) name and signature
Architect/ Licensed Engineer/ Supervisor name and signature
Job No. Drawing No. Scale Drawn by Checked by Registration No. of Architect/
License no. of Licensed
Engineer/ Supervisor
APPENDIX A-2: FORM FOR SUB-DIVISION OF LAND AS PLOTTED LAYOUT
Application for permission for development under Section 18/44/58/69 of The Maharashtra
Regional and Town Planning Act, 1966 read with any other Act governing the Planning Authority,
if any.*
From _________________ (Name of the owner)
To,
The Authority,( Name of the Authority.)
Sir,
I intend to carry out the under mentioned development in the site/plot of land, bearing S.No./Gat
No./City Survey No/Final Plot No.……………………,Mouje …………………, situated at Road/ Street
……………………… in accordance with Section 18/44/58/69 of The Maharashtra Regional and Town
Planning Act, 1966 read with Section (*)----------- of --------- Act.
I forward herewith the following plans and statements (Item 1 to 7), wherever applicable, in
quadruplicate, signed by me (Name in block letters) …………………………… and the Architect /
Licensed Engineer / Supervisor (Registration/ License No……………………….), who has been engaged
by me and has prepared the plans, designs and a copy of other statements /documents as applicable.
(1) Key Plan (Location Plan);(to be shown on first copy of the set of plans)
(2) Site Plan showing the surrounding land and existing access to the land included in the layout;(to
be shown on first copy of the set of plans)
(3)A layout plan showing,
(i) sub-divisions of the land or plot with dimensions and area of each of the proposed sub-
divisions and its use according to prescribed regulations;
(ii) width of the proposed streets; and
(iii) dimensions and area of recreational open spaces provided in the layout.
(iv) dimensions and area of amenity space provided in the layout.
(4) An extract of record of rights, property register card (any other document showing ownership of
land to be specified)
(5) In case of revised permission, document of consent as per Regulation No 2.2.3 (v).
(6) Particulars of development in Form enclosed.
(7)Attested copy of Receipt for payment of scrutiny fees.
(8) No Objection Certificate, wherever required. I request that the proposed Sub-division / layout may
please be approved and permission accorded to me to execute the work.
Signature of Owner
Name of Owner
Address of Owner
Contact No.
Dated:
CERTIFICATE
The above mentioned Plans are prepared by me as per UDCPR.
Signature of the Architect / Licensed
Engineer / Supervisor.
Name
License No.
Contact No.
Dated
(*) Name of the Act of the Planning Authority, if any, be mentioned.
Form giving Particulars of Development
(Part of Appendix A-2, Item 6)
1. (a) (i) Full Name of Applicant
(ii) Address of applicant
(iii) e-mail ID
(iv) Mobile No.
(b) (i) Name and address of Architect/ licensed Engineer / Supervisor
employed.
(ii) No. and date of issue of License ( Registration No. in case of
Architect.)
2. (a) Is the plot of, a City Triangulation Survey Number, Revenue Yes / No.
Survey Number or Hissa Number of a Survey Number or a Final
----------
Plot Number of a Town Planning Scheme?
(b) Whether the land is situated in Congested (core) Area or outside Yes / No.
Congested Area?
3. (a) What is the total area of the plot according to the ownership Area --------
document and measurement plan?
(b) Does it tally with the Revenue/CTS Record Yes / No.
(c) What is the actual area available on site measured by Architect/ Area --------
licensed Engineer/ Supervisor?
(The permission shall be based on the area whichever is minimum.)
(d) Is there any deduction in the original area of the plot on account Yes / No.
of D.P. Roads or reservation(s). If so, are they correctly marked
D.P. Road /
on the site plan? Please state the total area of such deductions?
widening Area
--------
Reservation
Area ------
(e) Is there any water stream in the land? State the area of such land Yes / No.
and state whether it is excluded?
Area --------
(e) What is the area remained for development after above Area --------
deduction(s)?
(f) What is the area proposed for recreational open space? (For Area --------
minimum original holding as mentioned in Regulation No. 3.4)
(g) Whether amenity space as required under Regulation No. 3.5 is Yes / No.
left? Please mention the area.
Area --------
(h) What is the net plot area as per Regulation No. 3.9? Area --------
4. Are all plans as required under Regulation No.2.2 enclosed? Yes / No.
5. (a) In what zone does the plot / land fall?
(b) For what purpose the layout is proposed? Is it permissible
according to the land use classification?
6. (a) Is road available as an approach to the land? What is the average Yes / No.
existing width of the road? (If the plot abuts on two or more roads, the
Width ------m.
above information in respect of all roads should be given)
(b) Is the land fronting on D.P. road? If so, width of the D.P. road Yes / No.
Width ------m.
(c) Is the land fronting on National or State highway? If so, is the Yes / No.
Building line / control line maintained? Please state the distance.
--------
7. Is the land subject to restrictions of blue / red flood line, airport, Yes / No.
railway, electric line, land fill sites, archaeology, etc.? Please state the
details along with ‗No objection certificate‘, if any.
8. Whether the internal roads proposed in the layout conform to the Yes / No.
Regulation No.3.3 ?
9. Whether roads in the layout are co-ordinated with the roads in the Yes / No.
surrounding layout?
10. Whether the area and dimensions of plots are proposed as per Yes / No.
prescribed regulations?
11. Whether area for inclusive housing is required as per Regulation No. Yes / No.
3.8 ? Please state the details.
I hereby declare that I am the Architect/ Licensed Engineer / Supervisor employed for the
proposed work and that the statements made in this form are true and correct to the best of my
knowledge.
Date : / / Signature of the
Architect/ Licensed
Engineer/ Supervisor
employed.
Proforma - I: Area Statement
(At Right Hand top Corner of Plans)
Proposed -------------------------- Layout on C.T.S. No./ Plot No. / S.No. /Gat. No./ Drawing
F.P.No.------- of Village Mauje ----- Sheet No.:
X/Y
Stamps of Approval of Plans:
Area Statement
Area of Plot (Minimum area of a, b, c to be considered)
a) As per ownership document (7/12, CTS extract)
b) as per measurement sheet
(c) as per site
2. Deductions for
(a) Proposed D.P./ D.P. Road widening Area/Service Road / Highway widening
(b) Any D.P. Reservation area
(Total a+b)
3. Balance area of plot (1-2)
4. Amenity Space (if applicable)
(a) Required -
(b) Adjustment of 2(b), if any -
(c) Balance Proposed -
5. Net Plot Area (3-4 (c))
6. Recreational Open space ( if applicable)
(a) Required -
(b) Proposed -
7. Internal Road area
8. Service road and Highway widening
9. Plotable area
10. Pro-rata factor for FSI calculation on layout plots = (5/9)
11. Area for inclusive housing
(a) Required -
(b) Proposed -
Certificate of Area:
Certified that the plot under reference was surveyed by me on__________ and the dimensions of
Area Statement
sides etc. of plot stated on plan are as measured on site and the area so worked out tallies with the area stated
in document of Ownership/ T.P. Scheme Records/ Land Records Department/City Survey records.
Signature
(Name of Architect/Licensed Engineer/Supervisor.)
Owner (s) name and signature
Architect/ Licensed Engineer/ Supervisor name and signature
Statement of distribution of FSI on each plot
(to be printed at suitable place on plan)
Plot Plot Corner Remaining Pro- Built up Front Basic Permissible
No. area Rounding Plot area Rata area on Road FSI Built-up
(Sq.m.) area of FSI pro-rata width area on
(b-c)
Road factor basis (m.) Basic FSI
(Sq.m.)
(if any) i.e.(d x e) (1) (f x h)
*
(Sq.m.) (Sq.m.)
(a) (b) (c) (d) (e) (f) (g) (h) (i)
* This factor may not be applied in case of individual plot, if quantum of FSI to be apportioned on various
plots is varied. In such case, column (e) shall read as "quantum of pro-rata FSI to be utilised" and total of
this column shall be equal to or less than the quantum at Sr. No. 5.
(1)
Substituted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
APPENDIX 'B': FORM FOR SUPERVISION
To,
The Authority
(Name of the Authority)
Sir,
I hereby certify that the development/erection/re-erection/demolition or material alteration in/ or
Building No____________ on / in Plot No. ____________ in Block No.________________ situated at
Road / street ___________________ Revenue S.No.……./ Gat No........./ Khasara No........ / City Survey
No…………../ Final Plot No......... shall be carried out under my supervision and I certify that all the
materials (types and grade) and the workmanship of the work shall be generally in accordance with the
general specifications and that the work shall be carried out according to the sanctioned plans. I shall be
responsible for the execution of the work in all respects.
Date : Signature and name of the Architect or Licensed
Engineer/ Site Engineer /Supervisor. *
Registration/ License No.
* Strike out whichever is not applicable.
CERTIFICATE
** I hereby certify that the structural drawings for the above mentioned work are prepared by me / us and
(1)the work, as far as structural drawings are concerned, shall be carried out (1) as specified in Appendix ‗C‘. I
shall be responsible for the (1) adequacy of the Structural Design as far as structural drawings are concerned.
Signature and name of the Structural Engineer
/ Architect / Licensed Engineer. ***
Registration/ License No.
Date :
** Wherever applicable.
*** Strikeout whichever is not applicable.
(1) CERTIFICATE
(1) ** I hereby certify that the work of structural elements for the above mentioned work shall be carried under
my supervision as per the above mentioned structural drawings after due verification by concerned Structural
Engineer. I shall be responsible for the execution of the work, quality of material used and quality of
workmanship as per the above mentioned Structural Design and structural drawings.
Date : Signature and name of the Architect or
Licensed Engineer/ Site Engineer /Supervisor. *
Registration/ License No.
** Wherever applicable.
* Strikeout whichever is not applicable.
(1)
Substituted vide Corrigendum / Addendum CR 121/21, dt. 02nd December, 2021.
APPENDIX -C
QUALIFICATION, COMPETENCE, DUTIES AND RESPONSIBILITIES ETC. OF LICENSED
TECHNICAL PERSONNEL OR ARCHITECT FOR DEVELOPMENT PERMISSION AND
SUPERVISON.
C-1 GENERAL
C-1.1 The qualifications of the technical personnel and their competence to carry out different jobs for
development permission and supervision for the purpose of licensing by the Authority shall be as
given in Regulation No. C-2 to C-6. The procedure for licensing the technical personnel is given
in Regulation No.C-7. In the event, the services of the technical personal is discontinued by the
owner / developer or such technical personal resigns from the services, he shall forthwith intimate
to the authority and owner / developer shall immediately appoint another technical person on the
project.
C-2 ARCHITECT
C-2.1 Qualifications-
The minimum qualifications for an architect shall be the qualifications as provided for in the
Architects Act, 1972 and should be registered with the Council of Architecture with valid
membership. Such registered Architects shall not be required to again register their names with the
Authority. However, he shall submit the registration certificate to the. Authority.
C-2.2 Competence of Architect:
To carry out work related to development permission as given below and shall be entitled to
submit -
i) All plans and technical information connected with designs and plans of development
permission.
ii) Structural details and calculations for building on plot up to 500 Sq.m. and up to 3 storeys or 11
m. height and
iii) Certificate of architectural supervision and completion for all buildings.
C-2.3 Duties and Responsibilities.
i) Design as per Client's requirements and site conditions.
ii) Prepare and submit plans as per the Regulations and shall be responsible for correctness of
the calculations and dimensions mentioned on the plan and shall be liable for consequences
arising thereof.
iii) Represent before the Authority for scrutiny of drawings.
iv) Prepare and issue working drawings details in conformity with approved plans.
v) Advice client to appoint Site Engineer/ Supervisor, in case he himself is not undertaking the
supervision work.
vi) Inform Authority about Commencement of work on site.
vii) To verify the work at obligatory stages of plinth completion, completion of RCC structure
and superstructure completion to ensure work progress in conformity of approved drawings
and dimensions.
viii) Inform Authority about reaching relevant stage of work where stage-wise approval from the
authority is required.
ix) Issue completion / part completion certificate for submission to the authority.
x) Inform in writing to the Authority in case of violation by Client during the period of
appointment
xi) To assist and co-operate with the Authority and other officers in carrying out and enforcing
the provisions of Maharashtra Regional and Town Planning Act, 1966 and of any
regulations for the time being in force under the same.
xii) The above mentioned Architect's scope and responsibilities shall be similarly applicable for
Landscape/ Heritage & Conservation Consultant, if any.
C-3 ENGINEER
C-3.1 Qualifications-
i) The qualifications for Licensing Engineer shall be the corporate membership (Civil) of the
Institution of Engineers or such Degree or Diploma in Civil or Structural Engineering or
equivalent; or
ii) Diploma in Civil Engineering or Diploma in Architectural Assistance ship or equivalent
qualification, having experience of 10 years in the field of land and building planning.
C-3.2 Competence-
To carry out work related to development permission as given below and shall be entitled to
submit-
i) All plans and related information connected with development permission.
ii) Structural details and calculations for building on plot up to 500 Sq.m. and up to 3 storeys or
11m. height, and
iii) Certificate of supervision and completion for all buildings.
C-3.3 Duties and Responsibilities.
Duties and Responsibilities of the Engineer shall be as mentioned in C-2.3 above within the
competency mentioned in Clause - C-3.2.
C-4 STRUCTURAL ENGINEER
C-4.1 Qualifications-
i) Graduate in Civil Engineering of recognised Indian or Foreign University and Chartered
Engineer or Associated Member in Civil Engineering Division of Institution of Engineers
(India) or equivalent Overseas Institution with minimum 3 years of experience of structural
engineering practice in designing and related field work; or
ii) Post graduate degree in structural engineering with 2 years' experience; or
iii) Doctorate in structural engineering with 1 year experience.
C-4.2 Competence -
The structural engineer shall be competent.
i) To prepare the structural design, calculations and details of all buildings and carry out
verification of reinforcement as per stages of work.
ii) To carry out structural audit/ structural condition survey of the existing/ old buildings.
C-4.3 Duties and Responsibilities of Structural Engineer
i) All structural layouts and structural design related with plan and development on the basis of
details received from architect/ owner/ builder/ developer/ geo technical consultant.
ii) Wherever required, structural engineer shall avail the services/advice of Geotechnical
Engineer.
iii) Provide lists of tests to be carried out at each stage of work and allow the further work only
after satisfying with the same.
iv) To verify the structural elements in compliance with structural drawings.
v) To document the site visit report mentioning therein the deviation / lapses, if any, in respect
of structural elements designed by him and inform the same to the site engineer, owner /
developer, architect / licensed personnel for rectification required.
vi) He shall be responsible for the adequacy of the structural design in compliance with BIS
code and plans received from architect/ owner/ builder/ developer.
vii) The structural engineer will advise owner/ builder/ developer to appoint formwork co-
coordinator (FWC) and same shall be employed by the owner/ builder/ developer for the
project.
viii) Certificate of structural design adequacy at the time of completion (1) shall be in the following
format:-
(1) PRAPTRA -1
CERTIFICATE AS PER APPENDIX C-4.3(viii)
Structural Design Adequacy
(to be submitted at the time of completion)
To,
The Authority
(Name of the Authority)
Sir,
I /we have been appointed as Structural Engineer by m/s------------------------------------for
preparing the structural design and drawings for the New structure consisting of -----floors,
construction of --------- additional floors over existing structure with -----floors, as described in
my enclosed Design base report, based on the Architectural drawings and other utilities and
services requirements given by the Owner/ Developer of the development work of building in
Plot No. _____ in Block No._____ situated at Road / street ___ Revenue S.No.……./ Gat
No........./ Khasara No........ / City Survey No……../ Final Plot No.........,.Tal.------ ,District-------.
The following listed firms /persons are associated with the work as appointed by M/s---------------.
Architect :- -------------------------------------
Owner /Developer:---------------------------
Licensing Engineer:--------------------------
Site Engineer:-----------------------------------
I/we hereby certify and confirm adequacy of the structural design for intended use represented
through my structural drawing issued from time to time.
I/we further confirm that the structural design structural drawings and details of the building
which has been done by me/us, satisfy the structural safety requirements for all situations
including natural disasters, as applicable, as stipulated in National Building Code of India and its
Part 6- Structural Design and other relevant Codes, considering the report of Subsurface
investigations, where applicable.
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
(1) I/we enclosing herewith undertaking of Site Engineer/ licensed Engineer, Owner regarding
compliance with structural drawings and adherence to standard construction practices while
executing the construction work.
On the basis of this I/we hereby certify that to the best of my Knowledge and belief the said
structure is structurally fit for the intended purpose.
As a Structural Engineer for design my responsibilities are limited to providing structural design
structural drawings and details in accordance with the provisions of relevant prevailing Indian
Standard codes, and visits to site at specified stages called for by the Supervising Structural
Engineer/ Supervising Engineer/ site Engineer for verification of reinforcement laid. All issues
related to Supervision, Materials, Workmanship and execution are the sole responsibility of the
Supervising Structural Engineer/Supervising Engineer/ site Engineer. Visit made by me as
Structural Engineer are not for Supervision since, i/we are not responsible for supervision and
quality of work. This certificate is issued on the clear understanding that my overall design
responsibility for safe and proper performance of structural design ceases, the moment any
addition and /or alteration or any damage to the structural frame is caused by accident or by
tampering with the geometrical sections of structural members for any purpose whatsoever or due
to overloading of the structure or lack of maintenance or any act that is detrimental to the
structure as a whole.
This certificate is issued in conjunction with the certificate of the licensed Engineer and owner
certifying the quality of work.
Enclosure-
1)
2)
3)
Date : Signature and name of the Licensed Structural Engineer
Registration/ License No.
C-5 SUPERVISOR
C-5.1 Qualification
(a) For Supervisor 1 :-
i) Three years architectural assistantship or intermediate in architecture with two years
experience, or
ii) Diploma in Civil engineering or equivalent qualifications with two years experience.
or
iii) Draftsman in Civil Engineering from ITI or equivalent qualifications with Ten years
experience out of which five year shall be under Architect/Engineer.
(b) For Supervisor - 2 :-
i) Draftsman in Civil Engineering from ITI or equivalent qualifications with five years
experience under Architect/ Engineer.
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
C-5.2 Competence
(a) For Supervisor-1: He shall be entitled to submit -
i) All plans and related information connected with development permission on plot up
to 500sq.m.; and
ii) Certificate of supervision of buildings on plot up to 500 Sq.m. and completion thereof.
(b) For Supervisor-2 :He shall be entitled to submit -
i) All Plans and related information up to 200sq.m. built up area, and
ii) Certificate of supervision for limits at (i) above and completion thereof.
C-5.3 Duties and Responsibilities.
Duties and Responsibility of the Engineer shall be as mentioned in C-2.3 above within the
competency mentioned in Clause C-5.2.
C-6 TOWN PLANNER
C-6.1 Qualification
Graduate or Post-graduate degree in Town and country planning, urban planning, planning,
regional planning or equivalent.
C-6.2 Competence
i) All plans and related information connected with development permission.
ii) Issuing certificates of supervision for development of all lands.
C-6.3 Duties and Responsibilities.
i) Design as per Client's requirements and site conditions.
ii) Prepare and submit plans as per the Regulations and shall be responsible for correctness of
the calculations and dimensions mentioned on the plan and shall be liable for consequences
arising thereof.
iii) Represent before the Authority for scrutiny of drawings.
iv) Advice client to appoint Site Engineer / Supervisor, in case he himself is not undertaking the
supervision work.
v) Inform Authority about Commencement of work on site.
vi) Inform Authority about reaching relevant stage of work where stage-wise approval from the
authority is required.
vii) Inform in writing to the Authority in case of violation by Client during the period of
appointment.
viii) To assist and co-operate with the Authority and other officers in carrying out and enforcing
the provisions of Maharashtra Regional and Town Planning Act, 1966 and of any
regulations for the time being in force under the same.
C-7. LICENSING-
C-7.1 (+) Technical Personnel to be licensed:-
The Qualified technical personnel or group as given in regulations; No. or (1) (--) C-3, C-4, C-5, C-6
shall be licensed with the Authority or (1) Directorate Office of Town Planning Department and the
license shall be valid for three calendar years ending 31stDecember after which it shall be
renewed every three years. The technical person registered with the Authority shall be entitled to
work within Authority's jurisdiction and those registered with (1) Directorate Office shall be
entitled to work within jurisdiction of all Authorities as well as regional plan area (1) (--).
(1)
Substituted / deleted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
(+)
Order issued by Director of Town Planning vide Order No. 5729, dt., 8th December, 2021.
(#) Fees for Licensing- The annual licensing fees shall be as follows:-
C-7.2 For Engineer, Structural Engineer and Town Planner. Rs.3000/- For three years.
For Supervisor (1) and For Supervisor (2) Rs.1500/- For three years. .
These fees shall be increased by 10% for every three years.
C-8 DUTIES AND RESPONSIBILITIES OF OTHER TECHNICAL PERSONS / Owner
C-8.1 SITE ENGINEER
C- Qualifications:
8.1.1
The "Site Engineer" must hold a minimum diploma in Civil/ Construction Engineering /
Construction Management or any other equivalent qualification in the field of Civil Engineering.
C- Duties and Responsibilities
8.1.2
i) To carry out day to day supervision in order to ensure that the work on site is carried out in
accordance with the development permissions, approved plans, drawings given by Licensed
personnel/ Architect of the project, structural drawings given by structural engineer.
ii) Enforce construction methodology; Ensure the quality of work as per the specifications and
keep site records.
iii) To make necessary arrangement for the temporary structures/formwork/shuttering required
for the execution of the building as per the design and drawing with the help of owner/
developer.
iv) To organise the all activities related to construction and development in coordination with
Architect / Engineer / Structural Engineer and Owner/ Developer.
v) To take necessary measures to ensure the safety of workers on site.
C-8.2 GEOTECHNICAL ENGINEER.
C- Qualifications:
8.2.1
i) Graduate in civil engineering or geotechnical engineering or Member of Civil Engineering
Division of Institution of Engineers (India), and with minimum 3 year experience in
geotechnical engineering practice in designing and field work., or
ii) Post graduate in civil engineering or geotechnical engineering with minimum 2 year
experience in geotechnical engineering practice in designing and field work. or
iii) Doctorate in civil engineering or geotechnical engineering with minimum 1 year experience
in geotechnical engineering practice in designing and field work.
C- Duties and Responsibilities of Geotechnical Engineer
8.2.2
i) Geotechnical investigation by exploring necessary field tests and visual inspection, taking
samples and testing in certified/ authorized Laboratory.
ii) Prepare the Geotechnical Report certifying the Geotechnical conditions, advise on safe
bearing capacity, required depth for foundation, stability of excavated slopes and safety of
the adjoining structures to the Structural Engineer by considering all relevant affecting/
governing aspects.
iv) Certify the strata and sub soil conditions before laying the foundation.
(#)
Clarification issued vide Order No. CR 236/18 (Part 2), dt, 23rd December, 2021.
C-8.3 OWNER / DEVELOPER
C- Duties and Responsibilities.
8.3.1
i) The applicant owner/ developer shall be responsible for title of the property.
ii) The applicant owner/developer shall be responsible for truthfulness and validity of orders,
NOCs, certificates obtained by him.
iii) Communicate with the consultants on reaching various stages of work in order to facilitate
them to get clearances for further action.
iv) Appoint professional/ consultant/ supervisors/ site engineer/ technical personnel/ staff
required for carrying out the work.
v) Provide necessary resources as may be required by the professionals/ consultants/
supervisors/ technical personnel/Staff.
vi) Commence work at various stages only after obtaining required approval to the plans from
the Authority or clearances under the law.
vii) To comply with any instructions, directions and orders by any Statutory Authority.
viii) Ensure that no work in violations of the sanctioned plan is carried out at any stage of the
work and even after Occupation certificate is obtained.
ix) To ensure overall safety during construction by engaging various technical persons, site engineer,
formwork coordinator etc.
C-8.4 DUTIES AND RESPONSIBILITIES OF THE OFFICERS OF THE AUTHORITY.
In addition to the duties and responsibilities assigned to the post of the officers of the Authority
dealing with the development permission, following duties shall also be performed.
i) The application of development permission shall be scrutinised and shall be disposed off
within the time limit specified in the Act/ DCPR or Right to Services Act.
ii) The concerned officer shall make site inspection/s as and when required.
iii) If any complaint is received in respect of any on-going work for which development
permission has been granted, he should take the cognizance of the said compliant and do the
needful within 15 days.
iv) On receipt of complaint, the officer of the Authority shall investigate thoroughly and do the
needful as per provisions of law and regulations. He shall not act arbitrarily on complaint
and issue stop work notice to on-going work.
C-8.5 TECHNICAL FACT FINDING COMMITTEE.
In case of any accident at site during construction on account of failure of any component of
building/ structure, the reason for the same shall be ascertained by the following technical fact
finding committee.
Committee for Planning Authority Area
Sr. No. Members Post
1 Collector of the concerned District Chairman
2 Deputy Commissioner of Police or Police Officer of the equivalent Member
rank.
3 Assistant Director of Town Planning of the District. Member
4 Superintending Engineer of P.W.D. (Building Design Division) of Member
the State.
5 Chief Fire Officer of the concerned Authority. In absence of such Member
officer at the Authority, representative of Director of Fire Services,
Maharashtra State.
6 Representative of Labour Commissioner not below the rank of Class- Member
A officer.
7 Representative of Indian Society of Structural Engineers of local/ Member
nearby centre.
8 Representative of Indian Institute of Architects of local/ nearby Member.
centre.
9 Representative of CREDAI of the concerned district/ city. Member.
10 In-charge Officer of the department of the concerned Authority, Member
granting the development permission. Secretary.
Committee for Regional Plan Area
Sr. No. Members Post
1 Divisional Commissioner of the Concerned Division. Chairman
2 Joint Director of Town Planning of the concerned Division. Member
3 Collector of the concerned District Member
4 Deputy Superintendent of Police or Police Officer of the equivalent Member
rank.
5 Superintending Engineer of P.W.D. (Building Design Division) of the Member
State.
6 Representative of Director of Fire Services, Maharashtra State. Member
7 Representative of Labour Commissioner not below the rank of Class- Member
A officer.
8 Representative of Indian Society of Structural Engineers of local/ Member
nearby centre.
9 Representative of Indian Institute of Architects of local/ nearby centre. Member.
10 Representative of CREDAI of the concerned district/ city. Member.
11 Assistant Director of Town Planning/ Town Planner of the concerned Member
area. Secretary.
In case of accident mentioned above, the concerned Authority shall intimate to the concerned
committee along with relevant documents. The Committee shall convene the meeting of the
committee immediately and shall send the report of its primary findings within 3 working days to
the concerned Authority for further necessary action. The committee shall submit final report
within 10 working days if detailed investigations are required. The committee shall be at liberty to
take the help of experts, if required. It may give hearing to the concerned persons, if required.
-*-*-*-*-*-
APPENDIX 'D-1'
FORM FOR SANCTION OF BUILDING PERMISSION AND COMMENCEMENT CERTIFICATE
To,
----------------------------------------------
----------------------------------------------
Sir,
With reference to your application No.__________________,dated ________________ for the grant of
sanction of (1) Building Permission Commencement Certificate under Section 18/44 of The Maharashtra Regional and
Town Planning Act, 1966 read with Section (*)----------- of --------- Act, to carry out development work / Building on
Plot No……… Revenue S.No.……./ Gat No........./ Khasara No........ / City Survey No…………../Final Plot
No.........Mauje___________________ situated at Road /Street_______________, Society ___________, the
Commencement Certificate/Building Permit is granted under Section 18/45 of the said Act, subject to the following
conditions:
1. The land vacated in consequence of the enforcement of the set-back rule shall form part of the public street in
future.
2. No new building or part thereof shall be occupied or allowed to be occupied or used or permitted to be used by
any person until occupancy certificate is granted.
3. The Commencement Certificate/ Building permit shall remain valid for a period of one year commencing from
the date of its issue (1) if the work is not commenced within the valid period.
4. This permission does not entitle you to develop the land which does not vest in you.
(1) Note 1 - At the time of building permission, the Planning Authority may add the necessary conditions
regarding compliance of these regulations.
Note 2 - At the time of Commencement Certificate, the Planning Authority may add the necessary one or two
conditions regarding compliance of the conditions of sanctioned Building Permission and these regulations.
Office No.
Office Stamp
Date : Yours faithfully,
Authority or an officer appointed by it
(*) Name of the Act of the Planning Authority, if any, be mentioned or concerned sentence be deleted.
(Specimen of Stamp of Approval to be marked on building plan)
OFFICE OF THE **-----------------
Building Permit No. ------------------
Date : -----------------.
SANCTIONED.
Signature
of the Authority
** Name of the Municipal Corporation / Council / Nagar Panchayat / Collector shall be mentioned.
(1)
Substituted / Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
APPENDIX 'D-2'
FORM FOR TENTATIVE APPROVAL FOR DEMARCATION OF LAND /
SUB-DIVISION LAYOUT
To,
----------------------------------------------
Sir,
With reference to your application No ___________________,dated ________________ for the
land sub-division approval, under Section 18/44 of The Maharashtra Regional and Town Planning Act, 1966
read with Section (*)----------- of --------- Act, to carry out development work in respect of land bearing Plot
No……… Revenue S.No.……./ Gat No........./ Khasara No........ / City Survey No…………../ Final Plot
No........., Mauje ……it is to inform you that, land sub-division layout is hereby tentatively approved and
recommended for demarcation, subject to the following conditions:
1. You will get the land sub-division layout demarcated on the site by the Land Records Department and
submit the certified copy to that effect for final approval.
2. It shall be the responsibility of the owner to carry out all the development work including construction
of roads, sewer lines, water supply lines, culverts, bridges, street lighting, etc. and hand it over to the
Authority after developing them to the satisfaction of the Authority.
3. If you wish that the Authority has to carry out these development works, then you will have to deposit
the estimated expenses to the Authority in advance, as decided by the Authority.
4. You will have to handover the amenity space to the Authority before approval of final layout as per
Regulation No. 3.5. (applicable in case where owner is not allowed to develop)
5. This permission does not entitle you to develop the land which does not vest in you.
Office No. Yours faithfully,
Office Date
Authority or an officer appointed by it
Office Stamp
(*) Name of the Act of the Planning Authority, if any, be mentioned or concerned sentence be deleted.
(Specimen of Stamp of Approval to be marked on Layout plan)
OFFICE OF THE **-----------------
Letter No. ------------------
Date : -----------------.
LAYOUT RECOMMENDED FOR
DEMARCATION.
Signature
of the Authority
** Name of the Municipal Corporation / Council / Nagar Panchayat / Collector shall be mentioned.
APPENDIX 'D-3'
FORM FOR FINAL APPROVAL TO THE LAND SUB-DIVISION / LAYOUT
To,
____________________________
____________________________
Sir,
With reference to your application No. ___________________,dated ________________ for the
land sub-division approval, under Section 18/44/69 of The Maharashtra Regional and Town Planning Act,
1966 read with Section (*)----------- of --------- Act, to carry out development work in respect of land bearing
Plot No……… Revenue S.No.……./ Gat No........./ Khasara No........ / City Survey No…………../ Final Plot
No........., Mauje…… the land sub-division layout is finally approved as demarcated, under Section 18/45/69
of the Maharashtra Regional & Town Planning Act, 1966, subject to the following conditions:
1. It shall be the responsibility of the owner to carry out all the development work including construction
of roads, sewer lines, water supply lines, culverts, bridges, street lighting, etc. and hand it over to the
Planning Authority /Collector after developing them to the satisfaction of the Authority.
2. If you wish that the Planning Authority /Collector should carry out these development works, then you
will have to deposit the estimated expenses to the Planning Authority /Collector in advance, as
decided by the Authority.
3. As per the undertaking submitted by you in respect of recreational open space as stipulated in
Regulation No.3.4, the said open space admeasuring ------- Sq.m. stand vested in the name of plot
holders of the layout or society of the plot holders and you have no right of ownership or interest in
the said recreational open space.
4. This permission does not entitle you to develop the land which does not vest in you.
5. ------------------------------------------------------------------------------------------------------
Yours faithfully,
Office Stamp Authority or an officer appointed by it
(*) Name of the Act of the Planning Authority, if any, be mentioned or concerned sentence be deleted.
(Specimen of Stamp of Approval to be marked on Layout plan)
OFFICE OF THE **-----------------
Letter No. ----------- Date : -----------
LAYOUT SANCTIONED
Subject to conditions mentioned in the said letter.
Signature
of the Authority
** Name of th e Municipal Corporation / Council / Nagar Panchayat / Collector shall be mentioned.
APPENDIX 'E-1'
FORM FOR REFUSAL OF BUILDING PERMIT/ COMMENCEMENT CERTIFICATE
Office No. Office Date
To,
----------------------------------------------
----------------------------------------------
----------------------------------------------
Sir,
With reference to your application No. ________________dated _______________ for the grant of
sanction for the development work / the erection of a building / execution of work on Plot No………
Revenue S.No.……./ Gat No........./ Khasara No........ / City Survey No…………../ Final Plot No.........
Mauje____________, I regret to inform you that the proposal has been refused under Section 18/45/69 of
the Maharashtra Regional and Town Planning Act, 1966, on the following grounds.
1.
2.
3.
4.
5.
6.
Yours faithfully,
Office Stamp
Authority or an officer appointed by it
Note - While refusing the permission, the Authority shall mention the Regulation number, provision of which
is not complied within the development proposal.
(Specimen of Stamp of rejection to be marked on building plan)
Letter No. --------
Date : -----------.
REJECTED
APPENDIX 'E-2'
FORM FOR REFUSAL OF LAND SUB-DIVISION/ LAYOUT
Office No. Date
To,
----------------------------------------------
----------------------------------------------
----------------------------------------------
Sir,
With reference to your application No. ________________dated _______________ for the
grant of sanction for the development work bearing Plot No……… Revenue S.No.……./ Gat No........./
Khasara No........ / City Survey No…………../ Final Plot No......... Mauje_______, I regret to inform you
that the proposal has been refused under Section 18/45/69 of the Maharashtra Regional and Town Planning
Act, 1966, on the following grounds.
1. -----------------------------------------------------------------------------------------------------------
2. -----------------------------------------------------------------------------------------------------------
3. -----------------------------------------------------------------------------------------------------------
4. -----------------------------------------------------------------------------------------------------------
5. -----------------------------------------------------------------------------------------------------------
6. -----------------------------------------------------------------------------------------------------------
Office Stamp
Yours faithfully,
Authority or an officer appointed by it
Note - While refusing the permission, the Authority shall mention the Regulation number, provision of which
is not complied within the development proposal.
(Specimen of Stamp of rejection to be marked on Layout plan)
Letter No. --------
Date : -----------.
REJECTED
APPENDIX 'F'
FORM FOR INTIMATION OF COMPLETION OF WORK UP TO PLINTH LEVEL*
To,
The Authority,
Planning Authority /Collector
Sir,
The construction up to plinth / column up to plinth level has been completed in Building No
______________ Plot No……… Revenue S.No.……./ Gat No........./ Khasara No........ / City Survey
No…………../ Final Plot No........., Mouje ……situated at Road/Street __________,Society____________
in accordance with your permission No _________ dated ___________________ under my architectural /
technical supervision and construction is carried out strictly in accordance with the sanctioned plan upto
plinth level.
This is for information to you and we are proceeding further with the remaining construction work.
Yours faithfully
Signature of Architect/Licensed Engineer/
/Supervisor
Name : ______________________
(In Block Letters)`_______________
Address :____________________
____________________
E-mail ID: ___________________
Mobile No.: ___________________
Date: ________________
APPENDIX 'G'
FORM FOR COMPLETION CERTIFICATE
To,
The Authority,
Planning Authority /Collector
Sir,
I hereby certify that the erection / re-erection or part/ full development work in / on building / part
building No ____________ Plot No……… Revenue S.No.……./ Gat No........./ Khasara No........ / City
Survey No…………../ Final Plot No........., Mouje ……has been supervised by technical person and has
been completed on ___________ without any departures of substantial nature according to the plans
sanctioned, vide office communication No. _____________ dated ______________. The work has been
completed as per sanctioned plan. No provisions of the Act or the building Regulations, no requisitions
made, conditions prescribed or orders issued thereunder have been transgressed, except * a few changes
made within the internal layout of residential or commercial units, which do not violate FSI or other
regulations, in the course of the work. I am enclosing three copies of the completion plans. The building is
fit for occupancy for which it has been erected/ re-erected or altered, constructed and enlarged.**
(1) All premium charges which are permitted to be paid in instalments with interest as per
Regulation No. 2.2.14 are fully paid.
I have to request you to arrange for the inspection & grant permission for the occupation of the
building.
Yours faithfully
(Signature of Owner)
Encl : As above. Name of Owner (in Block Letters)
Date :
Signature and name of Architect /Licensed
Engineer/Supervisor
* Wherever applicable.
** Delete whichever is not applicable.
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
APPENDIX 'H'
FORM FOR FULL / PART OCCUPANCY CERTIFICATE
Office No. Date
To,
i) Owner:
ii) Architect, Licensed Engineer , Structural Engineer / Supervisor
Sir,
The full / part development work / erection re-erection / or alteration in of building / part building No
________Plot No……… Revenue S.No.……./ Gat No........./ Khasara No........ / City Survey
No…………../ Final Plot No........., Mouje ……completed under the supervision of
___________________________________________ Architect, Licensed Engineer/ Structural Engineer /
Supervisor, / License No_______________________ may be occupied on the following conditions.
1. -----------------------------------------------------------------------------------------------------------
2. -----------------------------------------------------------------------------------------------------------
3. -----------------------------------------------------------------------------------------------------------
4. -----------------------------------------------------------------------------------------------------------
A set of certified completion plans is returned herewith.
Encl : As above.
Office Stamp Yours faithfully,
Authority or an officer appointed by it
(Specimen of Stamp to be marked on the plan)
OFFICE OF THE **----------------- OFFICE OF THE **-----------------
Letter No. ----------- Date : ----------- Letter No. ----------- Date : -----------
OCCUPATION GRANTED PART OCCUPATION GRANTED
Signature Signature
of the Authority of the Authority
** Name of the Municipal Corporation / Council / Nagar Panchayat / Collector shall be mentioned.
APPENDIX 'I'
FORM FOR REFUSAL OF OCCUPANCY CERTIFICATE
Office No. Date
To,
i) Owner:
ii) Architect, Licensed Engineer, Structural Engineer / Supervisor
Sir,
The part / full development work / erection re-erection / or alteration in of building / part building
No _________________ Plot No……… Revenue S.No.……./ Gat No........./ Khasara No........ / City
Survey No……./Final Plot No........., Mouje ……completed under the supervision of
___________________________________________ Architect, Licensed Engineer / Supervisor, / License
No___________ is not allowed to be occupy because of the following reasons -
1. The construction carried out by you does not conform to the sanctioned plans.
2. -----------------------------------------------------------------------------------------------------------
3. -----------------------------------------------------------------------------------------------------------
A set of completion plan is retained with the Authority and remaining sets are regretfully returned
herewith.
Encl : As above.
Office Stamp Yours faithfully,
Authority or an officer appointed by him
(Specimen of Stamp of rejection to be marked on the plan)
Letter No. --------
Date : -----------.
O.C. REJECTED
APPENDIX 'J'
FORM OF INDEMNITY FOR PART OCCUPANCY CERTIFICATE
(On Stamp Paper)
(Of such value as decided by the Authority.)
To,
The Authority,
---------------------------
Subject:-
Sir,
While thanking you for letting me occupy a portion of the above building before acceptance of the
Completion Certificate of the whole building for the plans approved in communication
No_______________, dated___________ I hereby indemnify the Authority against any risk, damage and
danger which may occur to occupants and users of the said portion of the building and also undertake to
take necessary security measures for their safety. This undertaking will be binding on me /us, our heirs,
administrators and our assignees.
Yours faithfully,
Signature and name of Owner
Witness:
Address:
Date:
APPENDIX 'K'
APPROVALS OF BUILDING PERMISSION BASED ON RISK BASED CATEGORIZATION
Sr. Parameters to be Risk Category
No. considered for Risk Low Risk Category Moderate Risk Category
Base
1 Plot area Building on a Plot Area upto 150 Buildings on a Plot Area more than
Sq.m. 150 Sq.m. and upto 300 Sq.m.
2 Plot status Plot should be from sanctioned Plot should be from sanctioned
layout released for construction or layout released for construction or
regularised under Gunthewari Act, regularised under Gunthewari Act, if
if plot is from congested area / plot is from congested area / gaothan
gaothan it should have undivided it should have undivided original
original City Survey Number/ City Survey Number/ original
original Property Card Number/ Property Card Number/
Independent 7/12 abstract.
Independent 7/12 abstract.
(Plot should not be from un-
(Plot should not be from un-
authorised sub-division.)
authorised sub-division.)
3 Buildability of Plot Plot should be buildable in view of Plot should be buildable in view of
the provisions in Regulation No.3.1. the provisions in Regulation No.3.1.
4 Zone in Development Residential or Commercial Zone or Residential or Commercial Zone or
Plan in a zone wherein Residential in a zone wherein Residential
development is allowed. development is allowed.
5 Type of Building Residential or Residential with shop Residential or Residential with shop
on ground floor. on ground floor or mixed use.
6 Front, side and rear As per the provisions of UDCPR. As per the provisions UDCPR.
open spaces, access,
parking and other
requirements.
7 Storeys allowed. G. F. + 2 or Stilt + 3 floors. G.F. + 2 or Stilt + 3 floors.
8 FSI Construction should be within basic Construction should be within basic
FSI + Premium FSI along with FSI + Premium FSI along with
ancillary area FSI thereon ancillary area FSI thereon
9 Submission of Applicant shall submit the intimation Applicant shall submit the
Application for letter as per Appendix-K-1 along application as per UDCPR and all
approval. with required document shall be certified
and signed by the licensed personal.
i) Ownership document.
The licensed personal shall also
ii) Copy of approved layout showing
submit the certificate stating that the
plot/ measurement plan of plot.
proposal is strictly in accordance
iii) Building plan showing periphery
with the provisions of UDCPR.
of construction (P-line) floor wise
and details of property, FSI
calculation as mentioned in
Proforma-I with the signature of
owner and licensed personal.
iv) Copy of receipt of development
charges including labour cess
paid to Authority, if any
v) The certificate of licensed
personal stating that the proposal
is strictly in accordance with the
provisions of UDCPR.
No more details shall be necessary.
10 Issue of The receipt of application along with After receipt of the application, the
Commencement the required documents and fees/ Demand Note regarding payment of
Certificate/ Approval. charges mentioned in 9 above, by the Development Charges and other
authority shall be treated as Charges based on the proposed
permission for development. Plans/ Drawing submitted, shall be
given by the concerned Engineer of
the authority within 10 days. After
the receipt of payment, the Authority
shall issue Commencement
Certificate within 10 days from
receipt of such plans without any
scrutiny, solely based on the
certificate of the licensed personal.
11 Plinth Checking Plinth Checking shall not be required. Plinth Checking shall not be
required.
12 Occupation Certificate. After completion of the work, the Licensed personal shall submit the
owner shall intimate to the Authority completion certificate in Appendix -
about the occupation of the building. H to the Authority. The licensed
personal shall not issue the
completion certificate unless the
construction is completed strictly as
per plan. The Authority shall issue
the occupation certificate within 10
days after site inspection.
13 Other Stipulations. ---- Any deficiency of documents or
payments as per UDCPR shall
amount to unauthorised construction
and shall be liable for action under
the provisions of the Act.
Note - The above procedure for permission shall not bar the owner to obtain development permission as per
provisions of this UDCPR, if he so desires.
APPENDIX 'K-1'
FORM FOR PERMISSION OF CONSTRUCTION OF BUILDING ON A PLOT
UPTO 150 SQ.M.
Application for permission for development under Section 18/44of The Maharashtra Regional and
Town Planning Act, 1966 read with any other Act governing the Planning Authority, if any.
From _________________
(Name of the owner)
To,
The Authority
(Name of the Authority )
Sir,
I intend to carry out the under mentioned development in the site/plot of land, on Plot No………
Revenue S.No.……./ Gat No........./ Khasara No........ / City Survey No……./Final Plot No........., Mouje
……situated at Road / Street ………… Society ………….in accordance with Section 18/44of the Maharashtra
Regional and Town Planning Act, 1966.
I forward herewith the following plans and statements, signed by me (Name in block letters)
…………..and the Architect / Licensed Engineer / Supervisor (License No………….), who has prepared the
plans.
i) Key Plan (Location Plan) and Site Plan (to be shown on the plan)
ii) A building plan showing the periphery of construction line (P-line) floor wise. No details of internal
room sizes and other details including section / elevation are to be shown. The height of building shall be
mentioned. Existing structure to be retained/ to be demolished, if any, shall be shown;
iii) Copy of sanctioned layout plan, if any;
iv) An extract of record of rights, property register card (any other document showing ownership of land to
be specified)
v) Attested copy of receipt of payment of Charges;(give details of proposed Area, FSI, Charges.)
vi) Copy of latest property tax receipt;
Please treat this intimation as permission for development.
Signature of Owner
Name of Owner
Address of Owner
Contact No. Dated ___________
The above mentioned P-line plans are prepared by me.
Signature of the Architect /
Licensed Engineer / Supervisor.
Name
License No.
Contact No.
Dated
(1) APPENDIX - „K-2‟
APPROVALS OF BUILDING PERMISSION FOR CONSTRUCTION UPTO 8 ROOMS FOR AGRO
TOURISM CENTER AND ALLIED ACTIVITIES AS PER TOURISM POLICY-2016
Sr. No. Parameters to be Description
considered
1 Agricultural Plot area and Plot Area No. of Rooms
No. of Rooms (i) Upto 0.8 ha. (i) Max. 04
(ii) 0.8 ha. upto 1.6 ha. (ii) Max. 06
(iii) 1.6 ha. & above (iii) Max.8 & 2 Dormitories.
Plot should be buildable in view of the provisions in Regulation
2 Buildability of Plot
No. 3.1 of UDCPR.
Agricultural Zone.
3 Zone in Development Plan
/ Regional Plan
Residential & Allied Amenities for Agro Tourism Centre.
4 Type of Building
As per the provisions of UDCPR.
5 Front, side and rear open
spaces, access, parking
and other requirements.
G.F. + 1 floor
6 Storeys allowed
Area of rooms should be minimum 150 Sq.m. and Area of
7 FSI
dormitories should be minimum 65 Sq.m. to 75 Sq.m. However,
total construction should be within maximum FSI of 0.2 of
gross plot area + along with ancillary area FSI thereon.
Applicant shall submit the intimation letter as per appendix-K-1
8 Submission of Application
of UDCPR along with -
for approval.
i) Ownership document.
ii) Copy of measurement plan of plot.
iii) Building plan showing periphery of construction (P-
line) floorwise and details of property, FSI calculation
as mentioned in Proforma-I with the signature of owner
and licensed personal.
iv) Copy of receipt of development charges including labour
cess paid to Authority, if any.
v) The certificate of licensed personal stating that the
proposal is strictly in accordance with the provisions of
UDCPR.
No more details shall be necessary.
The receipt of application along with the required documents
9 Issue of Commencement
and fees / charges mentioned in 8 above, by the authority shall
Certificate / Approval.
be treated as permission for development.
Plinth Checking shall not be required.
10 Plinth Checking
After completion of the work, the owner shall intimate to the
11 Occupation Certificate
Authority about the occupation of the building.
Note - The above procedure for permission shall not bar the owner to obtain development permission as
per provisions of this UDCPR, if he so desires.
(1)
Inserted Vide Directives u/s 154 No. CR 04/2022 dt. 2nd June 2022.
 (1) Notwithstanding anything mentioned above, if number of rooms exceeds 8 in Agro Tourism
Centre, it shall be considered as commercial enterprises and for such proposal it shall be necessary
to obtain development permission as per sanction Unified Development Control and Promotion
Regulations from concerned Authorities.
 All other provisions and terms / conditions mentioned in Government Resolution of Department of
Tourism and Cultural Affairs No. TDS-2018///CR.514/Tourism, dated 28/09/2020 shall be
applicable.
-*-*-*-*-
(1)
Inserted Vide Directives u/s 154 No. CR 04/2022 dt. 2nd June 2022.
APPENDIX - 'L'
HERITAGE LISTCARD (TOWN & REGION)
Location Pin/ MH 09 Heritage listing of the city
Photo w.r.t. Landmark (min. 4 Site photo (black and Card No.
side black and white photos) white)
Grade
Zone
Zone reference
Geological co-ordinate
Village / CTS / Survey / Plot No.
Postal Address
GTS R.L. Survey
A Name of the Property
i) Name
ii) Historic name
iii) Built in/ Age
B Built Form
i) Number of floors
C Area (sq.)
i) Plot Area
ii) Built-up area
D Approach
i) Access
ii) Distance from Rly. Station
E Ownership
i) Past owner (s)
ii) Present owner (s)
iii) Lease status
F Uses
i) Past uses
ii) Present uses
G Listing criteria and reference
i) Historic/Archaeological Significance
ii) Value for architectural, historical or
cultural reasons
iii) Architectural
iv) Historical
v) Cultural
vi) The date and/or period and/or design
and/or unique use of the building or
artefact
vii) Period
viii) Design
ix) Use
x)
Relevance to social or economic history
xi) Association with well-known persons or
events.
xii) A building or groups of buildings and/or
areas of a distinct architectural design
and/or style, historic period or way of
life having sociological interest and/or
community value.
xiii) The unique value of a building or
architectural features or artefact and/or
being part of a chain of architectural
development that would be broken if it
is lost.
xiv) Its value as a part of a group of
buildings.
xv) Representing forms of technological
development.
xvi) Vistas of natural/scenic beauty or
interest, including water front areas,
distinctive and/or planned lines of sight,
street line, skyline or topographical
features.
xvii) Special details related to services like
sanitation, plumbing, water supply
system, drainage system, electrical, wind
scoops, rainwater harvesting, etc.
xviii) Open spaces sometimes integrally
planned with their associated areas
having a distinctive way of life and for
which they have the potential to be areas
of recreation.
ix) Industrial sites of historical interest
xx) Archaeological sites
xxi) Natural heritage sites
xxii) Sites of scenic beauty
xxiii) Architectural Description (As- Built
drawings)
xxiv) Ecological Significance
xxv) Final grade
xxvi) Lister/ reviewer
H Architectural Systems in the Structure with Images/ Photos
i) Foundation and Plinth
ii) Walls
iii) Floor
iv) Roof
v) Openings
vi) Steps
vii) Decorative elements/Interiors
ANNEXURE I
Transformation over the years in
i) Form
ii) Structure
iii) Finishes
ANNEXURE II
Ecological and Environmental Features in and upto 500 m from the Site
i) No. of trees
ii) Type of trees
iii) Topography
ANNEXURE III
A Cultural Aspect
i) Folk cultural
ii) Social, Traditional Festivals
B Historical Aspect
i) Renewal time of form - every
5 years
C Present Structural Status
i) Structural Stability Audit every 5 years
ii) Maintenance Level
D Remarks
i) Conservation and Development -
Methodology
ii) Any other Significant Aspect
Name and Signature of Heritage
Conservationist
-*-*-*-*-
ANNEXURE III
A Cultural Aspect
i) Folk cultural
ii) Social, Traditional Festivals
B Historical Aspect
i) Renewal time of form - every
5 years
C Present Structural Status
i) Structural Stability Audit every 5
years
ii) Maintenance Level
D Remarks
i) Conservation and Development -
Methodology
ii) Any other Significant Aspect
Name and Signature of Heritage
Conservationist
-*-*-*-*-
APPENDIX - 'M'
Plan A - Nallahs identified for Cycle Track in Nashik Municipal Corporation Area.