# Chapter 3: General Land Development Requirements

CHAPTER-3
GENERAL LAND DEVELOPMENT REQUIREMENTS.
3.1 REQUIREMENTS OF SITE
3.1.1 Site not Eligible for Construction of Building
No piece of land shall be used as a site for the construction of building,
i) If the Authority considers that the site is insanitary, incapable of being well drained or is
dangerous to construct a building on it;
ii) If the entire site is within a distance of 6 m. from the edge of water mark of a minor water
course (like nallah, canal) and 15 m. from the edge of water mark of a major water course
(like river) shown on Development Plan/Regional Plan or village/city survey map or
otherwise.
Provided that where a minor water course passes through a low lying land without any well-
defined banks, the owner of the property may be permitted by the Authority to canalise
water course within the same land without changing the overall alignment and the position
of the inlet and outlet of the water course according to cross section as determined by the
Authority. In such case, marginal open space shall be as stipulated under these regulation
and shall be measured from edge of the trained nallah.
iii) If the site is hilly and having gradient more than 1:5;
iv) If the site is not drained properly or is incapable of being well drained;
v) If the owner of the building has not proposed appropriate measures required to safeguard the
construction from constantly getting damp to the satisfaction of the Authority;
vi) In case the building is proposed on any area filled up with carcasses, excreta, filth and
offensive matter, then certificate from the Authority to the effect that it is safe from the
health and sanitary point of view, to be built upon, is required;
vii) If the use of the site is for the purpose, which in the opinion of the Authority will be a source
of annoyance to the health and comfort of the inhabitants of the neighbourhood;
viii) If the proposed occupancy of the building on the site does not conform to the land use
proposals in the development plans/ Regional Plan or Zoning Regulations;
ix) If the level of the site is less than prescribed datum level depending on topography and
drainage aspects;
x) If it doesn‘t derive access from an authorized street/means of access of adequate width as
described in these Regulations;
xi) If it is within the river and blue flood line of the river (prohibitive zone), unless otherwise
specified in these regulations;
xii) If the site is within the boundary of Coastal Regulation Zone where CRZ Regulation does
not allow development;
xiii) If the site is not developable by virtue of restrictions imposed under any law or guidelines of
any Government Department;
xiv) If the entire site is within a distance of 50 m. from the mean high flood level of a wetland.
The mean shall be calculated as per the provisions of Wetlands (Conservation and
Management) Rules, 2017.
3.1.2 Distance of Site from Electric Lines
No structure including varandah or balcony shall be allowed to be erected or re-erected or any
additions or alterations made to a building on a site within the distance quoted in Table No. 3
below in accordance with the prevailing Indian Electricity Rules and its amendments from time to
time between the building and any overhead electric supply line.
Table No. (--)(1) 3 - Distance of site from Electric Lines
Electric Lines Vertical (Meters) Horizontal (Meters)
Low and medium voltage Lines 2.50 1.20
High voltage lines up to and including 3.70 2.00
33000 V,
Extra High voltage lines beyond 33,000 V 3.70 2.00
(Plus 0.3 m. for every additional 33,000 V or
part thereof)
Note - The minimum clearance specified above shall be measured from maximum sag for
vertical clearance and from maximum deflection due to wind pressure for horizontal clearance.
3.1.3 Construction within Blue and Red Flood Line
i) Where Blue and Red flood line are marked on the Development Plan / Regional Plan or
received from the Irrigation Department.
a) The Red Flood Line and Blue Flood Line shall be considered as per the plan prepared
by the Irrigation Department. The area between the river bank and blue flood line
(Flood line near the river bank) shall be prohibited zone for any construction except
parking, open vegetable market, garden, lawns, open space, cremation and burial
ground, sewage treatment plant, water / gas / drainage pipe lines, public toilet or like
uses, provided the land is feasible for such utilization.
Provided that, redevelopment of the existing authorised properties, within river bank
and blue flood line, may be permitted at a plinth height of 0.45 m. above red flood line
level.
b) Area between blue flood line and red flood line shall be restrictive zone for the
purposes of construction. The construction within this area may be permitted at a
height of 0.45 m. above the red flood line level.
c) If the area between the river bank and blue flood line forms part of the entire plot in
Development Zone, then, FSI of such part of land may be allowed to be utilised on the
remaining land.
d) The red and blue flood line, if shown on the Development/Regional Plan / Planning
Proposal shall stand modified as and when it is modified by the Irrigation Department.
ii) Where Blue and Red flood line is not marked on the Development Plan / Regional Plan
or not received from the Irrigation Department.
Where Blue and Red flood line is not marked on the Development Plan / Regional Plan or
not received from the Irrigation Department, the tentative Blue line shall be earmarked
taking into consideration maximum observed flood level records available locally and also
interacting with the residence in the area. The plan showing such tentative Blue line shall be
(1)
Substituted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
got approved from Chief Engineer, Irrigation Department. The distance of 50 m. on
landward side from this tentative Blue line shall be treated as No Construction Zone.
In such cases, provisions of Regulation No. 3.1.3 (i) (a,b,c,d) shall be applicable to that
extent.
Till such tentative Blue line is prepared and marked on the plan, the development permission
shall be governed by the provisions of Regulation No. 3.1.1 (ii).
3.1.4 Development within 30 M. Distance from Railway Boundary
For any construction within 30 m. from railway boundary, No Objection Certificate from Railway
Authority shall be necessary.
3.1.5 Environmental Clearance
Environmental clearance certificate shall be submitted for the project as may be prescribed by the
Ministry of Environment from time to time.
3.1.6 # Development along Highways / Classified Roads
The development along the highways shall be subject to the provisions of State Highways Act,
1965 and National Highway Act, 1956 and orders issued by Public Works Department, directives
issued by Urban Development Department vide Resolution No.TPS-1819/UOR-36/19/UD-13,
dated5.8.2019in this regard, from time to time. (1) All the classified roads passing through the
(1) ULBs i.e. Municipal Corporations / Municipal Councils / Nagar Panchayats shall be treated as
city roads.
A service road as specified in Regulation No. 3.3.8 shall be provided along State and National
Highways on both sides. Where service road of 12m width is already provided in adjoining land,
such service road of the same width may be continued in the development permission. Such
service roads may not be insisted if it has no continuity from junction to junction due to existing
authorised development / construction.
3.1.7 Development within certain distance from the Prison Premises
The development within 150 m., 100 m., 50 m., from the perimeter wall of Central Prison, District
Prison and any Sub Prison respectively shall be regulated and may be permitted with prior consent
of the committee constituted in this regard by the Home Department. This provision shall be
subject to the orders issued by the Government from time to time.
3.1.8 Distances from land fill sites
For any residential development, segregating distance from the land fill site shall be observed as
specified under Solid Waste Management Rules in force from time to time or as specified by
competent authority.
3.1.9 Restrictions in the vicinity of Airport
For structure, installations or buildings including installations in the vicinity of aerodromes,
i) The height shall be restricted to permissible top elevation as mentioned on Colour Coded
Zoning Maps(CCZM) prepared by the Airport Authority of India (AAI) published on its web
site.
ii) For any additional height beyond that mentioned in i) above, prior NOC from AAI shall be
submitted.
(1) Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
# Clarification issued vide Order No.CR-236/18 (Part -2) dt.23.12.2021.
iii) For the areas depicted in red colour on CCZM, prior NOC from AAI shall be submitted.
Note-
a) The height permitted by CCZM is indicated Above Mean Sea Level i.e. AMSL.
b) Building height permitted i.e. Above Ground level (AGL) shall be calculated as CCZM
height minus the site elevation of the plot.
Height of building (AGL) =CCZM height - site elevation.
c) In absence of aforesaid map, no objection certificate of Airport Authority of India shall be
required.
Explanation
i) Irrespective of their distance from the aerodrome, even beyond the 20km. limit from the
aerodrome reference point, no building, radio masts or similar installation exceeding 150 m.
in height shall be erected without prior permission of the Civil Aviation Authorities.
ii) The location of a slaughter house/abattoir/butcher house or other areas for activities like
depositing of garbage which may encourage the collection of high flying birds, like eagles
and hawks, shall not be permitted within 10 km. from the aerodrome reference point.
3.1.10 Restrictions in the Vicinity of Ancient Monuments
1) The Restrictions for Development in the vicinity of the protected monuments of national
importance as prescribed under the Ancient Monuments and Archaeological Sites and
Remains Act, 1958 shall be observed.
2) The Restrictions for Development in the vicinity of the protected monuments of state
importance as prescribed under Ancient Monuments and Archaeological Sites and Remains
Act, 1960 shall be observed.
3.1.11 Restriction under the Works of Defence Act, 1903
The restrictions imposed under the Work of Defense Act, 1903 shall be applicable and no
development in contravention with the notification shall be permissible.
Whether the area affected by the notification under Works of Defense Act- 1903, is earmarked in
Development Plan / Regional Plan or not, it shall be permissible to treat the area under such
restrictive zone as marginal distance at the time of construction of any building proposed on
contiguous unaffected area.
Provided that, it shall be permissible to utilise the FSI and also the receiving potential of the land
under this zone, as otherwise permissible, on the remaining contiguous unaffected land of the
same land owner.
3.1.12 Distance from Natural Lake and Dam.
In Regional Plan area, no construction shall be allowed within 100 m. from the high flood line of
natural lake.
In Development Plan area, development around natural lake shall be governed by the provisions
made in such plan. In absence of the provisions in such plan the distance as may be specified by
Irrigation Department shall be followed.
The regulation regarding clear distances from the High flood line while carrying out any
development of any land around dam and foothill areas as notified and the norms regarding
distance as prescribed in Government of Maharashtra, Water Resources Department Marathi
Circular No.संनकणग-2012/(प्र.क्र.20/2012) सस.व्य.(महसलू ), dt.08/03/2018 and amendments therein,
from time to time, will be applicable henceforth, subject to following condition.
Condition: - The concerned land owners/users are prohibited to discharge any Garbage/Water
Sewage/ Wastage in the reservoir, generating from its premises. It will be compulsory and binding
on the land owner/user to make necessary arrangements within the premises for Water and sewage
disposal management and to maintain the Zero Discharge condition at his own cost.
3.1.13 Authorities to Supply Complete Information about Restrictions to the Authority
The concerned authority putting restrictions as per their respective legislations/ regulations/ rules
as mentioned above shall make available to the Authority full details of restrictions (including
graded restrictions, if any) along with the relevant map detailing restrictions. In the interest of
increasing ease of doing business, no individual applicant should be required to approach the
concerned departments for NOC. However it is the duty of the applicant to ensure that restrictions
informed by the above said authorities are followed scrupulously. The Authority shall make a
reference to this effect to the concerned authorities and ensure compliance with the restriction
informed by them while sanctioning the development permission.
Such information shall be published by the Authority on its notice board/ website and also update
it as and when it is updated by the concerned department.
3.2 MEANS OF ACCESS
3.2.1 Every plot / land shall have means of access like street / road irrespective of its width.
3.2.2 In case of plot not abutting on a public means of access like street/roads etc., the plot shall have
access from spaces directly connected from the street by a hard surface approach as given below:-
(a) The width of such access ways in non-congested areas shall be as follows: -
Min width of access ways Max. Length of such access ways
6m. 75m.
9m. 150m.
(b) In congested areas, the width of such access ways shall not be less than 4.5m.
3.2.3 Every person who intends to erects a building shall not at any time erect or cause or permit to
erect or re-erect any building which in any way encroaches upon or diminishes the area set apart
as means of access.
3.3 REGULATIONS FOR LAND SUB-DIVISION AND LAYOUT
3.3.1 Obligation to Prepare Layout
Building Layout or Sub-division proposal shall be submitted for the following:-
i) When more than one building, except for accessory buildings in case of residential building
is proposed on any land, the owner of the land shall submit proposal for proper layout of
building or sub-division of his entire contiguous holding.
ii) When development and/or redevelopment of any tract of land which includes division and
sub-division or amalgamation of plots for various land uses is proposed.
iii) When group housing scheme or campus /cluster planning of any use is proposed.
iv) A two-stage approval process as specified in Regulation No. 2.6.1 will be followed for such
proposals, wherever necessary.
3.3.2 Roads / streets in Land Sub-division or Layout
A) For Residential Development- The minimum width of internal road in any layout or
subdivision of land shall be as given in Table No.3A.
Table No.3A - Internal Roads for Residential Development
Sr. Length of Internal Road in Width of Internal Road in Layout /
No. Layout / Sub division (m) Sub Division (m)
i Upto 150 9.00
ii Above 150 and upto300 12.00
iii Above 300 15.00
Note - For layout or part of layout where plots of 100 Sq.m. or less are proposed for Economical
weaker Sections (EWS), 4.5 m. wide road of length upto 60 m. and 6 m. wide road of length upto
100 m. may be permitted so that EWS plots shall abut on both sides of such roads.
B) For Other than Residential Development :The minimum width of internal road in any
layout or subdivision of land shall be as given in Table No. 3B
Table No.3B - Internal Roads for non-residential Development
Sr. Length of Width of Internal Road in Layout / Sub
Division (m)
No. Internal Road in Layout /
Sub division (m)
i Upto 150 12
ii Above 150 and upto300 15
iii Above 300 18 or more
C) Group Housing Scheme :In case of group housing schemes, minimum width of internal
roads shall be as given in Table No. 3C
Table No. 3C - Internal Roads for Group Housing Scheme
Sr. No. Length of Internal Road (m) Width of Internal Road
(m)
i Upto 150 7.50
ii Above 150 and upto300 9.00
iii Above 300and upto 600 12.00
iv Above 600 15.00
Note : It shall be necessary to provide through roads in group housing scheme of area more than
2 Hectares, so as to coordinate the adjoining major road links (15 m. and above) or give way to
new road link for adjoining area. The width required for such road link shall be as per Table No.
3A. This shall not bar coordination of smaller width roads approaching from adjoining area, if
owners so desire. Further the Authority may insist on coordination of smaller width roads from
adjoining area, if required from planning point of view.
D) Pathways
In case of Group Housing Scheme / Campus planning / Layout of Buildings, a pedestrian
approach to the buildings from road / street / internal means of access, wherever necessary, shall
be through paved pathway of width not less than 2.0 m., 3.0 & 4.5m. provided its length measured
from exit way of the building is not more than 40 m., 60 m. and 100 m. respectively from the main
/ internal means of access. If the length is more than 100m., then width of the road as provided in
Table No.3C shall be necessary. The marginal distances shall not be required from such pathways.
However, distance between two buildings shall be maintained which will include width of such
pathway.
3.3.3 Length of Internal Roads, How to be Measured
The length of Internal road shall be measured from the farthest plot (or building) to the public
street. The length of the subsidiary access way shall be measured from the point of its origin to the
next wider road on which it meets.
Provided that in the interest of general development of an area, the Authority may insist the means
of access to be of larger width than that required under Regulation No. 3.3.2.
3.3.4 Co-ordination of Roads in adjoining lands
While granting the development permission for land sub-division or group housing/ campus
planning, it shall be necessary to co-ordinate the roads in the adjoining lands subject to provisions
mentioned in Regulation No.3.3.2.C - Note. Also, proper hierarchy of roads shall be maintained
while deciding width of road.
3.3.5 Narrow Roads in Congested Areas(Core area in case of Nashik Municipal Corporation) :
In congested areas, plots facing street/ means of access less than 4.5m. in width, the plot boundary
shall be shifted to be away by 2.25 m. from the central line of the street/ means of access way to
give rise to a new street / means of access way of width of 4.5 m. clear from the structural
projections. However, this will not be applicable for lane of any length serving single plot /
property. In these cases, no separate setback from revised plot boundary shall be required.
3.3.6 Development of Street
Means of access / internal road shall be levelled, metalled, flagged, paved, sewered, drained,
channelled, lighted, laid with water supply line and provided with trees for shade (wherever
necessary), free of encroachment and shall be maintained in proper condition.
3.3.7 Development of Private Street, if neglected
If any private street or any other means of access to a building is not constructed & maintained as
specified above, the authority may by written notice require the owner or owners of the several
premises fronting or adjoining the said street or other means of access or abutting thereon or to
which access is obtained through such street or other means of access or which shall benefit by
works executed to carry out any or more of the aforesaid requirements in such manner and within
such time as the authority shall direct. If the owner or owners fail to comply with this direction,
the authority may arrange for its execution and recover the expenses incurred from the owner/
owners.
3.3.8 Access from the Highways/ Classified Roads
(a) Generally, plots/ buildings along Highways and classified roads shall derive access from
service roads. However, highway amenities like petrol pump, fuel station, hotel, etc. may
have a direct access from Highways and this shall be subject to the provisions of National
Highway Act, 1956 and State Highways Act, 1955.
(#) (b) Width of roads to be considered while granting development permissions, unless indicated
otherwise in Development Plan/ Regional Plan/ Planning Proposal / T.P. Scheme shall be as
mentioned in table below:-
Sr. Category of Road Width of Right of Remarks
No. Way of Road (m)
1 National Highway 60 Width inclusive of 12m. service roads
on both sides
2 State Highway 45 Width inclusive of 9m. service roads on
both sides
4 Major Dist. Road 24 No Service road required.
5 Other Dist. Road 18 No Service road required.
6 Village Road 15 No Service road required.
Notes :
1) If the width of any existing road is more than what is specified in above table then the greater
width shall prevail.
2) If the service roads are provided beyond the right of way in permission granted earlier then
such service roads may be continued further in adjoining land.
3) The above widths of roads may vary according to guidelines or circulars issued by the
respective department.
(1) This provision shall applicable to Area Development Authorities / Metropolitan Region
Development Authorities / Special Planning Authorities / New Town Development
Authorities and Regional Plan Areas.
3.3.9 Access Provisions for Special buildings in Regulation No.1.3 (93) (xiv)
For special buildings as mentioned in 93 (xiv) under Regulation No. 1.3, the following additional
provisions of means of access shall be ensured;
(a) The width of the main street on which the plot abuts shall not be less than 12m. in non-
congested area and shall not be less than 9m. in congested area, and one end of this street
shall join another street of width not less than at least 9 m. (1) in congested area and 12m. in
non-congested area.
(b) The marginal distances on all its sides shall be minimum 6m. and the layout for the same
shall be approved taking into consideration the requirements of fire services, and the margins
shall be of hard surface capable of taking the weight of fire engine, weighing up to 45
tonnes. The said marginal distances shall be kept free of obstructions and shall be motorable.
(c) Main entrances to the plot shall be of adequate width to allow easy access to the fire engine
and in no case it shall measure less than 6 m. The entrance gate shall fold back against the
compound wall of the premises, thus leaving the exterior access way within the plot free for
movement of fire engine / fire service vehicles. If main entrance at boundary wall is built
over, the minimum clearance (headroom) shall be 4.5 m.
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
(#)
Clarification issued vide Order No. CR 236/18 dt, 23rd December, 2021.
3.3.10 Cul-de-sacs
In addition to the provisions of Regulation No.3.3.2, Cul-de-sacs giving access to plots and
extending up to 150m. normally and 275m. maximum with an additional turning space at 150m.
may be allowed only in residential area, provided that Cul-de-sacs would be permissible only on
straight roads and provided further that cul-de-sac ends shall be higher in level than the level of
starting point. The turning space, in any case shall be not less than 81sq.m.in area with no
dimension being less than 9m.
3.3.11 Handing Over of Layout Roads
Whenever called upon by the Authority to do so, areas under internal layout roads shall be handed
over to the Planning Authority by way of deed after development of the same, within such period
as may be specified in commencement letter / development permission, for which no
compensation shall be paid by the Planning Authority.
3.3.12 Intersection of Roads
At junctions of roads meeting at right angles, the rounding off at the intersection shall be done
with the tangent length from the point of intersection to the curve being half the road width across
the direction of tangent as shown in Fig. 3A. The building shall also set back at required marginal
distance from this rounding off.
Fig. 3A - Rounding off at junctions of right angled intersections
Fig. 3B - Rounding off at junctions at acute/ obtuse intersections.
3.3.13 Acute Angled Junctions
For junctions of roads meeting at less than 60 degree, the rounding off or cut-off or similar
treatment shall have tangent length of U and V from the intersection point as shown in Fig.3B.
The tangent length at obtuse angle junction shall be equal to half the width of the road from which
the vehicle enters as shown in Fig. 3B. Provided, however, that the radius for the junction
rounding shall not be less than 6m. for both types.
3.3.14 Land-locked Plot
In case of a plot surrounded on all sides by other plots or reservation, if any, i.e. a land locked plot
which has no access to any street or road, the Authority may require access through an adjoining
plot or plots and shall, as far as possible be nearest to the street or road, to the land locked plot, at
the cost of owner of the land-locked plot & such other conditions as the Authority may specify. If
the Plot is land locked by any reservation, then access may be made available by adjusting
reservation within owners land without reduction in area. Such land locked plot, upto 100 mt.
shall be considered as fronting on the main road from which the access of minimum 9 mt. width is
made available.
3.3.15 Approach by underpass or Over Bridge for adjoining properties.
In case adjoining properties of an owner or different owner are separated by road, river, nallah etc.
then the Authority may allow the owner to construct underpass or over bridge or foot over bridge
of required size at his cost so as to ease the movement of people/vehicle across the properties.
3.4 RECREATIONAL OPEN SPACES
3.4.1 Recreational Open Space
In any layout or subdivision or any development of land for any land use/ zone admeasuring
0.4ha. or more (after deducting area under D.P/ R.P. road, D.P. Reservation including deemed
reservation under these regulations, if any, from the total area under development), 10%of the area
under layout shall be earmarked as recreational open space which shall, as far as possible, be
provided in one place. In case of land admeasuring more than 0.8ha, such recreational open space
may be allowed to be earmarked at different locations in the same layout, provided that the size
and other dimensions conform to the provisions herein below. However, the owner shall be at
liberty to provide recreational open space more than 10%.
# i) The above-mentioned area of 0.4ha., shall be measured with reference to original holding as
on 11thJanuary; 1967 and not with reference to sub-divided holding in revenue/ city survey
record thereafter without the permission under the Maharashtra Regional & Town Planning
Act, 1966. However, this provision shall not be applicable to plots compulsorily got
subdivided below 0.4 ha. due to the DP / RP Roads / Road widening/ reservations/ deemed
reservations or any other proposal of the Authority.
For the lands which are sub-divided after 11th January, 1967 without taking prior permission
from the Authority and having plot area below 0.4ha., the applicant may opt for any of the
options from: -
a) providing 10% open space subject to a minimum of 200sq.m., or
b) availing the reduced FSI of 75% of the basic FSI as otherwise permissible on such
land. In such cases, loading of TDR shall be permissible to the extent of 50%
mentioned in Chapter-6.
(#)
Clarification issued vide Order No. CR 104/2022 dt. 29th November, 2022.
c) avail full basic FSI and other permissible FSI / TDR by paying 10% value of the land
under proposal as per Annual Statement of Rates for that year, without considering
guidelines therein.
(ii) For the plots having area upto 0.4 ha. regularised under the Maharashtra Gunthewari
Development (Regularisation, Upgradation and Control) Act, 2001, no such open space shall
be required for the development permission. (1) However, for plots having area 0.4 ha. or
more regularised under this Act, all the provisions of UDCPR including Recreational Open
Space, Amenity space, shall be applicable.
(iii) Not more than 50% of such recreational open space may be provided on the terrace of a
podium in congested/non congested area subject to Regulation No.9.13.
Notwithstanding anything contained in the definition of "Recreational Open Space" in these
regulations, such recreational open space to the extent of 100% may be allowed to be
provided on the terrace of a podium if owner/developer provides 1.5 m. strip of land along
plot boundary, exclusive of marginal distances, for plantation of trees.
(iv) In case of lands declared surplus or retainable under Urban Land (C & R) Act, 1976, if the
entire retainable holding or entire surplus holding independently admeasures 0.4 ha or more,
then 10% recreational open space shall be necessary in respective holding.
(v) Such recreational open space shall also be necessary for group housing scheme or campus/
cluster planning for any use/ zone.
(vi) Such open space shall not be necessary :-
a) in cases of layout or subdivision of plots from a layout already sanctioned by the
Authority irrespective of percentage of open space left therein.
b) for development of the reservations in the Development Plans designated for the
purpose other than residential.
c) for the uses other than Residential, Industrial and Educational permissible in Agricultural
zone.
(vii) In the case of development of land for educational purpose, in lieu of 10% recreational open
space, following percentage of the gross area (or as decided by the Government from time to
time), excluding the area under Development/ Regional Plan road and Development Plan
reservations, shall be earmarked for playground. Notwithstanding anything contained in this
regulation, the shape and location of such open space shall be such that it can be properly
used as a playground. The area of such playground shall not be deducted for computation of
FSI. The independent playground of the institution attached with the school building shall
also be entitled for computation of FSI.
Provided that, in case of area more than 1ha. such area to be earmarked for playground shall
be as under :-
Sr. No. Gross Area of Land Percentage of Playground
1 Upto 1 ha. 40%
2 Above 1 ha. and upto 2 ha. area as per 1 + 35% of remaining area
3 Above 2 ha. and upto 3 ha. area as per 2 + 30% of remaining area
4 Above 3 ha. and upto 4 ha. area as per 3 + 25% of remaining area
5 Above 4 ha. area as per 4 + 20% of remaining area
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
Provided further that, in cases where space for such playground is not available because of
development permissions already granted by the Authority for education purpose and work
is completed, such space for playground may not be insisted.
viii) Such recreational open space shall not be entirely proposed in marginal distances / set back
or major part of it shall not be proposed in marginal distances / set back. However, such
recreational open space, bigger than marginal distances and confirming to the Regulation
No.3.4.6, may include part of marginal distances/ set back area, if such recreational open
space is proposed adjoining to plot boundary.
3.4.2 Recreational Open Space - Owner’s Undertaking
The owner shall give an undertaking that the recreational open space shall be for the common use
of all the residents or occupants of the layout/ building unit.
i) On sanction of the development permission, the recreational open space shall be deemed to
have been vested in the society / association of the residents / occupants of the layout/
building unit except as specified otherwise. In case such society or association is yet to be
formed, the owner shall give undertaking to the Authority at the time of occupation
certificate in case of Group Housing Scheme and at the time of final approval in case of
plotted layout, that he will transfer the recreational open space at a nominal cost of Re.1/- to
the society/ association whenever it is formed. The recreational open space shall not be sold/
leased out / allotted/ transferred for any purpose, to any other person and it shall not be put
to any other use except for the common use of society / association of the residents/
occupants as mentioned in Regulation No.3.4.7.
ii) If the Authority is convinced that, either the owner has failed to abide by the undertaking or
such open space is being used in violation of the provisions as prescribed in these
regulations, then the Authority shall take over possession of such land of recreational open
space for maintaining it for the uses permissible in these regulations, subject to condition
that it shall not be further handed over or allotted to any person/ institute/ authority other
than the society/ association of the residents/ occupants.
Provided that, it shall not bar the return of the possession of such open space to the original
society/ association of plot owners, after taking due undertaking to that effect.
Provided further that the cost incurred by the Planning Authority on maintenance of such
Recreational Open Space shall be recovered as arrears of dues to the Authority from the
owner/ society / association of the residents / occupants till reversion of the possession.
3.4.3 Recreational Open Space - Rearrangement
No permission shall be granted to delete / reduce open spaces of the existing sanctioned layout/
subdivision. However, while revising the layout, such recreational open space may be rearranged
without decrease in area subject to minimum prescribed area under these Regulations with the
consent of plot/ tenement holders/ co-owners, but such revision of recreational open space shall
ordinarily not be allowed after a period of 4 years from 1st final sanction. However, such revision
of open spaces may be allowed after 4 year also, where plots in the layout are not sold or
transferred.
3.4.4 Recreational Open Space - Exclusive
The open spaces shall be exclusive of means of accesses / internal roads / designations or
reservations, roads and areas for road widening in development plan / Regional Plan.
3.4.5 Recreational Open Space in Green Belt
Such recreational open space may be allowed to be earmarked, partly or fully, in green belt area
shown on the development plan after leaving distance of 15m. from river and 9m. from nallah,
provided, such recreational space is sizable as required under these regulations. Provided that, the
only use and structures permissible under the Regulation No.4.11 in respect of Green belt, may be
permitted in such open space.
3.4.6 Minimum Dimensions
The minimum dimension of such recreational open space shall not be less than 10m. and if the
average width of such recreational open space is less than 20m., the length thereof shall not
exceed 2 ½ times the average width.
3.4.7 Structures permitted in Open Space
If required, structure and uses which can be permitted without counting in FSI in the recreational
open spaces shall be as under:-
i) There may be maximum two storeyed structure with maximum 15% built up area of
recreational open space, out of which, built up area on ground floor shall not exceed 10%.
In case of stilt, additional floor may be allowed.
ii) The structures used for the purpose of pavilion, gymnasia, fitness centre, club house,
vipashyana and yoga centre, crèche, kindergarten, library, or other structures for the purpose
of sports and recreational activity (indoor or outdoor stadiums, etc. as per availability of
area) may be permitted. Utilities such as water tank (underground or elevated), electric
substation, generator set, pump houses, garbage treatment, public health out post/ centre may
be permitted only with the consent of the society of residents. Religious structure may be
allowed with the permission of competent Authority as decided by Government from time to
time.
iii) No detached toilet block shall be permitted.
iv) A swimming pool may also be permitted in such a recreational open space. The ownership
of such structures and other appurtenant users shall vest in all the owners on account of
whose cumulative holdings the recreational open space is required to be kept in the land.
v) The proposal for the construction of such structure should come as a proposal from the
owner/s, owners‘ society / societies or federation of owners‘ societies and shall be meant for
the beneficial use of the owners/ members of such society/ societies/ federation of societies.
vi) The remaining area of the recreational open space shall be kept open to sky and properly
accessible to all members as a place of recreation, garden or a playground.
vii) The owners‘ society / societies, the federation of the owners‘ societies shall submit to the
Authority, a registered undertaking agreeing to the conditions in (v) & (vi) above while
obtaining permission for the above said construction.
3.4.8 Recreational Open Space and Means of Access
Every plot meant for a recreational open space shall have an independent means of access. In case
of group housing scheme, if such recreational open space is surrounded by or located along
buildings and is meant for use by the occupants of those buildings, then independent means of
access may not be insisted upon.
3.5 PROVISION FOR AMENITY SPACE
(#) 3.5.1 In the areas of Local Authorities, Special Planning Authorities and Metropolitan Region
Development Authorities, Amenity Space as mentioned below on gross area after deducting area
under reservations/roads in Development Plan including proposals of road widening therein, shall
have to be provided in any layout or sub division of land or proposal for development.
Area of Land Minimum Amenity Space to be provided.
(1) a) less than 20000 Sq.m. Nil
b) 20000 Sq.m. or more 5% of the total area.
These amenity spaces shall be developed by the owner for the uses mentioned in the definition of
amenity. However, the Authority may insist for handing over the amenity space to the Authority,
if it is required for the following (2) six purposes only. If it is not required for the following (2) six
purposes and required for other purposes, it may be taken over by the Authority with the consent
of the owner.
i) Garden.
ii) Playground.
iii) Municipal School.
iv) Municipal Hospital.
v) Fire Brigade.
vi) Housing for Project affected Persons.
In such circumstances, amenity space shall deem to be reservations/ proposals in Development
Plan and Floor Space Index (FSI) in lieu thereof may be made available in-situ on remaining land.
The calculation of this in-situ FSI shall be shown on the layout / building plan. If the owner
desires to have TDR against it, instead of in-situ FSI, then he may be awarded TDR. The in-situ
FSI or TDR shall be granted only after transfer of the amenity space to the Authority. The
generation of TDR or in-situ FSI shall be equivalent to the quantum mentioned in Regulation
No.11.2 of Transferable Development Rights.
Provided that: -
i) this regulation shall not be applicable where separate amenity space is mandated by the
Government, while sanctioning modification proposal under section 37 or 20 of the Act. In
such cases, development of the amenity shall be governed by the conditions mentioned in
the said notification.
ii) amenity space shall be approachable by minimum 12m. wide road except the cases where
12m. approach road to the site is not available. If in case of B & C Class Municipal
Councils, Nagarpanchayats and R.P. areas, such amenity space may be located on 9 m. road,
however, in such case, special building on amenity plot shall not be allowed.
iii) this regulation shall not be applicable to Regulation No.4.8.1, (i.e., Regulation for allowing
Residential /Commercial user in Industrial Zone),wherein separate provision of land for
public amenities/ utilities is made.
iv) this regulation shall not be applicable where entire development permission is for amenities
specified in definition of amenity space in these Regulations and also for uses other than
residential permissible in agricultural zone. This regulation shall also not be applicable, if
construction on entire plot is for hotel building or IT establishment / building.
(1)
Substituted Vide Notification No.CR 236/18 (Part-3), dt. 16st June 2021.
(2)
Substituted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
(#)
Clarification issued vide Order No. CR 104/2022 dt. 29th November, 2022.
v) this regulation shall not be applicable to the Town Planning Scheme area under MRTP Act,
1966 or similar scheme permitted in agricultural zone.
vi) this regulation shall not be applicable for revision of earlier sanctioned development
permissions granted under the regulations in force prior to these regulations and work is
commenced, where no such amenity space has been provided in development permission
sanctioned earlier.
viii) if some amenity space is provided in the earlier permission, then the quantum of such
amenity space in the revised permission :-
a) shall be limited to the area provided in earlier permission.
b) shall not be reduced even though area of such amenity space is more than what is
specified in this regulation.
ix) if owner agrees to construct the amenity and hands it over to the Authority with consent of
the Authority, then he shall be entitled for amenity TDR / in-situ FSI as per Regulation
No.11.2.
x) the development in amenity space shall be allowed upto building potential mentioned in
Regulation No. 6.1 or 6.3.
xi) any other use, not mentioned in these regulations, may be allowed to be developed by the
Authority similar to the uses defined as amenity.
3.5.2 In case of Regional Plan areas, the percentage of amenity space to be provided shall be as
mentioned in Regulation No. 5.1.8.
3.5.3 Development of Amenity Spaces in Earlier Sanctioned Layout
Amenity spaces, which are earmarked in the layout sanctioned tentatively or finally earlier and not
so far developed, may also be allowed to be developed for any of the uses mentioned in this
regulation. Such amenity building may be allowed to be developed on the road on which such
amenity space is located in the sanctioned layout. However, special building shall require a front
road as specified in Regulation No. 3.3.9.
3.6 PROVISION FOR ELECTRIC SUB-STATION
In case of development/re-development of any land, building or premises mentioned below,
provision for electric sub-station shall be made as under, if the requirement for the same is
considered necessary by the concerned power supply authority.
Sr. No. Plot Area Maximum requirements
1 Plot above 2000 Sq.m. One single transformer sub-station of the size
of 5m.x 5m. and height of not more than 5m.
2 Layout or sub-division of a plot A suitable site for an electric sub-station as
measuring 2 .0 ha. or more. required by the Power Supply Company.
Provided that the sub-station is constructed in such a manner that it is away from main building at
a distance of at least 3 m. and in general does not affect the required side marginal distances or
prescribed width of internal access or recreational open space.
3.7 MINIMUM PLOT AREA FOR VARIOUS USES
Minimum plot area for various uses shall be as given in Table No.3D below :-
Table No.3D
Min. Plot Min. Plot
Sr.
Uses area Width Type of Development
No.
(in Sq.m.) (in m.)
1 Residential and Min 30 As per Table Row / Semi-detached / detached
Commercial No. 6 D development as specified /
anticipated in earlier approved
layout or layout to be approved in
future.
In other cases, as per
permissibility of the construction
area taking into consideration the
marginal distances.
2 Plots in EWS Housing / Min 20 Row / Semi-detached / detached.
High Density Housing / Sq.m. or as
Sites and Services / specified in
Slum Upgradation / the
Reconstruction Scheme respective
by Public Authority. scheme.
3 Vehicle fuel Filling station including LPG / CNG / Ethanol /Public Charging Stations for
Electric Vehicles-
(a) Without service As As required Detached.
required by the
bay
by the concerned
concerned authority.
authority.
(b) With service bay --do -- -- do -- Detached.
4. Industrial (other than 300 10 m. Detached.
service industries)
5 Other uses (other than 1 Required plot size and development shall be governed by
to 4 above) permissibility of construction under these regulations.
Note-
i) In case of plotted layout, the plot width to depth ratio shall be 1:1.5 to 1:2.5; as far as
possible.
ii) In case of Ulhasnagar, plot sizes and development shall be considered as per the lease or
sanad or patta granted by Government / Authority.
iii) In case of Sr. No. 1 above, pattern of development permissible within a plot shall be shown
in dotted line while approving the layout. However, change in pattern may be permitted in
future, if it fits into above pattern of development and does not disturb the overall pattern of
development already approved.
3.8 PROVISION FOR INCLUSIVE HOUSING
3.8.1 This regulation shall be applicable only to Municipal Corporations having population 10 lacs or
more as per the latest Census, as mentioned in Regulation No.3.8.2.
3.8.2 Inclusive Housing -
Provision for inclusive housing shall be applicable in following cases :-
(a) For the sub-division or layout of the land :-
For the sub-division or layout of the land admeasuring 4000 Sq.m. or more (after deducting
area under D.P. / R.P. Roads, D.P. Reservations including deemed reservations under these
regulations, if any) for residential purpose, minimum 20% of the plot area shall have to be
provided either :-
i) in the form of developed plots of 30 to 50 Sq.m. size for Economically Weaker
Sections/Low Income Groups (EWS/LIG), (hereinafter referred to as "affordable
plots") for allotment to the allottees as per the list provided by MHADA OR
ii) in the form of plot / plots equivalent to 20% plot area for constructing EWS/ LIG
tenements to be handed over to MHADA. Within this 20% area, proportionate road
and recreational open space area of this 20% space, shall be included, OR
iii) Land owner/ Developer can exercise an option to construct EWS/ LIG tenements on
the said 20% plot area as per provisions specified in subsequent regulation No (b).
Provided that the affordable Housing Plots / tenements as mentioned in (i, ii and iii)
above can also be provided at some other location(s) within 1 km. from original
location or within same ward, OR
iv) The Landowner/Developer may handover the affordable plots to MHADA at one
place in lieu of FSI / DR as per TDR regulations to be utilised on the remaining plots.
Provided that in case the Landowner / Developer desires not to utilize such additional
FSI / DR in the same land, fully or partly, then he shall be awarded TDR in lieu of
such unutilized additional FSI. The utilization of this TDR shall be subject to the
provisions of TDR regulations.
(b) For Group Housing Scheme:
For a plot of land, admeasuring 4000 Sq.m. or more (after deducting area under D.P. / R.P.
Roads, D.P. Reservations including deemed reservations under these regulations, if any) to
be developed for a Housing Scheme consisting of one or more buildings (hereinafter referred
to as 'the said Scheme'), EWS/ LIG Housing in the form of tenements of size ranging
between 30 and 50 Sq.m. (1) carpet area (hereinafter referred to as 'affordable housing
tenements) shall be constructed at least to the extent of 20% of the basic FSI subject to the
following conditions:-
i) The built up area of the EWS/ LIG tenements constructed under the Scheme shall not
be counted towards FSI and such built-up area of EWS/LIG tenements (20%) shall be
over and above the permissible FSI/ TDR as per UDCPR.
ii) The Landowner/ Developer shall construct the stock of the affordable housing
tenements in the same plot and the Authority shall ensure that the Occupation
Certificate for the rest of the development under the said scheme is not issued till the
occupation certificate is issued for the Affordable Housing tenements under the
scheme.
(1)
Substituted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
Provided further that the Affordable Housing tenements can also be provided at some
other location(s) within 1 km. from the original location or within same ward to the
extent of 40% of basic permissible FSI over and above permissible built up area of the
receiving\ alternative plot and such area shall be free of FSI on such alternative plot.
However, Affordable Housing tenements to be constructed on such alternative plot
shall be increased in proportion to the land rate of the respective lands for that year.
iii) The Owner / Developer, after getting commencement certificate of Affordable
Housing component as mentioned above shall immediately intimate to MHADA
regarding the numbers of tenement to be disposed by them to the allottees. Upon such
intimation, MHADA within a period of six months, from the date of receipt of such
intimation, after following procedure, shall send the list of allottees and forward it to
the Owner / Developer. The Owner / Developer shall allot such tenements to the
allottees at the construction cost mentioned in ASR applicable of the year of disposal
(date of occupancy certificate) plus 25% additional cost. Out of this 25% additional
cost, 1% shall be paid to MHADA towards administration charges by the Owner /
Developer.
If the allottees fails to deposit the amount in the phased manner as specified in the
agreement within specified time limit, then the allotment shall stand cancelled and in
such case the owner / developer shall dispose of such tenements in the market at the
construction cost in ASR applicable to the land of the year of disposal plus 25%
additional cost (1) to the persons belonging to the EWS/LIG category as determined by
Government in Housing Department. This shall also be applicable for plots mentioned
in (a) above.
If MHADA fails to send the list within the period of six months as specified above, ,
(1) concerned Planning Authority, after following procedure as that of MHADA shall
send the list of allottees within six months. If such Authority also fails to send the list
as specified above, the Owner / Developer shall be at liberty to dispose of the
tenements in the manner mentioned in the para above.
Provided that these regulations shall not be applicable :-
a) in case of individual bungalow irrespective of plot area, redevelopment of
existing buildings of Co-operative societies / development of buildings of
Government / Semi-Government / Government controlled bodies including
BOT / PPP projects or projects under taken through agency development
under Regulation No.7.3, development of MHADA colony under Regulation
No.7.4, Development of housing for EWS / LIG under Regulation No.7.7,
Development of PMAY under Regulation No.14.4,any development in
agriculture (or equivalent) zone.
b) in case of development of reservation for Public Housing, Housing the Dis-
housed, Public Housing / High Density Housing and the EWS/ LIG tenements
constructed under the provisions of any other Act, land exempted and
developed for weaker section housing scheme under section 20 of ULC Act
and allowing Residential / Commercial user in Industrial zone.
c) if company/ factory establishment proposes to construct staff quarters for their
staff on their own land and such construction which is meant to be used for
only staff quarters and not for sale of tenements/ flats.
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
d) lands reserved in Development Plan which are being developed under
Accommodation Reservation policy.
e) For any Housing Scheme or residential development project wherein, owing
to the relevant provisions of the Development Control Regulations / Laws,
20% or more of the basic FSI is required to be utilized towards construction of
residential tenements for the EWS/ LIG.
iv) The Landowner / Developer may also be permitted to utilise 1/4th of the total
20% FSI earmarked for Affordable Housing towards construction of
Affordable Housing Tenements in the form of service quarters in the same or
separate building which shall have to be sold as service quarters only to the
purchasers of free sale flats under the said scheme.
v) Affordable Housing tenements to be constructed to the extent of 20% of basic
FSI only and shall not be required on additional FSI/ TDR wherever
permissible as per UDCPR.
vi) Amalgamation of affordable plots/ affordable tenements shall not be allowed.
vii) The Government may nominate any other Authority instead of MAHADA
mentioned in the above Regulation, if required in future.
(c) Prospective Applicability: These Provisions shall be applicable prospectively and shall
not be applicable to revised permission of any Layout, Housing Scheme or residential
development project wherein Commencement Certificate has been issued prior to the date
of coming into force of these provisions and is valid on such date. However, this provision
shall be applicable to revised permission where revised permission is sought including
additional area more than 4000. In such case, this provision shall be applicable to
additionally included area.
Provided that, earlier permission wherein provision for affordable housing is made in
accordance with the then prevailing regulations, shall also be entitled for revision under
this regulation.
3.8.3 If owner/developer desires to construct inclusive housing, even though it is not mandatory,
inclusive housing may be provided with prior NOC from MHADA with respect to requirement of
EWS / LIG housing, then in addition to basic entitlement he shall be entitled for, additional 25%
FSI of the land covered under Inclusive Housing on his remaining land.
3.8.4 Provision of Inclusive Housing shall not be applicable, if the plots are auctioned by public
authorities without the condition of providing Inclusive Housing before coming into force of these
regulations. However, it shall be mandatory on public authorities to stipulate the condition of
providing Inclusive Housing as per provision of this regulation, while auctioning the plots
hereinafter, wherever applicable.
3.9 NET PLOT AREA AND COMPUTATION OF FSI
For the purpose of computing FSI/ Built-up area, the net area of the plot shall be as under :-
i) In case of a plotted layout/ sub-division/ group housing scheme/ any development, net area
shall be the balance plot area after deducting the area covered by amenity space under
Regulation No.3.5 and Development/ Regional Plan proposals including new roads and road
widening, if any, from the total area of plot.
ii) For the purpose of computation of FSI/ built-up area, the net area of the plot shall only be
considered.
iii) In case of plotted layout, the basic FSI of such net area shall be distributed on all plots on
pro-rata basis or on certain plots as land owner desires, subject to maximum receiving
potential prescribed in these regulations. However, such entitlement of FSI on certain plots
shall be clearly mentioned on the layout plan.
iv) In case of plots from already approved layouts, the plot area shall be treated as net plot area.
v) The above regulations in respect of net plot area and computation of FSI shall apply to
proposals in all land use zones.
3.10 TRANSFER OFLAND UNDER DP SITES (OTHER THAN DP ROAD) IN LIEU OF FSI
If in any development proposal, owner desires to hand over the reserved site / area free of cost to
the Authority, then FSI of such reserved site / area equivalent to the TDR may be allowed to be
utilized on the remaining land. Transfer deed to that effect shall be executed and FSI calculation
shall be mentioned on the plans of development proposal. In case of plotted layout, distribution of
FSI on plots in pursuance of such transfer shall be as desired by the owner and upto maximum
building potential according to road width as mentioned in regulation no.6.3. It may differ from
plot to plot, however the receiving plot shall front on road having minimum 9 m. width. If some
FSI remains unutilized, the owner shall be entitled for TDR against the remaining FSI. In such
cases where in-situ FSI is proposed to be used, the procedure of DRC shall not be insisted.
3.11 RELOCATION OF DP-RP SITES / ROADS
If the land proposed to be laid out for any development is affected by any reservations of public
purposes, the Authority may allow adjusting the location of such reservation to suit development
without altering the area of such reservation. Provided that such shifting of the reservations shall
not be permitted:-
a) If the reservation proposed to be relocated is in parts;
b) If the reservation proposed to be relocated is beyond 500 m. from the original location in the
Development Plan;
c) If the reservation proposed to be relocated is beyond the holding of the same owner;
d) Unless the alternative location and size is at least similar to the location and size of the
Development Plan as regards access, levels, etc.;
e) If the reservation is already relocated under these regulations;
f) If the land is reserved considering its geographical location like Bio-Diversity Proposal,
Nallah training reservation etc. and;
g) Unless the relocation is within area covered by the layout or development permission under
sanction.
All such relocation of the reservations shall be carried out by the Authority and shall be reported
to the Government and Director of Town Planning, Maharashtra State at the time of sanctioning
the development permission. The Development Plan is deemed to be modified to that extent.
Notwithstanding anything contained in this regulation, the relocation of the reservation from a
land may also be permitted on any land within 300 meters belonging to other owner‘s land if the
said other owner consents (by way of registered deed) to such relocation of reservation on his land
and consents to hand over his land to the Planning Authority where reservation is proposed to be
relocated in lieu of TDR and also subject to restrictions mentioned in above sub regulation No.
(d), (e), and (f). In such case, the other owner may not be insisted to submit the layout or
development proposal for his land.
In case of shifting of road alignment, the same shall be allowed without change in the inlet &
outlet points and also, without affecting smooth flow of traffic.
Provided that such shifting shall be carried out by the Authority in consultation with Divisional
Joint Director of Town Planning in case of D class Municipal Corporations, Municipal Councils,
Nagar Panchayats and Regional Plan areas.
In such case of shifting, the Development Plan / Regional Plan shall be deemed to be modified to
that extent.
3.12 AMALGAMATION OF PLOTS
i) Amalgamation of plots / lands shall be permissible if they form a sizable plot from planning
point of view and are contiguous. Amenity and layout plot shall also be entitled for
amalgamation provided amenity is developed on proportionate area.
ii) The amalgamation of plots from approved layout which is not desirable from planning point
of view (e.g. as shown in below) shall not be permitted.
iii) Land separated by minor water course or nallah or road may be entitled for amalgamation
provided connecting over bridge or under pass of sufficient width and strength is constructed
by the owner with the approval of the Authority.
3.13 DEVELOPMENT OF CYCLE TRACK ALONG RIVER AND NALLAH
3.13.1 A regulation in respect of development of cycle track along river and nallah for Nashik Municipal
Corporation area is given at Regulation No. 10.5.2.
3.13.2 For other Municipal Corporations, following regulations shall be applicable.
A cycle track shall be developed in green belt areas earmarked on Development Plan along the
rivers. Also, cycle track be developed along the major nallah.
A distance of 6 m. from the edge of minor water course (nallah) is to be left as marginal distance
for construction of any building. A 3 m. strip of land from the edge of such water course out of
this 6 m. distance to be left, shall be available for use as cycle track for general public. The
compound wall shall be constructed excluding this distance of 3 m. strip for cycle track. The
owner shall be entitled for FSI of this strip of land for cycle track, in-situ. This 3m. wide strip
shall be handed over to Municipal Corporation for which, owner shall be entitled for TDR or in-
situ FSI equivalent to 35% of the area of 3 m. wide strip. This regulation shall be applicable for
development of land along Nallahs and Green Belt areas as and when it is notified by the
Municipal Commissioner after identifying such green belt and Nallahs. Where development is
already taken place and it is not possible to make provision for such 3 m. wide cycle track, then
Municipal Commissioner shall not identify such green belt / Nallahs.
-*-*-*-*-*-