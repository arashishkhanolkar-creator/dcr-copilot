# Chapter 9: Requirements of Part of Building

CHAPTER - 9
REQUIREMENTS OF PART OF BUILDING
9.0 STANDARD REQUIREMENTS OF VARIOUS PARTS OF BUILDINGS.
This part sets out the standard space requirements of various parts of building, light and
ventilation, the building services, fire safety, etc. The following parts of a building, wherever
present, shall conform to the requirements given herein:
9.1 PLINTH
i) The plinth of building shall be so located with respect to the surrounding ground level that
adequate drainage of the site is assured. The height of the plinth shall not be less than
30cm. above the surrounding ground level. In areas subjected to flooding, the height of the
plinth shall be at least 45cm. above the high flood level.
ii) Covered parking spaces and garages shall be raised at least 15 cm. above the surrounding
ground level and shall be satisfactory drained.
9.2 HABITABLE ROOMS
9.2.1 Size and Dimension of Habitable Rooms
Size and dimension of habitable rooms, shall be as per requirement and convenience of the
owner.
9.2.2 Height of Habitable Rooms
The minimum and maximum height of a habitable room shall be given in Table No.9A
hereunder:
Table No. 9 A
No. Occupancy Minimum Maximum Height
Height (m) (m)
(1) (2) (3) (4)
1 Flat Roof -
a) Any habitable room 2.75 4.5
a1) Habitable room in EWS / LIG Housing. 2.75 4.2
b) Air-conditioned habitable room 2.4 4.5
c) Assembly Halls, Residential Hotels of 3 3.0 6.00 or higher
star category and above, Institutional, according to the
(2.40 m. in case
Educational, Industrial, Hazardous or storage requirement of
of Air
occupancies, Departmental Stores, Malls, IT occupancy.
conditioned
Buildings, Office Buildings, Exhibition
room)
Centre, Convention Hall, Theatre, Film
Studio, Entrance Halls and Lobbies to these
buildings.
d) Shops 3.00 4.5
2 Pitched roof-
a) Any habitable room 2.75 (average 4.5 (average with
with2.0 m. at the
3.2 m. at the lowest
lowest point)
point)
b) Habitable room in EWS / LIG Housing. 2.6 (average with 4.2 (average with
2.0 m. at the
3.2 m. at the lowest
lowest point)
point)
Provided that the minimum head-way under any beam shall be 2.4 m.
Provided further that height more than that specified above, if required for particular occupancy,
shall not be counted towards calculation of FSI.
9.3 KITCHEN
9.3.1 Size of Kitchen
The size of kitchen or a cooking alcove serving as cooking space shall be as per requirement and
convenience of the owner.
9.3.2 Height of Kitchen
The height of a kitchen measured from the surface of the floor, to the lowest point in the ceiling
(bottom of slab) shall not be less than 2.75 m. except for the portion to accommodate floor trap
of the upper floor.
9.4 BATH ROOMS, WATER CLOSETS, COMBINED BATH ROOM AND WATER
CLOSET
9.4.1 Size of bath room and water closet
Minimum size shall be as under
i) Independent Bath room 1.00 m. x 1.20 m.
ii) Independent Water closet 0.9 m. x 0.9 m.
iii) Combined bath room and water closet 1.50 Sq.m. with minimum width or 1.00m.
9.4.2 Height of bath room and water closet
The height of a bathroom or water closet measured from the surface of the floor to the lowest
point in the ceiling (bottom of slab) shall be not less than 2.1m.
9.4.3 Other requirements of bath room and water closet
Every bathroom or water-closet shall -
i) be so situated that it derives ventilation from ventilation shaft or external air,
ii) have a window or ventilator, opening to a shaft or open space, of area not less than
0.3sq.m. with side not less than 0.3m.
iii) all the sewerage outlets shall be connected to the sewerage system. Where no such systems
exist, a septic tank shall be provided within the plot conforming to the requirements of
Regulation No.9.25
9.5 LEDGE OR TAND / LOFT
9.5.1 Location and extent
Ledge or Tand may be provided at suitable places as per requirement. Lofts may be provided
over kitchen, habitable rooms, bathrooms, water closets, and corridor within a tenement in
residential buildings, over shops and in industrial building, as mentioned in below Table No. 9
B subject to the following restrictions-
i) The clear head room under the Loft shall not be less than2.1 m.
ii) Loft in commercial areas and industrial building shall be located 2 m. away from the
entrance.
iii) Loft shall not interfere with the ventilation of the room under any circumstances.
iv) The maximum height of loft shall be 1.5m.
Table No.9 B - Provision of Loft
Sr. Maximum Coverage
Rooms over which Permitted
No. (Percentage to area or room below)
(1) (2) (3)
1 Kitchen/Habitable room 25
2 Bathroom, water closet, corridor 100
3 Shops with width up to 3m. 33
4 Shops with width exceeding 3m. 50
5 Industrial 33
9.5.2 Location and extent of Ledge for Air Conditioning unit
Ledge for Air Conditioning unit may be provided on the exterior of wall of the rooms of size not
exceeding 0.5 m. x 1.0 m. at suitable location.
9.6 CUPBOARD
9.6.1 In residential buildings, cantilever projections of cupboards, floor to floor level, may be
permitted except on ground floor. Such projections excluding window area, may project upto
0.60 m. in the setbacks for buildings. However, the window frame shall be placed on the inner
side of the wall and such cupboard shall be allowed only on one wall of each room. Moreover,
such projection shall be at least 6m. from plot boundary in case of special buildings.
9.6.2 For height 24 m. and more no cupboard shall reduce the marginal open space to less than 6 m.
on first floor and 4.5 m. on upper floor. In congested area cupboard may be permitted on upper
floors projecting in front setbacks except over lanes having width 4.50 m. or less and in
marginal distances subject to 1.0 m. clear marginal distance from the plot boundary to the
external face of the cupboard.
9.7 MEZZANINE FLOOR
9.7.1 Size of Mezzanine Floor
The minimum size of the mezzanine floor shall be as per requirement and convenience of
owner. The aggregate area of such mezzanine floor shall in no case exceed 50% of (1) carpet
area of that room, shops, etc. Where loft is provided in the room, the mezzanine floor shall not
be allowed.
Note - Mezzanine floor area shall be counted towards FSI.
(1)
Substituted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
9.7.2 Height of Mezzanine Floor
The head room under mezzanine floor shall not be less than 2.1 m.
9.7.3 Other requirements of mezzanine floor
A mezzanine floor may be permitted in a room or within a space, provided
i) it conforms to the standards of living rooms as regards lighting and ventilation in case the
mezzanine floor is used as habitable room.
ii) it is so constructed as not to interfere, under any circumstances, with the ventilation of the
space over & under it.
iii) such mezzanine floor or any part thereof will not be used as a kitchen.
iv) it is atleast 1.8 m. away from front wall of such rooms.
v) access to the mezzanine floor is from within the respective room only.
vi) in no case shall a mezzanine floor be closed so as to make it liable to be converted into
unventilated compartments.
9.8 STORE ROOM
9.8.1 Size of Store Room
The area of a store room/ rooms, if provided in a residential building, where light, ventilation
and height are provided at standards lower than as required for living room, shall be as per
requirements and convenience of the owner.
9.9 GARAGE
9.9.1 Size of private Garage
The size of a garage in individual residential building shall not be less than 2.5 m. x 5.0 m. and
not more than3.0m. x 6.0m.The garage, if located in the side open space, shall not be
constructed within 3.0 m. from the main building, but at least 7.5 m. away from the any access
road. The area of garage shall be including in FSI.
9.9.2 Height of private Garage
The minimum and maximum height of garage shall be 2.4 m. and 2.75 m. respectively.
9.9.3 Plinth of private Garage
The plinth of garage located at ground level shall not be less than 15 cm. above the surrounding
ground level.
9.9.4 Set Back of private Garage
The garage shall be set-back behind the building line for a street or road on which the plot abuts
and shall not be located affecting the access ways to the building.
When the site fronts on two streets, the location of a garage (in a corner plot) (if provided within
the marginal distances) shall be on diagonally opposite the point of intersections.
9.10 ROOFS
9.10.1 The roof of a building shall be so constructed or framed as to permit effectual drainage of the
rainwater there from by means of sufficient rainwater pipes of adequate size, wherever required,
so arranged, jointed and fixed as to ensure that the rainwater is carried away from the building
without causing dampness in any part of the walls or foundations of the building or those of an
adjacent buildings.
9.10.2 Top Terrace of a building shall not be sub-divided and it shall have only common access.
However, intermediate terraces may be allowed to be attached with flat and shall not be counted
in balcony area.
9.10.3 The Authority may require rainwater pipes to be connected to a drain or sewer through a
covered channel formed beneath the public foot path to connect the rainwater pipe to the road
gutter or in any other approved manner, if not used for rain water harvesting.
Rainwater pipes shall be affixed to the outside of the walls of the buildings or in recesses or
chases cut or formed in such walls or in such other manner as may be necessary.
9.11 BASEMENTS
9.11.1 Basement shall generally be constructed within the prescribed setbacks / margins with one or
more level.
Following uses shall be permissible at free of FSI.
i) Air-conditioning equipment‘s and other machines used for services and utilities of the
building;
ii) Parking spaces;
iii) D.G. set room, meter room and electric substation (which will conform to required safety
requirements),Effluent Treatment Plant, suction tank, pump room;
Following uses shall be permissible and counted in FSI.
a) Storage of household or other goods or ordinarily non-combustible material incidental to
principle use;
b) Strong rooms, bank lockers, safe deposit vaults, laundry room, Radio/ laser therapy, post
mortem room, mortuary, medical shop and cold storage for hospital building etc.
c) Commercial use in first basement in case of shopping centre/ shopping malls.
d) Uses strictly ancillary to the Principal use.
e) Nursing quarters as ancillary use to hospital in first basement, if it is 0.9 to 1.2 m. above
ground level with proper ventilation.
Provided that,
i) If the basement is proposed flushing to average surrounding ground level, then such
basement can be extended in side and rear margins upto 1.5 m. from the plot boundary.
ii) Multilevel basements may be permitted if the basement is used for parking.
9.11.2 The basement shall have the following requirements -
a) Every basement shall be in every part at least 2.4 m. in height from the floor to the soffit
of beam.
b) Adequate ventilation shall be provided for the basement with a ventilation area not less
than 2.5% of the area of the basement. Any deficiency may be met by providing adequate
mechanical ventilation in the form of blowers, exhaust fans or air-conditioning systems,
etc.;
c) The minimum height of the ceiling of any basement shall be 0.9 m. and the maximum
shall be 1.2 m. above the average surrounding ground level. However, it does not apply to
the mechanically ventilated basements. In such cases, basement may also be allowed
flushing to the average ground level;
d) Adequate arrangements shall be made so as to ensure that surface drainage does not enter
the basement;
e) The walls and floors of the basements shall be water-tight and be so designed that the
effect of the surrounding solid and moisture, if any, is taken into account in design and
adequate damp proofing treatment is given. In case of special building, where, movement
of fire fighting vehicle is proposed on the basement flushing to the ground level, the slab
of the basement shall be designed to withstand the pressure of fire fighting vehicle.
f) The access to the basement shall be separate from the main and alternate staircase
providing access and exit from higher floors. Where the staircase is continuous, the same
shall be enclosed type serving as a fire separation from the basement floor and higher
floors. Open ramps shall be permitted subject to the provision of Regulation No. 9.12.
9.12 RAMP
9.12.1 Non Vehicular Ramp
All the requirements of stairways in Regulation No. 9.28.8shall apply mutatis mutandis to non-
vehicular ramp. In addition, the following requirement shall be complied with.
a) Ramps with a slope of not steeper than 1 in 10 may be substituted for and shall comply
with all the applicable requirements of required stairways as to enclosure, capacity and
dimensions. In certain cases, steeper slopes may be permitted but in no case greater than 1
in 8shall be permitted. Ramps shall be surfaced with approved non-slipping material.
Provided that in the case of public offices, hospitals, assembly halls, etc. the slope of the
ramp shall not be more than 1:12.
b) The minimum width of the ramps in hospitals shall be 2.25 m.
c) Handrails shall be provided on both sides of the ramp.
d) Ramps shall lead directly to outside open space at ground level or courtyards or safe place.
e) For building above 24 m. in height, access to ramps from any floor of the building shall be
through smoke stop door.
f) When there is a difference in level between connected areas for horizontal exits, ramps not
more than 1:10 slope shall be provided; steps shall not be used.
g) In case of non-special building, ramp may be permitted in side marginal distances. In case
of special building, ramps may be permitted in side marginal distances, after leaving 6 m.
marginal distance for movement of fire fighting vehicle.
9.12.2 Ramp to basements and upper storeys for vehicles
For parking spaces in a basement and upper floors, at least two ramps of minimum 3 m. width
with slope not more than 1:8 shall be provided, preferably at the opposite ends. Instead of two
ramps, one ramp of 6 m. width may be allowed. In addition to these, the owner may provide car
lifts, if he so desires.
If the ramp is proposed to be used only for two wheeler then at least two ramps of 2 m. width
with slope not more than 1:8 shall be provided, preferably at the opposite ends. Instead of two
ramps one ramp of 4 m. width may be allowed.
In case of plot admeasuring 1000 sq. m. or less, only one ramp of 3 m. may be provided for
(1) car / two wheeler parking or one ramp of 2 m. may be provided for two wheeler parking (1)or
the owner may provide minimum 2 Car lifts instead of Ramp.
In case of plot admeasuring up to 2000 Sq.m., one ramp of minimum 6 m. width may be
provided for car / two wheeler parking or the owner may provide minimum 2 Car lifts instead of
Ramp.
(2) Note - Sub Regulation No. 9.12.1 (g) shall also be applicable in this regulation.
9.13 (#) PODIUM
Podium for parking of the vehicles and other uses mentioned herein, may be permitted with
following requirements / conditions:
i) Height of the podium shall be at least 2.4 m. from the floor to the soffit of beam.
ii) Podium maybe allowed at a distance of 6m. from front, side and rear of the plot boundary
in case of special building, subject to provisions of Regulation No. 6.2.3.(c).
iii) Podium shall be designed to take load of fire engine, if required.
iv) Recreational open space may be permitted on Podium subject to regulation No. 3.4.1 (iii).
The structure mentioned in Regulation No. 3.4.7 may be permitted over the podium on
which recreational open space is provided, subject to 15% area of such recreational open
space.
v) Podium shall be permissible joining two or more buildings or wings of buildings, subject
to availability of manoeuvring space for fire engine. In such case, the distance between
two buildings/wings of the building shall be provided as otherwise required under these
Regulations.
vi) Part of the podium may be used for recreation or play area for schools.
vii) Part of the podium may be used for club house subject to regulation No. 3.4.7 (i).
9.14 BALCONY
Balcony or balconies of a minimum width of 1m. and maximum of 2m. may be permitted in
residential and other buildings at any floor except ground floor, and such balcony projection
shall be subject to the following conditions:-
i) In non-congested area, no balcony shall reduce the marginal open space (including front)
to less than 2m. upto 24m. building height. For height 24m. and more no balcony shall
reduce the marginal open space to less than 6m. on first floor and 4.5 m. on upper floor. In
congested area balcony may be permitted on upper floors projecting in front setbacks
except over lanes having width 4.50m. or less and in marginal distances subject to 1.0m.
clear marginal distance from the plot boundary to the external face of the balcony.
ii) Balcony, though not cantilever, shall be allowed on ground floor, after leaving required
setback/ marginal distances.
iii) The width of the balcony shall be measured perpendicular to the building up to the
outermost edge of balcony.
iv) The balcony may be allowed to be enclosed in the room, at the time of development
permission, if desired by the owner / developer. In such case depth of the enclosed
balcony shall not exceed 1/3 of the depth of the room. (including the depth of balcony)
v) Nothing shall be allowed beyond the outer edge of balcony.
(1) Inserted / Substituted Vide Corrigendum / Addendum No.CR 79/2021, dt. 02nd December 2021.
(2)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
(#) Clarification issued vide Order No. CR 236/18 (Part 2), dt., 23rd December, 2021.
9.15 SUPPORTED DOUBLE HEIGHT TERRACES
Supported double height terraces shall be permitted (open terraces with railing and minimum
height equal to two floors) within the building line.
9.16 STILT
A stilt with one or more levels may be permitted underneath a building. The height of the stilt
floor below the soffit of the beam shall not be less than 2.4 m. Atleast two sides of the stilt shall
be open. In case of stack parking, clear height of 4.50 m. shall be maintained. The open stilt
portion shall not be used for any purpose other than for vehicles parking or play area for
children. However, habitable use may be allowed in part of the stilt which shall be counted in
F.S.I. In case of stilt at ground floor plinth of stilt shall not be more than 15 cm. from
surrounding ground level.
9.17 CHIMNEYS
Chimney, where provided, shall conform to the requirements of Indian Standard Code of
Practice for Fire Safety of Building. Provided that the Chimney shall be built at least 0.9 m.
above flat roof. In the case of sloping roofs, the chimney top shall not be less than, 0.6 m. above
the ridge of the roof in which the chimney penetrates.
9.18 LETTER BOX
A letter box of appropriate dimensions shall be provided on the ground floor of residential and
commercial buildings.
9.19 METER ROOM
Meter room shall be provided as per the requirement of M.S.E.D.C.L. or power supply company
as per the number of tenements/ units.
9.20 LIGHTING AND VENTILATION OF ROOM
9.20.1 Adequacy and manner of provision
i) The minimum aggregate area of opening of habitable rooms and kitchens excluding doors
shall be not less than 1/10th of the floor area of the room.
ii) No portion of a room shall be assumed to be lighted, if it is more than 7.5 m. away from
the opening assumed for light and ventilation, provided additional depth of any room
beyond 7.5 m. may be permitted subject to provision of proportionate increase in the area
of opening.
iii) A staircase shall be deemed to be adequately lighted and ventilated, if it has one or more
openings and area taken together admeasures not less than 1 Sq.m. per landing on the
external wall.
iv) An opening with a minimum area of 1 Sq.m. in a kitchen, and 0.30 Sq.m. with one
dimension of 0.30 m. for any bathroom, water closet or store shall be treated as adequate.
9.20.2 Ventilation Shaft
For ventilating the spaces for water closets & bathrooms, if not opening on front, side, rear &
interior open spaces, these shall open on the ventilation shaft, the size of which shall not be less
than the values given in table below:-
Table No. 9 C - Ventilation Shaft
Sr. Height of Cross-section of Ventilation Minimum one dimension of
No. Buildings in m. shaft in Sq.m. the shaft in m.
(1) (2) (3) (4)
1 Upto10 1.2 0.9
2 Upto12 2.4 1.2
3 Upto 18 4.0 1.5
4 Upto 24 5.4 1.8
5 Upto30 8.0 2.4
6 Above 30 9.0 3.0
Note :-
a) For buildings above 30m., mechanical ventilation system shall be installed besides the
provisions of minimum ventilation shaft.
b) For fully air-conditioned residential/ other buildings, the ventilation shaft need not be
insisted upon, provided the air-conditioning system works in an uninterrupted manner, also
provided; there is an alternative source of power supply.
9.20.3 Artificial Lightning and Mechanical ventilation
Where lighting and ventilation requirements are not met through day-lighting and natural
ventilation, they shall be ensured through artificial lighting and ventilation in accordance with
the provisions of Part 8, Building Services- Section 1, Lighting and Ventilation, National
Building Code of India.
9.21 OVERHEAD TANKS
Every overhead water storage tank shall be maintained in a perfectly mosquito-proof condition
by providing a properly fitting hinged cover and every tank more than 1.5 m. in height shall be
provided with a permanently fixed iron ladder.
9.22 PARAPET
Parapet walls and handrails provided on the edges of roof terraces, podium, balcony, varandah
and recreational floor shall not be less than 1.0 m. and not more than1.2 m. in height from the
finished floor level. In case of occupancies like educational, health etc. such parapet may be
permitted upto 2.00 m. height.
9.23 CABIN
Where cabins are provided, the size of cabins shall be 3.0 Sq.m. with a minimum width of 1m.
The clear passages within the divided space of any floor shall not be less than 0.9 m. and the
distance from the farthest space in a cabin to any exit shall not be more than 18.5 m.
9.24 WELLS
Wells intended for supply of water for human consumption or domestic purposes may be
permitted at suitable place in a plot.
9.25 SEPTIC TANKS
Every building or group of buildings together shall be either connected to a Drainage system or
be provided with sub-soil dispersion system in the form of septic tank of suitable size and
technical specifications. Modern methods of disposals, as may be specified by Government/
Government bodies such as NEERI etc. may also be permissible.
9.26 BOUNDARY / COMPOUND WALL
i) The maximum height of the front compound wall shall be 1.5 m. above the central line of
the front street. Compound wall up to 2.4 m. height may be permitted, if the top 0.9 m. is of
open type construction. The maximum height of side and rear compound wall shall be 1.5
m. above the average ground level of the particular plot.
ii) In case of a corner plot, the height of the boundary wall shall be restricted to 0.75 m. for a
length equal to fanning of the road on the front and side of the intersection and the
remaining height of 0.75 m., if required, in accordance with sub-regulation (i) above, may
be of open type construction (railings).
iii) The provision of sub-regulations (i) and (ii) above shall not be applicable to boundary walls
of jails.
iv) In the case of industrial buildings, electric sub-stations, transformer stations, institutional
buildings like sanatoria, hospital, industrial building like workshops, factories and
educational buildings like schools, colleges including the hostels and other user of public
utility undertakings the height up to 2.4 m. may be permitted by the Authority.
v) The gates in a compound wall shall not open on any public access/ pathway / road / street
and shall open entirely inside the property.
9.27 PROVISION OF LIFT
9.27.1 (#) Planning and Design
Atleast one lift shall be provided in every building more than 15 m. in height. In case of
buildings more than 24 m. height, atleast two lifts shall be provided. However, in case of a
proposal to add one additional floor to an existing building having a lift, it will not be necessary
to raise the existing lift to the additional floor.
For building or floors of the building to be constructed for Retirement Home or Senior Citizen
Housing, lift shall be provided irrespective of height of building.
The planning and design of lifts including their number, type and capacity depending on the
occupancy of the building, the population of each floor based on the occupant load and the
building height shall be in accordance with Section 5 - Installation of Lift & Escalators of Part
VIII - Building Services of National Building Code of India.
All the floors shall be accessible for 24 hours by the lifts. The lifts provided in the buildings
shall not be considered as a means of escape in case of emergency. Grounding switch at ground
floor level to enable the fire service to ground the lift cars in an emergency shall also be
provided.
The lift machine rooms shall be separate and no other machinery shall be installed therein.
9.27.2 Fire Lift
Fire lift shall be provided as mentioned in Regulation No.9.29.8.
(#) Clarification issued vide Order No. CR 236/18 (Part 2), dt., 23rd December, 2021.
9.28 EXIT REQUIREMENTS
9.28.1 The following General requirements shall apply to exits
a) In every building or structure, exits shall comply with the minimum requirements of this
part, except those not accessible for general public use.
b) Every exit, exit access or exit discharge shall be continuously maintained free of all
obstructions or impediments to full use in the case of fire or other emergency.
c) Every building meant for human occupancy shall be provided with exits sufficient to
permit safe escape of occupants, in case of fire or other emergency.
d) No building shall be so altered as to reduce the number, width or protection of exits to less
than that required.
e) Exits shall be clearly visible and the route to reach the exits shall be clearly marked and
signs posted to guide the occupants of the floor concerned.
f) All exits shall provide continuous means of egress to the exterior of a building or to an
exterior open space leading to a street and,
g) Exits shall be so arranged that they may be reached without passing through another
occupied unit.
9.28.2 Type of Exits
An exit may be a doorway, a corridor, a passage or a way to an internal staircase or external
staircase, ramp or to a varandah and/or terraces which have eaves to the street or to roof of a
building. An exit may also include a horizontal exit leading to an adjoining building at the same
level. Lifts and escalators shall not be considered as exits.
9.28.3 Number and Size of Exits
The requisite number and size of various exits shall be provided, based on number of occupants
in each room and floor based on the occupant load, capacity of exits; travel distance and height
of building as per provisions of Regulation No. 9.28.4.to Regulation No. 9.28.8.
9.28.4 Arrangement of Exits
Exits shall be so located that the travel distance on the floor shall not exceed as given below :-
Table No. 9 D
Type of Building Travel Distance
Residential, Educational, institutional and 22.5 m.
Hazardous occupancies
Assembly, business, mercantile, Industrial and 30.0 m.
Storage Occupancies.
Whenever more than one exit is required for a floor of a building, exits shall be placed at remote
from each other as possible. All the exits shall be accessible from the entire floor area at all floor
levels.
(1) Note - For the buildings where sprinkler system has been provided in entire building for fire
fighting, the travel distance may be increased by 50% of the value specified in above table.
(1) Inserted Vide Corrigendum / Addendum No.CR 79/2021, dt. 02nd December 2021
9.28.5 Occupant Load
For determining the exits required, the number of persons within any floor area or the occupant
load shall be based on the actual number of occupants, but in no case less than that specified in
Table No. 9 E below :-
Table No. 9 E
Sr. Occupant Load Floor
Group of Occupancy
No. Area in Sq.m. per person
(1) (2) (3)
1 Residential 12.5
2 Educational 4.0
3 Institutional 15 (See Note i)
4 Assembly
a) With fixed or loose seat and dance 0.6 (See Note ii)
floors
b) Without seating facilities including 1.5(See Note ii)
dining rooms
5) Mercantile
a) Street floor & Sales basement 3
b) Upper sale floors 6
6) Business and industrial 10
7) Storage 30
8) Hazardous 10
Note:
i) Occupant load in dormitory portions of homes for the aged, orphanages, insane, asylums
etc. where sleeping accommodation provided, shall be calculated at not less than 7.5 Sq.m.
gross floor area per person.
ii) The gross floor area shall include, in addition to the main assembly rooms or space, any
occupied connecting room or space in the same storey or in the storeys above or below
where entrance is common to such rooms and spaces and they are available for use by the
occupants of the assembly place. No deductions shall be made in the area for corridors,
closets or other subdivisions, that area shall include all space serving the particular
assembly occupancy.
9.28.6 Capacity of Exits
1) The unit of exit width use to measure the capacity of any exit should be 50 cm. A clear
width of 25 cm. should be counted as additional half unit. Clear width less than 25 cm.
should not be computed for exit width.
2) Occupants per unit exit width shall be in accordance with Table No.9 F
Table No. 9 F
Sr. Number of Occupants
Group of Occupancy
No. Stairways Ramps Doors
(1) (2) (3) (4) (5)
1 Residential 25 50 75
2 Educational 25 50 75
3 Institutional 25 50 75
4 Assembly 40 50 60
5 Business 50 60 75
6 Mercantile 50 60 75
7 Industrial 50 60 75
8 Storage 50 60 75
9 Hazardous 25 30 40
9.28.7 Provision for Staircase
All buildings having height more than ground floor shall have provision of one staircase. The
special buildings specified in Regulations No. 1.3(93)(xiv) shall have two staircases out of
which one shall be fire escape staircase.
They shall be of enclosed type. At least one of them shall be on external walls of buildings and
shall open directly to the exterior, interior open space or to an open place of safety. Further, the
provision or otherwise of alternative staircases shall be subject to the requirements of travel
distance being complied with.
A staircase shall not be provided around the lift shaft unless provided with fire stop door of 1
hour rating at every floor level and no other openings in the inside wall as illustrated below.
9.28.8 Width of stair case
The minimum width of staircases/ corridors for various buildings shall be as below.
Table No.9G-Minimum width of staircase
Minimum width of
S. No Use of Building
Stair Case (in m.)
1 Residential Buildings
a) Individual Housing upto G + 2 storeys 0.75
b) Multi-storied Residential Building upto 15 m. height
1.00
c) Multi-storied Residential Building above 15 m. &
1.20
upto 24 m. height
(#) d) Multi-storied Residential Building above 24 m. height 1.50
(#)
Clarification issued vide Order No. CR 236/18 (Part 2), dt, 23rd December, 2021.
2 Residential hotel buildings 1.50
3 Assembly Building likes auditorium, theatres, cinemas, 2.00
multiplex, mangal karyalaya, marriage halls, etc.
4 Institutional &Educational Buildings. 2.00
5 All other buildings excluding Sr.No. (1) to (4) above 1.50
(1) Note - Internal staircase for duplex tenements shall be of minimum width 0.75 m. and for
mezzanine floor shall be of minimum width 0.90 m.
9.29 OTHER REQUIREMENTS OF INDIVIDUAL EXIT AT EACH FLOOR
The detailed requirements in respect of exits shall be as provided in Regulations No.9.29.1to
9.29.8 given below.
9.29.1 Doorways
i) Every exit doorway shall open into an enclosed stairway or a horizontal exit, or a corridor
or passageway providing continuous and protected means of egress:
ii) No exit doorway shall be less than 90 cm. in width except assembly buildings where door
width shall be not less than 200 cm. Doorway shall be not less than 200 cm. in height.
Doorways for the bathrooms, water-closets or stores shall be not less than 75 cm. wide.
iii) Exit doorways shall open outwards, that is away from the room but shall not obstruct the
travel along any exit. No door, when opened shall reduce the required width of stairways
or landing to less than 90 cm. Overheads or sliding doors shall not be installed.
iv) Exit door shall not open immediately upon a flight of stair. A landing equal to at least the
width of the door shall be provided in the stairway at each doorway. Level of landing shall
be the same as that of the floor which it serves.
v) Exit doorway shall be openable from the side which they serve without the use of a key.
vi) Mirrors shall not be placed in exit ways or exit doors to avoid confusion regarding the
direction of exit.
9.29.2 Revolving doors
Revolving doors shall not be used as required exits except in residential business and mercantile
occupancies but they shall not constitute more than half the total required door width.
9.29.3 Stairways
i) Interior staircase shall be constructed of non-combustible materials throughout.
ii) Interior staircase shall be constructed as a self-contained unit with at least one side to the
extent of required opening adjacent to an external wall and shall be completely enclosed.
iii) Hollow combustible construction shall not be permitted.
iv) The minimum width of tread without nosing shall be 25 cm. for an internal staircase for
residential buildings. In the case of other buildings, the minimum tread shall be 30 cm.
The treads shall be constructed and maintained in a manner to prevent slipping.
v) The maximum height of riser shall be 19 cm. in the case of residential buildings and
15cm. in the case of other buildings. They shall be limited to15 per flight.
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
vi) Handrails shall be provided with a minimum height of 100 cm. from the centre of the
tread to the top of the handrails. Balusters/ railing shall be provided such that the width of
staircase does not reduce.
vii) Floor indicator - The number of each floor shall be conspicuously painted in figures at
least 15 cm. large on the wall facing the flights of a stairway or at such suitable place as is
distinctly visible from the flights.
viii) The minimum headroom in a passage under the landing of a staircase shall be 2.2 m.
ix) (1) For special building, access to main staircase shall be gained through at least half an
hour fire resisting automatic closing doors placed in the enclosing wall of the staircase. It
shall be a swing type door opening in the direction of the escape.
x) No living space, store or other space including fire risk shall open directly into the
staircase.
xi) External exit door of staircase enclosure at ground level shall open directly to the open
spaces or should be reached without passing through any door other than a door provided
to form a draught lobby.
xii) In the case of assembly, institutional or residential occupancies or hotels or industrial and
hazardous occupancies, the exit sign with arrow indicating the way to the escapes route
shall be provided at a height of 0.5 m. from the floor level on the wall and shall be
illuminated by electric light connected to corridor circuits. All exit way marking signs
should be flushed with the wall and so designed that no mechanical damage shall occur to
them due to moving of furniture or other heavy equipment. Further all landings of floor
shall have floor indicating boards prominently indicating the number of floor. The floor
indication board shall be placed on the wall immediately facing the flight of stairs and
nearest to the landing. It shall be of the size not less than 0.5 m. x 0.5 m.
xiii) In case of a single staircase, it shall terminate at the ground floor level and the access to
the basement shall be by a separate staircase. Whenever the building is served by more
than one staircase one of the staircases may lead to basement level provided the same is
separated at ground level by either a ventilated lobby or a cut-off screen wall without
opening, having a fire resistance of not less than 2 hours with discharge point at two
different ends or through enclosures. It shall also be cut-off from the basement areas at
various basement levels by a protected and ventilated lobby or lobbies.
9.29.4 Fire escape or external stairs
A fire escape or external stair shall be provided as provided in Regulation No. 9.28.7 External
stairs, when provided, shall comply the following :
i) External stairs shall always be kept in sound operable conditions.
ii) All external stairs shall be directly connected to the ground.
iii) Entrance to the external stairs shall be separate and remote from the internal staircase.
iv) Care shall be taken to ensure that no wall opening or window opens on to or close to an
external stairs.
v) The route to the external stairs shall be free of obstructions at all times.
vi) The external stairs shall be constructed of non-combustible materials, and any doorway
leading to it shall have the required fire resistance.
(1) Substituted Vide Corrigendum / Addendum No.CR 79/2021, dt. 02nd December 2021.
vii) No external staircase, used as a fire escape, shall be inclined at an angle greater than 45
degree from the horizontal.
viii) External stairs shall have straight flight not less than 1250 mm wide with 250 mm treads
and risers not more than 190 mm. The number of risers shall be limited to 15 per flight.
ix) Handrails shall be of a height not less than 1000 mm. and not exceeding 1200 mm. There
shall be provisions of balusters with maximum gap of 150 mm.
x) The use of spiral staircase shall be limited to low occupant load and to a building not
exceeding 9 m. in height. A spiral stair case shall be not less than 1500 mm. in diameter
and shall be designed to give adequate headroom.
xi) Unprotected steel frame staircase will not be accepted as means of escape. However, steel
staircase in an enclosed fire rated compartment of 2 h will be accepted as means of escape.
xii) Fire escape staircase shall be connected to other staircases through common passage
at every floor.
(1) xiii) It shall not be permitted to provide fire escape chutes in alternate to fire escape or
external stairs. However the applicant may provide fire escape chute in addition to fire
escape / external stairs as mandatory under this Regulation.
9.29.5 Corridors and passageways
i) The minimum width of a corridor shall not be less than 75 cm. in the case of 2 storeys row
housing residential buildings and 100cm. in the case of other buildings and actual width
shall be calculated based on the provision of Regulations No.9.28.3 to 9.28.8 (both
inclusive)
ii) Where there is more than one staircase serving a building, there shall be at least one
smoke-stop door in the space between the staircases.
iii) Exit corridors & passageways shall be of width not less than the aggregate required width
of exit doorways leading from them in the direction of travel of the exterior/stairways.
iv) Where stairways discharge through corridors & passageways the height of the corridors &
passageways shall not be less than 2.4 m.
v) All means of exit including staircases, lifts, lobbies & corridors shall be adequately
ventilated.
9.29.6 Refuge Area
For buildings more than 24 m. in height, refuge area of 15 Sq.m. or an area equivalent to 0.3
Sq.m. per person to accommodate the occupants of two consecutive floors, whichever is higher,
shall be provided as under :
The refuge area shall be provided on the periphery of the floor or preferably on a cantilever
projection and open to air at least on one side protected with suitable railings.
a) For floors above 24 m. and upto 39m. height-One refuge area on the floor immediately
above 24 m.
b) For floors above 39 m height - One refuge area on the floor immediately above 39 m.
and so on after every 15 m.
Refuge area provided in excess of the requirements shall be counted towards FSI.
However, area remained in excess because of planning constraints, shall not be counted in
FSI, provided, such excess area does not exceed 100% of the required refuge area.
(1)
Inserted vide Notification u/s 37 (1AA)(c) No. CR 236/18 (Part 6), dt. 12th October 2022.
9.29.7 Lifts and Escalators
i) Lifts:- Provision of lift shall be made as mentioned in Regulation No.9.27.
ii) Escalators :Escalators may be permitted in addition to required lifts. Such escalators may
also be permitted in atrium area of the buildings.
9.29.8 Fire lift
Where applicable, fire lifts shall be provided with a minimum capacity for 8 passengers and
fully automated with emergency switch on ground level. In general, buildings 15 m. in height or
above shall be provided with fire lifts. In case of fire, only fireman shall operate the fire lift. In
normal course, it may be used by other persons. Each fire lift shall be equipped with suitable
inter-communication equipment for communicating with the control room on the ground floor
of the building. The number and location of fire lifts in a building shall be decided after taking
into consideration various factors like building population, floor area, compartmentation, etc.
9.29.9 Fire Escape Chutes / controlled Lowering Device for evacuation
i) (a) High rise building having height more than 70 m. shall necessarily be provided with fire
escape chute shaft/s for every wing adjacent to staircase.
b) Walls of the shaft shall have 4 hours' fire resistance.
c) One side of the shaft shall be at external face of the building with proper ventilation.
d) The dimension of the shaft shall not be less than 2.5 m. x 1.5 m.
e) The access to the fire escape chute's shaft shall be made at every floor level from lobby
area or from staircase mid-landing with self-closing door having fire resistance of at least
one hour.
f) The fire chute shall be of staggered type with landing of each section at the vertical height
of not more than 21 m.
Alternatively,
ii) High rise building having height more than 70 m, shall be provided with fire tower at
landing/ mid-landing level with smoke check lobby with fireman lift being integral part of
the fire escape staircase or fire evacuation lift (Hydro pneumatic / electrically operated) on
the external face of the building having opening within the fire escape staircase at landing/
mid-landing level with smoke check lobby as approved by Chief Fire Officer shall be
provided.
Note - Both the smoke check lobby with evacuation lift shall have positive level
difference of minimum 75 mm. with respect to staircase landing or mid-landing level to
avoid ingress of water in fireman lift shaft.
9.29.10 Refuge chute / Garbage Chute-
In residential buildings, Refuge chute / garbage chute may be provided with opening on each
floor or on mid-landing. Design and specifications of Refuge chute shall be in accordance with
provisions of IS 6924.
9.30 ARCHITECTURAL PROJECTIONS
Architectural Projections may be allowed to the following extent.
Horizontal Vertical ( above building)
H/20 subject to min 0.3 m. and max 3 m. exclusive of H/20 subject to max 6 m.
side and rear marginal distance of 6 m. required for
movement for fire fighting vehicle in case of special
buildings.
Where H=Height of building from ground level.
The owner shall submit the undertaking to the authority that, such architectural projection shall
not be converted to any habitable or other purpose.
9.31 ADDITIONAL REQUIREMENTS IN CASE OF HOUSING SCHEMES
Following amenities shall be provided in any housing scheme and shall be counted in FSI.
i) Fitness Centre, Crèche, society office cum letter box room, admeasuring area of about 20
sq.m.in scheme having minimum 100 flats and thereafter additional 20 Sq.m. area for
every 300flats.
ii) Sanitary block for servants having maximum area of 3 Sq.m. in schemes having
minimum100 flats and thereafter additional 3 Sq.m. area for every 200 flats.
iii) Drivers room of size 12 Sq.m. with attached toilet in schemes having minimum 100 flats
and thereafter additional 10 Sq.m. area for every 300 flats.
In case of scheme having more than 1000 flats, the above amenities shall be reasonably
provided keeping in view the above requirements.
iv) Every Residential building having more than 6 flats/tenements shall have entrance lobby of
minimum 9 Sq.m. at ground floor. Minimum dimension of such lobby shall not be less
than 2.50 m.
v) The requirements at (i) to (iii) above shall firstly be provided for the building having 30 (1)
to 100 tenements and thereafter the quantum mentioned in the said provisions shall be
provided.
9.32 FIRE PROTECTION REQUIREMENT
All special buildings shall be planned, designed and constructed to ensure fire safety and this
shall be done in accordance with the regulations of Maharashtra Fire Prevention and Life Safety
Measures Act, 2006. For the provisions not included in these regulations and the said Act,
provisions mentioned in Part IV of Fire Protection of National Building Code India, amended
from time to time shall be referred and prevail.
9.33 SERVICE FLOOR
A service floor of height not exceeding 1.8 m. may be provided in a building exclusively for
provision/diversion of services. Provided further that a service floor with height exceeding 1.8
m. may be allowed in a building of medical use or in building having height more than 70 m.
with the special permission of Authority with reasons recorded in writing.
-*-*-*-*-*-
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.