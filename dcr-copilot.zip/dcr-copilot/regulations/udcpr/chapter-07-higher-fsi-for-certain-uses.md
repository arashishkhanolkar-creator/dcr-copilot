# Chapter 7: Higher FSI for Certain Uses

CHAPTER - 7
HIGHER FSI FOR CERTAIN USES
7.0 GENERAL
Higher Floor Space Index may be allowed for certain uses in congested and non-congested area,
except as otherwise specified and subject to following conditions:
i) Permissible higher FSI for the buildings as mentioned in Table No 7-A shall be the maximum
permissible building potential according to road width as mentioned in column 6, 9, 12 of
Table No.6A or column 6, 9of Table No. 6Gunder Regulation No. 6.1 or 6.3 (whichever is
applicable) minus Basic FSI. Instead of availing this higher FSI, the owner shall be entitled to
avail premium FSI/ TDR or both to that extent.
ii) Such higher FSI shall only be available for use for which higher FSI is granted alongwith
ancillary uses.
iii) Premium -Premium for higher F.S.I. shall be as per column 4 of the Table No. 7Abelow:-
Rate of the premium is based on the land rate mentioned in ASR for respective S. No. / CTS
No. The premium collected shall be shared 50:50 between State Government & the Authority
respectively. Premium to be paid to the Government shall be deposited in the concerned
Account Head of Urban Development Department at Government Treasury by the Authority.
In case of areas of Regional Plans, such entire premium shall be paid to the Government
through the District office of the Town Planning and Valuation Department. The quantum /
rates of premium shall be subject to the orders of the Government from time to time.
iv) In addition to above, other ancillary area FSI as mentioned in notes below Table No.6 A and
6G (whichever is applicable) shall also be applicable for these uses.
vi) The higher FSI shall also be permissible to existing authorised uses subject to structural
stability.
f) If the owner/ developer desires to avail such higher F.S.I. in future for new buildings, then
while seeking building permission at first instance, the building plan shall be submitted
considering the marginal distances as required for the height of buildings for such higher
F.S.I. No condonation in the required open spaces, parking and other requirements in these
regulations shall be allowed. However, for the proposals in respect of existing building, such
condition need not be insisted upon and the proposal shall be cleared only after strictly
conforming to structural and fire safety norms.
h) No Amenity Spaces as per Regulation No. 3.5 shall be required to be provided for the uses
mentioned in Table No.7A.
j) In agricultural zone, uses mentioned at Sr.No. A & B of table 7A, shall be entitled for 100%
additional FSI over and above, permissible in said zone.
Table No. 7.1 - Higher F.S.I.
Table No. 7-A
Categories of the Basic FSI Additional FSI Rate of the Conditions if any,
other buildings Premium
1 2 3 4 5
A) Educational As per Regulation Maximum Building 5 % a) Provision of playground shall be complied with as specified
No. 6.1 or 6.3, Potential limit as per in these regulations.
i) Pre-primary School,
whichever is road width as
nursery Kindergarten Provided that, it shall not be necessary to increase area of
relevant. mentioned in Table
and Special Educational existing playground, if any, when utilisation of higher
No.6-A or 6-G
Institute for Physically F.S.I. as otherwise permissible in these regulations, is
(whichever is relevant)
challenged/ Mentally ill. proposed on upper floor of existing building.
minus basic FSI.
Provided further that, in case of existing building wherein
ii) Primary School --do-- --do-- 5% utilisation of higher F.S.I. is proposed on the vacant land,
area of playground shall not be less than 40% or the
iii) Other Educational --do-- --do-- For Charitable
existing area of playground whichever is minimum.
Buildings including Institutions 10%
boys/ girls / youth and for private Provided further that, in case of existing building wherein
hostels within 500 m. buildings 15%. utilisation of higher F.S.I. on upper floors is not possible
periphery from the and it is necessary to expand the existing building to
recognised educational accommodate number of students, then in such exceptional
institutions. circumstances, required area of playground(and not
existing) may be permitted to be reduced,
b) Maximum height of Educational building shall be as per
The Maharashtra Fire protection and Life Safety Measures
Act, 2006
B) Medical Institutions- --do-- As per Sr. No. A (i) For Charitable Maximum height of building for hospitals, sanatorium and
above. Institutions 10% nursing homes, shall be as per The Maharashtra Fire protection
Hospital, Maternity
Homes, buildings However, maximum and for private and Life Safety Measure, Act, 2006.
building potential shall buildings 15%.
be considered as 3.00
subject to Road width
18m. and above.
C) Institutional --do-- As per Sr. No. A (i) As per Sr. No. B
buildings / Banks above. above.
D) Starred category --do-- --do-- 20% i) Certificate from the Tourism Department, GOI shall be
hotels (two star and necessary for type of category of hotels.
above)Mega-Ultra
ii) The maximum building potential limit mentioned in Table
Mega and Large
No. 6-A or 6-G shall be allowed considering the road
Tourism Project/Unit as
width one step below.
per Maharashtra
e.g. for the roads as mentioned at Sr. No. 3 in Table No. 6-
Tourism Policy-2016 or
G, the maximum building potential shall be considered as
as amended from time
given at Sr. No. 4.
to time.
iii) Mega/Ultra Mega/Large Tourism Project/Unit may also
include Tourism support activities to the extent of 20% of
the additional FSI consumed.
i) The Authority may allow exceeding the limit of higher FSI
E) Buildings of --do-- As per Sr. No. A (i) Government and
mentioned in column 3.
Government and Semi- above. Semi-Government ii) (1) For the land in possession of MSRTC, maximum 2/3
Government Offices, However, maximum Originations, Local FSI out of maximum building potential shall be permitted
Local Authorities and building potential shall Authorities - Nil. to be utilized for commercial use. Provided that, Minimum
Public Sector be considered as 3.00 50% contiguous land shall be used for principal purpose of
For Public Sector
MSRTC.
Undertakings / the Land for Roads having width
Institutions - 15%
in possession of / 18m. and more.
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
Maharashtra State Road
Transport Corporation
City Transport / Metro
Stations and Depot
including Govt. Guest
Houses.
F) Religious Building: --do-- As per Sr. No. A (i) 15% i) It shall be necessary to obtain the No-Objection Certificate
above. from concerned Police Authority and Collector (District
Magistrate), before grant of permission.
ii) Other ancillary user like, administration office,
Dharmashala or Accommodation for devotees, eateries,
convenience shops, etc. may be permitted.
G) Yatri Niwas, --do-- --do-- 15%
I) Basic shelter for --do-- As per Sr. No. A (i) No premium Any housing scheme for EWS/ LIG undertaken by the authority,
urban poor and Housing above or FSI upto 2.5, government/ semi government organisation, under the basic
schemes developed for whichever is maximum. shelter for urban poor or similar programme/ scheme of the
EWS / LIG Central / State Government, shall be eligible for higher FSI.
J) Students' Hostel/ --do-- As per Sr. No. A (i) 10% i) Built-up area of the unit shall not exceed 17 Sq. m. with or
Working Women - Men above without toilet, excluding common area.
Hostel / Dormitories /
ii) Unit shall not be sold and shall be on rental basis. The
Hostel for Labourers
condition to that effect shall be stamped on plans and be
(for whom Labour Laws
incorporated in permission letter.
are applicable.)
iii) Ancillary facilities such as kitchen, dining hall, common
hall, common toilets may be permitted.
Note : i) The owner shall be at liberty to avail TDR instead of paying premium mentioned in above table to the extent specified above.
ii) The above premium shall not be applicable for development under taken by Government, Semi-Government Departments, Local Authorities and Public
Sector Undertakings.
7.2 Entitlement of FSI for Road Widening or Construction of New Roads / Surrender of
Reserved Land
The Authority may permit on the same plot, additional FSI of the area required for road widening
or for construction of a new road proposed under the Development Plan /Regional Plan / Planning
Proposal, and also service road proposed to NH/ SH/ MDR/ ODR whether shown on plan or not,
if the owner (including the lessee) of such land surrenders such land without claiming any
monetary compensation in lieu thereof and hands over the same free from encumbrances to the
satisfaction of the Authority. FSI generated against the surrender of land, shall be in proportion to
the provisions mentioned in Regulation of TDR and may be utilised on the remaining land within
the building potential mentioned in Table 6-A, 6-G and 6-H of Regulation No. 6.1, 6.3and 6.4
respectively, whichever is applicable. If desired by the owner, TDR, wherever applicable, may be
granted against such surrendered land instead of utilizing FSI on remaining land. Such TDR shall
be allowed to be utilised as a Development Right in accordance with the provisions regulating
Transfer of Development Rights (TDR). Thereafter, the road shall be transferred in the city survey
records/ revenue records in the name of the Authority and shall vest in it becoming part of a public
street.
Provided further that, this concession shall not be granted in respect of: -
a) Roads in the areas of Town Planning Scheme which are the proposals of the scheme.
b) Cases mentioned in provision of TDR as mentioned in Regulation No. 11.2.3.
7.3 DEVELOPMENT / REDEVELOPMENT OF STAFF QUARTERS OF THE STATE
GOVERNMENT OR ITS STATUTORY BODIES OR PLANNING AUTHORITY
7.3.1 Construction/ reconstruction of staff quarters of the State Government or its statutory bodies or
Authority shall be permitted on land belonging to such Authorities which are situated in
developable zones such as Residential/ Public Semi-public/ Commercial Zones etc. on the
following conditions
7.3.2 The basic FSI specified in these regulations may be allowed to be exceeded as per following table
on the gross plot area solely for the project of construction of staff quarters (hereinafter referred to
as - staff quarter project) for the employees of the Government, or its statutory bodies or the
Planning Authority (hereinafter collectively referred to as - User Authority), on land belonging to
such User Authority, by the PWD of the Government of Maharashtra or MHADA or Maharashtra
Police Housing Corporation or Planning Authority or any other Public Agency nominated by the
Government for this purpose, which may also include any Special Purpose Vehicle, wherein the
Government or a fully owned Company of the Government holds at least 51% equity share
(hereinafter collectively referred to as - "implementing Public Authority")
7.3.3 Maximum permissible FSI
Road width and plot area
including basic FSI
18m. or above, minimum plot area 4000sq.m. and 3.00
above
12m. or above but below 18m. 2.50
7.3.4 For the purpose of calculating the FSI, the entire area of the plot excluding area under
Development Plan roads / Regional Plan Roads and Development Plan reservations, if any, shall
be considered.
Provided that, the Development Plan reservations like Government Staff Quarters, Police
Housing, Municipal Housing, Municipal Staff Quarters etc. on lands belonging to Government /
Public Authorities/ Local Authorities, shall not be excluded, if the scheme is undertaken on the
said reservation.
Provided further that, amalgamation of such Development Plan reservation/s with adjoining lands
for the execution of project under this regulation shall be permissible.
7.3.5 The total permissible FSI under this regulation shall be utilised for construction of staff quarters
and ancillary activities for the User Authority, subject to the following :-
i) The area of staff quarters for various categories of employees shall be as per the norms
prescribed by the concerned User Authority and in no case shall the area of staff quarters
exceed the maximum limit of carpet area as prescribed therein.
ii a) The Authority may also permit up to 1/3rdof the total permissible FSI under this regulation for
construction of free sale area (hereinafter referred to as "free sale component") to be disposed
of by the Implementing Public Authority as provided herein. The free sale component shall
preferably be constructed in a separate block. Sub-division of plots shall be permissible on
the basis of equitable distribution of FSI, in case construction of free sale component is
permitted by the Authority.
The free sale component may be utilised for commercial use as per potential of plot as
decided by the following committee. The extent of commercial use, if required, shall be
decided by the said committee strictly within the limits as specified in these regulations.
Authorities Other than those in
Sr. Municipal Corporations/
Status column 2 including Regional
No. Metropolitan Authorities
Plan area
1 2 3 4
1 Municipal/ Metropolitan Chairman Collector of Concerned District
Commissioner (of the
Municipal Corporation/
Metropolitan Authority)
2 Police Commissioner/ Member District Superintendent of Police
District Superintendent of of Concerned District
Police of Concerned District
3 Collector of Concerned Member Chief Officer/ Chief Executive
District Officer of the Authority or
Assistant Director of Town
Planning of concerned District in
the Regional Plan area.
4 Superintendent Engineer Member Superintendent Engineer (PWD)
(PWD)
Secretary
ii-b) If the User Authority requires construction of staff quarters to the extent of full permissible
FSI, then the User Authority shall pay full cost of construction + 5% of construction cost as
establishment charges to the Implementing Public Authority.
ii-c) The flats constructed under the free sale component shall be first offered to the Central
Government, its statutory bodies, Central/State PSUs for purchase as staff quarters and if the
Central Government or its statutory Bodies or Central/ State PSUs do not indicate
willingness to purchase the same within the prescribed time limit, such flats shall be sold in
open market.
7.3.6 i) Notwithstanding anything contained in these regulations, no amount shall be charged
towards Premium, Scrutiny Fee etc., for the projects proposed under this regulation.
ii) The provisions of Inclusive Housing, mentioned in these regulations, shall not be applicable
for development under this regulation.
7.3.7 For any staff quarters project under this regulation, a development agreement shall be executed
between the User Authority and the Implementing Public Authority, which, inter alia, shall
authorise the Implementing Authority to dispose of the flats constructed under the free sale
component of the project, wherever applicable. Such development agreement shall contain the
details regarding the modalities and conditions of transferring such quarters (whether free of cost
or on payment/ receipt of certain amount by the User Authority) to the user authority and also
conditions, modalities of disposing of the flats under the free sale component by the Implementing
Public Authority.
7.4 DEVELOPMENT/ REDEVELOPMENT OF HOUSING SCHEMES OF MAHARASHTRA
HOUSING AND AREA DEVELOPMENT AUTHORITY
7.4.1 Development / re-development of housing schemes of Maharashtra Housing and Area
Development Authority shall be subject to the following provisions: -
i) The FSI for a new scheme of Low Cost Housing, implemented by MHADA departmentally
on vacant lands for Economically Weaker Sections (EWS), Low Income Group (LIG) and
Middle Income Group (MIG) categories shall be (1) 3.00 or maximum building potential as
per road width(Regulation No. 6.1 or 6.2) whichever is maximum, on the (1) Gross Plot
Area and at least 60% built-up area in such scheme shall be in the form of tenements under
the EWS, LIG and MIG categories, as defined by the Government in Housing Department
from time to time.
ii) For redevelopment of existing housing schemes of MHADA, containing (i) EWS/LIG
and/or (ii) MIG and/or (iii) HIG houses with carpet area less than the maximum carpet area
prescribed for MIG, the total permissible FSI shall be (1) 3.00 on the gross plot area.
7.4.2 Where redevelopment of buildings in existing housing schemes of MHADA is undertaken by the
housing co-operative societies or the occupiers of such buildings or by the lessees of MHADA,
the Rehabilitation Area Entitlement, Incentive FSI and sharing of balance FSI shall be as follows:-
i) Rehabilitation Area Entitlement:-Under redevelopment of building in existing Housing
scheme of MHADA, the entitlement of rehabilitation area for an existing residential
tenements shall be equal to sum total of-
a) a basic entitlement equivalent to the carpet area of the existing tenement plus 35%
thereof, subject to a minimum carpet area of 35sq.m.
b) an additional entitlement governed by the size of the plot under redevelopment, in
accordance with the Table 7-B below:-
(1)
Substituted Vide Notification No.CR 236/18 (Part-3), dt. 16th June, 2021.
Table 7-B
Area of the Plot under Additional Entitlement (As % of the Carpet
Redevelopment Area of the Existing Tenement)
Upto 4000 Sq.m. Nil
Above 4000 Sq.m. to 2 hect. 15%
Above 2 hect to 5 hect. 25%
Above 5 hect to 10 hect. 35%
Above 10 hect. 45%
Provided that the entitlement of rehabilitation area as admissible under this regulation shall be
exclusive of the area of balcony.
ii) Incentive FSI - Incentive FSI admissible against the FSI required for rehabilitation, as
calculated in (A) above, shall be based on the ratio (hereinafter referred to as Basic Ratio) of
Land Rate (LR) in Rs./Sq.m. of the plot under redevelopment as per the Annual Statements
of Rates (ASR) and Rate of Construction (RC)* in Rs./Sq.m. applicable to the area as per the
ASR and shall be as given in the Table 7-C below:-
Table No. 7-C
Basic Ratio (LR/RC) Incentive (As % of Admissible
Rehabilitation Area)
Above 6.00 40%
Above 4.00 and up to 6.00 50%
Above 2.00 and up to 4.00 60%
Up to 2.00 70%
Explanation:-
* RC is the rate of construction in respect of R.C.C. Construction, as published by the Chief
Controlling Revenue Authority & Inspector General of Registration, Maharashtra State in the
Annual Statements of Rates.
Provided that the above incentive shall be subject to the availability of the FSI on the Plot under
redevelopment and its distribution by MHADA.
Provided further that in case there are more than one land rate applicable to different parts of the
plot under redevelopment, a weighted average of all applicable rates shall be taken for calculating
the Average Land Rate and the Basic Ratio.
Provided further that the Land Rate (LR) and the Rate of Construction (RC) for calculation of the
Basic Ratio shall be taken for the year in which the redevelopment project is approved by the
authority competent to approve it.
iii) Sharing of the Balance FSI:-The FSI remaining in balance after providing for the
rehabilitation and the incentive components, calculated as per (i) and (ii) above respectively,
shall be shared between the Co-operative Housing Society and MHADA in the form of
built-up area, as given in Table No.7D below and the share of MHADA shall be handed over
to MHADA free of cost.
Table No. 7D
Basic Ratio (LR/CR) Sharing of balance FSI
Share of Co-operative Share of MHADA
Society
Above 6.00 30% 70%
Above 4.00 and up to 6.00 35% 65%
Above 2.00 and up to 4.00 40% 60%
Up to 2.00 45% 55%
Provided that in case of plots up to 4000 Sq.m., MHADA without insisting MHADA‘s
Share in the form of BUA, may allow additional BUA over and above existing BUA up to
(1) 3.00 FSI by charging premium at the percentage rate of ASR defined in Table No. 7E
below:-
Table No. 7E
LR/ RC Ratio EWS/LIG MIG HIG
0 to 2 20% 45% 60%
2 to 4 23% 49% 64%
4 to 6 25% 53% 68%
Above 6 28% 56% 71%
7.4.3 Where redevelopment of buildings in the existing Housing Schemes of MHADA is undertaken by
MHADA or jointly by the MHADA along with the housing societies or along with the occupiers
of such building or along with the lessees of MHADA, the Rehabilitation Area Entitlement shall
be as follows:-
i) Rehabilitation Area Entitlement:- The Rehabilitation Area Entitlement shall be increased
by 15% of the existing carpet area, over and above the Rehabilitation Area Entitlement
calculated as per Regulation No. 7.4.2 (i) above.
7.4.4 For the purpose of calculating the FSI, the entire area of the layout including Development Plan
roads / Regional Plan Roads and internal roads but excluding the land under the reservation of
public amenities shall be considered. Sub-division of plots shall be permissible on the basis of the
compulsory open spaces as in these Regulations. For low cost housing schemes of MHADA for
EWS/LIG categories, the Regulations of the UDCPR shall apply.
The reservations in the MHADA layout may be developed as per the provisions of these
Regulations.
Provided that there shall be no restriction on the utilization of the FSI permissible under this
Regulation except for the restrictions under any law, rule or regulation.
7.4.5 For the purpose of this Regulation the carpet areas for EWS, LIG or MIG tenements shall be as
determined by the Government from time to time.
7.4.6 i) For providing the requisite infrastructure for the increased population, an infrastructure
charge at the rate of 7% of the Land Rate as per the ASR of the year of approval of the
redevelopment project shall be chargeable for the extra FSI granted over and above the basic
(1)
Substituted Vide Notification No.CR 236/18 (Part-3), dt. 16th June, 2021.
FSI admissible for the redevelopment schemes. 50% of the Infrastructure Charge levied and
collected by MHADA shall be transferred to the Authority for developing necessary off site
infrastructure.
ii) No premium shall be charged for the FSI admissible as per the prevailing regulations.
a) Construction of EWS/LIG and MIG tenements by MHADA on a vacant plot, or
b) In a redevelopment project for the construction of EWS/ LIG and MIG tenements
towards the share of MHADA.
7.4.7 Notwithstanding anything contained in these Regulations, the relaxation incorporated for slum
rehabilitation scheme shall apply to the Housing Schemes under this Regulation for tenements
under EWS/LIG and MIG categories. However, the front open space shall not be less than 3.6m.
7.4.8 i) In any Redevelopment Scheme where the Co-operative Housing Society/ Developer
appointed by the Co-operative Housing Society has obtained No Objection Certificate from
the MHADA, thereby sanctioning additional balance FSI with the consent of 51% of its
members and where such NOC holder has made provision for alternative permanent
accommodation in the proposed building (including transit accommodation), then it shall be
obligatory for all the occupiers/ members to participate in the Redevelopment Scheme and
vacate the existing tenements for the purpose of redevelopment. In case of failure to vacate
the existing tenements, the provisions of relevant sections of the MHADA Act mutatis
mutandis shall apply for the purpose of getting the tenements vacated from the non-co-
operative members.
ii) For redevelopment of buildings in any existing Housing Scheme of MHADA under clause
7.4.8(i) hereinabove, by MHADA, the consent of the Co-operative Housing Society in the
form of a valid Resolution as per the Co-operative Societies Act, 1960 will be sufficient. In
respect of members not co-operating as per approval of the redevelopment project, action
under relevant sections of the Maharashtra Housing and Area Development Act, 1976 may
be taken by MHADA.
7.4.9 A corpus fund, as may be decided by MHADA, shall be created by the Developer which shall
remain with the Co-operative Housing Societies for the maintenance of the new buildings under
the Rehabilitation Component.
7.4.10 i) In case of layout of MHADA where development is proposed under this Regulation and
where such land is observed to be partially occupied by slum, under section 4 of Slum Act
existing prior to 1.1.2000 or such other reference date notified by the Govt., then for
integrated development of the entire layout area and in order to promote flexibility,
MHADA may propose development, including area occupied by the slum, under this
regulation.
ii) a) Each eligible residential or residential cum commercial slum dweller shall be entitled to
a tenement of carpet area of 27.88 Sq.m. (300 Sq.ft.)and
b) Existing or 20.90 Sq.m. whichever is less in case of non-residential.
iii) If such land occupied by slum is observed to be affected by reservation then the development
of reservation on land occupied by slum shall be regulated by the Slum Regulation.
iv) Corpus fund: An amount as may be decided by SRA as per Regulation shall be deposited
with MHADA Authority for each eligible slum dwellers.
7.5 PROTECTION OF FSI IN REDEVELOPMENT OF EXISTING BUILDINGS
For redevelopment or reconstruction of existing buildings, the FSI to be allowed shall be FSI
permissible under Regulation No.6.1 or 6.3,or the FSI consumed by the existing authorized
building including TDR, premium FSI etc., whichever is more. (Such TDR, Premium FSI etc.
utilised in existing building shall be treated as authorisedly consumed FSI entitled for
redevelopment.)
7.6 REDEVELOPMENT OF OLD DILAPIDATED/ DANGEROUS BUILDINGS
Reconstruction / Redevelopment in whole or in part of any building which has ceased to exist in
consequence of accidental fire / natural collapse or demolition for the reasons of the same having
been declared dangerous or dilapidated or unsafe by or under a lawful order of the Authority or
building having age of more than 30 years, shall be allowed subject to following conditions.
(3) 7.6.1 (3)Redevelopment of Multi-Dwelling Buildings of Co-Operative Housing Societies /
Apartments
i) FSI allowed for redevelopment shall be FSI of existing authorized building and incentive
FSI to the extent of 30% of existing built up area or 15 Sq.m. per tenement, whichever is
more.
Provided further that if the existing authorized built up area and incentive thereon as stated
above is less than maximum building potential mentioned in Regulation No. 6.1 or 6.3, as
the case may be, then society may avail premium FSI / TDR upto maximum building
potential.
Such incentive FSI shall not be applicable for redevelopment of existing bunglow.
ii) In cases where carpet area occupied by residential tenement in the existing building is less
than the carpet area of 27.87 Sq.m. then such tenement shall be entitled for minimum carpet
area of 27.87 Sq.m. and difference of these areas shall be allowed as additional FSI without
any premium.
In case of non-residential occupier the area to be given in the reconstructed building shall be
equivalent to the area occupied in the old building.
iii) This regulation shall be applicable only when existing members of the societies are proposed
to be re-accommodated.
iv) If tenanted building/s and building/s of co-operative housing society/non-tenanted building/s
coexist on the plot under development, then proportionate land component as per existing
authorized built up area of existing tenanted building on the plot shall be developed as per
Regulation No.7.6.2 and remainder notional plot shall be developed as per this regulation.
7.6.2 Redevelopment of tenanted buildings
i) The FSI allowed for redevelopment of building having protected tenants under the relevant
provisions of law, shall be FSI permissible under Regulation No.6.1 or 6.3,or the FSI
consumed by the existing authorized building including TDR, premium FSI etc., whichever
is more. (Such TDR, Premium FSI etc. utilised in existing building shall be treated as a basic
FSI for redevelopment.) In addition to this, 50% incentive FSI of the rehab area required for
rehabilitation of tenants, shall be allowed. Provided that rehab area shall be the authorisedly
utilised area or 27.87 Sq.m. carpet area per tenement whichever is more. In case of non-
residential occupier the area to be given in the reconstructed building shall be equivalent to
the area occupied in the old building.
(3)
Inserted Vide Notification No.CR 236/18 (Part-3), dt. 02nd December 2021.
Provided that, where such building is partly self-occupied by the owners, then entitlement of
such partly area shall be governed by the provisions mentioned in Regulation No.7.6.1
above.
Provided further that, if the existing authorised built up area and incentive thereon as stated
above is less than maximum building potential mentioned in Regulation No. 6.1 or 6.3, as
the case may be, then society may avail premium FSI / TDR upto maximum building
potential.
ii) All the eligible tenants of the old building shall be re-accommodated in the redeveloped
building.
iii) In case of fire gutted buildings, the conditions of more than 30 years age of buildings shall
not be applicable.
Note :- (applicable for Regulation No.7.6.1 & 7.6.2)
1) For the purpose of deciding authenticity of the structure if the approved plans of existing
structure are not available, the Authority shall consider other evidences such as Assessment
Record or City Survey Record or Sanad.
2) The new building may be permitted to be reconstructed in pursuance of an agreement to be
executed on stamp paper by at least 51% of the landlord/ occupants in the original building,
within the meaning of the Bombay Rents, Hotel and Lodging House Rents Control Act,
1947 or Apartment Act and its related provision and in such agreement provision for
accommodation for all occupants in the new building on agreed terms shall be made and a
copy of such agreement shall be deposited with the Planning Authority before
commencement or undertaking reconstruction of the new buildings.
3) An amount as may be decided by the Government shall be paid by the Owner/Developer/
Society as additional Development Cess for the built up area over and above the Base FSI. A
corpus fund as decided by the Authority is to be created by the Developer which will take
care of the maintenance of the building for a period of 10 years.
7.7 DEVELOPMENT OF HOUSING FOR EWS/ LIG
7.7.1 In Residential Zone-
If the owner constructs the housing for EWS/ LIG in the form of tenements of size up to 50 Sq.m.
(1) carpet area on his plot, then he shall be allowed FSI of maximum building potential mentioned
in the column 6 or 9 of Table No.6A or column 6 or 9 of Table No. 6G of Regulation No.6.1 or
6.3, subject to following conditions.
i) For the FSI availed over and above the basic FSI, the premium shall be charged at the rate of
15% of land rate in ASR, without considering guidelines therein.
ii) Out of the total tenements, at least 40% tenements shall be of (1) carpet area not more
than30sq.m.
iii) Only one tenement should be sold to a family. Adjoining tenement should not be sold to a
close relative of such tenement owner. Affidavit to that effect shall be obtained from the
land owner/ developer and purchaser.
iv) For these proposals, marginal distances (except front margin) parking and other requirement
shall be as per Slum Redevelopment Regulations, wherever such regulations exist.
(1)
Substituted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
v) The owner shall have option to avail TDR over and above basic FSI instead of availing FSI
with the payment of premium as mentioned in (i) above.
(1) Note - Out of the permissible FSI, 10% of the basic FSI mentioned in Regulation No. 6.1 or 6.3,
shall be allowed for commercial use.
7.7.2 In Agricultural Zone -
The housing scheme mentioned in Regulation (1) No.7.7.1 shall be permissible in Agricultural
Zone with FSI of 1.00 with approach road of minimum 9 m. The responsibility of development of
infrastructure shall lie with the owner / developer.
(1) Note - Out of the permissible FSI, 10% of the FSI shall be allowed for commercial use.
7.7.3 For Regional Plan Area -
The housing scheme mentioned in Regulation No.7.7.1 and 7.7.2 shall be applicable for Regional
Plan area mutatis mutandis.
7.8 REGULATIONS FOR DEVELOPMENT OF INFORMATION TECHNOLOGY
ESTABLISHMENT
7.8.1 For Municipal Corporation, Area Development Authority and Special Planning Authority
area.
Development of Information Technology Establishments shall be regulated as per the Information
Technology & Information Technology Enabled Services (IT/ITES) Policy 2015 as declared by
Industries Department vide Government Resolution No.ITP-2013/CR-265/IND-2, dated
25/08/2015, along with the special regulations sanctioned by the Government vide notification
No. TPB 4316/CR-167/2016/(3)/UD-11, dated 15th July, 2016 and amended from time to time
which are mentioned below :-
i) The Authority may permit additional FSI up to 200% over and above the basic permissible
F.S.I. to all registered Public and Private IT/ ITES Parks/AVGC Parks /IT SEZs or IT Parks
in SEZs / Stand-alone IT/ ITES units in public IT Park (including IT/ ITES units located in
Residential / Industrial/ No Development/ Green/ Agriculture Zone or any other land use
zone in which such users are permissible), which have been approved by the Directorate of
Industries, proposed to be set up or already set up under present / previous IT/ITES policies,
( hereinafter referred to as the "said unit") by charging premium of 20% of the land rate for
the said land as prescribed in Annual Statement of Rates for the relevant year of granting
such additional F.S.I.
In the case of lessor authorities such as New Town Development Authorities as land owner,
such Authorities may recover lease premium for additional F.S.I., if applicable, under their
land disposal policy.
Provided that additional FSI above 100% and up to 200% shall be permissible only on plots
having an access road of minimum18 m. width.
Provided further that, the premium so collected shall be shared between the Planning
Authority and the Government in the proportion of 50 : 50. The share of the Government shall be
paid to the concerned Branch office of the Town Planning Department.
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
(Explanation:- Premium charges shall be calculated on the value of lands under such zones,
determined by considering the land rates of the said land as prescribed in Annual Statement
of Rates (ASR). These charges shall be paid at the time of permitting additional F.S.I. by
considering the ASR for the relevant year without applying the guidelines)
ii) No premium shall be chargeable in areas of Planning Authorities, if they are covered under
No Industry Districts and Naxalism affected areas of the State (as defined in the "Package
Scheme of Incentives-2013" of the Industries, Energy & Labour Department of the State.)
ii) Maximum 20% of total proposed Built-up area (excluding parking area) inclusive of such
additional F.S.I. may be permitted for support services in IT Parks. Remaining built-up area
shall be utilized for IT/ ITES.
iv) Such new unit shall allocate at least 2% of the total proposed built-up area for providing
incubation facilities for new units. This area would be treated as a part of the Park to be used
for IT activities and eligible for additional FSI benefits accordingly.
v) Premium to be received by the Planning Authority as per provisions in this regulation shall
be deposited in a separate fund viz. "Critical Infrastructure Fund for IT/ ITES Industries"
and this fund shall be utilized only for creation of Critical Infrastructure for IT/ITES
Industries;
Provided that in the event, the developer come forward for providing such off site
infrastructure at his own cost, instead of paying premium as prescribed above, then the
Planning Authority may determine the estimated cost of the work by using rates prescribed
in District Schedule of Rates (DSR) of the relevant year, in which order for commencement
of such work is issued. The Planning Authority shall also prescribe the standards for the
work. After completion of the works, the Planning Authority shall verify and satisfy itself
that the same is developed as per prescribed standards and thereafter, by deducting the cost
of works, the balance amount of premium shall be recovered from such developer before
issuing Occupancy Certificate.
Provided that, in case the cost of work is more than the premium to be recovered, such
additional cost to be borne by such developer.
vi) Permission for erecting towers and antenna up to height permitted by the Civil Aviation
Department shall be granted by the authority as per the procedure followed for development
permission or otherwise as may be decided by the Government.
vii) While developing site for IT/ITES with additional FSI, support services as defined in the IT
Policy 2015 or amended from time to time, shall be allowed.
viii) Notwithstanding anything contained in the Development Control Regulations of Planning
Authorities, no amenity space is required to be left for development of IT/ITES buildings.
ix) The Directorate of industries will develop a web portal on which the developer of every IT
park will be bound to provide/ update detailed information about names of the units in the
park, utilization of built-up area and activities being carried out, manpower employed in the
IT Park for IT/ ITES and support services on yearly basis.
If a private IT park has availed additional FSI as per the provisions of IT/ ITES policy and
subsequently it is found that the built-up space in the park is being used for non IT/ ITES /
commercial activities/ any other activity not permitted as per the IT/ ITES policy under
which the said park was approved, a penal action as below will be taken, the payment shall
be shared between the concerned Planning Authority and the Government in the ratio of 3:1.
a) The misuse shall be ascertained by physical site verification of the said private IT park
by a team of officers from the Directorate of industries and the Planning Authority
which has approved the building plans of the said private IT park.
b) A per day penalty equal to 0.3% of the prevailing ASR value of the built-up area that
has been found to be used for non- IT/ ITES activities.
c) The penalty will be recovered from the date of commencement of unauthorized use till
the day non-IT use continues.
After payment of the penalty to the concerned Planning Authority which has sanctioned the
building plans of the concerned private IT park, the said private IT Park will restore the use
of premises to the original purpose for which LOI/ Registration was granted. If the private IT
Park fails to pay penalty and/ or restore the use to its original intended use, the concerned
Planning Authority will take suitable action under the Maharashtra Regional and Town
Planning Act 1966, against the erring private IT Park under intimation to the Directorate of
Industries. This provision will also be applicable to existing IT Parks.
7.8.2 For Municipal Council, Nagar Panchayat and Non-Municipal Town Development Plan area.
The regulations mentioned in Regulation No. 7.8.1 above shall be applicable to Municipal Council
area with following modifications. The Chief Officer shall grant additional FSI accordingly.
i) In case of Ambarnath and Kulgaon-Badlarpur Municipal Council, premium to be paid for
additional FSI shall be 30% of the land as prescribed in Annual Statement of Rates. In other
areas, it shall be 10%.
ii) Sharing of premium between the Planning Authority and the Government shall be 75:25.
iii) In case of Ambarnath and Kulgaon-Badlarpur Municipal Council 20% and other areas
Maximum 40% of total proposed Built-up area may be permitted for support services
7.8.3 For Regional Plan area
The regulations mentioned in Regulation No. 7.8.1 above shall be applicable to Regional Plan area
with following modifications. The Authority shall grant additional FSI accordingly.
i) In case of Regional Plan area, premium to be paid for additional FSI shall be10% of the land
as prescribed in Annual Statement of Rates and shall be paid to the Government through
District office of the Town Planning and Valuation Department.
ii) Maximum 40% of total proposed Built-up area may be permitted for support services.
7.9 REGULATION FOR DEVELOPMENT OF BIOTECHNOLOGY PARKS
7.9.1 Definition
The Biotechnology Units/ Parks shall mean Biotechnology units/ parks which are certified by the
Development Commissioner (Industries) or any officer authorised by him in his behalf. The
Biotechnology Park and unit/ units outside park shall have minimum land area of 0.80ha or
1,858sq.m. (20,000sq.ft.) built up area.
7.9.2 Biotechnology Units/ Parks to be Allowed in Industrial Zone
Biotechnology Units/ Parks shall be permitted in Industrial Zone on all plots fronting on roads
having width more than 12 meter and all regulation of Industrial Zone shall apply.
7.9.3 Biotechnology Units/ Park to be allowed in No Development Zone earmarked in the
Development/ Regional Plan.
Biotechnology Units/Parks shall be permitted in No Development Zone subject to following
conditions :-
i) Maximum FSI limit shall be 0.20on gross area and as far as possible the development shall
be at one place of the total land.
ii) The ground coverage shall not exceed 10% of the area of the plot.
iii) Tree plantation shall be done at the rate of 500 Trees/Ha on the remaining land excluding the
built up area and the surrounding open space/ utility space.
iv) The maximum height of buildings shall not exceed 24m.
v) Essential residential development for the staff/ officers‘ accommodation shall be permitted
up to the extent of 33% of the permissible built up area.
7.9.4 Additional FSI to Biotechnology Units/ Park
The Authority may permit the floor space indices specified in these regulations to be exceeded to
the extent of 100% over and above the permissible basic FSI for biotechnology units/ parks
subject to following conditions:-
i) Out of total built up area minimum 90% shall be used for Biotechnology purpose and
maximum 10% (by deducting parking space) shall be used for ancillary users such as
specified in the Govt. Resolution of Industry, Energy and Labour Department No. BTP 2008/
CR-1608/ Ind-2, dated 10/2/2009 or as amended from time to time.
ii) Additional FSI to Biotechnology units would be available to Biotechnology Parks duly
approved by the Directorate of Industries and after observance of all the regulation of
environment.
iii) Parking spaces, as per the provision of Development Control and Promotion Regulation shall
be provided subject to minimum requirement of one parking space per 100sq.m. built up
area.
iv) The additional FSI shall be granted upon payment of premium which shall be paid in the
manner as may be determined by the Government. Such premium shall be recovered at the
rate of 20% of the present day market value of the land under reference as indicated in the
ASR.
v) 25% of the total premium shall be paid to the Government and remaining 75% amount shall
be paid to the said Authority. In Regional Plan area, such amount shall be entirely paid to the
Government through the concerned branch office of the Town Planning and Valuation
Department.
vi) The premium so collected by the Authority shall be primarily used for development of offsite
infrastructure required for the Biotechnology Parks.
vii) In the event, the developer comes forward for provision of such off site infrastructure at his
own cost, then the said Authority shall determine the estimated cost of the works and shall
also prescribe the standards for the work. After completion of the works the said Authority
shall verify as to whether the same is as per prescribed standards and thereafter, by deducting
the cost of works, the balance amount of premium shall be recovered by the said Authority
viii) No condo-nation in the required open spaces, parking and other requirement prescribed in the
regulations shall be allowed in case of additional FSI.
ix) Development of biotechnology park shall be done as per the guidelines issued by Industries
Department vide the Government resolution dated 10th February, 2009 as amended from time
to time.
7.10 INCENTIVE FOR GREEN BUILDINGS
The Authority shall strive to promote green building concepts within the municipal area,
(2)CIDCO as Planning Authority by Virtue of NTDA In order to do so it may empanel agencies of
repute as listed/ recognised by the State/ Central Government. The following incentives shall be
provided for green rated buildings.
i) Green buildings shall be entitled for incentive FSI as below.
GRIHA Three star/ IGBC Silver / LEED silver (1) The ASSOCHAM GEM or equivalent
rating - 3% incentive FSI on basic FSI.
GRIHA Four star/IGBC Gold/LEED Gold (1) The ASSOCHAM GEM or equivalent rating -
5% incentive FSI on basic FSI.
GRIHA Five star/ IGBC Platinum/ LEED Platinum (1) The ASSOCHAM GEM or equivalent
rating - 7% incentive FSI on basic FSI.
Provided, achieving minimum GRIHA Three star/ IGBC Silver / LEED silver (1) The
ASSOCHAM GEM or equivalent rating for construction projects shall be mandatory for all
buildings belonging to Government, Semi- Government, local bodies and public sector
undertakings.
ii) Incentive FSI will be awarded after pre-certification from the empanelled agency. This FSI
shall be exclusive of the limits specified in this UDCPR.
iii) In case that the developer fails to achieve committed rating as per pre-certification at the time
of final occupancy, a penalty shall be imposed at the rate 2 times of the land cost as per ASR
for the incentive FSI for the rating not achieved.
7.11 DEVELOPMENT OF PUBLIC TOILET
If any person constructs public toilet prescribed by the Authority on its land, preferably on ground
floor, he may be granted Amenity TDR against the constructed area as per regulation of
Transferable Development Rights. If owner constructs such amenity on his own land, he shall also
be entitled for aforesaid benefit alongwith additional 50% TDR thereon as incentive, in addition to
TDR of land occupied by such structure along with appurtenant land. In such case, the said
structure along with land shall be transferred, to the Authority with proper approach.
7.12 BUILDINGS OF SMART FINTECH CENTRE
i) The Authority may permit additional FSI up to200% over and above the basic permissible
FSI to Smart Fin-Tech Centre located in Residential/Industrial/Commercial Zone, which
have been approved by the Directorate of Information Technology, proposed to be set up
(hereinafter referred to as the "said unit") by charging premium of 20%of the land rate for
the said landaus prescribed in Annual Statement of Rates for the relevant year of granting
such additional FSI.
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
(2)
Inserted vide Notification u/s 37 (1AA)(c) No. CR 236/18 (Part 6), dt. 12th October 2022.
Provided that additional FSI shall be permissible only on plots having an access road of
minimum 18m. width and subject to approval by committee chaired by the Principal
Secretary, Information Technology and comprising representatives of Industries, Finance
and Urban Development Department (UD-1).
Provided further that, the premium so collected shall be shared between the Planning
Authority and the Government in the proportion of 50: 50.The share of the Government shall
be deposited in the Fin-Tech Corpus fund which is being set up by Director of Information
Technology.
(Explanation:-Premium charges shall be calculated on the value of lands under such zones,
determined by considering the land rates of the said land as prescribed in Annual Statement
of Rates (ASR). These charges shall be paid at the time of permitting additional FSI by
considering the ASR for the relevant year without applying the guidelines).
ii) The total maximum permissible FSI shall not exceed limit of 3.00.In case of plot fronting on
roads having width of 24 m. or more, the FSI may be permitted to be exceeded upto 4.00.
iii) No amenity space is required to be left for development of plot/land up to 2.00Hectare for
Smart Fin-Tech Centre.
iv) At least 85% of total proposed Built-up area (excluding parking area) shall be permitted for
business of Fin-Tech (start-ups, incubators, and accelerators), banking and financial service
including NBFC and insurance, and IT/ITES with focus on FinTech.
v) The Directorate of Information Technology will develop a web portal on which the
developer of every Smart FinTech Centre will be bound to provide/ update detailed
information about names of the units in the park, utilization of built-up area and activities
being carried out, manpower employed in the Smart FinTech Centre on yearly basis.
vi) If a Smart FinTech Centre has availed additional FSI as per the provisions of this regulation
and subsequently it is found that the built-up space in the Smart FinTech Centre is being
used for non-FinTech/ commercial activities/ any other activity, not permitted as per the
Smart FinTech Centre policy under which the said Centre was approved, a penal action as
below will be taken, the payment shall be shared between the Authority and the Government
in the ratio of 3:1.
a) The misuse shall be ascertained by physical site verification of the said Smart FinTech
Centre policy by a team of officers from the Directorate of Information Technology
and the Authority, which has approved the building plans of the said Smart FinTech
Centre.
b) A per day penalty equal to 0.3% of the prevailing ready reckoner value of the built-up
area that has been found to be used for non-FinTech activities, shall be imposed.
c) The penalty will be recovered from the date of commencement of unauthorized use till
the day non-FinTech activities.
After payment of the penalty to the Authority, which has sanctioned the building plans of the
concerned Smart FinTech Centre, the said Smart FinTech Centre will restore the use of
premises to the original purpose for which LOI/ Registration was granted. If the Smart
FinTech Centre fails to pay penalty and/ or restore the use to its original intended use, the
Authority will take suitable action under the Maharashtra Regional and Town Planning Act
1966, against the erring Smart FinTech Centre under intimation to the Directorate of
Information Technology. These provisions will be over and above the penal provisions of
the MRTP Act, 1966.
vii) In this regulation the terms and expression shall have the meaning specified in Fin Tech
Policy declared by Directorate of Information Technology vide Govt. Resolution No.DIT-
2018/CR-17/D-1/39, dated 16th February, 2018. Notwithstanding anything contained in the
existing regulation, the above provisions shall be applicable for Smart FinTech Centre.
Other provisions of existing regulations, which are not specifically mentioned in this
regulation, shall be applicable.
7.13 (1) COMMERCIAL BUILDINGS IN CBD, COMMERCIAL, RESIDENTIAL ZONE IN
PLANNING AUTHORITIES AREAS
Additional FSI for Commercial user development in Central Business District (CBD) or plot
situated in Residential or Commercial Zone or Independent plot wherein Residential or
Commercial uses allowed in Industrial zone":
The Authority may allow FSI up to 5.0 including permissible FSI as per provision of regulation
No.6.3. Table No.6-G in Chaper-6 for commercial user / development on plots marked as CBD or
plots situated in Residential or Commercial zone or independent plot wherein Residential or
Commercial uses allowed in Industrial zone after compliance of Regulation No.4.8.1 of these
Regulations subject to the condition that permissible FSI as per Table No.6-G will be utilized first
and the additional FSI under this Regulation on payment of premium subject to following
conditions.:
1) Additional FSI shall be allowed for plots which are not reserved /designated in the DP except
affected by proposed DP roads/ sanctioned regular line of street under MMC Act and
parking reservation.
2) The development of reserved / designated plots in CBD shall be governed by provisions of
these Regulations.
3) Development for residential purpose to the extent of maximum 30% of the permissible FSI
as per provisions of Regulation No.6.3. Table No.6-G may be allowed. Additional FSI as per
this regulation shall not be permissible for residential user /development.
4) Premium for granting such additional BUA beyond permissible FSI as per Table No.6-G shall
be charged at the rate of 50% of ASR for land and shall be equally shared between the GoM
and the Authority.
5) Provision of Inclusive Housing shall not be applicable for development in CBD.
Provided further that in case the entire commercial development is on a plot situated in
Commercial zone / independent plot in Residential zone, and satisfies other related provisions of
these regulations, the Authority may allow FSI as detailed below including permissible FSI as per
provision of Regulation No.6.3, Table No.6-G for commercial uses/ development on area of plots
excluding area covered under reservation / designation in the DP except affected by proposed DP
roads / sanctioned RL under MMC Act on payment of premium for built up area @ 50% of ASR
for open developed land for FSI 1.00 and shall be equally shared between the GoM and Authority.
In this case, no residential development will be allowed on such plot.
Sr. No. Minimum Maximum Permissible FSI
1 12 m. 3
2 18 m. 4
3 27 m. 5
(1)
Inserted Vide Notification No.CR 236/18 (Part-3), dt. 16th June, 2021. -*-*-*-*-*-*-