# Chapter 12: Structural Safety, Water Supply, Drainage, Sanitary Requirements, Outdoor Display and Other Services

CHAPTER - 12
STRUCTURAL SAFETY, WATER SUPPLY, DRAINAGE AND SANITARY
REQUIREMENTS, OUTDOOR DISPLAY AND OTHER SERVICES.
12.1 STRUCTURAL DESIGN
The structural design of foundations, elements made of masonry, timber, plain concrete;
reinforced concrete, pre-stressed concrete and structural steel shall be carried out in accordance
with Part 6. Structural design Section 1-Loads, courses and effects, Section 2- Soils and
Foundation, Section 3-Timber and Bamboo, Section 4-Masonry, Section5-Concrete, Section 6-
Steel, Section7-Prefabrication, systems building and mixed/ composite construction of National
Building Code of India, amended from time to time. Proposed construction shall be as per the
norms as specified by Bureau of Indian Standard, for the resistance of earthquake, Fire Safety
and natural calamities. Certificate to that effect shall be submitted by the Licensed Structural
Engineer of the developer/ land owner, along with the proposal for development permission, as
prescribed in these Regulations.
12.2 QUALITY OF MATERIALS AND WORKMANSHIP
1) All materials and workmanship shall be of good quality conforming generally to accepted
standards of Public Works Department of Maharashtra and Indian Standard Specifications
and Codes as included in Part 5 - Building Materials and Part 7 - Construction Practices and
Safety of National Building Code of India, amended from time to time
2) All borrow pits dug in the course of construction and repair of buildings, roads,
embankments etc. shall be deep and connected with each other in the formation of a drain
directed towards the lowest level and properly stopped for discharge into a river stream,
channel or drain and no person shall create any isolated borrow pit which is likely to cause
accumulation of water which may breed mosquitoes.
12.3 ALTERNATIVE MATERIALS, METHODS OF DESIGN & CONSTRUCTION AND
TESTS
1) The provision of the regulations are not intended to prevent the use of any material or
method of design or construction, not specifically prescribed by the regulations, provided
any such alternative has been approved.
2) The provision of these regulations is also not intended to prevent the adoption for
architectural planning and layout conceived as an integrated development scheme.
3) The authority may approve any such alternative provided it is found that the proposed
alternative is satisfactory and conform to the provisions of relevant parts regarding material,
design, and construction and that material, method or work offered is, for the purpose
intended, at least equivalent to that prescribed in the rules in quality, strength, compatibility,
effectiveness, fire rating and resistance, durability and safety.
4) Tests: Whenever there is insufficient evidence of compliance with the provisions of the
regulations of evidence that any material or method of design or construction does not
conform to the requirements of the rules or in order to substantiate claims for alternative
materials, design or methods of construction, the Authority may require tests sufficient in
advance as proof of compliance. These tests shall be made by an approved agency at the
expense of the owner.
5) Test method shall be as specified by the regulations for the materials or design or
construction in question. If there are no appropriate test methods specified in the regulations,
the Authority shall determine the test procedure. For methods of tests for building materials;
reference may be made to relevant Indian standards as given the National Building Code of
India, published by the Bureau of Indian Standards. The latest version of the National
building Code of India shall be taken into account at the time of enforcement of these rules.
6) Copies of the results of all such tests shall be retained by the authority for a period of not
less than two year after the acceptance of the alternative material.
12.4 BUILDING SERVICES
1) The planning, design and installation of electrical installations, air-conditioning and heating
work shall be carried out in accordance with Part 8 - Building Services, Section 2-Electrical
and allied Installations, Section 3-Air Conditioning, heating and mechanical ventilation of
National building Code of India, amended from time to time.
2) The planning design including the number of lifts, type of lifts, capacity of lifts depending
on occupancy of building; population on each floor based on occupant load, height of
building shall be in accordance with Section-5 installation of Lifts and Escalators of
National Building Code of India, amended from time to time. In existing buildings, in case
of proposal for one additional floor, existing lift may not be raised to the additional floor.
3) The lifts shall be maintained in working order properly.
12.5 WATER SUPPLY, DRAINAGE AND SANITARY REQUIREMENTS
1) The planning, design, construction and installation of water supply, drainage and sanitation
and gas supply systems shall be in accordance with the provisions of Part 9 - Plumbing
Services, Section 1- Water Supply, Drainage and Sanitation, Section 2 - Gas supply of
National Building Code of India as amended from time to time.
2) Requirements of Water Supply in Building.
The total requirements of water supply shall be calculated based on the population as given
below:-
Occupancy Basis
Residential Building 5 persons per tenement
Other Buildings No. of persons on occupant load and area
of floors given in Table No. (1) 9-E
3) The requirements of water supply for various occupancies shall be as given in Table No.12-
A and Table No.12-B or as specified by the Authority from time to time.
(1)
Substituted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
Table No.12 A
Per Capita Water Requirements for Various Occupancies/ Uses
Sr. Type of Occupancy Consumption per head
No per day (in litres)
1 2 3
1 Residential
(a) in living units 135
(b) Hotels with lodging accommodation (per bed) 180
2 Educational
(a) Day Schools 45
(b) Boarding Schools 135
3 Institutional (Medical Hospitals)
(a) No. of beds not exceeding 100 340
(b) No. of beds exceeding 100 450
(c) Medical quarters and hostels 135
4 Assembly:-Cinema theatres, auditorium etc. (per seat of 15
accommodation)
5 Government and Semi-public business 45
6 Mercantile (Commercial)
(a) Restaurants (per seat) 70
(b) Other business buildings 45
7 Industrial
(a) Factories where bathrooms are to be provided 45
(b) Factories where no bath-rooms are required to be provided 30
Storage (including warehousing) 30
9 Hazardous 30
10 Intermediate / Stations (excluding mail and express stops) 45 (25)*
11 Junction Stations 70 (45)*
12 Terminal / Stations 45
13 International and domestic Airports 70
* - The value in parenthesis is for stations where bathing facilities are not provided.
Note: The number of persons for Sr. No. (10) to (13) shall be determined by the average number
of passengers, handled by the station daily; due consideration may be given to the staff
and workers likely to use the facilities.
Table No.12 B
FLUSHING STORAGE CAPACITIES
Sr. Classification of building Storage capacity.
No.
(1) (2) (3)
1 For tenements having common 900 litres net per w.c. seat.
convenience
2 For residential premises other 270 litres net for one w.c. seat and 180 litres for
than tenements having each additional seat in the same flat.
common convenience
3 For Factories and Workshops 900 litres per w.c. seat and 180 litres per urinal
seat.
4 For cinemas, public assembly 900 litres per w.c. seat and 350 litres per urinal
halls, etc. seat.
12.6 DRAINAGE AND SANITATION REQUIREMENTS
12.6.1 General
1) There should be at least one water tap and arrangement for drainage in the vicinity of each
water-closet or group of water-closets in all the buildings.
2) Each family dwelling unit on premises (abutting on a sewer or with a private sewage
disposal system) shall have, at least, one water-closet and one kitchen type sink. A bath or
shower shall also be installed to meet the basic requirement of sanitation and personal
hygiene.
3) All other structures for human occupancy or use on premises, abutting on a sewer or with a
private sewage disposal system, shall have adequate sanitary facilities, but in no case less
than one water-closet and one other fixture for cleaning purposes.
12.6.2 For Residences
1) Dwelling with individual convenience shall have at least the following fitments:
a) One bathroom provided with a tap and a floor trap,
b) One water-closet with flushing apparatus with an ablution tap; and
c) One tap with a floor trap or a sink in kitchen or wash place.
2) Dwelling without individual conveniences shall have the following fitments:
a) One water tap with floor trap in each tenement,
b) One water-closet with flushing apparatus and one ablution tap, bath for every two
tenements, and
c) One bath with water tap and floor trap for every two tenements.
Such fitments shall not be necessary where there is not water supply scheme of the
authority.
12.6.3 For Buildings other than Residences
The requirements for fitments for drainage and sanitation in the case of buildings other than
residences shall be in accordance with Table No. 12-C to 12-P. The following shall be, in
addition, taken into consideration:
a) The figures shown are based upon one (1) fixture being the minimum required for the
number of persons indicated or part thereof.
b) Building categories not included in the tables shall be considered separately by the
Authority.
c) Drinking fountains shall not be installed in the toilets.
d) Where there is the danger of exposure to skin contamination with poisonous, infectious or
irritating material, washbasin with eye wash jet and an emergency shower located in an
area accessible at all times with the passage / right of way suitable for access to a wheel
chair, shall be provided.
e) When applying the provision of these tables for providing the number of fixtures,
consideration shall be given to the accessibility of the fixtures. Using purely numerical
basis may not result in an installation suited to the need of a specific building. For
example, schools should be provided with toilet facilities on each floor. Similarly toilet
facilities shall be provided for temporary workmen employed in any establishment
according to the needs; and in any case one WC and one washbasin shall be provided.
f) All buildings used for human habitation for dwelling work, occupation, medical care or any
purpose detailed in the various tables, abutting a public sewer or a private sewage disposal
system, shall be provided with minimum sanitary facilities as per the schedule in the tables.
In case the disposal facilities are not available, they shall be provided as a part of the
building design for ensuring high standards of sanitary conditions in accordance with this
section.
g) Workplaces where crèches are provided, they shall be provided with one WC for 10
persons or part thereof, one washbasin for 15 persons or part thereof, one kitchen sink with
floor tap for preparing food / milk preparations. The sink provided shall be with a drinking
water tap.
h) In all types of buildings, individual toilets and pantry should be provided for executives and
for meeting / seminar / conference rooms, etc. as per the user requirement.
i) Where food is consumed indoors, water stations may be provided in place of drinking
water fountains.
12.7 SIGNS AND OUTDOOR DISPLAYSTRUCTURES
12.7.1 The display of advertising signs on buildings and land, shall be in accordance with Part 10,
Section-2 "Signs and outdoor display structures" of National Building Code of India as amended
from time to time and, shall be in accordance with respective rules/by-laws, directive given by
Government, and also rules/by-laws framed by the Authority in this regards from time to time.
12.7.2 Prohibition of advertising signs and outdoor display structure in certain cases
Notwithstanding the provisions of sub-regulations, no advertising sign or outdoor display
structures shall be permitted on buildings of architectural, aesthetical, historical or heritage
importance as may be decided by the Authority or on Government Buildings save that in the case
of Government buildings only advertising signs or outdoor display structure may be permitted if
they relate to the activities for the said buildings‘ own purposes or related programmers.
Table No. 12 C : Sanitation Requirements - Office Buildings
Sr. Fixtures Public Toilets Staff Toilets
No. Male Female Male Female
(1) (2) (3) (4) (5) (6)
i) Executive Rooms and Conference Unit could be common for For individual officer
Halls in Office Buildings Male/ Female or separate rooms
depending on the number of
Toilet suite comprising one WC,
user of each facility
one washbasin (with optional
shower stall if building is used
round the clock at user‘s option)
Pantry optional as per user
requirement
ii) Main Office Toilets for Staff and
Visitors
a) Water-closet 1 per 25 1 per 15 1 per 25 1 per 15
b) Urinals Nil up to 6 - Nil up to 6 -
1 for 7-20 1 for 7-20
2 for 21-45 2 for 21-45
3 for 46-70 3 for 46-70
4 for 71-100 4 for 71-
Add @ 3% for 101-200 101-200
Add @ 2.5 % Over 200 Over 200
Table No.12 D : Sanitation Requirements - Factories
Sr. Fixtures Offices/Visitors Workers
No. Male Female Male Female
(1) (2) (3) (4) (5) (6)
i) Water-closets 1 for up to 25 1 for up to 15 1 for up to 1 for up to 12
(Workers & Staff) 2 for 16-35 2 for 16-25 15 2 for 13-25
3 for 36-65 3 for 26-40 2 for 16-35 3 for 26-40
4 for 66-100 4 for 41-57 3 for 36-65 4 for 41-57
5 for 58-77 4 for 66-100 5 for 58-77
6 for 78-100 6 for 78-100
For persons 101-200 add 3 % 5 % 3 % 5 %
For persons over 200 add 2.5 % 4 % 2.5 % 4 %
ii) Urinals Nil up to 6 - Nil up to 6 -
1 for 7-20 1 for 7-20
2 for 21-45 2 for 21-45
3 for 46-70 3 for 46-70
4 for 71-100 4 for 71-100
For persons 101-200 add 3 % 3 %
For persons over 200 add 2.5 % 2.5 %
Table No. 12E : Sanitation Requirements - Cinema, Multiplex Cinema, Concerts and Convention
Halls, Theatres
Sr. Fixtures Public Staff
No.
Male Female Male Female
(1) (2) (3) (4) (5) (6)
i) Water-closets 1 per 100 up to 400 3 per 100 up to 200 1 for up to 15 1 for up to
Over 400, add at 1 per Over 200, add at 2 per 2 for 16 - 35 12
250 or part thereof 100 or part thereof 2 for 13 - 25
ii) Urinals 1 per 25 or part - Nil up to 6 -
thereof 1 for 7-20
2 for 21-45
NOTE - Male population may be assumed as two-third and female population as one-third.
Table No. 12-F- Sanitation Requirements - Art Galleries, Libraries and Museums
Sr. Fixtures Public Staff
No. Male Female Male Female
(1) (2) (3) (4) (5) (6)
i) Water-closets 1 per 200 up to 400 1 per 100 up to 200 1 for up to 15 1 for up to 12
Over 400 add at 1 per Over 200 add at 1 per 2 for 16-35 2 for 13-25
250 or part thereof 150 or part thereof
ii) Urinals 1 per 50 - Nil up to 6 -
1 per 7-20
2 per 21-45
Notes - Male population may be assumed as two-third and female population as one-third.
Table No. 12-G- Sanitation Requirements - Hospitals with Indoor Patient Wards
Sr. Fixtures Patient Toilets Staff Toilets
No. Male Female Male Female
(1) (2) (3) (4) (5) (6)
i) Toilet suite Private room with up to 4 patients For individual doctor‘s /
comprising one officer‘s rooms
WC and one
washbasin and
shower stall
For General Wards, Hospital Staff and Visitors
ii) Water-closets 1 per 8 beds or part 1 per 8 beds or 1 for up to 15 1 for up to 12
thereof part thereof
2 for 16-35 2 for 13-25
iii) Urinals 1 per 30 beds - Nil up to 6 -
1 for 7 to 20
2 for 21-45
Note - Male population may be assumed as two-third and female population as one-third.
Table No. 12-H- Sanitation Requirements - Hospitals - Outdoor Patient Department
Sr. Fixtures Patient Toilets Staff Toilets
No. Male Female Male Female
(1) (2) (3) (4) (5) (6)
i) Toilet suite comprising For up to 4 patients For individual doctor‘s/officer‘s
one WC and one rooms
washbasin (with
optional shower stall if
building used for 24 h)
ii) Water-closets 1per 100 2 per 100 1 for up to 15 1 for up to 12
persons or part persons or 2 for 16-35 2 for 13-25
thereof part thereof
ii) Urinals 1 per 50 - Nil up to 6 -
persons or part 1 per 7 to 20
thereof 2 per 21-45
Note - Male population may be assumed as two-third and female population as one-third.
Table No. 12-I - Sanitation Requirements - Hospitals’ Administrative Buildings
Sr. Fixtures Staff Toilets
No.
Male Female
(1) (2) (3) (4)
i) Toilet suite comprising one For individual doctor‘s/officer‘s rooms
WC and one washbasin
(with optional shower stall if
building used for 24 h)
ii) Water-closets 1per 25 persons or part 1per 15 persons or part
thereof thereof
iv) Urinals Nil up to 6 -
1 per 7 to 20
2 per 21-45
Note - Some WC‘s may be European style if desired.
Table No. 12-J- Sanitation Requirements -Hospitals’ Staff Quarters and Nurses Homes
Sr. Fixtures Staff Quarters Nurses Homes
No.
Male Female Male Female
(1) (2) (3) (4) (5) (6)
i) Water- 1 per 4 persons or 1per 4 persons 1 per 4 persons 1per 4 persons
closets part thereof or part thereof or part thereof or part thereof
2 for 16-35 2 for 16-35
Table No. 12- K -Sanitation Requirements -Hotels
Sr. Fixtures Public Rooms Non-Residential Staff
No. Male Female Male Female
(1) (2) (3) (4) (5) (6)
i) Toilet suite Individual guest rooms with attached -
comprising one toilets
WC, washbasin
with shower or a
bath tub
Guest Rooms with Common Facilities
ii) Water-closets 1 per 100 persons 2 per 100 persons 1 for up to 15 1 for up to 12
up to 400 up to 200 2 for 16-35 2 for 13-25
Over 400 add at Over 200 add at 1 3 for 36-65 3 for 26-40
1 per 250 or part per 100 or part 4 for 66-100 4 for 41-57
thereof thereof 5 for 58-77
6 for 78-100
iv) Urinals 1 per 50 persons Nil, upto 6 persons Nil up to 6 -
or part thereof 1 for 7-20 persons 1 for 7 to 20
2 for 21-45 persons 2 for 21-45
3 for 46-70 persons 3 for 46-70
4 for 71-100 4 for 71-100
persons
Note - Male population may be assumed as two-third and female population as one-third.
Table No. 12-L-Sanitation Requirements -Restaurants
Sr. Fixtures Public Rooms Non-Residential Staff
No. Male Female Male Female
(1) (2) (3) (4) (5) (6)
i) Water- 1 per 50 seats up to 2 per 50 seats 1 for up to 15 1 for up to 12
closets 200 up to 200 2 for 16-35 2 for 13-25
Over 200 add at 1 Over 200 add at 3 for 36-65 3 for 26-40
per 100 or part 1 per 100 or 4 for 66-100 4 for 41-57
thereof part thereof 5 for 58-77
6 for 78-100
ii) Urinals 1 per 50 persons or ---- Nil up to 6 ----
part thereof 1 for 7-20
2 for 21-45
3 for 46-70
4 for 71-100
NOTE : Male population may be assumed as two-third and female population as one-third.
Table No. 12-M- Sanitation Requirements -Schools and Educational Institutions
Sr. Fixtures Nursery Non-Residential Residential
School
No. Boys Girls Boys Girls
(1) (2) (3) (4) (5) (6) (7)
i) Water- 1 per 15 1 for 40 1 per 25 1 per 8 pupils 1 per 6 pupils
closets pupils or part pupils or part pupils or part or part thereof or part thereof
thereof thereof thereof
ii) Urinals ---- 1 per 20 ---- 1 per 25 ----
pupils or part pupils or part
thereof thereof
Table No. 12-N- Sanitation Requirements -Hostels
Sr. Fixtures Resident Non-Resident Visitor/Common Rooms
No. Male Female Male Female Male Female
(1) (2) (3) (4) (5) (6) (7) (8)
i) Water- 1 per 8 or 1 per 6 or 1 for up to 1 for up to 1 per 100 up 1 per 200
closet part part 15 12 to 400 up to 200
thereof thereof
2 for 16-35 2 for 13-25 Over 400 Over 200
add at 1 per add at 1 per
3 for 36-65 3 for 26-40
250 100
4 for 66- 4 for 41-57
5 for 58-77
6 for 78-
iii) Urinals 1 per 25 or ---- Nil up to 6 ---- 1 per 50 or ----
part part thereof
1 for 7-20
thereof
2 for 21-45
3 for 46-70
4 for 71-
Table No. 12-O-Sanitation Requirements - Mercantile Buildings, Commercial Complexes,
Shopping Malls, Fruit& Vegetable Markets
Sr.No Fixtures Shop Owners Common Toilets in Public Toilet for Floating
. Market/ Mall Building Population
Male Female Male Female Male Female
(1) (2) (3) (4) (5) (6) (7) (8)
i) Water- 1 per 8 persons or part 1 for up to 1 for up to 1 per 50 1 per 50
closets thereof 15 12 (Minimum (Minimum
2 for 16-35 2 for 13-25 2) 2)
3 for 36-65 3 for 26-40
4 for 66-100 4 for 41-57
5 for 58-77
6 for 78-100
iii) Urinals ---- ---- Nil up to 6 ---- 1 per 50 ----
1 for 7-20
2 for 21-45
3 for 46-70
4 for 71-100
Table No. 12-P-Sanitation Requirements - Airports and Railway Stations
Sr. Fixtures Junction Stations, Terminal Railway and Domestic and
No. Intermediate Stations Bus Stations International Airports
and Bus Stations
Male Female Male Female Male Female
(1) (2) (3) (4) (5) (6) (7) (8)
i) Water- 3 for up to 4 for up to 4 for up to 5 for up to Minimum-2 Minimum-2
closet 1000 Add 1000 Add 1 1000 Add 1000 Add for 200-2 For 200-2
1 per per 1 per 1 per For 400-9 For 400-9
additional additional additional additional For 600-12 For 600-12
1000 or 1000 or 1000 or 1000 or For 800-16 For 800-16
part part thereof part part thereof For For 1000-18
thereof thereof 1000-18
ii) Urinals 4 for up to ---- 6 for up to ---- 1 per 40 or ----
1000. Add 1000. Add part thereof
1 per 1 per
additional additional
1000 1000
iii) Toilet for 1 per 4000 1 per 4000 1 per 4000 1 per 4000 1 per 4000 1 per 4000
Disabled (Minimum (Minimum 1)
1)
-*-*-*-*-*-