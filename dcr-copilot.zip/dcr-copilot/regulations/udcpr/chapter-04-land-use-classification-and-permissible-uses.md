# Chapter 4: Land Use Classification and Permissible Uses

CHAPTER -4
LAND USE CLASSIFICATION AND PERMISSIBLE USES
4.1 GENERAL
i) In case of development / re-development of any land, building or premises, the intended use
shall conform to the land use or, as the case may be, purpose of designation, allocation or
reservation assigned to it in the Development Plan / Regional Plan/ Planning Proposal,
unless specified otherwise.
ii) Non-Conforming Uses Existing Lawfully - Any lawful non-conforming use of premises
existing prior to the date of coming in to force of the Development Plan / Regional Plan/
Planning Proposal shall continue and may be allowed to be expanded within the holding in
the original sanctioned permission and that when a building containing non-conforming use
is pulled down or has fallen down, the use of the new building shall be in conformity with
these regulations or with lawful existing use.
iii) Existing features shown on the plan - The existing features shown on Development/
Regional Plan are indicative and shall stand modified on Development/ Regional
Plan/Planning Proposal as per actual situation. Mention of particular use on Development/
Regional Plan shall not bar the owner from permission to develop land as allowed in the
zone shown for such land. Also, boundaries of S.No., alignment of existing road/ nallah and
other physical features of land shall be as per measurement plan of Land Records
Department and the land unaffected by such physical features shall be allowed to be
developed for the uses permissible under the adjoining predominant land use zone.
iv) Development of Parking - The Authority may develop any land, owned by or in possession
of the Authority, for public parking in any of the forms - single or multi-storeyed,
underground or above ground, irrespective of its existing use or proposed use in
Development / Regional Plan/Planning Proposal.
Provided that the Authority may allow Basement Parking below existing or proposed Play
Ground, in the plan at one or two levels below the ground level subject to conditions, as may
be prescribed by the Authority.
v) Discontinuance of Zoning in pursuance of existing use- If any land is shown in Public
Semi-Public zone or Public Utility Zone because of the activity that existed there or
otherwise, such lands shall be deemed to have been shown in the adjacent predominant Zone
after such activity ceases to exist, unless otherwise prohibited.
4.2 LAND USE CLASSIFICATION AND EQUIVALENCY OF ZONES
The different land use classifications in Development / Regional Plan / Planning Proposal &
different uses permissible in that land use zone and equivalency of zone in various Authorities'
areas shall be as given below:-
I) Residential Zone -Following other zones shall be treated as equivalent to Residential zone.
i) Residential Zone - (R1)
ii) Residential Zone with Shop line. (R-2)
iii) General Residential Zone.
iv) Residential Zone - R-2. (1) (----)
v) Residential Zone - (2) R-3 and R-4, with payment of (2) infrastructure cost as decided by
the Authority.
vi) Urbanisable Zone.
vii) Special Residential Zone.
viii) Pre-dominantly Residential Zone.
ix) Slum Improvement Zone.
x) Low Density Residential Zone in Development Plan of Jalgaon.
xi) Mix use Zone.
II) Low Density Residential Zone.
III) Future Urbanisable Zone.
IV) Commercial Zone -Following other zones shall be treated as equivalent to Commercial
Zone.
i) Local Commercial - (C-1)
ii) Commercial Zone - (C-1)/ Special Commercial Zone/ Business Hub Area/ Central
Business District Zone
iii) Commercial Zone - (C-2)
iv) Predominantly Commercial
V) Industrial Zone - Following other zones shall be treated as equivalent to Industrial Zone.
i) Service Industries - (I-1)
ii) General Industries - (I-2)
iii) Special Industries (I-3)
iv) Wholesale Market and Warehousing.
v) Transport Hub and Logistic Park.
VI) Loom Industry cum Residential Zone.
VII) Public Semi-public Zone - following zone shall be treated (2) as equivalent to Public Semi-
public Zone.
i) Institutional.
VIII) Agricultural Zone - Following other zones shall be treated as equivalent to Agricultural
Zone.
i) Horticultural Zone.
ii) Plantation Zone.
iii) No Development Zone.
iv) Green Zone - 1. / Green Zone.
v) Cattle Shed Zone.
(+)vi) Command Area Zone with following Condition.
Condition - The Development in command Area Shall be permissible subject to
prior NOC and Payment of restoration charges, if any , to Irrigation Department.
(1)
The word ‗R-3‘ is deleted vide Corrigendum / Addendum under Regulation No. 1.10 CR 121/21, dt. 02nd December, 2021.
(2)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
(+) Inserted vide Order by Director of Town Planning dt. 07/04/20222.
IX) Green Belt / Green Belt Zone. (Other than Reservation of Green Belt.) / River Protection
Belt. (other than reservation) - Following zone shall be treated as equivalent to Green
Belt / Green Belt Zone.
i) Recreational land use.
X) Traffic and Transportation Zone - Following zone shall be treated as equivalent to Traffic
and Transportation Zone
i) Marshalling yard.
XI) Regional Park Zone.
i) (1) Recreation Centres
ii) (1) Recreational Zone
XII) Tourism Development Zone- Following zone shall be treated as equivalent to Tourism
Development Zone.
i) Tourist Centre
ii) Hill Station Zone.
XIII) Afforestation Zone.
XIV) Hill Top-Hill Slope Zone (HTHS) (Slope having gradient more than 1:5 irrespective of
whether shown on plan or not.) / Hilly area.
XV) Green Zone -2
XVI) Forest Zone.
XVII) Defence Zone.
XVIII) Mines and Quarry Zone - Following zone shall be treated as equivalent to Mining and
Quarry Zone.
i) Quarry to Park Zone,
XIX) Public Utility Zone.
XX) Woodland Corridor.
XXI) Special Economic Zone.
XXII) Airport and Allied Activities / Service Zone.
Note : In case, any land use zone is not listed above, the equivalency of such zone shall be
decided by the Director of Town Planning, Maharashtra State, Pune.
4.3 RESIDENTIAL ZONE - R-1
(Residential Zone R1 includes Residential plots abutting on roads below 9m. in width in
congested area shown on the Development Plan and on roads below 12m. in width in outside
congested area (i.e. in non-congested area)).
(In case of C Class MCs, Nagarpanchayats and R.P. areas, the above road width of 12 m. shall be
9 m. in non-congested area).
The following uses and accessory uses to the principal use shall be permitted in buildings or
premises in purely Residential Zone, subject to other regulations:-
i) Any residences, Slum Improvement / Rehabilitation.
ii) Hostels for students / working men/ women, lodging with or without boarding facilities.
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
iii) Old age home, sanatorium, orphanage, night shelter dormitories.
iv) Customary Home occupation i.e. occupations customarily carried out by the members of
the household without employing hired labourer and shall include stitching, embroidery,
beauty parlour, button making etc. with or without motive power. If motive power is used,
the total electricity load should not exceed 1 HP (0.75kw).
v) Medical and Dental Practitioner's Dispensaries including pathological laboratory,
diagnostic clinics, polyclinics, counselling centres, clinics, to be permitted on any floor.
Maternity homes, clinics, nursing homes with indoor patients with bed not exceeding 20 on
any floor with separate means of access of staircase from within the building or outside
may be permitted but not in any case within the prescribed marginal open spaces. Where
doctor's residence is located on upper floor, then such separate means of access of staircase
may not be necessary.
vi) Professional Offices in residential tenement for own purpose not exceeding carpet area of
50 Sq.m. each
vii) Community halls, welfare centre, gymnasia (each not exceeding 100sq.m.)
viii) Primary and nursery schools including students' hostels except trade schools
ix) Crèche, Day-care centre upto 100sq.m.in an independent building or part of building.
x) Private coaching classes, student‘s mess in an independent building or part of building
upto100 Sq.m. Subject to separate parking facility in the same premises.
xi) Religious buildings.
xii) Public/ City Libraries and Museums in independent building or on ground or first floor of
the composite building.
xiii) Club Houses or gymkhanas in residential complexes.
xiv) Public or Private Park (except an amusement park), garden and play field in independent
plot not used for business purpose.
xv) Bus shelters, Taxi-Rickshaw stands, trolley bus shelters, Railway Station, Metro station,
BRT stand, cycle stand and like uses.
xvi) Convenience shops only on ground floor.
xvii) Police Station, Police Chowky, Government and Municipal sub-offices, Post and Telegraph
Offices, Branch offices of Banks with safe Deposit Vaults, Electric substations, Fire Aid
posts, Home Guards and Civil Defence Centres, essential Public utilities, Pumping stations,
water installations and ancillary structures thereof required to cater to the local area.
xviii) Electronic Industry of the Assembly type (not of the manufacturing type) with the
following restrictions :-
a) Motive Power shall not exceed 1 H.P.
xix) Information technology establishment (ITE) (pertaining to software only) on the plots/
premises fronting on roads having width 9m. and above
xx) Flour mill and wet / dry masala grinding / subject to following conditions: -
a) Power requirement shall not exceed 10HP.
xxi) Burial grounds, cremation grounds and essential public utilities, on a road having width of
9m. and above
xxii) Agricultural, horticultural and allied uses (except agro-based industries).
xxiii) Raisin production, book binding.
xxiv) Public conveniences.
xxv) Research, experimental and testing laboratories not involving any danger of fire or
explosion or of any obnoxious nature
4.4 RESIDENTIAL ZONE R-2
(Residential Zone R2 includes Residential plots abutting on roads having existing or proposed
width of 9 m. and above in congested area and 12 m. and above in non-congested area).
(In case of C Class MCs, Nagarpanchayats and R.P. areas, the above road width of 12 m. shall be
9 m. in non-congested area).
4.4.1 In this zone, the following uses, mixed uses may be permitted
i) All uses permissible in R-1 shall be permitted in R-2 zone, without any restriction of area,
ii) All uses or mix uses may be permitted irrespective of restriction on floor or area, except uses
mentioned at Regulation No. 4.8 (ii), 4.11(viii, xviii, xxi, xxii, xxxi, xxxvii), 4.21 and like.
iii) All Uses permissible in Public Semi-public Zone.
4.4.2 Uses Permitted in Independent Premises/ Buildings
i) Vehicle Fuel filling Station including LPG / CNG / Ethanol with or without service stations
subject to provisions of Regulation No.4.11(vi) (c, d and e) and subject to provisions in
Regulation No. 6.2.2. Sr. No. 6 of Table 6E. (This station may include Electric Vehicle
Charging Stations)
ii) Trade or other similar schools.
iii) LPG godown, Bulk storage and sale of kerosene subject to NOC of Chief Controller of
Explosives, Government of India.
iv) Service Industries:- The Service Industries may be permitted in independent building / Plot
as given below :-
a) Following Industries may be permitted with power requirement not more than 10 H.P.,
employment not more than 9 persons and floor area not exceeding 100 Sq.m.
(I) FOOD PRODUCT
i) Manufacture of milk and dairy products such as butter, ghee, etc.
ii) (a) Rice huller
(b) Groundnut decorticators
(c) Grain Mill for production of flour
(d) Manufacture of supari and Masala grindings.
(e) Baby oil expellers
iii) Manufacture of bakery products with no Floor above.
iv) Coffee, curing roasting and grinding
v) Manufacture of Ice
vi) Sugarcane crushing & Fruit Juice
(II) BEVERAGES & TOBACCO
i) Manufacture of bidi ( May be permitted in R-1 Zone also)
(III) TEXTILE & TEXTILEPRODUCTS
i) Handloom / power-loom of yarn for a maximum of 4 looms.
ii) Embroidery & making of crape laces & fringes
iii) Manufacture of all types of textile garments including wearing apparel.
iv) Manufacture of made up textiles goods such as curtains, mosquito net,
mattresses, bedding material pillow cases, textile bags. etc.
(IV) WOOD PRODUCTS AND FURNITURE
Manufacture of wooden furniture and fixtures.
(V) PAPER PRODUCTS AND PRINTING PUBLISHING
i) Manufacture of cartons and boxes from papers and paper board, paper
pulp,
ii) Printing & Publishing newspaper.
iii) Engraving etching block making etc.
iv) Book binding(May be permitted in R-1 Zone also)
(VI) LEATHER PRODUCTS
Repair of footwear and other leather.
(VII) RUBBER AND PLASTIC
i) Re-treading and vulcanizing works
ii) Manufacture of rubber balloons, hand gloves and allied products
(VIII) METAL PRODUCTS
i) Manufacture of metal building components such as grills, gates. Doors
and window frames, water tanks, wire nets, etc.
ii) Tool sharpening and razor sharpening works
(IX) ELECTRICAL GOODS
Repairs of household electrical appliances such as radio set. Television set, tape
recorders, heaters, irons, shavers, vacuum cleaners, refrigerators, air-
conditioners, washing machines, electric cooking ranges, motor rewinding
works etc.
(X) TRANSPORT EQUIPMENT
i) Manufacturing of push cart, hand cart, etc.
ii) (a) Servicing and repairing of bicycle, rickshaws, motor cycle and
motor Vehicles
(b) Battery charging and repairs.
(XI) OTHER MANUFACATURING AND REPAIR INDUSTRIES AND
SERVICES
i) Manufacture of jewellery and related articles
ii) Repair of watch, clock and jewellery
iii) Manufacture of Musical instruments and its repair.
iv) (a) Repairs of locks, stoves, umbrellas, sewing machines, gas burners,
buckets & other sundry household equipment.
(b) Optical glass grinding and repairs
v) Petrol/CNG/Ethanol/All fuel filling/Electric Vehicle Charging Stations)
subject to provisions in Regulation No. 6.2.2. Sr. No. 6 of Table 6E.
vi) Laundries, Laundry service and cleaning, dyeing, bleaching and dry
cleaning
vii) Photo processing laboratories.
viii) Electronic Industry of assembly type (and not of manufacturing type
including heating load) ;
(1) (XII) Manufacture of structural stone goods, stone dressing, stone crushing and polishing,
Manufacture of earthen & plaster states and images, toys and art wares and
Manufacture of cement concrete building components, concrete jallies, septic tank,
plaster of paris work lime mortar etc.
b) Following service industries may be permitted without restrictions mentioned in (a)
above.
(I) FOOD PRODUCT
Canning & preservation of Fruits & Vegetables, Meat and Fish including
production of Jam, Jelly, Sauce, etc.
(II) PAPER PRODUCTS AND PRINTING PUBLISHING
Printing & Publishing periodicals, books journals, atlases, maps, envelope,
printing picture, post-card, embossing
4.5 LOW DENSITY RESIDENTIAL ZONE
In this zone, all uses permissible in Residential Zone shall be permitted subject to FSI restrictions
mentioned in these regulations. (Chapter 10)
4.6 FUTURE URBANIZABLE ZONE
In this zone all uses permissible in Residential Zone shall be permitted subject to fulfilment of
following requirements.
i) For extending offsite infrastructure like road, water supply, sewage line, electricity, to the
land, the expenses shall be borne by the owner and shall be deposited with the Authority as
per the expenses communicated by it. However the owner shall have liberty to construct
such infrastructure at his own cost, as per the drawing, design and specification approved by
the Authority.
ii) If the land is located on Development Plan road of width more than 18 m., then construction
of road of width 18 m. to his land, shall be the liability of the owner, else 12 m. wide road
with asphalting shall be necessary.
4.7 COMMERCIAL ZONE
In commercial zones, buildings or premises shall be used for the uses and purposes given below :-
i) Any use permitted in residential R2 zone.
ii) Any commercial use, wholesale establishments with or without storage area,
iii) Uses permissible in Public Semi-public Zone.
iv) Public utility buildings.
v) Activities permissible in Service Industries.
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
4.8 INDUSTRIAL ZONE
Industries shall include any building or part of a building or structure, in which products or
materials of all kinds and properties are fabricated, assembled or processed, for example assembly
plants, laboratories, dry cleaning plants, power plants, pumping station; smoke houses, laundries,
gas plants, refineries, dairies and saw - mills.
The following uses shall be permissible in Industrial Zone.
i) The service industries as listed in Regulation No.4.4.2 (iv) without restrictions on power
requirement, employment, floor area and other restrictions.
ii) Any industry / industries may be permitted. Minimum buffer open space / set back (which
may include marginal distance and road width if any) from the boundary of industrial
Building / use to residential or habitable zone/ use, shall not be less than 23 m. Such buffer
open space shall be kept in the land falling in the industrial zone. In cases where
construction has already taken place in Industrial Zone, then such Buffer open space may be
kept in a Residential Zone.
Provided that, the area under such buffer open space / setback shall not be deducted for
computation of FSI.
Provided further that, if the land under industrial zone is utilized entirely for non-polluting
industries, IT / ITES or like purposes, then such buffer zone / open space shall not be
necessary.
Provided further that, industrial godowns/ godowns shall also be permissible under this
regulation.
iii) Building or premises in industrial zone may be used for any industrial as well as accessory
uses like banks, canteens, welfare centre and such other common purposes considered
necessary for the industrial workers, quarters of watchmen, caretakers or other essential staff
required to be maintained on the premises. Such residential/ commercial/ other uses may be
permitted up to 25% of the total proposed built-up area of such industrial use.
iv) Following uses may also be permitted
a) Parking lots,
b) Buildings of public utility concerns,
c) Buildings of Banks,
d) Residential Hotels, Restaurants,
e) Storage Buildings,
f) Drive-in-Theatres, cinema or theatres, subject to provisions of the Maharashtra
Cinemas (Regulation) Act,
g) Highway amenities as permitted in Agriculture zone with FSI at par with Industrial
zone,
h) Industrial training centre/ institute,
i) Information Technology Establishments. (IT/ ITES),
j) Bio-technology units,
k) Public Charging Stations for Electric Vehicle, Petrol pumps and Service Stations /
Fuel Filling Stations including LPG / CNG / Ethanol etc. subject to provisions in
Regulation No. 6.2.2.Sr. No. 6 of Table 6E.
(l) Hospitals and dispensaries.
v) Transport Hub and Logistic Park including warehousing, cold storage, multimodal transport,
container depot, container freight stations etc.
4.8.1 Allowing Residential / Commercial Uses in Industrial Zone -
In consultation with the Divisional Head of concerned division of the Town Planning Directorate
in case of areas other than Municipal Corporations and in case of Municipal Corporations without
such consultation, and on appropriate conditions,
a) The existing or newly built-up area of Industrial unit in the Industrial zone (excluding the
area of Cotton Textile Mills)may be permitted to be utilized for Residential or Commercial
purposes;
b) The lands in the Industrial Zone in Development Plan, Regional Plan excluding the area of
Cotton Textile Mills, but including lands in industrial zone in Town Planning Scheme area,
may be utilised for any of the permissible uses in the Residential and Commercial Zone
subject to the following provisions: -
i) Such use shall be allowed only on payment of Premium at the rate of 5%of the land
value arrived at as per the Annual Statement of Rates (without considering the
guidelines therein) of the respective year. For calculating land value, industrial
holding in the development proposal shall be considered. Out of this, 50% amount
shall be paid to the Authority and 50% amount shall be paid to the Government.
ii) The Residential/ Commercial use in respect of industries which are not in operation or
which are to be closed, shall not be permitted without an NOC from Labour
Commissioner, Maharashtra State, Mumbai stating that all legal dues have been paid
to the workers or satisfactory arrangements between management and workers have
been made. However, in respect of any open land in the Industrial Zone where
industry never existed, NOC from Labour Commissioner shall not be required.
iii) Recreational open space as may be required under regulations for Residential use shall
be provided.
iv) The land to be provided as amenity space in the provisions mentioned hereunder shall
be handed over to the Authority free of encumbrances.
v) In the layout or sub-division of such land admeasuring up to 2 Ha., 10% of land shall
be provided for public utilities and amenities, like electric sub-station, bus-station,
sub-post office, police out-post, garden, playground, school, dispensary and such
other amenities/ utilities as may be considered necessary. In case of land admeasuring
more than 2 ha., such amenity space shall be 10% upto 2 ha. area and 15% for the area
over and above 2 ha.
vi) The land having area up to (1)1.0 hectare in size which is allocated for industrial use
may be permitted to be used for Residential purpose or any other permissible uses in
Residential/ Commercial Zone. The owner / developer shall provide either 10%
amenity space in the form of open land or 5% built up space in the proposed
construction at appropriate location, preferably on ground floor. Amenity TDR, as per
regulation containing provisions of TDR, shall be permissible.
vii) The land under public utility / amenity shall be handed over to the Planning Authority
in lieu of FSI / TDR with proper access and levelling of the land. These areas will be
in addition to the recreational space as required to be provided under these
regulations.
(1)
Inserted Vide Notification u/s 37(1AA)(C) & 20 (4) by Govt. No. CR 236/18(Part 4) dt. 28 Dec. 2022.
viii) At least 50% of total land provided for public amenity/ utility space shall be reserved
for unbuildable purposes such as garden, recreational ground, etc. by the Authority.
(1) Provided that if such amenity space is less than 1000 Sq.m. then it shall be reserved
only for unbuildable purposes such as garden, recreational ground and may be allowed
on internal road / Layout road / existing road / access road having width less than 12
m.
ix) The required segregating distance between Industrial Zone and the area over which
Residential use is permitted under this regulation, shall be provided within such land
intended to be used for residential or commercial purpose. In case of adjoining area is
developed and obnoxious industry is existing on such part, then necessary segregation
distance shall be provided. However, if non-obnoxious user is existing on such part,
no such segregation distance shall be provided.
x) Such residential or commercial development shall be allowed within the permissible
FSI of the nearby Residential or Commercial Zone.
xi) Provision for Amenity Spaces shall be considered to be reservations in the
Development Plan and Transferable Development Rights against such amenity as per
Regulation No.11.2 may be given or FSI of the same equivalent to the TDR quantum
shall be available for utilisation on the remaining land. Moreover, the owner shall be
entitled to develop remaining land with permissible TDR potential including the land
under amenity space subject to maximum permissible limit of FSI (Maximum
Building Potential) as mentioned in Regulation No.6.3.
xii) Residential/ Commercial use may be allowed on the part area of the land holding
subject to the condition that total area of the entire industrial land holding shall be
considered for deciding the percentage of the land to be earmarked for public amenity/
utility spaces, as per these regulations.
xiii) If Development Plan Reservations (excluding DP Road/ Road widening) falls within
or adjacent to the land of the same land owner under I to R provision, then such
reservation may be adjusted in amenity space in the following manner :
a) If the area under development plan reservation is less than the area required for
public amenity space as per this regulation, then only the difference between
the areas shall be provided for public amenity space.
b) If the area under reservation in development plan is more than the area required
for public amenity space as per this regulation, then the area for public amenity
space shall be provided equal to area required under this regulation.
The word "adjacent" shall also include the land of the same owner separated by
nallah, river, canal, road etc., for the purpose of this regulation.
xiv) Provisions of Accommodation Reservation mentioned in Regulation No. 11.1 shall
not be applicable for development of amenity space provided in this regulation.
xv) Minimum 10% built up area (basic FSI) for area upto 1 ha. and 5% built up area
(basic FSI) for area more than 1 ha., shall be used for offices and commercial purpose,
in case of development undertaken under this regulation, by closing down the existing
industry. However, this provision shall not be applicable, in case of permission being
sought under this regulation, where such plot falls in industrial zone, without existing
industry.
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
xvi) The provision of inclusive housing as mentioned in Regulation No. 3.8 shall not be
applicable. However, 20% of the land or FSI proposed to be used for residential
purpose shall be utilised for plots below 100sq.m.in case of plotted layout
development or below 50 sq.mt built-up area tenement in case of construction of
housing scheme.
xvii) The industrial zone on which Residential/ Commercial permission is granted, it shall
be deemed to be converted into Residential/ Commercial zone to the extent of that
area, after issuance of final occupation certificate to the project.
xviii) If at the request of the Authority, the owner agrees to construct the amenity on the land
on such amenity space, then he shall be entitled for construction TDR/FSI as per TDR
Regulations.
c) On the date of draft publication of these UDCPR, if the entire holding of a person at a place
in industrial zone admeasures less than 500 Sq.m., then regulation mentioned in (b) above
shall not be applicable and such plot in industrial zone shall be deemed to be included in
adjoining zone, if requested by the owner.
d) If the land for industrial unit is acquired under the provisions of relevant Land Acquisition
Act, then prior permission of the Government is necessary before permitting residential use
on such lands and additional items and conditions mentioned in Land and Revenue
Department, G.R. No.Sankirna-01/2017/C.R.11/A-2,dated 11/01/2018, as amended from
time to time, shall be applicable.
4.9 Loom Industry cum Residential Zone.
The following uses shall be permissible:-
i) Uses permissible in R-1, R-2 Zone according to road width.
ii) Power loom.
iii) Power looms cum residential to any extent.
User (i) above shall be as per conditions of R-1 and R-2 zone. However, (ii) and (iii) shall
be permissible with following conditions.
a) Power loom use shall be restricted up to maximum permissible floor area of 250 Sq.m. with
maximum 20 H.P. and 20 labourers.
b) Total FSI permissible shall be as that of residential zone.
c) Adequate safety measures shall be taken to reduce noise and air pollution etc. by providing
vibration absorbing platform and dust settler.
d) Working hours for looms shall be 8 am to 8 pm.
4.10 PUBLIC/ SEMI PUBLIC ZONE
The following uses shall be permissible:-
(i) Schools, Colleges, Educational Complexes, Training institutions, Hostels for students and
essential staff quarters.
(ii) Home for the aged, Hospitals, Sanatoria, Dispensaries, Maternity Homes, Health Centres
and related health facilities with ancillary structures like quarters, Dharmashala, veterinary
hospitals etc.
(iii) Offices and essential staff quarters of the Government/ Semi Government and/or their
authorities/ Local Self-Government, Courts etc., Public Housing by Government /
Government Bodies.
(iv) Public/semi-public sector utility and transport establishments/ institutions of research,
education and health.
(v) Libraries, Mangal karyalayas, Gymnasia, Gymkhanas, Stadia, Community halls, Civic and
Cultural Centres, Religious Structures, auditoria etc..
(vi) Commercial use upto 15%shall be permissible subject to following conditions: -
a) Shop/ permit rooms for liquor/ wine/ beer, pan, cigarette, tobacco, lottery tickets and
such other uses which do not serve public purpose, similarly storage of domestic gas
cylinders, kerosene etc., which are dangerous to public health, shall not be permitted.
b) The plots in which there is an existing development; such commercial use shall be
restricted to a maximum of 15% of the existing and proposed development taken
together.
Provided that, in case of lands owned by Zilla Parishad and Panchayat Samiti, which
are earmarked as public and semi-public zone, the limit of such commercial use shall
be up to 33%.
(vii) Vehicle Fuel Filling Station including LPG/ CNG/ Public Charging Stations for Electric
Vehicles as per Regulation No. 6.2.2, Sr. No. 6 of Table 6E.
(viii) Nursery, crèches, Spastic rehabilitation centres, orphanages, hostel for Autistic persons and
Mentally Retarded persons.
(ix) Fire stations.
(x) Traffic and Transport related facilities.
4.11 AGRICULTURAL ZONE
i) All agricultural uses including stables of domestic animals, piggeries, poultry farms
accessory building, tents etc.;
ii) Golf Course and Links, Race tracks, and shooting ranges with necessary safety measures,
Trekking Routes / nature trails / nature walks, etc.;
iii) Garden, forestry, nursery, public parks, private parks; play fields, summer camps for
recreation of all types;
iv) Public/ semi-public sector utility establishments such as electric sub-stations, receiving
stations, switch yards, over-head line corridors, radio and television stations, receiving
stations, main stations for public gas distribution, sewage treatment and disposal works,
water works along with residential quarters for essential staff required for such works;
v) L.P.G. Godown, subject to following conditions:-
a) Minimum plot size and area of the plot shall be as decided by concerned Licensing
Authority.
b) The maximum permissible FSI shall be 20% on this plot.
c) Only ground floor structure shall be permissible.
d) It is necessary to obtain No Objection Certificate from Controller of Explosives and
competent fire authority.
vi) Vehicle Fuel filling Station including LPG/ CNG / Ethanol / Public Charging Stations for
Electric Vehicles, subject to following conditions:-
a) Plot shall be located on any road with a minimum width of 12m. or more.
b) FSI for such facilities in this zone shall be up to 20% on gross area, underground
structures along with kiosks shall not be counted towards FSI.
c) NOC from Chief Controller of Explosives shall be necessary.
d) In case the plot is located on any Classified road, the distance from the junction of
roads as may be specified by Indian Road Congress / Ministry of Road, Transport and
Highway, shall be followed. (IRC guideline 2009 and MORTH Letter No.RW / NH -
33023 / 19 / 99 - DO III, Dated: 25.09.2003 as amended from time to time)
e) In a plot of Fuel Station, other building or composite building for sales office, snack
bars, restaurant, public conveniences or like activities , may be permitted
vii) Pottery manufacture.
viii) Storage and drying of fertilizer.
(#) ix) Farm houses shall be permitted subject to following conditions:-
a) Minimum plot area for above use shall be 0.4 Ha.. However, one farmhouse per land
holding shall be permitted, irrespective of size of the land holding.
(1) b) The FSI shall not exceed 0.04 subject to a maximum built up area of 400sq.m. in any
case. Only ground + 1 floor structure with height not exceeding 9m.shall be
permissible.
x) Swimming pools / sports and games, canteen, tennis courts, etc.
xi) Amusement park.
a) Amusement park with minimum plot area of 1 ha. with recreational and amusement
devices like a giant wheel, roller coaster, merry-go-round or similar rides both indoor
and outdoor, oceanic-park, swimming pool, magic mountain and lake, ethnic village,
shops for souvenirs/ citations, toys, goods, as principal uses and ancillary activities
such as administrative offices, exhibition hall or auditorium, open air theatre, essential
staff quarters, store buildings, fast food shops, museum, small shops, ancillary
structures to swimming pool, ancillary constructions along with staff quarters and
residential hotels. Maximum permissible FSI shall be 0.70on gross plot area, out of
which 0.20 shall be without payment of premium and remaining with payment of
premium at the rate of 20%of the rate mentioned in the annul statement of rates of
very said land without considering the guidelines therein.
b) The required infrastructure, like proper and adequate access to the park, water supply,
sanitation, conservancy services, sewage disposal and adequate off-street parking will
have to be provided and maintained by the promoters of the project at their cost.
c) The promoters of the project shall provide adequate facilities for collection and
disposal of garbage at their cost, and will keep, at all times, the entire environment
clean, neat and hygienic.
d) Area of Rides, whether covered or uncovered, shall not be computed towards FSI.
e) At least 250trees (of indigenous species) per Hector shall be planted and grown within
the area of the park.
f) Sufficient parking facilities and ancillary facilities for cars, buses, transport vehicles
etc. shall be provided on site.
xii) IT/ITES parks/ units with 0.20 FSI, subject to Regulation No.7.8.
(1)
Substituted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
(#)
Clarification issued vide Order No. CR 236/18 dt, 23rd December, 2021.
xiii) Any building / use by the Government / Semi-Government or Government Controlled
bodies with basic FSI and village resettlement or resettlement of project affected person with
full permissible FSI as that of residential zone.
xiv) Biotechnology unit / B.T. Park subject to Regulation No.7.9.
xv) Development of buildings of educational, research and medical institutions, community
development, human resources development, rural upliftment, yogashram, mediation
centres, vipashyana centres, spiritual Centres, goshalas, panjarpol, old Age homes and
Rehabilitation Centres along with allied activities, Planetarium / Astronomical /
Astrophysical facilities / projects with FSI of 1.00 on gross plot area, out of which 0.20 shall
be without payment of premium and remaining with payment of premium at the rate of 20%
of the rate mentioned in the annul statement of rates of very said land without considering
the guidelines therein subject to following conditions :-
Conditions:-
a) The trees at the rate of 250 trees per hectare shall be planted on the plot.
b) The provisions of higher FSI mentioned in Chapter-7 of these Regulations shall apply
to the above buildings listed in the said chapter. However, higher FSI in such case
shall not exceed 100% of the above.
c) In case of educational use, 15% area may be used for commercial purpose subject to
provisions of Regulation No. 4.10 (vi).
xvi) Integrated highway/ Wayside amenities such as motels, way-side restaurants, fuel pumps,
service stations, restroom and canteen for employees working on site and truck drivers,
service godowns, factory outlets, highway malls, hypermarket along with public
conveniences like toilets, trauma centre, medicine shop, bank ATMs and like activities with
FSI of 0.2 on gross area without payment of premium and further FSI upto 0.3 with
premium at the rate of 20% land rate in Annual Statement of Rates of the said land without
considering the guidelines therein, shall be allowed subject to following conditions: -
Integrated Highway/ Wayside Amenities may be permitted to be developed on plots of land
having a minimum area of 10,000 Sq.m. abutting to National Highways / State Highways or
on any road not less than 18 m. width.
Provided that, No subdivision of land shall be allowed and location of fuel pump, if
provided, shall be separately earmarked.
(1) Notwithstanding anything contained in this regulation, an individual use as mentioned in
this regulation may be permissible, on road having minimum width of 12 m. The minimum
plot size for this regulation shall be entire holding mention in the single 7/12 extract or
minimum of 4000 Sq.m. In any case Sub-division / layout shall not be permitted.
xvii) Ancillary Service Industries
Ancillary service industries for agro related products like flowers, fruits, vegetables, poultry
products, marine products, related collection centres, auction halls, godowns, grading
services and packing units, knowledge parks, cold storages, utility services (like banking,
insurance, post office services) etc. on the land owned by individuals / organizations with
FSI of 0.20 without payment of premium. Further FSI up to 1.00 may be granted with
payment of premium at the rate of 20% of land rate in Annual Statement of Rates of the said
land without considering the guidelines therein.
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
xviii) Any industry / industries with FSI of 0.20 without payment of premium and further FSI up
to 1.00 with payment of premium at the rate of 20%of land rate in Annual Statement of
Rates of the said land without considering the guidelines therein. Minimum buffer open
space / set back (which may include marginal distance and road width if any) from the
boundary of industrial Building / use to residential or habitable zone / use, shall not be less
than 23 m. Such buffer open space shall be kept in the same land.
Provided that, the area under such buffer open space / setback shall not be deducted for
computation of FSI.
Provided further that, if the land under industrial zone is utilized entirely for non-polluting
industries, IT / ITES or like purposes, then such buffer zone / open space shall not be
necessary.
Provided further that, Industrial layout / sub-division of land shall also be permissible
subject to regulations of Industrial Zone. In such case, the plot shall be entitled for 0.20 FSI
and further FSI as mentioned above, shall be subject to payment of premium. The condition
to this effect shall be stamped on the layout / sub-division plan and also mentioned in the
approval letter.
Provided further that, industrial godowns/ godowns shall also be permissible under this
regulation.
xix) Solid waste management, land fill sites, bio-gas plants, power generation from waste.
xx) Power generation from non-conventional sources of energy. Area covered under solar panels
shall not be counted in FSI.
xxi) Brick, tile manufacture.
xxii) Fish Farming.
xxiii) Religious buildings subject to conditions as may be prescribed by Authority.
xxiv) Slaughter house or facilities for processing and disposal of dead animals with the special
permission of Authority.
xxv) Cemeteries and crematoria and structures incidental thereto.
xxvi) Scrap Market with FSI of 0.20 without payment premium and further FSI upto 1.00 with the
payment of premium at the rate of 20% of land rate in Annual Statement of Rates of the said
land without considering the guidelines therein.
xxvii) Mangal karyalayas/ lawns.
a) Minimum area for mangal karyalaya shall be 0.4ha with FSI of 0.20. It may be
permitted along with essential guest rooms not exceeding 30% of the area of mangal
karyalaya. Area for parking shall be 40% of gross area which shall be properly
earmarked and bounded by bifurcating wall. Further FSI up to 1.00 with payment of
premium at the rate of 20% of land rate in Annual Statement of Rates of the said land
without considering the guidelines therein.
b) Lawns for ceremony shall be 0.8ha with FSI of 0.10. Area for parking shall be 40% of
gross area.
c) The plot for mangal karyalaya or lawn shall abut on road width of minimum 9m. in
case of Nagar Panchayat, Municipal Council and Regional Plan area and 12 m. in case
of other areas.
xxviii) Bus Terminus.
xxix) Construction of any communication route, road, railway, airstrips, ropeways, ports,
electric lines, etc.
xxx) Town planning scheme under the provisions contained in chapter-V of Maharashtra
Regional & Town Planning Act, 1966 shall be allowed for minimum 20 hectare area,
with proper road network subject to condition that entire cost of scheme shall be borne by
the owners. After sanction of preliminary scheme under section 86 of the Act, all uses as
that of residential zone, shall be permitted. FSI and other regulations shall be applicable
as per residential zone. Or
If the owners come together for development on aforesaid concept of town planning
scheme instead of undertaking town planning scheme under the Act, the Authority may
allow and approve such development subject to availability of existing approach road of
minimum 12 m. width and earmarking 40% of the land for roads, parks, playgrounds,
gardens, social infrastructure and sale by the Authority, which shall be handed over to the
Authority subject to following.
a) Minimum 10% land shall be earmarked for playgrounds and parks, for which no
FSI / compensation shall be allowed.
b) Minimum 15% land shall be earmarked for social infrastructure and that for sale by
the authority and shall be handed over to the authority for which compensation in
the form of FSI shall be allowed in-situ.
c) Road area only to the extent of 15% shall be calculated in this component for which
compensation in the form of FSI shall be allowed in-situ. The road area over and
above 15% shall be calculated in the owner's / developer's share.
d) The regulation No. 3.4 and 3.5 shall not be applicable in this case.
Development permission for uses permissible in residential zone shall be granted phase
wise after completion of physical infrastructure works including off-site infrastructure
and handing over of land to the Authority. The land under such proposals shall be entitled
for basic FSI / Premium FSI / TDR / In-situ FSI as that in Residential Zone.
xxxi) Manufacturing of Fireworks / Explosives and Storage of Magazine / Explosives beyond 2
km. of Gaothan Settlement / Gaothan Boundary subject to No Objection Certificate from
the Chief Controller of Explosives.
xxxii) Development of Cinema and TV film production, shooting, editing and recording studios
with its ancillary and supporting users, including construction of staff quarters, rest
rooms, canteens etc. subject to the following condition :-
a) The minimum plot area (necessarily under one ownership) shall not be less than 2
hectares.
b) The permissible FSI shall be 0.2 on gross plot area without payment of premium
and up to 1.00 with payment of premium at the rate of 20% of land rate in Annual
Statement of Rates of the said land without considering the guidelines therein.
xxxiii) Tourist homes, Resorts, Hotels, Motels, Health and Wellness spa, Golf courses, Art and
Craft villages, Exhibition cum Convention Centre, Camping-Caravanning and tent
facilities, Adventure Tourism Project, Eco Tourism Project, Agricultural Tourism
Project, Medical Tourism Project, Boutique wineries, Guest houses and Bed and
Breakfast scheme approved by MTDC / DoT, etc., with Rooms / Suites, support areas for
reception, kitchen, utility services etc., along with ancillary structures like covered
parking, watchman's quarter, guard cabin, landscape elements, and if required, one
observation tower per tourist resort upto the height of 15m. with platform area up to 10
Sq.m. in permanent / semi-permanent structural components. The permissible FSI shall
be 0.2 on gross plot area without payment of premium and up to 1.00 with payment of
premium at the rate of 20% of land rate in Annual Statement of Rates of the said land
without considering the guidelines therein.
xxxiv) Tourist Resort Complexes may be permitted with following conditions :-
A) General conditions -
The minimum area of such site shall not be less than 1.00 H. and 0.4H.in case of local
resident.
B) Condition for Development -
a) Maximum permissible FSI in this zone shall be 0.25of gross plot area without
payment of premium and remaining up to 1.00with payment of premium at the rate
of 20% of land rate in Annual Statement of Rates of the said land without
considering the guidelines therein.
b) The uses like resort, Holiday camp, recreational activities, amusement park, may
be permitted in this zone.
c) If the site is located adjacent to forts, archaeological and historical monuments, the
development shall be governed by the rules prescribed by the archaeological
department.
d) If the site is located near natural lakes, then, development shall be governed by the
following :-
Distance from high Development to be allowed
flood line (HFL) / full
storage level (FSL)
Up to 100 m. Not permissible.
above 100 m. to 300 m. Ground floor structure with maximum height of 5 m.
above 300 m. to 500 m. G+1 storey structure with maximum height of 9 m.
above 500 m. Within permissible FSI and subject to other
regulations.
f) No subdivision of land shall be allowed.
g) The land should have approach of minimum 9 m. wide road.
h) The land having slope steeper than 1:5, shall not be eligible for development.
C) Infrastructural Facilities - All the infrastructural facilities required in site as specified by
the Authority, shall be provided by the owner / developer at his own cost on the site. Proper
arrangement for treatment and disposal of sewage and solid waste shall be made. No untreated
effluent shall be allowed to pass into any watercourse.
xxxv) In the areas of Local Bodies and the area of SPA where Development Plan or planning
proposal is sanctioned, "Pradhan Mantri Awas Yojana" shall be permitted subject to the
provisions of Regulation No.14.4.1.
xxxvi) Individual house of size upto 150 Sq.m. for entire holding mentioned in the single 7/12
extract, as on date of coming in to force of these regulations.
xxxvii) Mining and quarrying subject to provisions of Regulation no. 15.1
xxxviii) In the area of Regional Plans (excluding the area of Local Bodies and SPA where
Development Plan or planning proposal is sanctioned) "Pradhan Mantri Awas Yojana"
shall be permitted subject to the provisions of Regulation No.14.4.2.
xxxix) Development of Tourism and Hospitality Services under Community Nature Conservancy
around wild life sanctuaries and national parks shall be permitted as per Regulation No.
14.9.
xxxx) Integrated Township Projects as per Regulation No. 14.1.1.
xxxxi) Buildings for Three star and above category hotels along National / State Highways, MDR
and on other roads not less than 18 m. in width, may be permitted with FSI 0.2 on gross
area without payment of premium and remaining up to 1.00with payment of premium at
the rate of 20% of land rate in Annual Statement of Rates of the said land without
considering the guidelines therein.
xxxxii) Bulk storage and sale of Kerosene subject to NOC of Chief Controller of Explosive,
Government of India.
(1) xxxxiii) Development of housing for EWS / LIG as per Regulation No. 7.7.
(1) xxxxiv) Development permissible adjacent to Gaothan as specified in Regulation No.5.1.1.
Notes :-
1) The permissible FSI for uses mentioned above shall be 0.20, if not specified.
2) Height of building shall be permissible as per regulation No. 6.10 subject to FSI
permissibility under this regulation.
3) For the uses permissible in Agricultural Zone minimum road width shall be 6 m. for non-
special building, unless otherwise specified, and for special building shall be as per
Regulation No. 3.3.9.
4) The premium for FSI (allowed with payment of premium)shall be levied for FSI actually
proposed in the permission.
5) The payment to be recovered in above cases shall be apportioned 50% - 50% between the
Authority and the State Government, unless otherwise exempted by the Government by
separate order.
6) The payment to be recovered in above cases may be exempted by the Government by
separate order in case of deserving charitable institutions.
7) No such premium shall be leviable in case of Government / Semi Government or
Government controlled bodies.
8) Trees at the rate of 100/hector shall be planted on the land, unless otherwise specified.
4.12 GREEN BELTZONE / RIVER PROTECTION BELT
4.12.1 Following uses shall be permissible
i) Agriculture,
ii) Tree Plantation, Gardens, Public park, Landscaping, Recreational Open Space, Forestry and
Nursery etc.
iii) River front development by Authority or any institution authorised on behalf of Authority.
iv) Development of pedestrian pathways, Jogging tracks, Cycle tracks, Boat clubs etc.
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
v) Swimming pools, club houses, recreational facilities after leaving 15 m. belt along river
bank and 9m. from Nallahs, subject to other provisions in these regulations.
vi) Public toilets as per requirement.
vii) Recreational open space of any layout/ sub-division/ development proposals, if submitted
along with the developable land adjoining such green belt, after leaving marginal distances
of minimum 15m. and 9m. from rivers and Nallahs, respectively, or subject to (1) restrictions
mentioned in Regulation No.3.1.3.
a) The uses and their extent shall be permissible in such Recreational open space, as
prescribed in this regulation.
b) If the land under green belt zone, excepting open space therein, if any, is required by
Authority for the public purposes mentioned above, the owner shall hand over the
possession of such land for the development and maintenance of public purposes.
Thereafter, such land shall remain open and accessible to general public for
recreational activities.
c) The side/ rear marginal distances for a proposed building in a land adjoining a river /
nallah shall be the maximum of :-
(i) Side/ rear marginal distance, to be measured from river/ nallah, as required
according to height of building or
(ii) 4.5 m. from the dividing line between green belt zone and the other developable
zone; or
(iii) Mandatory distance of 15m. or 9m to be observed from a river or nallah
respectively.
4.13 TRAFFIC AND TRANSPORTATIONZONE
i) All uses / activities related to surface, water and air traffic and transportation including
Parking, ancillary uses shall be permissible.
ii) Separable lands of Railways shall be allowed to be developed for uses permissible in
Commercial Zone.
4.14 REGIONAL PARK ZONE
The following uses shall be permissible:-
i) All uses permissible in Green Belt Zone, Hill Top Hill Slope Zone and Afforestation Zone.
ii) Uses at Regulation No. 4.11 (iv, v, vi, viii, ix, x, xiii, xix, xx, xxii, xxv, xxviii, xxix, xxxvi,
xxxix, xxxxii) permissible in Agriculture Zone.
iii) Uses at Regulation No. 4.11 (xv, xxxiii, xxxiv) permissible in Agriculture Zone with
maximum FSI of 0.20 without premium and additional 0.30 i.e. upto 0.50 with payment of
premium @ 20% of land rate in ASR.
iv) Gaothan expansion as specified in Regulation No. 5.1.1 subject to 200 m. from the gaothan
limit.
4.15 TOURISM DEVELOPMENT ZONE
The following uses shall be permissible:-
i) All uses permissible in Agricultural Zone (except uses at Sr. No. xviii and xxxi of
Regulation No. 4.11).
(1)
Substituted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
ii) Gaothan expansion as specified in Regulation 5.1.1.
4.16 AFFORESTATION ZONE
The following uses shall be permissible :-
i) All uses permissible in Hill Top and Hill Slope Zone.
ii) Forest houses (1)(--) meant for forest tourist / servants / technicians / owner and for storing of
fertilizes etc., may be permitted subject to the following: -
It shall have built-up area not exceeding 150 Sq.m., provided that, forest plot area is not less
than 0.4 hectare. Structures to be erected for these purposes should be of ground + 1 floor
only and should not have height more than 7 m. and should be of such material as would
blend with the surroundings. The owner shall plant trees at the rate of 250 trees per hectare
and shall maintain it properly.
Provided that, layout of the forest houses / (1) (--) may be permitted for areas more than 0.4
hectare.
iii) Uses mentioned in Regulation No. 4.11 (iv, v, vi, xiii, xxviii, xxix) permissible in
Agriculture Zone.
iv) Uses mentioned in Regulation No. 4.11 (2) (xv, xvi, xxxiii, xxxiv) permissible in Agriculture
Zone with FSI of (1) 0.2, 0.2, 0.1, 0.15 respectively.
v) (2) Development permissible adjacent to Gaothan as specified in Regulation No.5.1.1 subject
to maximum 200 m. periphery from gaothan limit.
(2) vi) The above uses shall not be permitted on hill slope steeper than 1:5 and such area shall not
be considered for FSI.
4.17 HILL TOP -HILL SLOPE ZONE / HILLY AREA
Kept in abeyance.
4.18 GREEN ZONE-2
The following users shall be permissible in this zone.
i) All uses permissible in Hill Top Hill Slope Zone.
ii) Gaothan expansion as specified in Regulation 5.1.1.
iii) Primary and Nursery Schools including student hostels.
iv) Uses at Regulation No. 4.11 (vi, ix, xiii, xx, xxii, xxv, xxviii) with maximum FSI of 0.20.
4.19 FOREST ZONE
The developments as may be required by the Ministry of Forest or its Authorities shall only be
permissible on the lands owned and possessed by the Ministry/ Department of Forest or its
Authorities.
4.20 DEFENCE ZONE
i) The developments as may be required by the Ministry of Defence or its Authorities shall
only be permissible on the lands owned and possessed by the Ministry of Defence or its
Authorities.
(1)
Word ‗Farm house" is deleted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
(2)
Inserted vide Corrigendum / Addendum under Regulation No. 1.10 CR 121/21, dt. 02nd December, 2021.
ii) Restrictive Zone -
No development in contravention with the notification shall be permissible in the area
affected by the notification under Works of Defence Act- 1903, whether earmarked as such
on Development Plan/Regional Plan or not or development shall be permissible with the No
Objection Certificate from the concerned Defence Authority.
Provided that, it shall be permissible to treat the area under such restrictive zone as marginal
distance at the time of construction of any building proposed on contiguous unaffected area.
Provided further that, it shall be permissible to utilise the FSI and also the receiving potential
of the land under this zone, on the remaining contiguous unaffected land of the same land
owner.
4.21 MINES AND QUARRY ZONE
In this zone quarry, mining, stone crushing or similar operations shall be permissible subject to
provisions of Regulation No. 15.1. In addition to this following uses shall be permissible.
Stone quarrying, soil excavation, stone crushing or other similar activities, mining activity, bricks
kilns, caretaker's quarters or residential quarters for essential staff upto maximum built-up area 20
Sq.m. ancillary buildings like site offices, cafeteria with maximum built-up area upto 250 Sq.m.
The existing uses within these zones such as bricks kilns, fly ash bricks, cremation ground, etc.,
shall be continued for the respective purposes. The mining and quarry operation shall not be
permitted within the restrictive area as per their prevailing regulations. The development after the
closing of existing mining areas / quarries shall be as per the closing polices of the respective
department. However, the private lands which are included in Mines and Quarry Zone shall deem
to be included in the adjacent zone and Authority shall grant development permission accordingly.
4.22 PUBLICUTILITY ZONE
The following users shall be permissible in this zone.
Water treatment plant, water reservoirs, pumping station, water storage tank, sewage /influent
treatment plant, waste water recycling plant, electric substation, cemeteries, burial ground and
cremation grounds, slaughter house, solid waste landfill / management site, fire station, post,
telegram and communication office, telephone exchange, cattle pond, dairy farm, public urinals
including all public utilities.
4.23 WOODLAND CORRIDOR
Following uses shall be permissible in this zone.
i) Garden, Nurseries, Horticulture and Arboriculture.
4.24 SPECIAL ECONOMIC ZONE
Following uses shall be permissible in this zone.
i) Residential, Educational, Institutional, Assembly, Business, Mercantile, Industrial, Storage,
information Technology, Recreational.
ii) Any other land use as may be made permissible by the Government of India within SEZ.
4.25 AIRPORT AND ALLIED ACTIVITIES / SERVICE ZONE
The following uses shall be permissible in this zone.
i) Airport and allied activities and services incidental thereto.
4.26 ADDITIONAL USES
The lists of uses mentioned under various land use zones herein above may be amended by the
Authority from time to time with the consent of Director of Town Planning, Maharashtra State,
Pune.
4.27 USES PERMISSIBLE IN DEVELOPMENT PLAN RESERVATIONS
1) The uses permissible in a reserved site shall conform to the use for which it is reserved
unless specified otherwise. The required parking, public toilets and separate place for
garbage bins shall also be permissible in the reserved site itself.
2) Where the Authority or the Appropriate Authority proposes to use land / building / premises
reserved for one specific public purpose / purposes, partly for different public purpose /
purposes, it may do so, provided that such partial use shall not exceed 40% of the reserved
area and such combination shall not be of incompatible uses. However, public necessities
like Police Stations/ Chowkys, water supply establishments, Arogya Kothies (i.e. Waste
Segregation Centre at Ward Level with allied uses), etc. and other public utility services can
be established in the said area. This provision shall not be applicable for the purposes
mentioned below in (1) 4.27 (5) (a), (b) and (c).
3) Any site reserved for specific purpose in the development plan may be allowed to be
developed for any other public purpose with the permission of the Government. In doing so,
buildable reservation may be allowed to be developed for buildable or open / recreational
uses and open / recreational reservation may be allowed to be developed for open /
recreational uses only.
4) Planning Authority, with the prior approval from Government, may acquire and develop any
of the reservations proposed in the Development Plan, partly or fully, for multi-storeyed
public parking, irrespective of its designation, if amenity of parking is direly needed in the
area. However, Authority should be satisfied that there is pressing need for parking in that
area and priority for parking is more important than purpose for which the reservation is
made. In case of purposes mentioned at Regulation No. (1) 4.27 (5)(a)(b)(c), parking may be
allowed to be developed in basement/s subject to development of main purpose on the
ground level with layer of soil of 1 m. depth and arrangement of soil water recharge.
5) Combination of uses as mentioned below may be permissible with the permission of the
Authority even if the reservation is for a specific purpose.
a) Playground - In playground reservation, minimum 90% area shall be kept open for
open play activities. In remaining 10% of area, covered swimming pool & allied
construction, gymnasium, covered badminton court, pavilion, (with or without shops,
offices beneath), watchman‘s quarter, small restaurant or food stalls to the extent of
20 Sq.m. (for every 4000 Sq.m. reservation area) may be permitted. The maximum FSI
permissible shall be 0.15.
b) Stadium / Sports Complex - In addition to the uses permissible in playground
mentioned above, shops/ offices below the spectators‘ tiered gallery may be permitted.
Permissible FSI shall be as mentioned in Regulation No. 6.2.2 Table 6-E Sr. No. 8.
c) Garden / Park - In addition to the main use of garden, open swimming pool & allied
construction, aquarium, water tank, booking counter, toilets, rain water harvesting
system, gardener / watchman‘s quarter, small restaurant or food stalls to the extent of
(1)
Substituted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
20 Sq.m. (for every 4000 Sq.m. reservation area) may be permitted. Total FSI used for
such constructions shall not exceed 0.10 of the garden area. If required, the sites of park
or garden may be developed for playground; however, such change shall not exceed
more than 10% of the like reservations in the said sector of Development plan.
d) Civic Centre/ Community and Cultural Centre - Community Hall, welfare centre,
gymnasium, badminton hall, art gallery, museum, club house, public conveniences,
cafeteria, gardens, exhibition centre, and like combination of uses. (1) Convenience
Shops may be permitted within 15% of basic FSI.
e) Vegetable Market - Open or covered ottas for sale of vegetables and/or mutton and
fish, along with petty convenience shops and fruit stalls may be permitted.
f) Shopping Centre/ Market - Shopping, vegetable market, hawkers place etc. and
departmental stores, offices, banks/ community hall on upper floors.
g) Auditorium/ Drama Theatre - In addition to Auditorium, Drama theatre / Natyagriha,
Art Gallery, Exhibition Hall, Library, small restaurant to the extent of 20 Sq.m. (for
every 4000 Sq.m. reservation area) and allied uses such as guest rooms for the artists
may be permitted.
h) Primary School/ High School - Respective uses with their lower/ ancillary uses along
with canteen and ancillary uses including staff quarters, hostels. Fifteen percent of the
built-up area may be permitted for commercial use, on basic FSI related to the
educational purpose, on ground floor with a separate entry and exit.
i) Hospital / Maternity Home, etc. - Respective uses with their lower / ancillary uses
and any sort of medical facilities along with ancillary construction such as staff
quarters, chemist shop, restaurant, ATM, PCO, cyber café of not more than 20 Sq.m.,
etc. and sleeping accommodation for guests in case of bigger hospitals of built up area
not less than 2000sq.m may be permitted.
j) Slum Improvement Zone - It shall be developed for slum rehabilitation as per
regulations of Slum Rehabilitation Authority.
k) Truck Terminus - In addition to minimum 60% area for parking of trucks, ancillary
office, restaurant, hotel, motel, lodging facility for drivers, Vehicle fuel Filling station
including LPG / CNG / Ethanol /Charging Stations for Electric Vehicles, auto repair
centre, auto service centre, shops for auto spare parts, shops for daily needs, ATM,
PCO, Primary Health Centre / First Aid Centre and provision for loading-unloading
may be permitted. Moreover, these reservations may also be developed for bus stand,
bus-MRT interchange with mall.
l) Bus Stand for Local and Regional Services/ Metro station/ Transport Hub-In
addition to respective purpose, bus-metro reservation may have interchange along with
other ancillary uses. Where there is/are any existing building/s accommodating owners/
occupants in such reservation, they may be accommodated by the Planning Authority
on upper floors of any proposed building/s on the reservation, subject to their
willingness.
m) Fire Brigade Station - Fire brigade station along with allied activities.
n) Sewage Treatment Plant (STP), Solid Waste Facility, Water Works - respective use
with allied activities and interchangebility among one another.
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
o) Parking / Parking Lot - Parking along with ancillary uses such as public convenience,
drivers room, motor garage etc. on not more than 10% area.
Provided further that, the Planning Authority may accommodate, on the willingness of
the owners/ occupants residing in the existing building/s on reserved area, on the same
land, on any floor of the proposed parking building.
p) Public Amenity- Any amenity, along with ancillary use.
q) Municipal Purpose - Any public purpose related with functioning of Municipal
Authority as may be decided by the Authority.
r) Cremation Ground/ Burial Ground - Respective use with allied activities and
interchangebility among one another.
s) Weekly Market -Weekly vegetable market with open ottas, cattle market and ancillary
petty convenience shops.
t) Multipurpose Ground - Users permissible in sites reserved for Multi-purpose ground:
i) Playground
ii) Exhibition ground
iii) Festival fairs, ceremonies, religious functions etc.
iv) Circus
v) Social gathering, public speeches
vi) Cultural activities like Kalagram etc.
vii) Music Concerts etc.
viii) Institutional programs
ix) Touring Talkies
x) Govt. or semi-government organisation functions.
xi) Parking.
In addition to above the Authority may add or alter the above list from time to time. No
permanent construction or permanent use, except as a playground, shall be permissible
in this reservation.
u) Exhibition Ground / Open Exhibition Ground / Exhibition Centre - All activities
related to various exhibitions and ancillary structures like office, restaurant etc. of built-
up area not exceeding 10% of the total area.
v) Bio Diversity Park - Uses permissible
i) Agricultural, including horticultural uses.
ii) Forestry and Nursery.
iii) Park.
iv) Historical museum only on the lands owned by the Govt./ Authority subject to
maximum floor space area not exceeding 4% of the total plot with ground floor
structure without stilts.
v) Bio-Diversity information Centre and Research center subject to maximum floor
space area not exceeding 4% of the total plot with ground floor structure without
stilts.
vi) Public Streets having width not exceeding 9.0 m. alignment and the cross section
of the street shall be finalised by the Authority without cutting the hill area.
w) Composite development of Bus Terminal / Bus Depot / Truck Terminal for cities
having population of 5 lacs and above -
In case of cities having population 5 lacs and above, the composite development of the
reserved lands for Bus Terminal/Bus Depot/Truck Terminal, may be allowed subject to
the following :-
i) 40% land shall be kept open for basic use with proper maneuvering buses/vehicle
and remaining upto 60% land may be allow to be developed for affordable
housing.
ii) Such plot shall be owned by planning authority or development authority.
iii) Such composite use shall be segregated by separate entry/exit.
x) Other reservations - Other reservations may be developed for the respective purposes
along with compatible, ancillary uses.
Note :- The permissible FSI and the maximum permissible loading limit including TDR and FSI
with payment of premium for above uses in reservation, shall be as permissible for
residential zone, if not specified otherwise.
-*-*-*-*-*-