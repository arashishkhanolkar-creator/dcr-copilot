# Chapter 11: Acquisition and Development of Reserved Sites in Development Plans

CHAPTER - 11
ACQUISITION AND DEVELOPMENT OF RESERVED SITES IN
DEVELOPMENT PLANS
11.0 GENERAL
These regulations shall be applicable for the areas within the jurisdiction of planning
authorities, unless otherwise specified.
11.1 Manner of Development of Reserved Site in Development Plan (Accommodation
Reservation Principle)
The use of lands situated within the limits of Planning Authority which have been reserved for
certain purpose in the Development Plan, shall be regulated in regard to type and manner of
development/ redevelopment according to the provisions mentioned in following Table No.11A.
When owner is allowed to develop a reservation, he should have exclusive ownership/ title of the
land without any restriction under any other Act or Regulations in force.
Table No.11-A - Manner of Development
Reservation Person/Authority Principle For Development through
who may acquire/ Accommodation Reservation subject to
develop which development is permissible
1 2 3
1) Recreational -
1.1) Open reservations Planning Authority/ Planning Authority may acquire the land
like Garden, Play Appropriate and develop the same for the purpose. If the
Ground, Children Authority/ Owner Land under reservation is owned by any
PG, Open Space, Government agency/ Authority, in such
Recreation cases the Planning Authority may allow
Ground, such Government agency/ Authority to
Recreational Develop full reservation for the said
Centre, Park etc. purpose subject to condition as may be
decided by the Authority and such
Developed Amenity shall be open to the
general Public.
OR
The Authority, after handing over of 70%
of the land of the reservation to the
planning authority by the owner (1) free of
cost and free from all encumbrances, may
allow him to develop remaining 30% of
land as per adjoining use, subject to
following terms/conditions:-
(1)
Substituted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
i) The owner shall be entitled to develop
remaining 30% land for the uses
permissible in adjoining zone with full
permissible FSI of the entire Plot and
permissible TDR potential of the
entire Plot.
ii) The Authority, if required, shall allow
the TDR for the unutilized FSI, if any
(after deducting in-situ FSI as
mentioned in Sr.No.(i) above), to be
utilised as per TDR Regulations.
iii) The reservation shall be allowed to be
developed in parts. However, it shall
be ensured that Garden and Play
Ground area to be handed over to
Authority shall be minimum
1000sq.m.
1.2) Stadium, Sport
Planning Authority/ Planning Authority/ Appropriate Authority
Complex, etc.
Appropriate shall acquire the land and develop the same
Authority for the purpose.
1.3) Swimming Tank / Planning Authority The Planning Authority/ Appropriate
Swimming Pool /Appropriate Authority may acquire and develop the site
Authority for the same purpose.
/ Owner OR
The Planning Authority/ Appropriate
Authority after acquiring the land or after
acquiring and developing the same, as the
case may be, lease out as per the provisions
of the Municipal Councils/Municipal
Corporations/Authority Act, to the
Registered Public Institution for developing
and running or only for running the same.
OR
The Owner may be allowed to develop
according to the designs; specifications and
conditions prescribed by the Authority and
run the same.
2 ) Public Utilities
a) Cremation Ground, Planning Authority/ The Planning Authority/ Appropriate
Appropriate Authority shall acquire the land and
b) Burial Ground,
Authority develop the reserAvuattihoonr ityf/o r the same
c) Slaughter House,
purpose.
d) Sewerage Treatment
Plant,
e) Water Treatment
Plant,
f) Water Tank
3 ) Commercial
3.1) Market and Planning Authority/ The Planning Authority/ Appropriate
Mandies- Appropriate Authority shall acquire the land and
Authority/ Owner develop the reservation for the same
a) Weekly Market/
purpose.
b) Vegetable Market
OR
c) Open Market.
i) The Authority may allow the owner to
d) Hawkers Market
develop the reservation, subject to
3.2) Shopping centres handing over to the Planning
a) Shopping Centre, Authority an independent plot along
with constructed amenity of total area,
b) Commercial
mentioned in Note-1 below this table&
Complex,
as per norms prescribed by the
c) District Commercial
Authority.
Centre,
ii) The owner shall be entitled to develop
c) Municipal Market
remaining land for the uses
d) Fish Market permissible in adjoining zone with full
e) District Commercial permissible FSI of the entire Plot and
(C-2) etc. permissible TDR potential of the
entire Plot.
iii) The Authority, if required, shall allow
the TDR for the unutilized FSI, if any
(after deducting in-situ FSI), to be
utilised as per TDR Regulations.
iv) Reservation may be allowed to be
developed in parts.
4) Health Facility
a) Health Centre
Planning The Planning Authority / Appropriate
b) Hospital Authority/Appropria Authority may acquire and develop the
c) Dispensary te Authority/Owner reservation site for the same purpose.
d) Maternity Home OR
e) Veterinary
The owner may be allowed to develop
Hospital/ Clinic entire reservation for the intended purpose
f) Urban Health only.
Centre
OR
g) Rural Hospital and
i) The Authority may allow the owner to
like
develop the reservation, subject to
handing over to the Planning
Authority an independent plot along
with constructed amenity of total area,
mentioned in Note-1 below this table
&as per norms prescribed by the
Authority.
ii) The owner shall be entitled to develop
remaining land for the uses
permissible in adjoining zone with full
permissible FSI of the entire Plot and
permissible TDR potential of the
entire Plot.
iii) The Authority, if required, shall allow
the TDR for the unutilized FSI, if any
(after deducting in-situ FSI), to be
utilised as per TDR Regulations.
iv) Reservation may be allowed to be
developed in parts.
5) Transportation
5.1) Depots and Planning The Planning Authority/ Appropriate
Stands- Authority/Appropria Authority may acquire and develop the
te Authority/ Owner reservation site for the same purpose.
a) Bus Stand
OR
b) Bus Depot etc.
The owner may be allowed to develop
c) Metro Car Shed
entire reservation for the intended purpose.
d) MRTS Station
OR
i) The Authority may allow the owner to
develop the reservation, subject to
handing over to the Planning
Authority an independent plot along
with constructed amenity of total area,
mentioned in Note-1 below this table&
as per norms prescribed by the
Authority. The Authority shall ensure
that constructed amenity to be handed
over is of proper size and utilisable for
the said use.
ii) The owner shall be entitled to develop
remaining land for the uses
permissible in adjoining zone with full
permissible FSI of the entire Plot and
permissible TDR potential of the
entire Plot.
iii) The Authority if required, shall allow
the TDR for the unutilized FSI, if any
(after deducting in-situ FSI), to be
utilised as per TDR Regulations.
iv) In case of Bus Stand/ Bus Depot,
atleast 40% of the area shall be kept
for parking/ movement of buses.
iv) Reservation may be allowed to be
developed in parts.
5.2) Roads Proposed Planning Authority / The Planning Authority/ Appropriate
Appropriate Authority shall acquire the land and
Authority / Owner develop the reservation for the same
purpose.
OR
The Authority may allow the owner to
develop the new Development Plan road,
along with the construction of road as per
the specifications given by the Authority.
After handing over the said constructed
road along with the land under proposed
road to the Authority, the owner shall be
entitled for TDR and Amenity TDR. The
cost incurred for construction of road shall
be calculated on the basis of District
Schedule of Rates of Public Works
Department.
5.3) Parking Planning The Planning Authority/ Appropriate
Authority/Appropria Authority may acquire and develop the site
te Authority/ Owner for the same purpose.
OR
The Planning Authority/ Appropriate
Authority after acquiring the land or after
acquiring and developing the same, as the
case may be, lease out as per the provisions
of the Municipal Corporations Act, to the
Registered Public Institution for developing
and running or only for running the same.
OR
The owner may be allowed to develop
entire reservation for public parking and he
shall maintain it for public parking forever.
Agreement to that effect shall be executed
with the Authority by the owner.
OR
The Owner may be allowed to develop area
of the reservation, subject to following :-
i) The owner shall develop parking space
according to the designs,
specifications and conditions
prescribed by the Authority and
handover the constructed parking area
equal to the reservation area, to
Authority.
ii) The operation and the maintenance of
the facility will be decided by the
Authority.
iii) Parking spaces may be in basement or
on stilts or on first/second floor with
separate entry & exit.
iv) After handing over the above said
parking area to the Planning Authority,
the owner shall be entitled to
construct with full permissible FSI of
the entire Plot and permissible TDR
potential of the entire Plot for other
permissible user in that zone.
v) The Authority, if required, shall allow
the TDR for the unutilized FSI, if any
(after deducting in-situ FSI), to be
utilised as TDR Regulations.
(1) vi) Reservation may be allowed to be
developed in parts, if the area under
such part reservation is 50% or more,
out of total area of reservation.
The Planning Authority/ Appropriate
5.4) Truck Terminus Planning Authority
Authority may acquire and develop the
or similar /Appropriate
reservation site for the same purpose. OR
Authority/ Owner
The owner may be allowed to develop
entire reservation for the intended purpose.
OR
i) The Authority may allow the owner to
develop the reservation, subject to
handing over to the Planning
Authority an independent plot along
with constructed amenity of total area,
mentioned in note-1 below this table &
as per norms prescribed by the
Authority.
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
ii) The owner shall be entitled to develop
remaining land for the uses
permissible in adjoining zone with full
permissible FSI of the entire Plot and
permissible TDR potential of the
entire Plot.
iii) The Authority, if required, shall allow
the TDR for the unutilized FSI, if any
(after deducting in-situ FSI), to be
utilised as per TDR Regulations.
iv) Reservation may be allowed to be
developed in parts.
6 ) Educational
(a) Primary School Planning Authority/ The Planning Authority/ Appropriate
Appropriate Authority may acquire and develop the site
(b) High School
Authority/ for the same purpose.
(c) College
Registered
OR
Educational
The Planning Authority / Appropriate
Institution Trust /
Authority after acquiring land or after
Owner
acquiring and constructing the building on
it, as the case may be, lease out the same as
per the provisions of the Municipal
Councils/Municipal Corporations/Authority
Act, to the Registered Public Educational
Institution trust for developing and running
or only for running the same.
OR
The owner may be allowed to develop the
reservation for the same purpose. The
Registered Public Educational Institution
trust on behalf of owner may also be
allowed to develop subject to
terms/conditions as prescribed by the
Authority.
OR
i) The Authority may allow the owner to
develop the reservation, subject to
handing over to the Authority an
independent plot along with
constructed amenity of total area,
mentioned in Note-1 below this table
& as per norms prescribed by the
Authority.
ii) The owner shall be entitled to develop
remaining land for the uses
permissible in adjoining zone with full
permissible FSI of the entire Plot and
permissible TDR potential of the
entire Plot.
iii) The Authority, if required, shall allow
the TDR for the unutilized FSI, if any
(after deducting in-situ FSI) to be
utilised as per TDR Regulations.
iv) Reservation may be allowed to be
developed in parts. However, it shall
be ensured that school or college of
proper size is constructed. It shall be
ensured that Primary School and High
School area to be handed over to
Authority shall be minimum
2000sq.m.
(c) Educational Planning Authority/ The Planning Authority/ Appropriate
Complex Appropriate Authority may acquire and develop the site
Authority/ Land for the same purpose.
Owner
OR
The Planning Authority/ Appropriate
Authority after acquiring land or after
acquiring and constructing the building on
it, as the case may be, lease out the same as
per the provisions of the Municipal
Corporations Act, to the Registered Public
Educational Institution Trust for developing
and running or only for running the same.
OR
The owner may be allowed to develop the
reservation for the same purpose. The
Registered Public Educational Institution
trust on behalf of owner may also be
allowed to develop subject to
terms/conditions as prescribed by the
Authority.
OR
If the area of the Educational Complex
reservation is more than 1.00 Ha. then,
i) The Authority may allow the owner to
develop the reservation, subject to
handing over to the Planning
Authority an independent plot
alongwith constructed amenity of total
area, mentioned in Note-1 below this
table & as per norms prescribed by the
Authority.
ii) The owner shall be entitled to develop
remaining land for the uses
permissible in adjoining zone with full
permissible FSI of the entire Plot and
permissible TDR potential of the
entire Plot.
iii) The Authority, if required, shall allow
the TDR for the unutilized FSI, if any
(after deducting in-situ FSI), to be
utilised as per TDR Regulations.
iv) Reservation may be allowed to be
developed in parts.
7) Residential
a) Public Housing / Planning Authority/ Planning Authority / Appropriate Authority
Appropriate may acquire the reserved land and develop
EWS/LIG
Authority/ Owner for the same purpose.
Housing.
OR
b) High Density
i) The Authority may allow the owner to
Housing.
develop the reservation, subject to
c) Housing for
handing over to the Planning
Dis-housed. Authority an independent plot along
d) Reservation with constructed tenements of not
similar as above. more than 30 Sq.m. carpet area each to
the Authority, mentioned in Note-1
below this table& as per norms
prescribed by the Authority.
ii) The owner shall be entitled to develop
remaining land for the uses
permissible in adjoining zone with full
permissible FSI of the entire Plot and
permissible TDR potential of the
entire Plot.
iii) The Authority, if required, shall allow
the TDR for the unutilized FSI, if any
(after deducting in-situ FSI), to be
utilised as per TDR Regulations.
iv) The Planning Authority / Appropriate
Authority shall allot such tenement on
priority to the persons dispossessed by
implementation of Development Plan.
v) Reservation maybe allowed to be
developed in parts.
OR
The Authority may allow the owner to
develop the reservation, subject to-
a) Handing over of 40 % land to Authority
in lieu of FSI/TDR, for laying out
plots for EWS/LIG. The owner shall
thereafter be entitled to develop
remaining plot as per the uses
permissible in residential zone with
permissible FSI/TDR potential of
entire plot on remaining plot without
taking into account the area handed
over to the Planning Authority.
b) The Planning Authority / Appropriate
Authority shall prepare layout for
EWS/LIG plots and allot such plots on
priority to the persons dispossessed by
implementation of Development Plan.
The Planning Authority may construct
EWS/LIG tenements on such land.
8) Assembly and Institutional
a) Town Hall, Planning Authority/ The Planning Authority / Appropriate
Appropriate Authority may acquire and develop the site
b) Drama Theatre,
Authority/ Owner for the same purpose.
c) Auditorium,
OR
d) Samaj Mandir,
The Planning Authority/ Appropriate
e) Community
Authority after acquiring the land or after
Hall,
acquiring and developing the same, as the
f) Multipurpose case may be, lease out as per the provisions
Hall, of the Authorities' Act to a Registered
g) Library Public Institution to develop and running or
only for running the same.
h) Town Centre,
OR
i) Town Sub-
Centre etc. The owner may be allowed to develop
entire reservation for the intended purpose
only.
OR
i) The Authority may allow the owner to
develop the reservation, subject to
handing over to the Planning
Authority an independent plot along
with constructed amenity of total area,
mentioned in Note-1 below this table
& as per norms prescribed by the
Authority.
ii) The owner shall be entitled to develop
remaining land for the uses
permissible in adjoining zone with full
permissible FSI of the entire Plot and
permissible TDR potential of the
entire Plot.
iii) The Authority, if required, shall allow
the TDR for the unutilized FSI, if any
(after deducting in-situ FSI), to be
utilised as per TDR Regulations.
iv) Reservation may be allowed to be
developed in parts.
9) Public-Semi public
a) Govt. Offices Planning Authority/ The Planning Authority/ Appropriate
Appropriate Authority may acquire and develop the
b) Fire Brigade
Authority/ Owner reservation site for the same purpose.
Station
OR
c) Reservations
similar to i) The Authority may allow the owner to
above. develop the reservation, subject to
handing over to the Planning
Authority independent plot along with
constructed amenity of total area,
mentioned in Note-1 below Table & as
per norms prescribed by the Authority.
ii) The owner shall be entitled to develop
remaining land for the uses
permissible in adjoining zone with full
permissible FSI of the entire Plot and
permissible TDR potential of the
entire Plot.
iii) The Authority, if required, shall allow
the TDR for the unutilized FSI, if any
(after deducting in-situ FSI), to be
utilised as per TDR Regulations.
iv) Reservation may be allowed to be
developed in parts.
10) Reservations of Planning Authority/ The Planning Authority/ Appropriate
composite nature Appropriate Authority may acquire and develop the site
like Vegetable Authority/ Owner for the same purpose.
Market & Explanation-For the reservation of
Shopping Centre, composite nature, proposed in Development
Town Hall & Plan except Town Hall & Library, area of
Library, etc. each user shall be considered equal i.e. 50-
50% and for Town Hall & Library, area of
Library shall be 10% of area of Town Hall
and such area shall be allowed to be
developed as per the norms applicable for
such reservation as mentioned in these
regulations.
11) Reservations Planning Authority/ Planning Authority/ Appropriate Authority
which are not Appropriate may acquire the reserved land and develop
included in these Authority/ Owner for the same purpose.
regulations but
OR
are compatible to
The development permissions for such type
other similar type
of user under this Regulation may be
of reservation.
granted by the Authority in consultation
with the Divisional Joint Director of Town
Planning, subject to verification of
compatibility of both the users and as per
the norms applicable for such reservation as
mentioned in these regulations.
12) For other Planning Authority/ The Planning Authority/ Appropriate
buildable Appropriate Authority may acquire and develop the
reservations Authority Owner. reservation site for the same purpose.
shown in
OR
Development Plan
i) The Authority may allow the owner to
which are not
develop the reservation, subject to
covered above
handing over to the Planning
Authority an independent plot along
with constructed amenity of total area,
mentioned in Note-1 below this table&
as per norms prescribed by the
Authority.
ii) The owner shall be entitled to develop
remaining land for the uses
permissible in adjoining zone with full
permissible FSI of the entire Plot and
permissible TDR potential of the
entire Plot.
iii) The Authority, if required, shall allow
the TDR for the unutilized FSI, if any
(after deducting in-situ FSI), to be
utilised as per TDR Regulations.
iv) Reservation may be allowed to be
developed in parts.
13) Reservations for Planning Authority/ Planning Authority/ Appropriate Authority
the Appropriate Appropriate may acquire the reserved land and develop
Authority other Authority/ Owner for the same purpose.
than Planning
OR
Authority
The Authority may allow the owner to
Develop the reservation subject to condition
that;
i) Wherever the reservation is to be
developed by the Appropriate
Authority other than Municipal
Corporation, No Objection Certificate
from the Appropriate Authority shall
be obtained before granting
development permission.
ii) The concerned Appropriate Authority
(other than the State Government
Department) shall deposit cost of
construction for the built- up area to be
handed over to it, as per Annual
Statement of Rates with the Planning
Authority. However, the Authority
shall handover such constructed area
to the State Government/ concerned
State Government Department free of
cost.
General conditions/notes to allow development under above regulations:-
i) The percentage of land and construction of amenity to be surrendered to the Authority
as per above mentioned regulations for various authorities, shall be as below:-
Sr. No. Reservation Type of Authority Percentage of Percentage of
of total land to be constructed
surrendered amenity of the
above
free of cost total land
Table
&free from area to be
encumbrances surrendered
free of cost &
free from
encumbrances
1 2 3 4 5
3 Commercial A, B, C Class Municipal 40 50
Corporations and
4 Health Facility
Development Authorities
5 Transportation
7 Residential D Class Municipal 40 25
8 Assembly & Corporations & A Class
Institutional Municipal Councils.
9 Public-Semi B & C Class Municipal 30 20
public Councils and Nagar
Panchayats.
12 Other Buildable
Reservations
5.4 Truck Terminus A, B, C Class Municipal 40 10
or Similar Corporations and
Development Authorities.
D Class Municipal 30 7
Corporations & A Class
Municipal Councils.
B & C Class Municipal 20 5
Councils and Nagar
Panchayats
5.1 Bus Stand A, B, C Class Municipal 50 20
Corporations and
Development Authorities
D Class Municipal 40 15
Corporations & A Class
Municipal Councils
B & C Class Municipal 40 10
Councils and Nagar
Panchayats
6 Education A, B, C Class Municipal 40 50
Corporations and
Development Authorities
D Class Municipal 40 40
Corporations & A Class
Municipal Councils
B & C Class Municipal 40 30
Councils and Nagar
Panchayats
ii) The owner shall be entitled for Amenity TDR against the construction of amenity, if any,
as per TDR Regulation.
iii) The word 'Authority' means Municipal Commissioner of Municipal Corporation, Chief
Officer of Municipal Council, Metropolitan Commissioner of Metropolitan Development
Authority or Chief Executive Officer of the concerned Authority.
iv) If the area of reservation is not adequate to construct independent building as mentioned
above OR When it is not possible to handover individual plot along with public amenity,
then in such cases Authority may allow composite building on said land subject to
condition that the built up area mentioned as above may be allowed to be handed over to
the Planning Authority or Appropriate Authority, as the case may be, preferably on ground
floor and subject to payment of premium (1) for the land required to be handed over to
Authority at the rate of 40% of land rate in ASR, without considering the guidelines
therein. If ground floor is utilised for parking, then such built up area shall be given on
stilt/first floor with separate entry & exit from Public Street. In such cases, built-up area
(along with proportionate undivided share in land) shall be handed over to the Planning
Authority or Appropriate Authority, as the case maybe.
v) In case of development of reservation of Bus Stand at Sr. No. 5.1, the construction area for
allied activities and uses permissible in Residential Zone may be allowed to be constructed
up to FSI of 2.00 of the surrendered plot with the consent of owner. In such cases, the
owner shall be entitled for amenity TDR to that extent. If the plot along with construction
is handed over to MSRTC, the regulations applicable to the plot owned by MSRTC shall
be applicable to the said plot.
vi) If owner desires to construct area of amenity more than what is mentioned above table
(1)upto maximum building potential as per Regulation No.6.1, Table 6-A or Regulation
No.6.3, Table 6-G, as the case may be, with the consent of the authority, then he shall be
entitled for amenity TDR to that extent.
vii) It shall be obligatory on the Authority to make registered agreement with the developer
/owner at the time of granting the development permission subject to terms and conditions
as it deem fit. Occupancy Certificate shall be issued only after compliance of all terms &
conditions and getting possession of the constructed amenity.
viii) The area/ built-up area to be handed over to the Planning Authority under these
Regulations shall be earmarked on the sanctioned building plan clearly mentioning the
same. After completion of construction, the said amenity shall be handed over by
executing the deed of transfer in this respect and expenses thereon shall be borne by the
owner. The occupation certificate to the construction belonging to owner shall be granted
only after handing over said amenity to the Planning Authority. The constructed amenity
shall be made available to the general public by the Authority within 3 month from
possession.
ix) In cases, where permission for development under accommodation reservation principle is
already granted as per earlier regulations, the same shall continue to be valid till
completion of construction.
x) Provisions of Regulations of Inclusive Housing, Amenity Space if any, shall not be
applicable for development under this Regulation. Moreover Regulation of required
recreational open space shall not be applicable for development of reservation other than
Residential purpose as mentioned at Sr. No.7.
xi) Notwithstanding anything contained in these regulations, there shall be no cap for
utilization of available in-situ FSI /and (1) Premium FSI and TDR potential of the entire plot
on the remaining plot.
xii) Once sanction is granted under this regulation, the owner/developer shall have to complete
the development and hand over the developed reservation to the Authority within the
period as specified by Authority. Thereafter Authority may levy penalty for any delay.
xiii) The development permissions granted under the provisions of Accommodation Reservation
provisions and full & final occupation certificate is issued, in such cases the
portion/location designated for respective reservation is continued to be in said reservation
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
and rest of land on which residential/commercial development permission is granted is
deemed to be converted into residential/ commercial zone to the extent of that area.
xiv) Where appropriate authority for development of reservation is other than the planning
authority, then such appropriate authority may be consulted for usefulness of the
constructed amenity to be handed over, before granting the development permission.
xv) In case of Nagpur Municipal Corporation, for development of commercial reservation at
Sr. No. 3 of Table No. 11-A, FSI permissible for development of reservation shall be as per
Regulation No. 10.3.1. In such case the construction area to be handed over to the
authority shall be 1.5 time of the plot area to be handed over and the owner shall be entitled
to utilise entire potential of reserved plot as per Regulation No. 10.3.1.
xvi) This regulation shall not be applicable for development of amenity space to be provided as
per Regulation No. 3.5 and Regulation No. 4.8.1.
xvii) The norms mentioned above in note (1)(i) for B and C class Municipal Councils, shall be
applicable to non-Municipal Town Development Plan also.
11.2 REGULATIONS FOR GRANT OF TRANSFERABLE DEVELOPMENT RIGHTS
11.2.1 Transferable Development Rights
Transferable Development Rights (TDR) is compensation in the form of Floor Space Index (FSI)
or Development Rights which shall entitle the owner for construction of built-up area subject to
provisions in this regulation. This FSI credit shall be issued in a certificate which shall be called as
Development Right Certificate (DRC).
Development Rights Certificate (DRC) shall be issued by Authority under his signature and
endorse thereon in writing in figures and in words, the FSI credit in square meters of the built-up
area to which the owner or lessee is entitled, the place from where it is generated and the rate of
that plot as prescribed in the Annual Statement of Rates issued by the Registration Department for
the concerned year. TDR generated within the jurisdiction of a particular Authority, shall be
utilised within the jurisdiction of the same Authority as per this regulation.
11.2.2 Cases eligible for Transferable Development Rights (TDR)
Compensation in terms of Transferable Development Rights(TDR)shall be permissible for-
i) lands under various reservations for public purposes, new roads, road widening etc. which
are subjected to acquisition, proposed in Draft or Final Development Plan, prepared under
the provisions of the Maharashtra Regional and Town PlanningAct,1966;
ii) lands under any deemed reservations according to any regulations prepared as per the
provisions of Maharashtra Regional & Town Planning Act,1966;
iii) lands under any new road or road widening proposed under the provisions of Maharashtra
Municipal Corporation Act, Maharashtra Municipal Council, Nagar Panchayat and
Industrial Township Act;
iv) In case where layout is submitted along with proposed Development Plan Road, in such
cases TDR shall be permissible for entire road width as per these regulations.
v) development or construction of the amenity on the reserved or deemed reserved land;
vi) unutilized FSI of any structure or precinct which is declared as Heritage structure or
precinct under the provisions of Unified Development Control and Promotion Regulations,
due to restrictions imposed in that regulation;
vii) in lieu of constructing housing for slum-dwellers according to regulations prepared under
the Maharashtra Regional & Town Planning Act,1966;
(1)
Substituted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
viii) for handing over land to the Authority for development of housing under PMAY by the
Authority.
ix) The purposes as may be notified by the Government from time to time.
11.2.3 Cases not eligible for Transferable Development Rights (TDR)
It shall not be permissible to grant Transferable Development Rights (TDR)in the following
circumstances:-
i) For earlier land acquisition or development for which compensation has been already paid
partly or fully by any means;
ii) Where award of land has already been declared and which is valid under the Acquisition
or the Right to Fair Compensation & Transparency in Land Acquisition, Rehabilitation
Act
and Resettlement Act, 2013 unless lands are withdrawn from the award by the Appropriate
Authority according to the provisions of the relevant Acts.
iii) In cases where layout has already been sanctioned and layout roads are incorporated as
Development Plan roads prior to these regulations.
iv) If the compensation in the form of FSI / or by any means has already been granted to the
owner.
v) Where lawful possession including by mutual agreement /or contract has been taken and
such agreement does not provide for TDR.
vi) For an existing user or retention user or any required compulsory open space or
recreational open space or recreational ground, in any layout.
vii) For any designation, allocation of the use or zone which is not subjected to acquisition.
viii) Existing nallah, river, natural stream, natural pond, tank, water bodies etc.
ix) Reservations which are not developable under the provisions of UDCPR.
x) For the lands owned by the State Government.
11.2.4 Generation of the Transferable Development Rights (TDR)
Transferable Development Rights (TDR) against surrender of land:-
a. For surrender of the gross area of the land which is subjected to acquisition, free of cost
and free from all encumbrances, the owner shall be entitled for TDR or DR irrespective of
the FSI permissible or development potential of such land to be surrendered and also that
of land surrounding to such land at the rate given below :-
Entitlement for TDR / DR
Area Designated on DP
2 times the area of surrendered land.
Non-Congested Area
Congested Area 3 times the area of surrendered land.
Note :-
i) The quantum of Transferable Development Rights (TDR) generated for reservation in area
having total legal impediment / constraint on construction or development like CRZ /
Hazardous zone / Low Density zone, shall be 50% of TDR generated as prescribed above.
ii) The quantum of Transferable Development Rights (TDR) generated for Bio Diversity Park
reservation shall be 8% of gross area.
(Explanation :- Above entitlement may also be applicable to the compensation paid in the
form of FSI to the owner to be utilised on unaffected part of same land parcel and in such
cases the procedure of DRC shall not be insisted.)
Provided that, if levelling of land and construction/erection of the compound wall/ fencing
as per Clause (b) below to the land under surrender is not desirable considering the total
area of reservation, the quantum of TDR shall be reduced to 1:1.85 and 1:2.85 in non-
congested area and congested area respectively. In such cases, the owner shall have also an
option of paying the cost of construction of compound wall (as decided by the Authority)
without reducing the quantum of TDR.
Provided further that such construction/ erection of compound wall/ fencing shall not be
necessary for area under development plan roads. In such cases TDR equivalent to
entitlement as mentioned above shall be granted without any reduction.
Provided also that Additional/ incentive Transferable Development Rights (TDR) or
Development Rights (DR) to the extent of 5% of the surrendered land area shall also be
allowed to the land owners who submit the proposal for grant of Transferable Development
Rights (TDR) of land reserved in the development plan, within 2years from the sanction of
these regulations.
Provided that the quantum of generation of TDR as prescribed above, shall not be
applicable for TDR generated from construction of amenity or construction of reservation/ /
(1)deemed reservations / roads, Slum TDR, Heritage TDR.
b. DRC shall be issued only after the land is surrendered to the Authority, free of cost and free
from encumbrances and after levelling the land to the surrounding ground level and after
constructing/ erecting a 1.5 m. high compound wall / fencing i.e. brick/stone wall up to
0.60m. above ground level and fencing above that upto remaining height with a gate, at the
cost of the owner and to the satisfaction of the Authority.
c. If any contiguous land of the same owner/developer, in addition to the land under surrender
for which Transferable Development Rights (TDR) is to be granted, remains unbuildable,
the Authority may grant Transferable Development Rights (TDR) for such remaining
unbuildable land also if the owner / developer hands it over free of cost and free from all
encumbrance and encroachment. If such land is from the proposed roads then such land
shall be utilised for road side parking, garden, open space or road side amenities including
bus bays, public toilets or any compatible user as the Authority may decide and if the such
land is from the proposed reservation then same shall be included in such proposed
reservation and shall be developed for the same purpose.
d) In case of lessee, the award of Transferable Development Rights (TDR) shall be subject to
lessee paying the lessor or depositing with the Authority for payment to the lessor, an
amount equivalent to the value of the lessor's interest to be determined by the Authority on
the basis of Right to Fair Compensation and Transparency in Land Acquisition,
Rehabilitation and Resettlement Act, 2013 against the area of land surrendered, free of cost
and free from all encumbrances.
e) Where the authority has taken the possession of the reserved land in development plan with
the commitment of granting TDR / DRC in the past and DRC is not issued, in such cases,
DRC shall be issued for the quantum as per this UDCPR.
11.2.5 (#) Transferable Development Rights (TDR) against Construction of Amenity-
When an owner or lessee, with prior approval of Authority, develops or constructs the amenity on
the surrendered plot, at his own cost subject to such stipulations as may be prescribed and to the
satisfaction of the Authority and hands over the said developed/constructed amenity free of cost to
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
(#)
Clarification issued vide letter - CR 44/21 dt., 10th June, 2021.
the Authority, then he may be granted a Transferable Development Rights (TDR ) in the form of
FSI as per the following formula :-
Construction Amenity TDR in Sq.m. = A/B * 2.00 Where,
A = cost of construction of amenity in rupees as per the rates of construction mentioned in
Annual Statement of Rates (ASR) prepared by the Inspector General of Registration for the
year in which construction of amenity is commenced. (In case of construction of new D.P.
road, cost of construction as worked out on the basis of District Schedule of Rates.)
B = land rate per Sq.m. as per the Annual Statement of Rates (ASR) prepared by the Inspector
General of Registration for the year in which construction of amenity is commenced.
In case of buildings like auditorium, assembly etc. wherein height of building is more, cost of the
building may be worked out from the Public Works Department as per applicable DSR. Also
expenses for ancillary requirements only of immovable items like acoustic etc. may also be
included in such cost. Such expenses for ancillary requirement may also be considered for hospital
and educational buildings.
If any person, with the consent of the authority, constructs D.P. road by obtaining development
rights / consent of the other owners whose land is covered under the D.P. road, then such person
may be entitled for construction amenity TDR subject to -
i) This provision shall only apply to construction of new road proposed in the Development
Plan.
ii) One end of road should meet other existing public road.
iii) The specifications for construction of road shall be as decided by the Authority.
11.2.6 Utilisation of Transferable Development Rights (TDR)
i) A holder of DRC who desires to use FSI credit therein on a particular plot of land shall
attach valid DRCs to the extent required with his application for development permission.
Proposal for Transferable Development Rights (TDR) utilisation shall be submitted along
with the documents as may be prescribed by the Authority or by the Government from time
to time.
ii) With an application for development permission, where an owner seeks utilization of DRC,
he shall submit the DRC to the Authority who shall endorse thereon in writing in figures
and words, the quantum of the TDR proposed to be utilised, before granting development
permission. Before issuance of Occupation Certificate, the Authority shall endorse on the
DRC, in writing in figures and words, the quantum of TDR/DRs actually used and the
balance remaining, if any
iii) The Transferable Development Rights (TDR) generated from any land use zone shall be
utilised on any receiving plot irrespective of the land use zone including development plan
reservations of buildable nature and anywhere in congested or non-congested area or town
planning scheme area earmarked on Development Plan. The equivalent quantum of
Transferable Development Rights (TDR) to be permitted on receiving plot shall be
governed by the formula given below:-
Formula: X = (Rg / Rr) x Y Where,
X = Permissible Utilisation of TDR/DR in Sq.m. on receiving plot.
Rg = Rate for land in Rs. per sq.m.as per ASR of generating plots in generating year.
Rr = Rate for land in Rs. per Sq.m. as per ASR of receiving plot in generating year.
Y = TDR debited from DRC in Sq.m.
11.2.7 Utilisation of Transferable Development Rights (TDR) and Road Width Relation
i) The total maximum permissible built-up area and utilisation of Transferable Development
Rights (TDR) on receiving plot shall be, as per Regulation No. 6.1, 6.2 and 6.3.
ii) The quantum of maximum permissible TDR loading mentioned in Table 6-G of Regulation
No. 6.3 shall include minimum 30 % and maximum 50% slum TDR/ URT/ Amenity TDR
(wherever applicable). If such TDR is not available, the other TDR may be used.
Moreover, this shall not be applicable for TDR loading mentioned in Regulation No.6.1.1.
Table 6A.
iii) The utilisation of Transferable Development Rights (TDR) shall be permissible by
considering (1) the provision mentioned in Note (xiv) below Table No. 6G of Regulation
No.6.3.
11.2.8 Areas Restricted from Utilisation of Transferable Development Rights (TDR)
Utilisation of Transferable Development Rights (TDR) shall not be permitted in following areas:-
a. Agricultural/ No Development/ Green zone/ Green Belt/ Regional Park/ HTHS Zone and
Bio Diversity Park reservation in the Development Plan.
b. Area within the flood control line i.e. blue line (prohibitive zone) as specified by Irrigation
Department.
c. Coastal regulation zone.
d. Area having developmental prohibition or restrictions imposed by any notification issued
under the provisions of any Central/State Act (like CRZ regulations, Defense restriction
areas, etc.) or under these regulations
e. Koregaon Park area in Pune Municipal Corporation area.
11.2.9 General stipulation
i) Development Rights (DRs) will be granted to an owner or lessee, only for reserved lands
which are retainable and not vested or handed over to the Government /Urban Local
Bodies and not exempted under section 20 or 21 of the then Urban Land (Ceiling and
Regulations) Act, 1976 and undertaking to that effect shall be obtained, before a
Development Right is granted. In the case of schemes sanctioned under section 20 or 21 of
the said Act, the grant of Development Rights (DRs) shall be to such extent and subject to
the conditions mentioned in section20 or 21 scheme and such conditions as the
Government may prescribe. In case of non-retainable land (surplus land), the grant of
Development Rights shall be to such extent and subject to such conditions as the
Government may specify. The provisions of this Regulation shall be subject to the orders
issued by the Government from time to time in this regard.
ii) In case of lands having tenure other than Class-I, (1) i.e. Inam lands, tribal lands etc., N.O.C.
from Competent Authority shall be produced by the land holder at the time of submission
of application for grant of TDR.
iii) DRC shall be issued by the Authority as a certificate printed on bond paper in an
appropriate form prescribed by him. Such a certificate shall be a "transferable and
negotiable instrument" after the authentication by the Authority. The Authority shall
maintain a register in a form considered appropriate by him of all transactions, etc. relating
to grant of, or utilisation of DRC.
iv) The Authority shall issue DRC within 90 days from the date of application or reply from
the applicant in respect of any requisition made by him, whichever is later.
(1)
Substituted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
v) The TDR shall be granted only for those reservations which are developable for intended
purpose under these regulations.
11.2.10 Transfer of DRC
The Authority shall allow transfer of DRC in the following manner :-
i) In case of death of holder of DRC, the DRC shall be transferred only on production of the
documents, as may be prescribed by him, from time to time, after due verification and
satisfaction regarding title and legal successor.
ii) If a holder of DRC intends to transfer it to any other person, he shall submit the original
DRC to the Authority with an application along with relevant documents as may be
prescribed by the Authority and a registered agreement which is duly signed by Transferor
and Transferee, for seeking endorsement of the new holders name, i.e., the transferee, on
the said certificate. The transfer shall not be valid without endorsement by the Authority
and in such circumstances the Certificate shall be available for use only to the holder
/transferor.
The utilisation of TDR from such certificate shall not be permissible during transfer
procedure.
iii) The Authority may refrain the DRC holder from utilizing the DRC in the following
circumstances:-
a) Under direction from a competent Court.
b) Where the Authority has reason to believe that the DRC is obtained
a) by producing fraudulent documents b) by misrepresentation,
iv) Any DRC may be utilised on one or more plots or lands whether vacant, or already
developed fully or partly by erection of additional storey, or in any other manner consistent
with the these Regulations,
v) DRC may be used on plots/land having Development Plan reservations of buildable nature,
whether vacant or already developed for the same purpose, or on the lands under deemed
reservations, if any, as per these Regulations or on amenity space.
vi) DRC may be used on plots/land available with the owner after surrendering the required
land and construction to the Authority under the provisions of Accommodation
Reservation. In such circumstances, for the purpose of deciding receiving potential of the
plot for the Transferable Development Rights (TDR), the total area of the reservation
before surrender shall be considered.
11.2.11 Infrastructure Improvement Charges-
No infrastructure improvement charges shall be paid for utilisation of TDR.
11.2.12 Vesting of Land:-
The Authority, before issuing DRC, shall verify and satisfy himself that the ownership and title of
the land proposed for surrender is with the applicant, and get the Record of Right corrected in the
name of Authority.
In case the Appropriate Authority for reservation is other than Authority, it shall be permissible for
the Authority, on the request of such authority to grant TDR under this regulation and hold such
possession as a facilitator.
Provided that, the Authority shall handover the possession of such land to concerned Appropriate
Authority, after receipt of value of land, from such Appropriate Authority as per Annual Statement
of Rates prevailing at the time of handing over possession of land under reservation.
Provided also that, if such Appropriate Authority is the State Government or State Government
Department, the Authority shall handover the possession of such land to the concerned
Department, free of cost.
11.2.13 Effect of this Regulation
DRC issued under the old regulations as per TDR zone, shall be utilised as per these regulation
considering the year of generation of TDR mentioned on the original DRC and accordingly land
rate in the relevant ASR shall be considered.
Provided also that old TDR purchased as per TDR zones for utilisation on a specific plot with
registered documents of sale and / or specific proposal for utilisation of such TDR pending in the
ULBs, shall be allowed completely as per the old regulations.
11.3 RESERVATION CREDIT CERTIFICATE (RCC)
The reservation credit certificate is a certificate specifying the amount of compensation in lieu of
handing over of reserved land to the Corporation and shall be issued by the Authority. The amount
mentioned in this credit certificate may be used for payment of various charges like development
charges, premium, property tax, infrastructure charges etc. to the authority from time to time in
future till exhausting the amount mentioned therein. Reservation Credit Certificate shall be issued
subject to the following conditions.
i) The authority shall acquire the land under reservation in lieu of RCC only when it is
immediately required for development or creation of amenity or services or utilities.
ii) Such certificate shall not bear any interest on the amount mentioned therein and shall be
transferable. However, payment being made to the authority through the amount from RCC
after six months from the date of issue of RCC shall be discounted @10% for the payments
to be made under provisions of these UDCPR.
iii) The amount of compensation to be paid to the owner shall be as per the provisions of the
relevant Acts dealing with land acquisition as amended from time to time
iv) The land to be handed over to the Corporation shall be free from all encumbrances and
procedure laid down in TDR regulations shall be followed.
The Authority shall endorse the entries of payment on such certificate from time to time. It shall
maintain a record in a form considered appropriate by it of all transactions relating to grant of
utilisation of reservation credit certificate.
-*-*-*-*-*-