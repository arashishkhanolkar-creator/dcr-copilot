# Chapter 1: Administration

CHAPTER - 1
ADMINISTRATION
1.0 SHORT TITLE, EXTENT & COMMENCEMENT
These regulations shall be called as "Unified Development Control and Promotion Regulations for
Maharashtra" (hereinafter called "These Regulations" or "Unified Development Control and
Promotion Regulations" - UDCPR )
1.1 Extent and Jurisdiction
i) These regulations shall apply to the building activities and development works on lands
within the jurisdiction of all Planning Authorities and Regional Plan areas except Municipal
Corporation of Greater Mumbai, other Planning Authorities / Special Planning Authorities /
Development Authorities within the limit of Municipal Corporation of Greater Mumbai,
MIDC, NAINA, Jawaharlal Nehru Port Trust, Hill Station Municipal Councils,
(1) Chikhaldara notified area (consisting Chikhaldara Hill Station M.C. & four villages) Eco-
sensitive / Eco-fragile region notified by MoEF & CC, and Lonavala Municipal Council in
Maharashtra.
ii) These Regulations shall also be applicable to the Town Planning Scheme area. However this
will not bar the Development Permission to be granted as per the Regulations of the Town
Planning Scheme in toto.
1.2 Commencement of Regulations
These regulations shall come into force with effect from the date of publication of notification in
the official Gazette. All the Development Control Regulations / special Regulations which are in
operation shall cease to operate.
1.3 DEFINITIONS
In these Regulations, unless the context otherwise requires, the definitions given hereunder, shall
have meaning indicated against each of them.
Words and expressions which are not defined in these Regulations, shall have the same meaning or
sense as in the :-
i) Maharashtra Regional and Town Planning Act, 1966;
ii) Maharashtra Municipal Corporations Act, 1949;
iii) Nagpur Improvement Trust Act, 1936;
iv) Maharashtra Municipal Councils, Nagar Panchayats and Industrial Townships Act, 1965;
v) Maharashtra Metropolitan Region Development Authority Act, 2016;
vi) Maharashtra Land Revenue Code, 1966;
vii) Real Estate (Regulation and Development) Act, 2016;
viii) National Building Code of India, 2016;
ix) Maharashtra Housing and Area Development Act, 1976;
x) Maharashtra Slum Areas (Improvement, Clearance And Redevelopment) Act, 1971.
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
1. Act - means the Maharashtra Regional & Town Planning Act, 1966 as may be amended from time
to time.
2. Addition / Alteration- means any change in existing authorized building or change from one
occupancy to another, or a structural change, such as an addition to the area or height, or the
removal of part of a building, or any change to the structure, such as the construction of, cutting
into or removal of any wall, partition, column, beam, joist, floor, roof or other support or a change
to or closing of any required means of ingress or egress or a change to the fixtures of equipment as
provided under these regulations. However, modification in regards to gardening, white washing,
painting, plastering, pointing, paving and retiling shall not be deemed to be alteration.
3. Advertising Sign- means any surface or structure with characters, letters or illustrations applied
thereto and displayed outdoor in any manner whatsoever for purposes of advertising or to give
information regarding or to attract the public to any place for public performance, article or
merchandise whatsoever, or is attached to, or forms a part of building, or is connected with any
building or is fixed to a tree or to the ground or to any pole, screen, fence or hoarding or displayed
in space, or in or over any water body.
4. Air-conditioning - means the process of treating air so as to control simultaneously its
temperature, humidity, cleanliness and distribution to meet the requirement of conditioned space.
5. Accessory Building - means a building separate from the main building on a plot and containing
one or more rooms for accessory use such as servant quarters, garage, store rooms etc.
6. Accessory / Ancillary Use - means any use of the premises subordinate to the principal use and
incidental to the principal use.
7. Amenity Space - for the purpose of these regulations, amenity space means a statutory space kept
in any layout to be used for any of the amenity such as open spaces, parks recreational grounds,
playgrounds, sports complex, gardens, convenience shopping, parking lots, primary and secondary
schools, nursery, health club, Dispensary, Nursing Home, Hospital, sub post-office, police station,
electric substation, ATM of banks, electronic cyber library, open market, garbage bin, assisted
living and hospice together, senior citizen housing and orphanage together, project affected
persons' housing, auditorium, conventional centre, water supply, electricity supply and includes
other utilities, services and conveniences.
8. Annual Statements of Rates - means the Annual Statements of Rates (ASR) published by the
Inspector General of Registration, Maharashtra State, Pune.
9. Architectural projection -means a chajja, cornice etc. which is a protrusion from the building
facade or line of the building only for aesthetic purpose and not used for any habitable purpose.
10. Access - means a clear approach to a plot or a building.
11. Architect - An Architect who is a member of the Indian Institute of Architects and duly registered
with the Council of Architecture under the Architects Act, 1972.
12. Apartment - means whether called block, chamber, dwelling unit, flat, office, showroom, shop,
godown, premises, suit, tenement, unit or by any other name, means a separate and self-contained
part of any immovable property, including one or more rooms or enclosed spaces, located on one
or more floors or any part thereof, in a building or on a plot of land, used or intended to be used for
any residential or commercial use such as residence, office, shop, showroom or godown or for
carrying on any business, occupation, profession or trade, or for any other type of use ancillary to
the purpose specified.
13. Applicant-means any person who is an owner or a person having an irrevocable registered Power
of Attorney of an owner and any other document as acceptable to the Authority.
14. Authority - means :
i) in the case of a Municipal Corporation, the Municipal Commissioner or such other officer as
he may appoint in this behalf;
ii) in the case of a Zilla Parishad, the Chief Executive Officer or such other officers as he may
appoint in this behalf;
iii) in the case of a Municipal Council, the Chief Officer of the Council; and
iv) in the case of any other local authority, Special Planning Authority, New Town Development
Authority or Area Development Authority, the Chief Executive Officer or person exercising
such powers under Acts applicable to such authorities;
v) in the area of a Regional Plan, the Collector of the District;
vi) in case of Development Authorities established under the Metropolitan Region Development
Authorities Act, Metropolitan Commissioner or such other officer as he may appoint in this
behalf;
vii) in case the land is situated in the gaothan, within the meaning of clause (10) of section 2 of
the Maharashtra Land Revenue Code, 1966, the village Panchayat concerned.
15. Atrium - means a sky lighted and naturally/mechanically ventilated area in a building, with no
intermediate floors and used as circulation space or entrance foyer.
16. Balcony - means a horizontal cantilever projection, including parapet, handrail or balustrade to
serve as a passage or sitting out place with at least one side open, except for the railing or parapet
wall for safety.
Also, non-cantilever balcony shown in the illustration below shall be treated as balcony.
17. Basic FSI - means floor Space Index permissible without levy of premium or loading of TDR on
any parcel of land as per the provisions of these regulations.
18. Basement/Cellar - means the lower storey of a building below or partly below the ground level
with one or more than one levels.
19. Biotechnology Unit / Park - means a Unit or a Park which is certified as such by the
Development Commissioner (Industries).
20. Building - means any structure for whatsoever purpose and of whatsoever materials constructed
and every part thereof whether used as human habitation or not and includes foundation, plinth,
walls, floors, roofs, chimneys, wells, door steps, fencing, plumbing and building services, fixed -
platforms, varandahs, balcony; cornice or projection, part of a building or anything affixed thereto
or any wall fence enclosing or intended to enclose any land or space and signs and outdoor display
structures. However, tents, shamiyanas and the tarpaulin shelters erected for temporary and
ceremonial occasions with the permission of the Authority shall not be considered as building.
21. Built up Area - means the area covered by a building on all floors including cantilevered portion,
mezzanine floors, if any, but excluding the areas specifically exempted from computation of Floor
Space Index (F.S.I.) under these Regulations.
22. Building Line - means the line up to which the plinth of a building adjoining a street or an
extension of a street or on a future street may lawfully extend. It includes the lines prescribed, if
any, in any scheme and / or development plan / Regional Plan, or under any other law in force.
23. Building Height - means the vertical distance measured in the case of flat roofs, from the average
level of the ground around and contiguous to the building or as decided by the Authority to the
terrace of last floor of the building adjacent to the external walls; to the highest point of the
building and in the case of pitched roofs, up to the point where the external surface of the outer
wall intersects the finished surface of the sloping roof; and in the case of gable facing road, the
mid-point between the eaves level and the ridge. Architectural features serving no other function
except that of decoration, terrace water tank, staircase roof and parapet wall shall be excluded for
the purpose of measuring heights.
24. Cabin - means a non-residential enclosure constructed of non-load bearing, non-masonry
partitions.
25. Carpet area - means the net usable floor area of an apartment, excluding the area covered by the
external walls, areas under services shafts, exclusive balcony or veranda area and exclusive open
terrace area, but includes the area covered by the internal partition walls of the apartment.
Explanation (1) -The expression "exclusive balcony or veranda area" means the area of the
balcony or veranda, as the case may be, which is appurtenant to the net usable floor area of an
apartment, meant for the exclusive use of the allottee; and "exclusive open terrace area" means the
area of open terrace which is appurtenant to the net usable floor area of an apartment, meant for the
exclusive use of the allottee.
Explanation (2) - If in any regulation of these regulations, carpet area is defined different than
what is mentioned here, then carpet area as mentioned in that regulation, shall be applicable
26. Chajja - means a sloping or horizontal structural overhang usually provided over openings on
external walls to provide protection from sun and rain and for purpose of architectural appearance.
27. Chief Fire Officer - means a Chief Fire Officer as specified in the Maharashtra Fire Prevention
and Life Safety Measures Act, 2006 and Rules there under as amended from time to time.
28. Chimney - means an upright shaft containing one or more flues provided for the conveyance to
the outer air of any product of combustion resulting from the operation of heat producing appliance
or equipment employing solid, liquid or gaseous fuel.
29. Cluster - means any area of land so defined, under these regulations.
30. Combustible Material - means a material which when burnt adds heat to a fire when tested for
combustibility in accordance with IS 3808-1979: Method of test for non-combustibility of building
materials (first revision) given in the National Building Code.
31. Congested Area - In case of Regional Plan area, a land included within the gaothan as determined
under Maharashtra Land Revenue Code, 1966, and in case of other areas as specifically earmarked
in the Development Plan/ Planning Proposal. (In case of Nashik Municipal Corporation, congested
area is referred to as Core area).
32. Control Line - means a line on either side of a highway or part of highway beyond the building
line fixed in respect of such highway by the Highway Authority from time to time.
33. Courtyard or Chowk - means a space permanently open to sky enclosed on sides fully or
partially by buildings and may be at ground level or any other level within or adjacent to a
building.
34. Canopy - means a cantilevered projection over any entrance to a building
35. Convenience Shops - means shops for day-to-day domestic needs, as distinguished from
wholesale trade or departmental store.
36. Corridor - means a common passage or circulation space including a common entrance space.
37. Curb Cut - means a small solid (usually concrete) ramp that slopes down from the top surface of
a sidewalk or footpath to the surface of an adjoining street. It is designated for ease of access for
pedestrians, bicyclists and differently abled people.
38. Detached Building - means a building whose walls and roofs are independent of any other
building with marginal distances on all sides as may be specified.
39. Development - Development with its grammatical variations means the carrying out of buildings,
engineering, mining or other operations in or over, or under land or the making of any material
change, in any building or land or in the use of any building or land or any material or structural
change in any Heritage building or its precinct and includes demolition of any existing building,
structure or erection of part of such building, structure or erection and reclamation, redevelopment
and layout or sub-division of any land and to develop shall be construed accordingly.
40. Development Rights - means right to carryout development or to develop the land or building or
both and shall include the transferable development right in the form of right to utilize the floor
space index of land utilizable either on the reminder of the land partially reserved for public
purpose or elsewhere as the development control& promotion regulations in this behalf provide.
41. Dharmashala - means a building used as a place of religious assembly, rest house, a place in
which charity is exercised with religious or social motives, or a place where in a certain section of
people have a right of residence or are granted residence without payment or on nominal payment.
42. Development Plan - means a plan for the development or re-development of the area within the
jurisdiction of a Planning Authority and includes revision of a Development Plan and Planning
Proposals of a Special Planning Authority for development of land within its jurisdiction.
43. Drain - means a system or a line of pipes, with their fittings and accessories, such as manholes,
inspection chambers, traps, gullies, floor traps used for the drainage of building, or number of
building or land appurtenant to the buildings within the same cartilage. A drain shall also include
open channel for conveying surface water or a system for the removal of any liquid.
44. Dwelling Unit / Tenement - means an independent housing unit with separate facilities for living,
cooking and sanitary requirements.
45. Eating House - means any premises where any kind of food is prepared or supplied for
consumption by public for a profit or gain of any person owning or having an interest in or
managing such premises.
46. Enclosed Stair case - means a stair case separated by fire resistant walls and door(s) from the rest
of the building.
47. Energy Efficient Building - means a building compliant with the provisions of Energy
Conservation Building Code (ECBC).
48. Existing Building or use - means a building, structure or premises or its use existing on ground.
49. Exit - means a passage, channel or means of egress from any building, storeys or floor area to a
street or other open space of safety.
i) "Horizontal Exit" means a protected opening through or around a firewall or a bridge
connecting two or more buildings;
ii) "Outside Exit" means an exit from a building to a public way, or to an open area leading to
a public way, or to an enclosed fire resistant passage leading to a public way;
iii) "Vertical Exit" means an exit used for ascension or dissension between two or more levels
including stairways, smoke-proof towers, ramps, escalators and fire escapes;
50. External Wall - means an outer wall of a building not being a party wall even though adjoining to
a wall of another building and also means a wall abutting on an interior open space of any building.
51. Escalator - means a power-driven, inclined, continuous stairway used for ascending or descending
between floors or bridge over a road/ railway line.
52. Escape Route - means any well-ventilated corridor, staircase or other circulation space, or any
combination of the same, by means of which a safe place in the open air at ground level can be
reached.
53. Fire and/ or Emergency Alarm System - means an arrangement of call points or detectors,
sounders and other equipment's for the transmission and indication of alarm signals, for testing of
circuits and, whenever required, for the operation of auxiliary services. This device may be
workable automatically or manually to alert the occupants in the event of fire or other emergency.
54. Fire Lift - means a special lift designed for a use of fire service personnel in the event of fire or
other emergency.
55. Fire Proof Door - means a door or shutter fitted to a wall opening made of fire resistant material
to prevent the transmission and spread of heat, smoke and fire for a specified period.
56. Fire Pump - means a machine driven by external power of transmitting energy to fluids by
coupling the pump to a suitable engine or motor, which may have varying outputs/capacity but
shall be capable of having a pressure of 3.2 kg/cm2 at the topmost level of a multi-storied or high
rise building.
57. Fire Resistance - means the time during which a material fulfils its function of contributing to the
fire safety of a building when subjected to prescribed conditions of heat and load or restraint. The
fire resistance test of structures shall be done in accordance with "IS 3809 (1979): Fire resistance
test for structures"
58. Fire Resisting Material - means a material which has certain degree of fire resistance.
59. Fire Separation - means the distance in meters measured from any other building on the site, or
from other site, or from the opposite side of a street or other public space to the building.
60. Fire Service Inlet - means a connection provided at the base of a building for pumping up water
through in-built fire-fighting arrangements by fire service pumps in accordance with the
recommendations of the Chief Fire Officer.
61. Fire Tower - means an enclosed staircase which can only be approached from the various floors
through landings or lobbies separated from both, the floor areas and the staircase by fire resisting
doors and open to the outer air.
62. Floor - means the lower surface in a storey on which one normally walks in a building. The
general term floor, unless otherwise specifically mentioned, shall not refer to a mezzanine floor.
Note - The sequential numbering of floors shall be determined by its relation to the determining
entrance level. For floor at or above ground level, with direct entrance from / to road or street shall
be termed as ground floor. The other floors above ground floor shall be numbered in sequence as
Floor 1, Floor 2, etc., with the number increasing upwards. The stilt shall be termed as stilt floor or
Stilt floor 1, Stilt floor 2 etc. and floors above shall be numbered as Floor 1, Floor 2, etc.
63. Floor space index (F. S. I) - means the quotient obtained by dividing the area covered by P line as
mentioned in Regulation No. 6.6 by the net area of the plot.
F.S.I. = Area covered by P line as mentioned in Regulation No. 6.6on all floors /Net Plot area
"Premium FSI" means the FSI that may be available on payment of premium as may be
prescribed under these regulations.
64. Footing - means a foundation unit constructed in brick work, masonry or concrete, steel or any
other material permissible as per IS Code under the base of a wall or column for the purpose of
distributing the load over a large area.
66. Foundation - means that part of the structure which is in direct contact with transmitting loads to
the ground.
66. Front Open Space/Margin / Setback - means the distance between the boundary line of plot
abutting the means of access/ road/ street and the building line. In case of plots facing two or more
means of accesses / roads / streets, the plot shall be deemed to front on all such means of accesses /
roads / streets.
67. Gallery - means an intermediate floor or platform projecting from a wall of an auditorium of a hall
providing extra floor area, additional seating accommodation etc. These shall also include the
structures provided for seating in stadia.
68. Garage -A) Private Garage - means a building or portion thereof having a roof and walls on
three sides, designed and used for parking of privately owned motor driven or other vehicles within
a project. A private garage is not operated for gain and not designed or used for repairing,
servicing, hiring, selling etc. of such vehicles. It does not include an unenclosed or uncovered
parking space such as open parking areas.
B) Public Garage - means a building or portion thereof designed as a garage operated for gain,
and used for repairing, servicing, hiring, selling or storing or parking of motor driven or other
vehicles.
69. Grey Water - means waste water from kitchen sink, bathrooms, tubs, showers, wash basins,
washing machines and dish washers excluding the waste water from water closets (W.C.).
70. Group Housing Scheme - means a building or a group of buildings constructed or to be
constructed with one or more floors, consisting of more than one dwelling units and having
common service facilities. Common service facilities means facilities like stair case, balcony,
corridor and varandahs, lift, etc.
71. Ground Level -means the average level of the ground in a plot.
72. Habitable Room - means a room constructed or intended for human habitation and uses incidental
thereto, including kitchen if used as a living room but excluding a bathroom, water closet
compartment, laundry, serving and storing pantry, corridor, cellar, attic and spaces not frequently
used.
73. Hazardous Material means -
i) Radioactive substances;
ii) Material which is highly combustible or explosive and/or which may produce poisonous
fumes or explosive emanations or storage, handling, processing or manufacturing of which
may involve highly corrosive, toxic or noxious alkalis or acids or other liquids;
iii) Other liquids or chemicals producing flame, explosives, poisonous irritant or corrosive gases
or which may produce explosive mixtures of dust or fine particles capable of spontaneous
ignition.
74. High-rise Building - means a building having a height of 24 m. or more above the average
surrounding ground level. Excluding chimneys, cooling towers, boiler, rooms / lift machine rooms,
cold storage and other non-working areas in case of industrial buildings, and water tanks, and
architectural features in respect of other buildings.
75. Home Occupation - means customary home occupation other than the conduct of an eating or a
drinking place offering services to the general public, customarily carried out by a member of the
family residing on the premises without employing hired labour, and for which there is no display
to indicate from the exterior of the building that it is being utilised in whole or in part for any
purpose other than a residential or dwelling use, and in connection with which no article or service
is sold or exhibited for sale except that which is produced therein, which shall be non-hazardous
and not affecting the safety of the inhabitants of the building and the neighbourhood, and provided
that no mechanical equipment is used except that as is customarily used for purely domestic or
household purposes and/or employing licensable goods. Home Occupation may also include such
similar occupations as may be specified by the Authority.
76. Layout Open Space / Recreational Open Space - means a statutory common open space kept in
any layout, sub-division or group housing scheme or campus planning exclusive of margins and
approaches.
77. Ledge or Tand - means a shelf like projection, supported in any manner whatsoever, except by
vertical supports within a room.
78. Licensed Engineer / Structural Engineer / Supervisor - means a qualified Engineer / Structural
Engineer / Town Planner / Supervisor licensed by the Authority.
79. Lift - means an appliance designed to transport persons or materials between two or more levels in
vertical or substantially vertical directions, by means of a guided car platform.
80. Lift Lobby - means a space from which people directly enter lift car(s) and in to which people
directly enter upon exiting lift car(s).
81. Lift Machine - means part of the lift equipment comprising the motor (s) and the control gear
there with, reduction gear (if any), brakes and winding drum or sheave, by which the lift car is
raised or lowered.
82. Lift Well - means unobstructed space within an enclosure provided for the vertical movement of
the lift car(s) and any counter weights, including the lift pit and the space for top clearance.
83. Loft - means an intermediate floor between two floors which is constructed for storage purpose
and as defined in these regulations.
84. Mall - means a large enclosed area comprising of shopping, entertainment and eating facilities and
facilities incidental thereto.
85. Side and Rear Marginal Open Space / Marginal Distance - means a minimum distance
required to be left open to sky between the boundary of the building plot and the building line on
respective sides.
86. Masonry - means an assemblage of masonry units properly bound together with mortar.
87. Mezzanine floor - means an intermediate floor between two floors of any story, forming an
integral part of floor below, overhanging or overlooking a floor beneath, not being a loft between
the floor and ceiling of any storey.
88. Means of Access - means the road/ street/ vehicular access way, pathway upto the plot and to the
building within a plot.
89. Multiplex/Multiplex Theatre Complex (MTC) - means a place of public entertainment for the
purpose of exhibition of motion pictures with multiple screens and/or dramas and other social or
cultural programmes as described in Maharashtra Entertainment Duty Act, 1923.
90. Net Plot Area - means area of the plot as defined in these regulations.
91. Non-conforming User - means any lawful use/building existed on the site but which does not
conform to the zoning shown on the Development Plan/Planning Proposal/Regional Plan in force.
92. Noise Barrier - means an exterior structure/part of structure designed to protect inhabitants of
sensitive land use areas from noise pollution.
93. Occupancy or Use Group - means the principal occupancy or use for which a building or a part
of a building is used, or intended to be used. Occupancy shall be deemed to include subsidiary
occupancies which are contingent upon principal occupancy or use. Buildings with mixed
occupancies are those in which, more than one, occupancy is present in different portions of the
building. The occupancy classification shall have the meaning given in this regulation, unless
otherwise spelt out in any plan under the Act.
i) Residential Building means any building in which sleeping accommodation is provided for
normal residential purposes with or without cooking or dining or both facilities. It includes
one or two or multi-family dwellings, lodging or rooming houses, residential hotels, hostels,
dormitories, Dharmashala, apartment houses, flats, service apartments, studio apartments and
private garages incidental thereto;
ii) Educational Building means a building exclusively used for a school or college recognized
by the appropriate Board or University, or any other competent authority involving assembly
for instruction, education or recreation incidental to educational use, and including a building
for such other uses incidental thereto such as library, multi-purpose hall, auditorium or a
research institution. It shall also include quarters for essential staff required to reside on the
premises and a building used as a hostel attached or independent to an educational institution
whether situated on or off its campus and also includes buildings used for day-care purposes
for more than 8 hours per week;
iii) Institutional Building means a building constructed or used for research in education,
health and other activities, for medical or other treatment, hostel for working women/
persons/ students but not for lodging, an auditorium or complex for cultural and allied
activities or for an hospice, care of persons suffering from physical or mental illness,
handicap, disease or infirmity, care of orphans, abandoned women, children and infants,
convalescents, destitute or aged persons and for penal or correctional detention with
restricted liberty of the inmates ordinarily providing sleeping accommodation, and includes
hospitals, sanatoria, custodial and penal institutions such as jails, prisons, mental hospitals,
houses for correctional detention and reformatories;
iv) Assembly Building means any building or part of a building where groups of people
congregate or gather for amusement, recreation or social, religious, patriotic, civil, travel and
similar purposes, e.g. theatres, motion picture houses, drive-in-theatres, multiplexes,
assembly halls, city halls, town halls, auditoria, exhibition halls, museums, mangal-
karyalayas, cultural centres, skating rinks, places of worship, dance theatres, clubs &
gymkhanas, malls, passenger stations and terminals of air, surface and other public
transportation services, recreation piers and stadia;
v) Business Building means any building or part thereof which is used for transaction of
business for the keeping of accounts and records for similar purposes; offices, banks,
professional establishments, I.T. establishments, call centres, offices for private entrepreneurs
etc. shall be classified in this group in so far as principal function of these is transaction of
public business and the keeping of books and records;
vi) Office Building / Premises means the premises whose sole or principal use is to be used as
an office or for office purpose; "office purposes" shall include the purpose of administration,
clerical work, handling money, telephone/telegraph/ computer operations; and ‗clerical work‘
shall include writing, book-keeping, sorting papers, typing, filing, duplicating, drawing of
matter for publication and the editorial preparation of matter for publication and such other
activities;
vii) Mercantile (Commercial) Building means any building or part of a building which is used
as shops, stores, market, malls for display and sale of merchandise, either wholesale or retail,
including office, storage and service facilities incidental to the sale of merchandise and
located in the same building;
viii) Public / Semi - public Building means a building used or intended to be used, either
ordinarily or occasionally by the public such as (a) offices of State or Central Government,
any public sector undertaking or statutory or local Authority or Semi Government
Organization (b) a place for public worship, etc.;
ix) Wholesale Establishment means an establishment, wholly or partly engaged in wholesale
trade, manufacturers‘ wholesale outlets including related storage facilities, A.P.M.C.
establishments, warehouses and establishments engaged in truck transport including truck
transport booking agencies;
x) Industrial Buildings means any building or part of a building or structure, in which products
or materials of all kinds and properties are fabricated, assembled or processed like
assembling plants, laboratories, power plants, smoke houses, refineries, gas plants, mills,
dairies, factories etc.;
xi) Storage Buildings means any building or part of a building used primarily for the storage or
sheltering of goods, wares or merchandise, like warehouses, cold storages, freight depots,
transit sheds, godowns, store houses, public garages, hangars, truck terminals, grain
elevators, barns and stables;
xii) Hazardous Building means any building or part of a building which is used for the storage,
handling, manufacture or processing of radioactive, highly combustible or explosive
materials or products which are liable to burn with extreme rapidity and / or which may
produce poisonous fumes or explosive emanations during storage, handling, manufacturing
or processing, which involve highly corrosive, toxic or noxious alkalis, acids or other liquids
or chemicals producing flames, fumes and explosive mixtures of dust or which result in the
division of matter into fine particles capable of spontaneous ignition;
xiii) Information Technology Building / Establishment (ITE) means an establishment which is
in the business of developing either software or hardware relating to computers or computer
technology as approved by Director of Industries.
(#) xiv) Special Building means - i) any multi-storeyed building which is more than 24 m. in
height measured from ground level, or
ii) buildings for educational, assembly, mercantile, institutional, industrial, storage and
hazardous occupancies having built-up area 500 Sq.m. or more on any floor irrespective of
height of such building , or
iii) Any building with mixed occupancies with any of the aforesaid occupancies in (ii) above
with built-up area 500sq.m.or more on any floor irrespective of height of such building.
(1) Note : Any building for residential or mix occupancy with height upto 24 mtr. but built up area
upto 750 sq. mtr. on any floor and sprinkler system is provided and travel distance is maintained as
per these regulations, shall not be considered as special building, subject to fire NOC.
xv) Yatri Niwas means a building used for accommodation of tourist, traveller etc.
94. Owner - means a person who has legal title to land or building and includes any person for the
time being receiving or entitled to receive, whether on his own account or as agent, trustee,
guardian, manager or receiver for another person or for any religious or charitable purposes the
rents or profits of the property in connection with which it is used;
95. Parapet - means low wall or railing built along the edge of a roof, terraces, balcony, varandah etc.
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
(#)
Clarifications issued vide letter - CR 44/21 dt, 10th June, 2021 & CR 42/21/UD 12, dt. 14th June, 2021.
96. Parking Space - means an enclosed or unenclosed, covered or open area or area provided by
mechanical means sufficient in size to park vehicle. Parking spaces shall be served by a driveway
connecting them with a street or alley and permitting ingress or egress of vehicles.
97. Partition-means an interior non-load-bearing barrier, one storey or part-storey in height.
98. Permit / Permission - means permission or authorization in writing by the Authority to carry out
the work regulated by these regulations.
99. Plinth - means the portion of a structure between the surface of the surrounding ground and
surface of the floor immediately above the ground.
100. Plot / Site - means a parcel or piece of land enclosed by definite boundaries.
101. Pandals / Shamiyanas - means a temporary structure with roof or walls made of canvas, cloth
other like material which is not adopted for permanent or continuous occupancy.
102. Porch - means a covered surface supported on pillars or otherwise, for the purpose of pedestrian
or vehicular approach to an entrance in a building.
103. Podium - means a floor of a building extending beyond building line/s and used for parking,
recreational open space, recreation, fire and building services/ utilities and incidental purposes, as
specified in these regulations.
104. Reconstruction - means a reconstruction in whole or part of a building which has ceased to exist
due to an accidental fire, natural collapse or demolition after having been declared unsafe by the
Authority, or which is likely to be demolished by or under the order of the Authority/ Other
Competent Municipal Officer.
105. Refuge Area - means an unenclosed space in a multi-storied building specifically provided to
serve as fire-proof space to gather easily for evacuation of the occupants.
106. Refuge chute - means a vertical pipe system passing from floor to floor provided with ventilation
and inlet openings for receiving refuge from successive flats and ending at ground floor on top of
the collecting chamber.
107. Road / Street - means any highway, street, lane, pathway, alley, stairway, passageway,
carriageway, footway, square place or bridge, tunnel, underpass, elevated road, whether a
thoroughfare or not, over which the public have a right of passage or access or have passed and had
access uninterruptedly for a specified period, whether existing or proposed in any scheme, and
includes all bunds, channels, ditches, storm-water drains, culverts, sidewalks, traffic islands,
roadside trees, hedges, retaining walls, fences, barriers and railings within the street lines.
108. Road / Street Line - means the line defining the side limit of a road / street.
109. Road width or Width of road/street - means the whole extent of space within the boundaries of
a road when applied to a new road/street, as laid down in the city survey or development plan or
prescribed road lines by any act or law and measured at right angles to the course or intended
course or direction of such road.
110. Room Height - means the vertical distance measured from the finished floor surface to the
finished slab surface of a room. In case of pitched roofs, the room height shall be the average
height between bottom of the eaves and bottom of the ridge from the finished floor surface.
111. Roof Top Photovoltaic (RTPV) System - means any of the two Photovoltaic Systems installed
on the roof of any building, i.e. (i) RTPV System with storage facility using battery, and (ii) Grid
Connected RTPV System.
112. Row Housing - means a row of houses with only front and rear open spaces except end houses
which shall be with side open spaces.
113. Semi Detached Building - means a building detached on three sides with marginal distances as
specified and on the fourth side attached to a building in an adjoining plot.
114. Service Apartment - means premises other than a lodge or hotel, in which furnished rooms or a
suite of rooms are let out on short/long term basis.
115. Service Floor - means a non-habitable floor with a height not more than 1.8m. from floor level to
soffit of beam, generally provided in special buildings, wherever required, wherefrom services like
water supply, sewage disposal system, electricity etc. are co-coordinated/ maintained.
116. Service Road - means a local road on a continuous alignment that normally runs adjacent and
parallel to main roads like National or State Highways and provides access to properties bordering
it.
117. Site corner - means the side at the junctions of and fronting on two or more intersecting streets.
118. Site, Depth of Site - means the mean horizontal distance between the front and rear side
boundaries.
119. Solar Assisted Water Heating (SWH) System - means a device to heat water using solar energy
as heat source.
120. Double Frontage - means a site, having a frontage on two streets other than a corner plot.
121. Site, Interior or Tandem - means a site, access to which is by a passage from a street whether
such passage forms part of the site or not.
122. Smoke Stop Door - means a door for preventing or checking the spread of smoke from one area
to another.
123. Stair Cover/Staircase Room - means a structure with a covering roof over a staircase and its
landing built to enclose only the stair and its landings for the purpose of providing protection from
weather which should not be used for human habitation.
124. Stall - means a small shop, floor area of which does not exceed 5.0 Sq.m.
125. Storage - means a place where goods are stored.
126. Store Room - means a room used as storage space.
127. Storey - means the portion of a building included between the surface of any floor and the surface
of the floor next above it, or if there be no floor above it, then the space between any floor and the
ceiling next above it.
128. Stilts or Stilt Floor - means the portion of a building above ground level consisting of structural
columns supporting the super-structure with at least two sides open and without any enclosures and
used for the purpose of parking vehicles like cars, scooters, cycles, etc. and other services as may
be permitted under these Regulations.
129. Sub-station (Electric) - means a station for transforming or converting electricity for the
transmission or distribution thereof and includes transformers, converters, switchgears, capacitors,
synchronous condensers, structures, cables and other appurtenant equipment and any buildings
used for that purpose and the site thereof.
130. Supported Double Height Terraces - means open terraces, unenclosed on at-least one side with
railing and lying wholly within building line with supports underneath and having minimum height
of two floors.
131. Tenement - means an independent dwelling unit with a kitchen or cooking alcove.
132. Terrace - means an open-to-sky flat roof of a building or part of a building, provided with a
parapet for safety and with or without any cantilevered portion.
133. Theatre - means a place of public entertainment for the purposes of exhibition of motion picture
and/or dramas and other social or cultural programs
134. Travel Distance - means the distance from the remotest point on a floor of a building to a place of
safety, be it a vertical exit, horizontal exit or an outside exit measured along the line of travel.
135. Tower like structure - means a structure in which the height of the tower like portion is at least
twice the width of the broader base.
136. Unsafe Building - means buildings which are structurally unsafe, unsanitary or not provided with
adequate means of ingress or egress which constitute a fire hazard or are otherwise dangerous to
human life or which in relation to existing use constitute a hazard to safety or health or public
welfare, by reason of inadequate maintenance, dilapidation or abandonment.
137. Varandah - means a covered area with at least one side open to the outside with the exception of
1 m. high parapet on the upper floors to be provided on the open side.
138. Water Closet (WC) - means a privy with arrangement for flushing the pan with water. It does not
include a bathroom.
139. Water Course - means a natural channel meant for carrying storm water and includes an artificial
one formed by training or diversion of a natural channel;
i) "Major Water Course" means a river.
ii) "Minor Water Course" means a nallah.
140. Window - means an opening to the outside other than the door which provides all or part of the
required natural light, ventilation or both, to the interior space.
141. Wing of a Building - means a part of a building with independent access, staircase and lift
connected to other parts with common basement/ stilt/ podium/ terrace/ common wall and
connecting passages.
1.4 APPLICABILITY OF REGULATIONS
i) Development and Construction: Except as hereinafter otherwise provided, these
regulations shall apply to all development, redevelopment, erection and/ or re-erection of a
building, change of user etc. as well as to the design, construction or reconstruction, additions
and alterations to a building.
ii) Part Construction: Where the whole or part of a building is demolished or altered or
reconstructed or removed, except where otherwise specifically stipulated, these Regulations
apply only to the extent of the work involved.
iii) Change of Occupancy/ Use: Where the occupancy or the user of a building is changed,
except where otherwise specifically stipulated, these regulations shall apply to all parts of the
building affected by the change.
iv) Reconstruction: The reconstruction in whole or part of a building which has ceased to exist
due to an accidental fire, natural collapse or demolition, having been declared unsafe, or
which is likely to be demolished by or under an order of the Authority and for which the
necessary certificate has been given by the Authority shall be allowed subject to the
provisions in these regulations.
v) Development of sites or/and subdivision or amalgamation of land: Where land is to be
developed, subdivided, or two or more plots are to be amalgamated, or a lay-out is to be
prepared; these Regulations shall apply to the entire area under development, sub-division,
amalgamation and layout. Provided that, where a developed land, an existing lay-out / sub-
division plan is being altered, these Regulations shall apply only to that part which is being
altered.
vi) Revised permission: Any development permission granted earlier may be revised provided
that, third party interest established in pursuance of such permissions, if any, are not
adversely affected. In such case, consent of the adversely affected persons shall be necessary,
if required under RERA. While granting the revised permission, the approved plans and
commencement certificate of the earlier permission with office, shall be stamped as
‗SUPERSEDED‘ by the Authority.
vii) Exclusions: Nothing in these regulations shall require the removal, alteration or
abandonment or prevent the continuance of the lawfully established use or occupancy of an
existing building or its use, unless in the opinion of the Authority, such a building is unsafe
or constitutes a hazard to the safety of adjacent property.
1.5 SAVINGS
Notwithstanding anything contained in these regulations, any development permission granted or
any development proposal for which any action is taken under the erstwhile regulations shall be
valid and continue to be so valid, unless otherwise specified in these regulations.
Provided that, the words 'action taken' in this regulation shall also include the issuance of letter for
payment of Development and other Charges issued after approval of the proposal in principle.
Provided further that if any development permission has been issued before the date of coming into
force of these regulations and if work is not commenced within validity period and such
permission is not renewed (1 )in time i.e. before expiry of validity period of one year, then the said
development permission shall be deemed to have been lapsed. (1) However, there is no bar to
further renew the valid permission from year to year; but such extended period shall in no case
exceed three years.
Provided further that, it shall be permissible for the owner to -
a) Either continues to develop the project as approved under the erstwhile regulations in toto;
and for that limited purpose erstwhile regulation shall remain in force.
(1)In case the commencement certificate is issued and the construction is in progress / part
occupancy issued, and if plans for additional built up area (2) as per erstwhile regulations are
submitted to the Authority (2) either before or after (1) coming into force of these regulations
by consuming / utilising FSI / TDR as per the erstwhile regulations; but could not be
sanctioned due to the pandemic situation arisen out of COVID-19, the same may be
allowed to be permitted as per the erstwhile regulations in toto including the payment of
premium / charges, if the applicant so desires. However, such cases shall be disposed by
the authority before (3) 31st January, 2022; (1)else such applicants will have to submit the
fresh proposal as per these regulations.
(1) Provided further that, if any development proposal (2) as per erstwhile regulations
is (1) submitted before the date of coming into force of these regulations (2) either upto
maximum building potential or part of maximum building potential (1) for which any action
is not taken under the erstwhile regulations, due to the pandemic situation arisen out of
COVID-19, it shall be permissible for the owner to continue the project as per the erstwhile
regulations in toto (2) upto maximum building potential as per erstwhile regulations, if
applicant so desire (1)and for that limited purpose the erstwhile regulations shall remain in
force. However, such cases shall be disposed by the authority before (3)31st January, 2022
(1) else such applicants will have to submit the fresh proposal as per these regulations or
b) Apply for grant of revised permission under the new regulations, if the project is on-going
and the occupation certificate has not been granted fully. In such cases, charges/premium
etc. paid earlier (1) against the FSI sanctioned / exemptions granted in side margins, allowing
Residential/Commercial use on the Industrial Zone as per erstwhile regulations shall be
deemed to have been paid against such earlier sanctioned FSI/ exemptions/allowance of
use. (3) In such cases (1)the charges / premium under these (1) regulations shall be leviable (2)
against the revised permission and the charges / premium paid earlier shall be adjusted
against the revised charges / premium under these regulations. Provided that no refund is
permissible in any case.
(1
) Inserted Vide Order No.CR 236/18 (Part-1), dt. 01st March 2021.
(2)
Inserted Vide Order No CR 236/18 (Part-1), dt. 26st July 2021.
(3)
Inserted Vide Order No.CR 236/18 (Part 1), dt. 02nd December 2021.
c) In case the development is started with due permission before these regulations have come
into force, and if the owner/developer, at his option, thereafter seeks further development of
plot/layout/buildings as per these regulations, then the provision of these regulations shall
apply to the balance development. The development potential of such entire plot shall be
computed as per these regulations from which the sanctioned FSI of buildings/part of
buildings which are proposed to be retained as per approved plan shall be deducted to arrive
at the balance development potential of such plot (1) and ancillary FSI shall be permissible
only on such balance potential. Such balance potential can be distributed on one or more
existing, earlier/newly proposed building/s in a group housing scheme.
(1) In case of approved layouts in group housing scheme with buildings having height
between 15 m. to 24 m., and complying with provisions mentioned in Regulation No.
1.3(93) (xiv), NOC from Chief Fire Officer shall not be necessary, if the applicant is
applying for revised permission under these regulations.
d) The existing marginal distances including front margin may be allowed for higher floor /
floors subject to step margin as per these regulations. (1) In case of a building sanctioned
under the erstwhile regulations as non-special one with a height of 16 m with 3 m. setbacks
and the construction work is in progress, then while revising the plan under these
regulations, for height up to 16 m, the setbacks as per the erstwhile regulations shall be
allowed to be continued and for the height above 16m (instead of 15 m), setback as per H/5
requirement shall be insisted in the form of step-margin.
e) For the on-going buildings for which passages, stairs, lifts, lift rooms etc. are allowed as free
of FSI by charging premium, in such cases these free of FSI items are allowed to that extent
only and for the remaining balance potential, provisions for free of FSI items of these
regulations shall be applicable.
f) For the on-going buildings for which balconies are allowed to be enclosed as free of FSI by
charging premium, these free of FSI items are allowed to that extent only and for the
remaining balance potential balcony shall only be allowed as mentioned in these
regulations.
g) For the cases where occupation certificate is fully granted, revised permission as per these
regulations, may be granted subject to provisions of Real Estate (Regulations and
Development) Act, 2016, as may be applicable.
(1)Provisions mentioned in (b) to (f) shall be applicable mutatis-mutandis to the proposals to
be sanctioned under this provision.
h) If the project proponent applies for occupation with minor amendments in plans approved
prior to this UDCPR, then amendment (1) permitted as per the erstwhile regulations in terms
of internal / locational changes, amendment to the extent of 5% in the built-up area /
dimensions per floor within the permissible FSI as per then regulations may be considered.
(1)Note - The State Government may issue guidelines from time to time, if necessary, for
smooth implementation and removal of difficulties in transitional proposals.
1.5 (i) Megacity Project approved under regulation no.15.4.3 of Mumbai Metropolitan Regional Plan
shall remain valid till completion of the said project as per said regulation.
(1
) Inserted Vide Order No.CR 236/18 (Part-1), dt. 01st March 2021.
(2)
Inserted Vide Order No.CR 236/18 (Part 1), dt. 02nd December 2021.
1.6 APPLICABILITY OF OTHER REGULATIONS
i) CRZ Regulations - Any development within CRZ areas shall be governed by the Coastal
Regulation Zone Notification No. S.O.19(E) dt. 6th January, 2011and No. G.S.R. 37(E),
dated 18th January, 2019 as amended or replaced from time to time, wherever applicable.
ii) Restriction in Western Ghat Eco Sensitive Area - The restrictions in the Western Ghat Eco
Sensitive Area imposed by the notification issued from time to time by Ministry of
Environment, Forest and Climate Change, Government of India, shall be followed.
ii) Other Regulations - Any other Restrictions imposed under the relevant regulations/ Rules /
Acts shall also be applicable, wherever applicable.
1.7 POWER TO PRESCRIBE THE PROFORMAS
(1) Notwithstanding anything contained in any Appendices / Proformas, provision in respective
regulations shall prevail. The Authority, with the approval of Government, shall have the powers
to prescribe proformas / appendices and/ or make amendments in the contents of such proformas /
appendices A to M attached with these regulations.
1.8 POWER TO DECIDE CHARGES
The charges mentioned in these regulations for additional FSI, premium FSI, rate of interest or for
any other matter shall be subject to amendment by the Government from time to time. Wherever
the rate of premium is to be decided based on rates mentioned in ASR, rate in the ASR shall be of
the year of granting the permission.
1.9 MEANINGS AS IN ACTS, RULES & INTERPRETATIONS
i) Terms and expressions not defined in these regulations shall have the same meaning or sense
as in the Maharashtra Regional and Town Planning Act, 1966 (Maharashtra Act No. XXXVII
of 1966) or the Maharashtra Municipal Corporations Act, 1949 or National Building
Code2005 as amended from time to time and the rules or bye-laws framed there under, as the
case may be, unless the context otherwise requires.
ii) The Maharashtra General Clauses Act, as amended from time to time shall be applicable in
case of standard terms and phrases as defined and interpreted therein,
iii) In these regulations, the use of the present tense includes the future tense, the masculine
gender includes the feminine and neutral genders, the singular includes the plural and plural
includes singular. The word "person" includes a corporation as well as an individual;
"writing" includes printing, typing, e-communication and "signature" includes e-signature,
digital signature and thumb impression of a person unable to sign, provided that his name is
written below such impression.
iv) Whenever sizes and dimensions of rooms and spaces within buildings are specified, they
shall mean clear dimensions unless otherwise specified in these regulations. However, sizes
and dimensions may not be disputed with reference to finished/unfinished surfaces unless
they affect overall dimensions of the building.
v) If any question or dispute arises with regard to interpretation of any of these regulations the
matter shall be referred to the State Government, who, after considering the matter and, if
necessary, after giving hearing to the parties, shall give a decision on the interpretation of the
provisions of these regulations. The decision of the Government on the interpretation of these
regulations shall be final and binding on the concerned party or parties.
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
vi) In the case of provisions of other Acts/ Rules/ Regulations which are incorporated in these
regulations, the amendments made subsequently in parent Acts/Rules/Regulations, will
automatically be applicable, wherever applicable, to these regulations.
vii) If a Marathi version of these Regulations exists and if there is a conflict in interpretation of
any clause between English & Marathi versions of these Regulations, then the interpretation
of English version shall prevail.
1.10 REMOVAL OF DIFFICULTIES.
If any difficulty arises in giving effect to the provisions of this Unified Development Control and
Promotion Regulations, the State Government may, by order published in the official Gazette, give
such directions, as may appear to it to be necessary or expedient for the purpose of removing the
difficulty.
Provided that, no such order shall be made after the expiry of a period of 1 years from the date of
coming in to force of this Unified Development Control and Promotion Regulations.
-*-*-*-*-*-