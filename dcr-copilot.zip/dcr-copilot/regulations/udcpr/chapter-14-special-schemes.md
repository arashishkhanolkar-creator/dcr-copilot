# Chapter 14: Special Schemes

CHAPTER - 14
SPECIAL SCHEMES
14.1 INTEGRATED TOWNSHIP PROJECT (ITP)
14.1.1 For Regional Plan Area
14.1.1.1 Applicability:-
These regulations shall be applicable to the areas under Regional Plan sanctioned under the
provisions of Maharashtra Regional and Town Planning Act, 1966 (hereinafter referred to as
"the said Act").
Provided that, if the Development Control Regulations regarding development of Integrated
Township Project for an area over which a Planning Authority/Special Planning
Authority/Area Development Authority has been appointed or constituted or deemed to have
been appointed are yet to be sanctioned, then in considering the application for permission,
these regulations, shall be applicable, mutatis mutandis, till such Authority adopts the
Regulations in this regard.
If the ITP falls within the jurisdiction of more than one authority then in such cases
Government can issue directives at the time of Locational Clearance or at any time regarding
as to which authority shall give permission and supervise the project subject to terms and
conditions as may be specified.
14.1.1.2 Requirements of Site:-
The area proposed for Integrated Township shall fulfil the following requirements:-
i) Any suitable area having area of 40 hect. (100 Acres) or more at one place.
ii) The area shall be one, contiguous, unbroken and uninterrupted. Provided that, such area
if divided by one or more water courses (such as nallah, canals, etc.), existing or
proposed roads of any width or by railways, pipeline etc., shall be treated as one,
contiguous, unbroken and uninterrupted, subject to condition that the Project
Proponent/s shall construct necessary connecting roads or bridges as per site
requirements at his own cost with due permission from concerned authorities.
Integrated Township area may also include;
a) Lands in afforestation zone provided that such land is not a forest land and
subject to no construction being allowed on land having slope more than 1:5.
b) Lands within the buffer zone of National Park subject to restriction on
development permissible in such buffer zone and subject to NOC of Forest
Department.
c) Tribal land subject to permission granted under MLR code, Government lands
allotted to project proponent subject to Regulation No. 14.1.1.13 (ii).
d) Private forest land that have been restored back after completion of section 22(a)
Enquiry of Maharashtra Private Forest Act, 1975 shall be allowed to be part of
the ITP with the condition that development permission shall be granted on such
land only after necessary permission under the provision of Forest Conservation
Act,1980.
e) Buffer zone of Eco-sensitive Zone notified subject to all restriction on
development and FSI permissible in such buffer zone.
f) Areas under flood line/ flood zone subject to clearance from Water Resource
Department.
g) Areas under Hill Top/ Hill Slope Zone, and (b), (e), (f) mentioned above as
shown on Regional Plan/Development Plan subject to condition as mentioned in
Regulation No. 14.1.1.7 (i) (c) However total of these areas shall be restricted to
maximum 40% of total area under ITP.
iii) If the Integrated Township area is more than 200 Ha., it can be segregated as long as
each parcel is more than 40 Ha. and is located within a radius of 5 kms. Provided that
the land use mix is maintained in each parcel.
iv) The area shall have an access by means of an existing, or proposed road having
minimum width of 18 m. In case of proposed road, such area shall have an access by
existing road having width 12 m. for the purpose of declaration locational clearance
and LoI of such project but it is necessary for the project proponent to have an existing
access of 18 m. before sanction of Commencement Certificate to the FSI beyond 25%
of project. Provided that Government land or land belonging to tribal can be considered
for the purpose of road if there is a registered Agreement. However development
permission shall be granted only after due permission of appropriate authority is given.
v) The ITP Area shall not include the area under:-
a) Notified forest, (excluding the private forest land subject to NOCs of forest
Department.)
b) Water bodies like river, creek, canal, reservoir, etc. Mangroves, Tidal Zone, Mud
Flats
c) The area under Notified National Parks.
d) Defence Estates
e) Cantonment Boards
f) Any restricted area.
g) Quarry Zone, Notified SEZ, designated port/harbour areas, wildlife corridor and
biosphere reserves, Gaothan/Congested Area.
h) The historical and archaeological places notified under the relevant act.
i) Any other area that may be declared by the Govt. of Maharashtra from time to
time.
14.1.1.3 Ownership of Lands:-
The project proponent/s shall have the ownership of all the land parcels under project.
(Explanation - for this clause, ownership includes rights accrued vide one or more registered
Development Agreement/s or Power of Attorney (PoA) for such development and disposal,
on behalf of land owner/owners).
14.1.1.4 Permission and Declaration of Project by State Government
i) The Project Proponent/s shall apply to the State Government for obtaining permission
and declaration of such project to be a "Integrated Township Project". Such application
shall be accompanied by the following attested documents in two sets:-
a) Details of ownership of land viz. extracts of V.F.No. 7/12 or Property Register
Cards, in original having date not more than six months prior to the date of
submission. In case of rights accrued through registered Development
Agreement or PoA, attested copies of such documents.
b) Self-attested list of S.No./G.No./CTS showing name of owner as per record of
rights, total area of such land parcel, area owned by the applicant in such land
parcel, the name of person/ company owning the Development Rights, area
proposed to be included in project from such land parcel.
c) Part plan of sanctioned Regional Plan, showing all the lands falling in the
project.
d) No Objection Certificate from the officer at Divisional level, Water Resources
Department in respect of lands falling in "Command Area" of any Irrigation
Project unless these powers are exercisable by the higher authority.
e) Village maps showing the lands falling in the project.
f) Certificate from concerned Forest Officer not below the rank of Dy. Conservator
of Forests at Divisional level (unless these powers are exercisable by higher
authority), showing that the lands under project do not form part of and not
included in reserved forest or protected forest or non-classified forest or not
acquired under the provisions of the Maharashtra Private Forest (Acquisition)
Act, 1975 and also, confirming that such lands do not form part of the Notified
National Parks, prohibited area of Notified Wildlife Sanctuaries and Notified
Bird Sanctuaries.
g) Certificate from the concerned revenue officer not below the rank of Tahasildar,
showing the lands under project do not include lands belonging to tribal or that
tribal land included in ITP have necessary permission under MLR code.
h) Certificate from the Director of Archaeological Department, Maharashtra State,
showing that the lands under project do not include monuments notified by the
Archaeological Department, Heritage buildings and Precincts. Such certificate
should also mention the distance to be kept around such places, if any.
i) Receipt of processing fee (non-refundable) paid, at the concerned branch office
of the Town Planning Department, at the rate of Rs.5000/- per ha. for the current
year with the yearly rise of Rs.500/- per ha. starting from the month of January
every year.
ii) On receipt of an application under Clause (i) above, the Government may, after
consulting the Director of Town Planning, Maharashtra State, by notification in the
Official Gazette, grant the Locational Clearance and declare such project to be a
"Integrated Township Project", subject to such general and/or special conditions or,
reject the application, under the provisions of Section 18(3) of the said Act, within a
period of 90 days from the date of receipt of application or reply from the Project
Proponent/s in respect of any requisition made by the Government, whichever is later.
If the project proponent fails to comply with the conditions specified while granting
location clearance within the specified time limit, then in such cases location clearance
given earlier stands automatically cancelled and no refund or adjustment of premium/
fees/ expenses etc. shall be eligible.
(Explanation - In circumstances described in Clause (ii) above, such grant of
permission and declaration of project shall be made under the provisions of Section
18(3) of the Maharashtra Regional and Town Planning Act, 1966 )
iii) Every such permission and declaration shall remain in force for a period of two years, if
not applied for Letter of Intent under Regulation No. 14.1.1.5, from the date of issue of
Locational Clearance Notification and thereafter it shall lapse.
Provided that, the Director of Town Planning, Maharashtra State, Pune may, on
application made by Project Proponent/s before expiry of the above period extend such
period by two years in aggregate. Provided also that, it is not mandatory on Project
Proponent/s to submit all the papers afresh as prescribed under Clause (i) above,
however the affidavit regarding the ownership of land about any dispute shall be
mandatory.
iv) Such lapse shall not bar any subsequent application for fresh proposal.
v) The Director of Town Planning, Maharashtra State, on the request of Project
Proponent/s, by notification in the Official Gazette, may grant to add or delete any area,
not exceeding 50%of the total area under Locational Clearance, subject to condition
that the remaining area shall not be less than 40 Hect. The permissible FSI and other
parameters shall increase or decrease accordingly.
14.1.1.5 Letter of Intent (LOI) by the Collector
i) The Project Proponent/s shall apply to the Collector for obtaining the Letter of Intent for
such project. Such application shall be accompanied by the ownership documents as
prescribed in Regulation No. 14.1.1.4 (i)(a) & (i) (b) and with locational clearance
notification issued by the Government.
ii) The Collector shall verify and satisfy himself that Ownership and Development Rights
of all the lands under project are with the Project Proponent/s before issuing the Letter
of Intent.
iii) On receipt of an application under Clause (i) above, the Collector shall grant the Letter
of Intent for the whole area or separately for any part thereof, which shall not be less
than 40 Ha. at the first instance, subject to conditions as may be deem fit, or reject the
application, within a period of 45 days from the date of receipt of application or reply
from the Project Proponent/s in respect of any requisition made by the Collector,
whichever is later.
Provided that, in case of rejection, the Collector shall mention the grounds for such
refusal.
iv) Every such Letter of Intent shall remain in force for a period of two year, if not applied
for Development Permission under Regulation No 14.1.1.6, from the date of issue of
Letter of Intent, unless renewed. Provided that, the Collector may, on application made
by Project Proponent/s before expiry of the above period extend such period by two
years in aggregate. Provided also that letter of intent granted by collector under earlier
regulations may also be extended subject to other conditions of these regulations.
14.1.1.6 Master Layout Plan Approval by the Collector:-
i) The project proponent/s shall apply to the concerned Collector for obtaining the
approval to the Master Layout Plan of the entire area as per Letter of Intent. Such
application shall be accompanied by the documents in two sets as prescribed below:-
a) Attested copy of Gazette Notification issued by the Government under Regulation
No. 14.1.1.4(ii).
b) Attested copy of Letter of Intent issued by Collector under Regulation
No.14.1.1.5.
c) Part plan of sanctioned Regional Plan showing the lands under the Master Layout
Plan.
d) Village Map showing the lands under the Master Layout Plan.
e) In case, project has no access from existing road having right of way of 18 m. then
documents showing the ownership of Project Proponent/s in lands proposed for
18m. wide access road.
f) Bank Guarantee of requisite amount as prescribed in Regulation No.14.1.1.12 (vi)
g) Undertaking and Affidavit as may be prescribed by the Collector.
h) Copies of Master Layout Plan with or without Building Plans in three sets
prepared and signed by expert in respective field and team headed by an Architect
or Town Planner registered with Institute of Town Planners India (ITPI)with sign
of owner/developer.
i) Contour map showing contour levels of lands under Master Layout Plan. Trueness
of the contour shall be certified and attested by the surveying agency and the
Project Proponent/s under their signature and seal.
j) Colored Google earth image/ Bhuvan image/ Drone survey image etc. showing
lands under Master Layout Plan.
k) Phased Program for development of physical infrastructure with amenities under
project, along with the project cost details.
ii) If the application is not accompanied by the documents mentioned in Regulation
No.14.1.1.6(i) above, the Collector convey the same to the Project Proponent/s
immediately within 10 working days giving specific time period for fulfilment of such
documents and if the same are not submitted by the said project proponent in given
time then return the proposal at his level only.
iii) On receipt of application, complete in all respects, as prescribed under Regulation No.
14.1.1.6(i) above, the Collector shall forward the same to the concerned Divisional
Joint Director of Town Planning for technical consultation within 10 working days.
iv) The office of the Divisional Joint Director of Town Planning shall send its remarks to
Collector within two months from the receipt of proposal from the Collector or receipt
of reply from the Project Proponent/s in respect of any requisition made by him,
whichever is later. Such master layout approval will be given with the condition that
project proponent will not commence work without environmental clearance. Such
environmental clearance shall be submitted at the time of sanction to the building
permission. Sanctioned master Plan layout along with complete set of drawings shall
be endorsed to the concerned branch office of Town Planning Department, for the
further permissions.
v) Approval to the Master Plan:- The Collector shall grant approval to the master layout or
reject the application, under Section 18 of the said Act, within one month from the
receipt of reply from the Divisional Joint Director of Town Planning as mentioned in
Regulation No. 14.1.1.6 (iv) above.
vi) Approval to the building plan:- Detailed building permission under the master layout
plan sanctioned as per Regulation No. 14.1.1.6(v) shall be granted by the Assistant
Director of Town Planning/Town Planner of concerned Branch within 30 days from the
receipt of the proposal from the project proponent as mentioned in (a) below.
a) The Project Proponent/s shall apply to the concerned head of the Branch office
of the Town Planning Department, for grant of building permission, alongwith
all relevant documents and attested copy of Environment Clearance for the
project from MoEF or the Authority empowered by the MoEF.
b) The Project Proponent/s shall submit the certificate of Architect regarding
completion of plinth stating that the construction of plinth is as per the approved
building Plans to the concerned branch office of the Town Planning along with
approved Plan. The Branch Office of the Town Planning verify the same within
stipulated time period. If it is found that the construction of plinth is not as per
the building permission sanctioned, the said office shall reject such plinth
checking certificate. In such circumstances, the Project Proponent/s shall either
demolish the said plinth or get the revised plan sanction according to changes. If
it is found that the construction of plinth is as per the building permission
sanctioned, then granting the plinth checking certificate is not necessary.
14.1.1.7 Planning Considerations
i) Permissibility in respect of Zoning:-
a) Notwithstanding anything contained in any regulation for the time being in force,
the project to be notified under this regulation may be permissible in any land-
use zone/s of sanctioned Regional Plan/ Development Plan, excepting areas
mentioned in Regulation No. 14.1.1.2(v).
b) For the areas falling in zones, other than residential, commercial and U1 & U2
zone as per the sanctioned Regional Plan the Project Proponent/s shall have to
pay a premium for permitting project in such zones at the rates prescribed below
in Table No. 14 A :-
Table No. 14 A
Sr. No. Type of Zone Premium Charges
1 Afforestation Zone, Hill Top & Hill Slope Zone as shown 15 %
on Regional Plan / Development Plan.
2 Public / Semi-public Zone, Industrial Zone, TH & LP 8 %
3 Agriculture/ No Development Zone/G1 zone / Low 10 %
Density Residential Zone / Buffer Zone of ESZ and other
zones excepting at Sr. No. a & b above.
Explanation: Premium charges shall be calculated by considering the agriculture land
rate of the said land as prescribed in Annual Statement of Rates (ASR) without
applying the guidelines. If agriculture land rate is not mentioned in ASR, in such cases
the Agricultural land rate for such land will be decided by referring the matter to the
Inspector General of Registration. Thereafter the premium will be calculated by
considering the land rate given by IGR in such cases. Out of total premium10% shall
be paid at the time of Locational Clearance, 10%paid at the time of letter of Intent, 20
%at the time of sanctioning of Master Layout Plan and remaining 60%shall be in four
equal instalments per year and subject to interest as per Prime Lending Rate. (PLR)
c) Restriction on development-No construction shall be permitted on the lands
within the HFL (Blue line),land in Hill Top & Hill Slope Zone and on lands
having slope equal to or more than 1:5 in the said Project, whether specifically
marked as such on the Regional Plan/ Development Plan or not. No development
of any sort and activity involving cutting/ levelling/ filling shall be permissible
on such sloping lands. Provided that, it shall be permissible to use such lands for
Plantation, Park, Garden purposes, access road to township development with
minimum cutting and other users as otherwise permissible in respective Regional
Plan/ Development Plans and the FSI of such lands shall be permissible to the
extent as prescribed in Regulation No. 14.1.1.7(ii).
d) In the Buffer zone of notified ESZ and in ESZ‘s, only those development
activities and FSI as permissible under MoEF notification of the ESZ (as
amended from time to time) under Environment Protection Act, 1986 shall be
permitted. All the development in this buffer zones shall be in accordance with
MoEF notifications.
ii) Permissible Floor Space Index (FSI):-
a) Notwithstanding anything contained in any regulation for the time being in force,
if premium as mentioned in 14.1.1.7 (i) (b) is paid by the project proponent then
the basic permissible FSI for such project shall be 1.0 to be calculated on Gross
Plot Area under Master Layout Plan without deducting any areas under the
slopes within HFL, etc.
b) Further, additional FSI on payment of premium as mentioned below Table No. 14
B shall be permissible on payment of premium at the rate of 10% of the
weighted average land rate of the said land as prescribed in Annual Statement of
Rates for the relevant year, without applying the guidelines therein. Such
premium shall be paid at the time of Building permission.
Table No. 14 B
Area under Township Additional built-up area on
payment of premium
40 hect. and upto 200 Hector. Up to 70 % of basic permissible FSI
More than 200 hect. and upto 500 Up to 80 % of basic permissible FSI
Hector
More than 500 hect. Hector Up to 100 % of basic permissible FSI
c) Over and above the FSI as prescribed above, an additional FSI in lieu of
construction of tenements for social housing shall be permissible as prescribed in
Regulation No.14.1.1.9, without charging premium.
d) It shall be permissible to utilise the maximum permissible built-up area as
prescribed above, anywhere in the area under sanctioned Master Layout Plan.
iii) Mandatory Town-Level Amenities - Area and FSI Allocations:-
Master Layout Plan shall provide for town-level area and FSI allocation, to be kept at
one or more places, as follows :-
a) Spaces for Recreation
Table No. 14 C
Sr. Particulars Minimum Area Conditions
No. Required
i Garden/s and 5% of Master Layout Out of this at least 1000 Sq.m. area
Park/s Area.(out of this 50% area shall be kept open for Town
may be allowed on Hill Plaza/Town Square, at one place and
Top Hill Slope Zone, remaining area shall be kept open
Buffer Zone of ESZ and and may be allowed to be proposed
within HFL) at suitable places. Major public
amenities / activities shall be cluster
around this area.
ii Play 7.5% of Master Layout Maximum 10% of area under Play
Ground/s Area (may be allowed in Ground which may accommodate
Buffer Zone of ESZ indoor games, stadiums and allied
having slope less than 1: users only.
5)
Note - These spaces shall be exclusive of open spaces to be required at sector-level layouts.
Notwithstanding anything contained (1)UDCPR, 10% open space shall be provided in sector
level layout. Such open space shall be calculated by considering area of the sector excluding
roads in Master Layout Plan and Town Level Amenity spaces excepting Economic
Activities.)
b) Spaces for combined School/s (Primary School/s + High School/s) -
Table No. 14 D
Sr. Particulars Minimum Minimum Built-up
No. Area Required Area required
i For Master Layout area of 40 Ha. 5,000 Sq.m. 5,000 Sq.m.
ii For Master Layout area more than To be increased proportionately with
40 Ha. increase in Master Layout area and be
proposed at one or more locations, as per
requirements.
Note-
1) The requirements prescribed above are by considering School to be run in double shift,
2) Requirement of plot area and built up area shall be exclusive of Play Ground spaces.
Hence it is mandatory to show separate Play Ground adjoining to school building at the
rate of 7 Sq.m./ student.
c) Community Health Care Facilities:- Primary and Secondary Health Care
Facilities like Dispensary, Maternity Home, Hospital etc.
(1)
Substituted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
Table No. 14 E
Sr. Particulars Minimum Area Minimum Built-up
No. Required Area required
i For Master Layout area of 40 Ha. 1,000 sq. m. 1500 sq. m.
ii For Master Layout area more than To be increased proportionately with
40 Ha. increase in Master Layout area and be
proposed at one or more locations, as per
requirements.
d) Community Market:-
Table No. 14 F
Sr. Particulars Minimum Area Minimum Built-up
No. Required Area required
i General Market including Mutton and Fish Market
For Master Layout area upto & 1000 Sq.m. As per requirement
inclusive of 200 Ha.
For Master Layout area more than To be increased proportionately with
200 Ha. increase in Master Layout area and be
proposed at one or more locations, as per
requirements.
ii Vegetable Market
For Master Layout area upto & 1000 Sq.m. As per requirement
inclusive of 200 Ha.
For Master Layout area more than To be increased proportionately with
200 Ha. increase in Master Layout area and be
proposed at one or more locations, as per
requirements.
Note - Users mentioned in (i) & (ii) above may be clubbed together for convenience purpose,
without altering the requirements in plot area and built-up area.
e) Public Assembly Facilities:-Town Hall and/or Auditorium including Library
Table No. 14 G
Sr. Particulars Minimum Area Minimum Built-up
No. Required Area required
i For Master Layout area up to & 5000 Sq.m. 5000 Sq.m.
inclusive of 100 Ha
ii For Master Layout area more than 10000 Sq.m. 10000 Sq.m.
100 Ha. and upto 200 Ha.
iii For Master Layout area more than To be increased proportionately with increase
200 Ha. in Master Layout area and be proposed at one
or more locations, as per requirements.
f) Economic Activities :- Economic activities including users such as Market,
Multiplex, Mall, Information Technology & Information Technology enabled
Services (IT & ITES) including SEZs, Essential Shopping, Recreational Centres,
Trade & Commerce, Education, Hospitals, Non-polluting Industries, Service
Industries, Entertainment, Tourism, Star Category Hotels, Convention Centres,
Gymnasiums, Socio-economic activities, such as workshop, hostel for Autistic
persons,challenged persons and Senior Citizens except independent residential
tenements as per requirements.
Table No. 14 H
Sr. Particulars Minimum Minimum Built-up
No. Area Required Area required
i For Master Layout area of 40 Ha. 40000 Sq.m. 80000 Sq.m.
ii For Master Layout area more than To be increased proportionately with
40 Ha. increase in Master Layout area and be
proposed at one or more locations, as per
requirements.
Note :-
1) Users as mentioned in b, c, d, e & f may be clubbed together, in Economic Activities
Component, subject to condition that, total built-up area should not be less than the
summation of minimum required for all such users, irrespective of their individual plot
area requirements.
2) The required parking spaces for all such amenities as per norms shall be provided in
same plot.
g) Public Utilities:- For Master Layout area up to & inclusive of 200 Ha.
Table No. 14 I
Sr. Particulars Minimum Area Permissible Built-up
No. Required Area
i Fire Brigade Station 3000 Sq.m. or as As per recommendations
prescribed by the of the Director of Fire
Director of Fire Services, Maharashtra
Services, Maharashtra State/Chief fire Officer of
State/ Chief fire the concern Authority.
Officer of the concern
Authority.
ii Sewage Waste 4000 Sq.m. As per requirements
Management
Project(SWMP)
iii Cremation Ground 2000 Sq.m. As per requirements
iv Burial Ground 2000 Sq.m. As per requirements
v Bus Station / Transport 3000 Sq.m.
Hub
vi Police Station 1000 Sq.m.
vii Electric Sub-station As per requirement
viii Other Public Utilities As per requirement
ix Public Parking Facilities As per prevailing
DCR
x Solid waste management As per requirement
Note:
1) If the facility of Cremation Ground/ Burial Ground is available in the village where the
Township is located in such case these requirements need not be insisted subject to
NOCs of respective Gram Panchayat.
2) If Police Station is available within 1km. area from the proposed Township, then such
facility need not to be provided.
h) Transport & Communication:-
i) The entire area of the project shall have a proper road pattern, taking into
consideration the linkages with existing roads within the project and
outside area as well. All such roads shall be developed by the Project
Proponent/s as per standard prescribed by the Indian Road Congress.
ii) The width of the -
a) Classified Road should not be less than as may be prescribed by
concerned public authority;
b) Main/Arterial/Ring Road should be of minimum right of way of 18m.
c) Other Sub-Arterial roads, Collector streets, local streets, etc., shall be
proposed as per the requirements to cater to the need of occupancies
on such roads including for pedestrians.
d) Network of cycle track in entire Township area of minimum width of
3 meter shall be provided without clashing with the vehicular traffic,
to the extent possible.
iii) It may be permissible for Project Proponent/s, to realign the Regional Plan
/ Development Plan Roads, and earlier existing roads passing through the
project area, without changing the entry and exit points of such roads.
iv) All the Regional Plan / Development Plan Roads and all the Main/
Arterial / Ring Roads, shall always be open for general public, irrespective
of the fact that, they resides in the project or not.
General Note for Amenities (a) to (h):
1) The requirements prescribed above for items (a) to (f) are by considering FSI proposed
for the project is only 1.0. If the FSI proposed is increased or decreased then the only
built up area requirement shall be increased or decreased proportionately.
2) The requirements prescribed above for items (g) are for Master Layout area up to &
inclusive of 200 Ha. It shall be increased or decreased proportionately and may be
proposed at one or more locations, as per requirements.
iv) Residential Activities:-
Table No. 14 J
Sr. No. Particulars Area Built-up Area
i Residential Activities The land excluding Remaining built-up
(including lands required for the land required for area subject to
social housing, infrastructure purposes as shown minimum 60% of the
such as water storage, drainage (iii) (a) to (h). total proposed Basic
and garbage disposal, etc.) Residential FSI.
14.1.1.8 Development Control Regulations:-
For those aspects which are not covered under this regulation, the prevailing provisions as
prescribed in the (1)Unified Development Control and Promotion Regulations for Regional
Plan in Maharashtra shall apply mutatis-mutandis. The provisions of MoEF CRZ
notifications amended from time to time shall also be applicable.
However where in prevailing DCR of the respective authority the maximum height of
building is not mentioned in such cases the maximum height shall be allowed subject to
provisions of Maharashtra Fire Prevention and Life safety measures Act 2006 and any
restriction imposed by Chief Fire Officer.
14.1.1.9 Social Housing:-
i) The Master Layout Plan shall provide sufficient space for construction of small
tenements for persons from EWS and LIG categories (hereinafter referred to as the
"Social Housing Component"), as a social responsibility with FSI as mention in
Regulation No. 14.1.1.9 (iii). Out of this Social Housing Component 25% FSI shall be
utilised exclusively for construction of EWS tenements and remaining 75% FSI may be
used for LIG tenements. Out of the total tenements constructed as Social Housing
component, one third (1/3rd) tenements shall be kept for Rental Housing tenements
which will be disposed on Rent only by the project Proponents.
ii) Social Housing tenements shall be constructed with area as specified by the MHADA
for EWS and LIG category respectively.
iii) The minimum Social Housing component shall be constructed at 15% of the
Residential basic FSI of the area available for Residential Development as prescribed
in Regulation No. 14.1.1.7 (iv) (hereinafter referred to as the "Social Housing
component").
iv) Social Housing tenements shall be constructed as per the general and special
specifications prescribed by concerned unit of MHADA for their projects.
v) The Project Proponent/s, after getting commencement certificate of Social Housing
component as mentioned above shall immediately intimate to MHADA regarding the
numbers of Social Housing Component to be disposed by them to the allottees. Upon
such intimation, MHADA within a period of six months, from the date of receipt of
such intimation after following procedure of lottery system shall prepare the list of the
allottees from the district as far as possible and forward it to the Project Proponent/s.
The project proponent shall dispose of such housing tenements to the allottees at the
construction cost mentioned in ASR applicable of the year of disposal (date of
occupancy certificate) plus 25% additional cost. Out of this 25% additional cost, 1%
shall be paid to MHADA towards administration charges.
(1)
Substituted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
If the allottees fails to deposit the amount within specified time limit, then the
allotment shall stand cancelled and MHADA can give fresh names of allottees from
waiting list within one month.
Provided that if the MHADA is unable to provide the list of the allottees as mentioned
above then the project proponent shall dispose of such social housing tenements in the
market at the construction cost in ASR applicable to the land of the year of disposal
plus 20% additional cost.
vi) Every Occupation Certificate for the regular tenements shall be granted only alongwith
the Occupation Certificate in proportionate with Social Housing component.
vii) Amalgamation of such Social Housing tenements shall not be permitted in any case.
viii) The purchaser of tenement under social housing shall deposit an amount equivalent to
10% of the construction cost of tenement, as prescribed in Annual Statement of Rates
prevailing at the time of occupation, with the Project Proponent/s as one-time
maintenance deposit for onsite infrastructure maintenance.
ix) The Project Proponent/s shall maintain the premises and common spaces outside the
building/s of social housing including concerned all basic infrastructure and amenities,
in good condition in the same manner with the maintenance of remaining area of the
project.
x) The purchaser of tenement under social housing shall have to pay all the government
taxes, duties like stamp duty, GST etc. and also the fees charged for use of common
amenities at actual, to the Project Proponent/s, as per the requirement, from time to
time.
14.1.1.10 Liability of Project Proponent/s:-
i) The entire project shall be an integrated one with all facilities within the boundaries of
such project. All the on-site infrastructure i.e. internal roads, approach road, street
lights, water supply and drainage system shall be mandatory and constructed/
maintained in future by the Project Proponent/s. Proposed internal roads and Open
Spaces in the layouts shall be used only for ITP.
ii) The Regional Plan Roads & Reservations which are included in ITP shall be Developed
by project proponent and after development made available to the general public. Such
reservations may be allowed to shift within 500 m. (within Township Area Only) in
consultation with the concerned Divisional Joint Director of Town Planning.
iii) It shall be the responsibility of the Project Proponent/s to develop and maintain all the
infrastructure in good condition till handing over to the appropriate authority.
The project proponent may collect periodical contribution or raise corpus funds for the
maintenance of infrastructure from the purchasers of tenements or statutory bodies of
the purchasers of tenements formed by the developer for this purpose.
Provided that, the Project Proponent/s shall handover the infrastructure, for
maintenance purpose, only after the completion of the project, to the Urban Local Body
or appropriate authority, when constituted in the area comprised by the project along
with the unutilized corpus fund collected for maintenance of common infrastructure.
iv) Project Proponent/s shall mandatorily provide facilities for making the Township
SMART-
a) For the people residing in the project area, an efficient and timely public
transportation system up to the nearest public transportation
station/hub/depot/stand. He shall develop it himself or tie with Government /
Semi Government or private transport agency for such efficient public
transportation. The number of buses and trips will be decided by MSRTC / Local
Transport Authority.
b) Continuous unobstructed footpath of minimum 2 m. width on either sides of all
street / roads of width ROW 12 m. or more and of a lesser width for roads / Streets
of ROW less than 12 m.
c) Dedicated and physically segregated bicycle track with a width of 3 m. or more,
should be provided for entire Township Area.
d) Pedestrian friendly pathways, encouragement to non-motorized transport,
intelligent traffic management, non-vehicle street / zones, smart parking, energy
efficient street lighting visible improvement in the area i.e. replacing existing
overhead electric wiring with underground wiring, encroachment free public areas,
e) Arranging generation of power through non-conventional energy sources like
solar, wind and other shall be mandatorily provided with at least 10% of total
requirement of common physical infrastructure of the project;
f) To provide energy management by adopting advanced technology like installing
Solar Water Heating System, Solar Lamps/Lights in common areas, LED Lamps,
auto-operated street lights, solar pumps, etc. all external lighting shall be of LED,
Solar Water Heating System, Solar Lamp shall be compulsorily provided;
g) To provide effective water management by adopting water harvesting techniques
like rain water harvesting, recycling of used water, metered water supply to the
users under project, double plumbing pipeline. The recycled water shall be used for
flush system, gardening, carwash and industrial use;
h) To provide effective safety & security measures like CCTV surveillance at
strategic locations, centralized control room, etc.;
i) Arranging smart and fast internet/broad band connectivity to all residences, e-
governance online system for grievance redressal;
j) Encouraging and providing platform for citizens participations in decision making
about public community issues.
k) Arranging real time environmental monitoring i.e. air pollution, noise pollution etc.
shall be observed.
l) Encouraging and providing platform for e-DCR for building plans with BIM, 3-D
maps on GIS of the utility services network and properties in the city, central
command, control and emergency response center for all infrastructure facilities.
Project Proponent/s shall also provide urban design concept plans along with
Master Plan.
m) It shall be obligatory on the part of Project Proponent/s to provide the infrastructure
and green building norms that are necessary as per the guidelines as may be laid
down by the Government, under the policy of development of ‗Smart City‘ from
time to time.
n) Ensure that the buildings have at least 3 star ratings from GRIHA/(1) Silver from
IGBC/Silver from LEED/equivalent rating from The ASSOCHAM GEM.
(1) Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
v) Project Proponent/s shall also mandatorily provide for:-
a) Water Supply-Safe and potable drinking water at the rate of 90 litters per capita
per day, exclusive of requirement of water for fire fighting and gardening
purposes. The storage capacity of the same shall be at least 1.5 times of the
actual required quantity as determined by expected population (Resident and
Floating) and other uses. The Project Proponent/s would be required to develop
proper internal distribution with double pipe plumbing for reuse of treated water
at appropriate places and maintenance system along with smart metering and
shall specially undertake rain water harvesting, groundwater recharging and
waste water recycling within the project.
Provided that, the Project Proponent/s should not use groundwater as a source of
water, to meet the above requirement.
b) Drainage and Garbage Disposal :- The Project Proponent/s shall make suitable
and environment friendly arrangements for the disposal and treatment of sewage
and solid waste generated in the project at source, as per the norms of the
Maharashtra Pollution Control Board. The Project Proponent shall provide zero
discharge in ITP for solid as well as liquid waste.
The Project Proponent/s should provide facilities for water conservation by
different means such as Rain Water Harvesting, Recycling of Waste Water, etc.
and also set-up, in the project area itself, the Solid Waste Management Project
(SWMP) with a sufficient capacity for processing of 100% garbage and solid
waste.
c) Power:- The Project Proponent/s shall ensure continuous and quality power
supply for the project area. The Project Proponent/s may draw the power from
any existing supply system or may go in for arrangement of captive power
generation with the approval from the concerned authority. If power is drawn
from any existing supply system, the Project Proponent/s shall, before
commencement of development, procure a firm commitment of power for the
entire Township from the power supply company.
14.1.1.11 Occupancy Certificate:-
i) Application for obtaining the Occupancy Certificate for buildings in project, in full or
part shall be submitted by Project Proponent/s to the concerned branch Officer of Town
Planning. Such application shall be accompanied by -
a) All the relevant documents alongwith coloured Google Earth / Bhuvan /Drone
survey image showing the area under Master Layout Plan;
b) Documents showing compliance of the conditions prescribed while according
sanctions from time to time;
c) Appropriate declaration/s and undertaking/s made by the Project Proponent/s and
his technical personnel‘s;
d) Any other requirement as may be prescribed by the Collector.
ii) The concern Branch Officer of Town Planning shall grant Occupancy Certificate or
reject the application giving specific reason within one month from the receipt of
application.
iii) The Collector, before issuing the Occupancy Certificate for the project as a whole,
shall verify and satisfy himself about the completion of erection /
development/construction of all the basic required infrastructure in Master Layout
plan. In case, an application for part occupancy, such completion shall be as
prescribed in phase programme.
14.1.1.12 General Stipulations:-
i) Development of basic infrastructure and amenities shall be completed by the Project
Proponent/s to the satisfaction of the Collector either for whole or as per phases, of the
project.
ii) It shall not be mandatory for the Project Proponent/s to provide Amenity Space as
otherwise required as per regulation of Regional Plan / Development Plan, if any.
iii) The Project Proponent/s shall plant indigenous trees at the rate of at least 150 trees per
ha. and maintain it properly. The certificate to that effect issued by the Deputy
Conservator of Forest or an Officer nominated by him for this purpose shall be
produced by Project Proponent/s at the time of application for Final Occupation
Certificate under Regulation No. 14.1.1.11.
iv) All the powers and functions that are supposed to be exercised by the Collector under
this regulation shall be exercised by the Chief Officer / Chief Executive Officer of the
concerned Planning Authority wherever applicable, excepting the powers to grant
Letter of Intent under Regulation No. 14.1.1.5 of this regulation.
Provided that, before grant or refusal to the Master Layout Plan, the Chief Officer /
Chief Executive Officer of the Authority shall, consult the, concerned Divisional Joint
Director of Town Planning as prescribed in Regulation No.14.1.1.6(iii) and (iv), if the
Planning Officer posted in such Authority is below the rank of Joint Director of Town
Planning, and to the concerned branch office of Town Planning as prescribed in
Regulation No. 14.1.1.6 (vi) and Regulation No. 14.1.1.11, if the Planning Officer
posted in such Authority is below the rank of Assistant Director of Town Planning.
v) All the amounts of scrutiny fees, charges, premium etc. payable to the Government
shall be deposited with the concerned Branch office of the Town Planning. In
circumstances described in proviso of Regulation No. 14.1.1.12(iv) above, 50% of
such amount shall be deposited with the concerned Branch office of the Town
Planning, and 50% to the concerned Planning Authority.
vi) The Project Proponent/s shall submit a bank guarantee of an amount equal to the 15%
of estimated development cost required for development of the basic Physical
infrastructure such as roads, water supply, drainage & garbage disposal, Trunk
installations for power supply, fire brigade station & fire engines. Such development
cost be worked out as per respective phases taking into consideration the phased
programme for development of infrastructure with amenities under project as
submitted and as required under Regulation NO. 14.1.1.6(i).Certificate regarding
estimated development cost shall be produced by the respective Architect of the
project. If Bank Guarantee as mentioned above is submitted then separate security
deposit shall not be insisted by the authority.
vii) The Project Proponent/s shall construct and maintain the Fire Station building &
Infrastructure at their cost. The project proponent shall post well-trained staff at fire
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
station as per the recommendations of the Director of Fire Services, Maharashtra State
/Chief Fire Officer of the concerned Authority or the cost of staff appointed by Chief
Fire Officer for this purpose shall be borne by the Project Proponent. The amount of
all expenditure on such staff shall be the responsibility of the Project Proponent/s.
After completion of fire station and as per requirement such fire brigade/station shall
be handed over to the nearest respective authority on the terms and condition decided
by the respective authority and project proponent.
viii) Developer shall complete the Special Township Project within 10 years or such period
as allowed by the Government from the approval to the master plan. Developer shall
develop and maintain the all infrastructure (internal street light, roads etc.) upto the
completion of the ITP project. Within such period or till the authority is formed as per
Regulation No. 14.1.1.12 (ix), the concession in property tax levied by the respective
Grampanchayat or the respective Planning Authority shall be 66% of normal rate as
prescribed under the Grampanchayat Act or under Maharashtra Municipal Council,
Nagar Panchayat and Industrial Town ship Act 1965 or Maharashtra Municipal
Corporation ACT. Such property tax shall be levied from date of Occupancy
Certificate. Respective Grampanchayat /Planning Authority shall provide mandatory
provisions like Birth and Death Registration Certificate etc. for the same period in
such ITP. Provided that the utilities like fire brigade, police station/Chowky etc. shall
be handed over to the nearest respective Authority at the terms and condition decided
by the respective authority.
ix) A local Authority shall be formed under section 3 read with section 341 of the
Maharashtra Municipal Council, Nagar Panchayat and Industrial Town ship Act 1965
according to population of such town ship. The newly formed respective authority
shall take over the operation maintenance of infrastructure in the Integrated Township
Project area with the previous approval of Government. However, if the area under
ITPs merged in any Local Authority then operation and maintenance of infrastructure
in such Integrated Township Project area shall be made by the respective Local
Authority.
x) Licensing to the Project Proponent/s - The respective Authority shall provide licenses
to the Project Proponent/s for telephone Connection, Power and other utilities in the
Township area as per existing rules & regulations. After granting the license from the
respective Authority, the project proponent/s shall provide utilities in the Township
area as per the conditions laid down by the respective authority.
xi) It shall be mandatory for the Project Proponent/s to provide appropriate width of road
to the land not owned by the project proponent which is surrounded by the Township
Area.
14.1.1.13 Special Concessions
i) Deemed conversion for Non-Agricultural ( N.A. ) Use :- The lands under approved
Master Layout Plan shall be considered as deemed N.A. No separate permission shall
be required under the provisions of Maharashtra Land Revenue Code, 1966. The
amount of non-agricultural assessment shall be exempted to the extent of 50% of the
normal rate for the land under Integrated Township Project.
ii) Grant of Government land:- The Government land/s, if surrounded or adjacent by
the lands owned by the Project Proponent/s, may preferably be granted to the Project
Proponent/s, as per the rules and regulations to that effect, by the Revenue and Forest
Department of the State Government. Maximum 10% of the total area under township
shall be allowed to be included in such township.
iii) Concession in Stamp Duty:- For the purchase of land by project proponent for
township area or for the first transaction from Project Proponent/s to Purchaser of any
unit under any user from approved Master Layout Plan or subsequent building plan
under this Regulation, concession of 50% of stamp duty as otherwise required under
the Mumbai Stamp Act, shall be granted. This concession will be available only at one
stage i.e. either at the time of land purchase or at the time of sale of units. Also, if the
project proponent assigns the rights to his own subsidiary companies for the running
of the Amenities in such Township project as per the approved plan in such cases
concession of 50 % of stamp duty as otherwise required under the Mumbai Stamp
Act, shall be granted.
iv) Exemption in payment of Development Charges:- 50 % of the amount of
Development Charges under sub-section (3) of Section 124F of the said Act shall be
exempted for institution use or, change of use of any land or building or,
development of any land or building, proposed for project undertaken by a Project
Proponent/s under this Regulation.
v) Relaxation from Mumbai Tenancy and Agriculture Land Act:- The condition that,
only the agriculturist will be eligible to buy the agriculture land shall not be applicable
to the Project Proponent/s for purchasing agriculture land for Integrated Township
under this Regulation.
vi) Exemption from Ceiling for holding agriculture land:- The limit for holding
agriculture land, stipulated in the Maharashtra Agricultural Lands (Ceiling and
Holdings) Act, 1961 shall not be applicable to the Project Proponent/s for
development of Integrated Township Project under this Regulation.
vii) Exemption from scrutiny fee:- The amount of scrutiny fee shall be exempted to the
extent of 50% of the normal rate for building permission under Integrated Township
Project.
viii) Exemption from royalty on minor minerals:- The amount of royalty on minor
minerals as per the Maharashtra Minor Mineral Extraction (Development and
Regulation) Rules shall be exempted to the extent of 50% for the earth which is
extracted while developing the land within Township area and fully exempted if the
said excavated material is used in the same project.
14.1.1.14 Transition Policy
i) It shall be permissible for the Project Proponent/s, to whom Special Township Project
has already been granted location clearance and / or LOI or the project is on-going
wherein part Occupancy Certificate is granted before 26/12/2016 to -
a) Continue such Special / Integrated Township Project under the erstwhile
regulations under which LC is granted without considering these regulations.
b) If the project proponents wish to develop township according to this regulations
then he may apply for grant of Letter of Intent or Master Layout Plan as the
case may be wherever required, under this regulation.
ii) If in case as described in Regulation No. 14.1.1.14 (i) (b), the construction of the
project is on-going and the Occupation Certificate, either in fully or partly has granted
or not been granted, it shall be permissible for the Project Proponent/s to choose an
option to prefer this regulation subject to payment of premium as prescribed in
Regulation No. 14.1.1.7 (i) and (ii). In such cases premium shall be calculated on
balance area which shall be the difference of FSI permitted as per earlier regulation
and that being availed as per this regulation.
14.1.1.15 Appeal
Anyone aggrieved by an order passed under prevailing byelaws may within forty days of the
date of communication of the order prefer an appeal to the Director of Town Planning,
Maharashtra State, Pune. The appeal shall be decided within 60 days.
14.1.1.16 Control by the State Government -
Director of Town Planning M.S Pune is authorised on behalf of Government to monitor the
Township Project and submit his report once in six months to Government.
14.1.1.17 Government may relax any provisions from these regulation considering the site condition
of the particular project.
14.1.1.18 Read the concern Planning Authority/ Special Planning Authority constituted under relevant
Acts instead Collector, wherever applicable.
14.1.1.19 The rate of premium mentioned in the Regulation No. 14.1.1.7 (i) (b) and 14.1.1.7(ii) (b) can
be revised by the Government from time to time.
14.1.2 For Development Plan area
Regulations for Integrated Township Projects for Regional Plan mentioned in Regulation No
14.1.1 shall be applicable to Development Plan area with modified Regulations as mentioned
below.
14.1.1.4 (ii) ---------------------------
(Explanation - In circumstances described in Regulation No. 14.1.1.4 (ii) above, such
grant of permission and declaration of project shall be made under the provisions of
Section 18(3) read with section 44 (2) of the Maharashtra Regional and Town Planning
Act, 1966)
14.1.1.6 (i ) ---------------------------
e) In case, project has no access from existing road having right of way of
18m. then documents showing the ownership or registered agreement for
permanent right of way, as the case may be, of Project Proponent/s in lands
proposed for 18 m. wide access road.
j) Colored Google earth image / Bhuvan image/ Drone survey image etc.
showing lands under Master Layout Plan, signed by project proponent
iv) The office of the Divisional Joint Director of Town Planning shall send its remarks
to Authority within two months from the receipt of proposal from the Authority or
receipt of reply from the Project Proponent/s in respect of any requisition made by
him, whichever is later. Such master layout approval will be given with the condition
that project proponent will not commence work without environmental clearance.
Such environmental clearance shall be submitted at the time of sanction to the
building permission.
14.1.1.6 (vi) -Approval to the building plan:-Detailed building permission under the
master layout plan sanctioned as per Regulation No. 14.1.1.6(v) shall be granted by the
concerned Authority with prior consultation as prescribed in proviso to Regulation No.
14.1.1.12(iv) within 30 days from the receipt of the proposal from the project proponent
as mentioned in 14.1.1.6 (vi) (a).
14.1.1.6 (vi) (b) -The Project Proponent/s shall submit the certificate of Architect regarding
completion of plinth stating that the construction of plinth is as per the approved building
Plans to the concerned branch office of the Town Planning along with approved Plan. The
Branch Office of the Town Planning verify the same within stipulated time period. If it is
found that the construction of plinth is not as per the building permission sanctioned, the said
office shall reject such plinth checking certificate. In such circumstances, the Project
Proponent/s shall either demolish the said plinth or get the revised plan sanction according to
changes. If it is found that the construction of plinth is as per the building permission
sanctioned, then granting the plinth checking certificate is not necessary.
However, notwithstanding anything mentioned above, before grant or refusal to the Master
Layout Plan, the Authority shall, consult the, concerned Divisional Joint Director of Town
Planning as prescribed in Regulation No. 14.1.1.6 (iii) and (iv) if the planning officer posted
in such Authority is below the rank of Joint Director of Town Planning, and to the concerned
branch office of Town Planning as prescribed in Regulation No. 14.1.1.6(vi) and Regulation
No. 14.1.1.11, if the Planning Officer posted in such Authority is below the rank of
Assistant Director of Town Planning.
14.1.1.7 (iii) ---------------------------
h) Transport & Communication:-
i) The entire area of the project shall have a proper road pattern, taking into
consideration the linkages with proposed roads of D.P. and R.P. existing roads within
the project and outside area as well. All such roads shall be developed by the Project
Proponent/s as per standard prescribed by the Indian Road Congress.
14.1.1.11 (ii) - On receipt of application as prescribed under Regulation No.14.1.1.11(i) the
Planning Authority shall forward the same to the concerned officer as stipulated in the
proviso to Regulation No. 14.1.1.12(iv) for technical consultation within 10 working days.
Following new Regulation shall be added.
14.1.1.7 (v) - Share of Local / Planning Authority.
The integration of Integrated Township Projects included in the Local / Planning Authority,
an area @ 2% of gross area shall be earmarked and shall be handed over free of cost to the
respective Authority for development of the City Level Facilities.
For determining eligibility of ITP, the above 2% area shall be considered in area calculation.
This area shall not contain area under hill slopes, and shall be accessible by major road.
Base FSI of such 2% land shall be made available to the applicant on remaining land.
14.2 TRANSIT ORIENTED DEVELOPMENT (TOD)
The following regulations in respect of Transit Oriented Development shall be applicable for
the areas mentioned herein under. These provisions shall come in to operation where
Authorities either have or proposed RTS/ Metro-rail/ BRTS corridors in their Development
Plans and have started implementing them.
14.2.1 For Pune Municipal Corporation Area
(1) The planning authority shall ensure execution of complete street design for the success
of TOD and enable construction of street oriented buildings while achieving optimum
densities in residential, commercial and office buildings.
The Planning authority shall also ensure complete pedestrianisation in the TOD zones for
easy movement of the pedestrians to & from station within a period of 1 year from
sanction of this regulation.
14.2.1.1 Definitions
(i) TOD zone :- It is the area 500 mt. around the proposed Metro station boundary as
will be delineated by the Planning Authority with the approval of the State
Government. Wherever any reservation / amenity space within such distance is
utilized for the purpose of transportation as prescribed in these regulations, and the
distance of 500 mtr shall stand relaxed up to 30%. The TOD zone shall be
delineated on ground by the Planning Authority in time bound manner i.e. within 2
months from this notification.
(ii) Base permissible FSI :- It is the FSI that is otherwise permissible on any land with
respect to zone shown as per the sanctioned development plan and the relevant
provision of the Principal DCPR excluding the TDR and the premium FSI,
redevelopment incentive FSI that can be received.
(iii) Gross plot area :- Gross Plot Area means total area of land after deducting area
under reservation or deemed reservation like amenity space if any, area under D.P.
Road and Road widening.
(iv) Principal DCPR :- Principal DCPR means the UDCPR sanctioned vide notification
dt.02.12.2020 and as amended from time to time.
14.2.1.2 Maximum Permissible FSI
The maximum permissible total FSI in TOD zone shall be 4.00 including the base
permissible FSI, subject to condition that, the additional FSI over and above the base
permissible FSI shall be allowed within the overall limit of maximum permissible FSI, as
given in the Table below -
Sr. No. Road width in mt. Maximum Permissible FSI
1 2 3
1 9 m. and up to 12 m. 2.50
2 12 m. and up to 15 m. 3.00
3 15 m. and up to 24 m. 3.50
4 24 m. and above 4.00
(1)
Inserted vide Notification u/s 37 (1AA)(C) & 20(4) No.CR 158/19, dt. 10th October, 2022
(1) Note : The Regulations as pertaining to Ancillary FSI as listed in the principle DCPR
shall be applicable on the above mentioned FSI. The Built-up Area Calculation shall be in
accordance with Regulation 6.6 of UDCPR.
14.2.1.2.1 Premium to be Paid
Additional FSI Over and above the base permissible FSI of respective land use zones as
per principal DCPR may be permitted on the payment of premium
Rate of premium for the additional F.S.I., as mentioned in Column No.3 above shall be
30% for FSI to be used for tenements of size equal to or less than 60 sq.mt. and 35% for
remaining FSI to be used for residential and / or commercial use, of the rate of the said
land mentioned in Annual Statement of Rates without considering the guidelines therein.
In the area of Planning Authority, 50% of the amount of premium collected should be
paid to the Planning Authority in the area concerned with the Urban Transport Project
and remaining 50% to the Project Implementing Authority.
In the area of Regional Plans, 50% of the amount of premium collected should be paid to
the Government through the District offices of Town Planning and Valuation Department
and remaining 50% to the Project Implementing Authority.
14.2.1.2.2 Impact Assessment and Integrated Mobility Plan
Such additional FSI over and above the base permissible FSI, shall be granted by the
Authority from where the Metro Rail is passing through, after taking into account the
Impact Assessment of the implementation of these regulations, regarding the impact on
the city and sector level infrastructure and amenities as well as traffic and environment.
Such Impact Assessment shall also contain measures to be undertaken to mitigate its
likely impact and the Action Plan for implementation of such measures in a time bound
manner.
There shall be an Integrated Mobility Plan envisaging inter-linkages between different
modes of mass transport, parking management, traffic management and
pedestrianisation, non-motorized transport network, last mile connectivity, traffic calming,
inter-connected street networking etc.
The impact assessment analysis shall be done by Planning Authority within 4 months
containing the remedial measures required regarding upgradation of infrastructure etc.
taking into consideration the impact analysis and provisions of sanctioned Development
Plan and need of such area falling in TOD Zone. Local Area Plans shall be prepared by
Planning Authority with participation of local residents within a period of four (4)
months. Such Local Area Plans shall contain complete street design to achieve optimum
densities and also to ensure complete pedestrianisation.
14.2.1.2.3 Entire area of plot may be considered for calculating the potential of plot in respect of
premium FSI + TDR, but not the basic FSI. Basic FSI shall be calculated on area of the
plot remaining with the owner after deducting area under D.P. road / road widening /
reservations and amenity space. This shall be applicable in cases where reservation area
or amenity space is handed over to the authority.
(1)
Inserted vide Notification u/s 37 (1AA)(C) & 20(4) No.CR 158/19, dt. 10th October, 2022
14.2.1.2.4 (1) In case of plot / plots falling partly within the TOD zone, the FSI permissible shall be as
follows, provided that the total area of the plot (plot falling within TOD zone plus plot
falling outside TOD zone) shall be as prescribed in the table in regulation no.14.2.1.2 :-
(i) Where 50% or more area of such plot / plots falls within TOD zone, these
regulations including FSI shall apply to the total area of such plot / plots.
(ii) Where less than 50% area of such plot / plots falls within TOD zone, these
regulations including FSI shall be applicable to the part of plot / plots falling within
TOD zone, whereas for the part of plot / plots falling outside TOD zone, these
regulations except provisions regarding FSI shall be applicable. The FSI
permissible for the part falling outside TOD zone shall be as per Principal DCPR.
Notwithstanding anything contained in any other provisions of these regulations,
TDR shall be allowed to be received on the plots within TOD zone, irrespective of its
location in congested area / non-congested area as per the Development Plan of
Pune subject to condition that it shall be utilised in 1/4 share with premium FSI at
every stage of utilization. Such share shall be calculated on the potential remaining
after utilizing the in-situ FSI towards Development Plan road, reservation, amenity
space, if any, on such land. However in case of non -availability / shortage of TDR,
the Authority, after considering the local situation, may allow utilisation of entire
potential with premium FSI. The Planning Authority shall compensate for the same
to Metro Project Implementing Authority as per the sharing formula decided by the
Government from time to time.
(iii) In case of plot / plots which marginally fall in TOD Zone i.e. less than 10% or 500
sq.mt., whichever is less, the land owner / developer shall decide to follow this TOD
Regulations or Principal DCPR.
14.2.1.3 Tenement Size
For any development or redevelopment within TOD zone, size of tenement shall be
minimum 25 sq.mt. and maximum 120 Sq.m. of carpet area and out of total proposed
tenements, the tenements equivalent to at least 50% of total FSI shall be of a size equal to
or less than 60 Sq.m. carpet area except the projects in which rehabilitation of existing
tenements is undertaken. In case of redevelopment scheme, size of tenement can be
relaxed for Rehab Component subject to other provisions of Principal DCPR. However
for free sale component 50% of residual FSI shall be utilise for tenements of size equal to
or less than 60 sq.mt. carpet area. These tenements shall not be allowed to be clubbed /
amalgamated in any case. However, this restriction for the residual FSI shall not be
necessary in case of single building redevelopment projects on plots below 1000 sq.mt.
In case of building with mixed use, 50% of FSI utilized for residential purpose shall be
considered for calculating requirement of tenements of a size equal to or less than 60
sq.mt. carpet area.
If the holder / owner of the property needs to build this 50% component at some other
location(s) within the same TOD zone / circle, the difference between rate of sale of
tenements as mentioned in Annual Statement of Rates shall be paid by the developer to
the Municipal Corporation as premium.
(1)
Inserted vide Notification u/s 37 (1AA)(C) & 20(4) No.CR 158/19, dt. 10th October, 2022
14.2.1.4 (1) Permissible mixed use in TOD zone
Mixed use in the form of residential and commercial may be permissible on the residential
plot in TOD zone fronting on the road width of 12 mt., and above and mix use on plot /
plots in commercial plot in TOD zone shall be permissible as per the Principal DCPR and
the maximum permissible FSI under this regulation shall be allowed on the payment of
premium. Purely Mercantile building office building, schools, colleges, hospitals, hotels,
assembly buildings will be permissible on independent plot & Information Technology
building will be permissible on independent plot subject to payment of premium. For I.T.
Buildings the rate of premium for additional FSI up to 200 % shall be as per regulation
No.7.8 of Principal DCPR and for additional FSI over it shall be as required under this
regulation.
14.2.1.5 Marginal Distances
Marginal Distances Shall be applicable as per provisions in principle DCPR.
14.2.1.6 Parking
Parking provisions in the TOD Zone shall be at 50% of those as mentioned in UDCPR.
Note : No on-street parking shall be permissible, unless specifically allowed in the
integrated mobility plan report.
14.2.1.6.1 Incentive for providing Public Parking in the area falling within the radius of 200 mt.
from the Metro/MRTS Station.
If the owner / developer of the plot falling within the radius of 200 mt. from the Metro
Station is willing to provide Public Parking space over and above the parking spaces
required as per regulation No.14.2.1.6 of this regulation, the same shall be allowed
without charging premium for such additional area and in that case the overall premium
shall be discounted on 50 % of such parking area while calculating premium for
additional FSI allowed over and above the base FSI, subject to following conditions :-
a) Such parking area shall be in the built-up form and shall be handed over to
Planning Authority free of cost before granting the Occupation Certificate to the
project. The Planning Authority should enter into an agreement with owner /
developer for such parking space at the time of granting Commencement Certificate
to the project. Such Public Parking area shall be clearly shown on the proposed
building plan / layout and a condition to above effect shall be incorporated in the
Commencement Certificate.
b) The parking area shall have independent access from major road adjacent to the
plot and with proper entry and exits.
c) The parking area to be made available at individual site shall be at minimum 100
sq.mt. at one place either at Ground floor / Stilt floor or first floor.
d) The maximum parking area that can be provided shall be decided by the Authority,
as the case may be, on considering the location of such site and the parking
requirement.
e) A board showing the location of such public parking space should he displayed at
suitable places by the Planning Authority.
(1)
Inserted vide Notification u/s 37 (1AA)(C) & 20(4) No.CR 158/19, dt. 10th October, 2022
(1)f) Area covered under such parking shall not be counted towards FSI consumption.
g) Concerned land owner / developer / society / public company shall not be allowed to
operate the public parking.
h) The proposed development shall be further subject to such conditions as may be
decided by the Authority.
14.2.1.7 In case of development or redevelopment, proposed by the Authority / individual applicant
/ any other Planning Authority, from the edge of the Metro Rail, within 20 mt. distance on
its either side, the concerned Planning Authority before granting such permission for
development / redevelopment shall seek prior NOC from the concerned Metro Railway
Authority as required under the Metro Railways (Construction of Works) Act, 1978 from
the point of view of safety of the Metro Railway and such other related matters.
14.2.1.8 For the matters not provided in this regulation, the relevant provisions of Principal DCPR
shall apply. However, in case of any conflict between this Regulation and any other
Regulation/s of the Principal DCPR, this Regulation shall prevail for the TOD zone.
14.2.1.9 No Compound wall / fencing shall be permissible on the boundary of plot facing the road
and 50% front marginal distance (subject to minimum of 3.0 mt.) shall be kept accessible
to the pedestrians to be used as foot paths. However, it shall be permissible for the
applicant to construct / erect fencing, on the receded boundary, after leaving the space for
pedestrians as specified above.
14.2.1.10 Large wholesale stores having built-up area of more than 500 sq.mt., car dealer
showrooms, warehouses / storages, auto service centres, Garages etc. shall not be
permissible in TOD zone.
14.2.1.11 Provision of Inclusive housing shall not be applicable in TOD zone.
14.2.1.12 For Gunthewari development regularized under the provisions of Maharashtra
Gunthewari Development Act, 2001 and falling in TOD zone, seeking permission for
development / redevelopment, these regulations shall apply.
14.2.1.13 In case of independent unit / Bungalow for self-use, such Development / Redevelopment
may be allowed within base FSI subject to Principal DCPR.
Notwithstanding anything contained in this regulation, if any development on plot in TOD
zone is proposed within base permissible FSI (without TDR or Premium FSI) as per
provisions of Principal DCPR, all other provisions of Principal DCPR shall be applicable.
14.2.1.14 The layout of building / group housing layout or standalone building on a plot / plots
situated in TOD zone / Circle, over which any development permission granted or any
development proposal for which any action is taken and for which occupancy certificate is
not granted, may be revised and balance potential, as per this regulation, if any, may be
allowed subject to structural stability criteria and provisions in Regulation 1.5 of Principle
DCPR and subject to following.
a) Parking - For the ongoing buildings, the requirement of parking as per this
regulation shall be applicable for the balance building potential.
b) Tenement size - For the ongoing buildings, the requirement of tenement size as per
this regulation shall be applicable for the balance building potential.
(1)
Inserted vide Notification u/s 37 (1AA)(C) & 20(4) No.CR 158/19, dt. 10th October, 2022
14.2.1.15 (1) The Amount received as scrutiny fee, hardship premium, and premium for additional
FSI etc. in TOD zone / circle shall be kept in separate head at Authority level and shall be
utilized for development of metro project as per directives issued by Government from time
to time.
14.2.1.16 These TOD provisions will also be made applicable to other MRTS projects such as BRTS.
The scale of FSI availability will be notified later by the Government for such other
projects.
14.2.2 Pune Metropolitan Region Development Authority area.
For this areas, the regulations specified in Regulation No. 14.2.1 are applicable mutatis -
mutandis
14.2.3 For Nagpur Municipal Corporation and Nagpur Metropolitan Region Development
Authority.
Following Regulations are applicable for Development / Redevelopment of building falling
within Nagpur Metro Rail Corridor (NMRC)
i) Definitions
a) Nagpur Metro Rail Corridor (NMRC) - It is the area falling within 500 m.
distance on either side of the Nagpur Metro Rail measured from its Centre line
and also includes the area falling within 500 m. distance from the longitudinal
end of the last Metro Railway Station. This regulation is also applicable for all
the Planning Authorities from where the Metro Rail is passing through.
b) Base permissible FSI - It is the FSI that is otherwise permissible on any land
with respect to zone shown as per the sanctioned development plan and the
relevant provision of the Principal DCR excluding the TDR and the premium
FSI, redevelopment incentive FSI that can be received.
c) Gross plot area - Gross Plot Area means total area of land after deducting area
under reservation or deemed reservation like amenity space if any, area under
D.P. Road and Road widening.
ii) Maximum Permissible FSI
The maximum permissible total FSI in NMRC shall be 4.00 including the basic
permissible FSI, subject to condition that, the additional FSI over and above the basic
permissible FSI shall be allowed within the overall limit of maximum permissible
FSI, as given in the Table No 14 O below :-
Table No. 14 O
Sr. Minimum Road Plot Area Maximum
No. Width Permissible FSI
1 9.00 m. Below 1000 Sq.m. 2.00
2 9.00 m. 1000 Sq.m. or above 3.00
3 12.00 m. 2000 Sq.m. or above 3.50
4 15.00 m. 2000 Sq.m. or above 4.00
(#)
Clarification issued Vide Letter No.CR 236/18 (Part 1), dt. 14th January, 2021.
(1)
Inserted vide Notification u/s 37 (1AA)(C) & 20(4) No.CR 158/19, dt. 10th October, 2022
Explanation:-
1) The maximum permissible FSI as per the above Table shall be determined by
satisfaction of both the criterias viz. Minimum Road width as well as plot area,
simultaneously. However in case, both these criterias are not satisfied simultaneously,
the maximum permissible FSI shall be the minimum of that permissible against each
of these two criterias, as illustrated below ;
2) Land owner / Developer shall not have option to use TDR in NMRC.
Illustrations: -
Table No. 14 P
Road width
Plot Area Less than 9m. 9 m. & 12 m. & 15 m.
above above &
above
below 1000 Sq.m. As mentioned in Chapter 6 2 2 2
1000 Sq.m. up to 2000 sq. m. As mentioned in Chapter 6 3 3.5 3.5
Above 2000 Sq.m. As mentioned in Chapter 6 3 3.5 4.0
a) Premium to be Paid
Additional FSI over and above basic permissible FSI of respective land use
zones as mentioned in Chapter 6 may be permitted on the payment of premium
as may be decided by the Govt. from time to time.
i) The additional FSI as prescribed in the Table under provision (1) (ii) above,
in case of development / redevelopment proposed in the NMRC with
minimum tenement density per hectare of the gross plot area as given
below.
Minimum Numbers of Tenements = Gross Plot Area x Maximum
Proposed FSI for Residential use x 200 Tenement per Hector.
ii) However, subject to the provisions of regulation (1)14.2.3(iii) herein
below, if the tenement density proposed is less than that stipulated under
(1)provision (ii)(a)(i), the premium to be paid in that event shall be the
additional premium as may be decided by the Govt. from time to time
and such premium shall be chargeable on the total additional FSI to be
availed beyond the basic permissible FSI.
iii) For construction of buildings mentioned in Chapter 7, the rates of
premium shall be as mentioned in the said Chapter.
b) Impact Assessment and Integrated Mobility Plan
Such additional FSI over and above the base permissible FSI, shall be granted by the
Commissioner, Nagpur Municipal Corporation / Chairman, Nagpur Improvement Trust,
any Planning Authorities from where the Metro Rail is passing through after taking into
account the Impact Assessment of the implementation of these regulations regarding the
impact on the city and sector level infrastructure and amenities as well as traffic and
environment on such
(1)
Substituted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
NMRC. Such Impact Assessment shall also contain measures to be undertaken
to mitigate its likely impact and the Action Plan for implementation of such
measures in a time bound manner. It shall also contain Integrated Mobility Plan
envisaging therein inter-linkages between different modes of mass transport,
parking management, traffic management and pedestrianisation.
c) The maximum permissible FSI as given in Table under Regulation No.(ii)
above shall be calculated on the gross plot area.
d) In case of plot / plots falling partly within the NMRC, the FSI permissible shall
be as follows, provided that the total area of the plot (plot falling within NMRC
plus plot falling outside NMRC) shall be as prescribed in the table in
Regulation No.(ii) above:-
(i) Where 50% or more area of such plot / plots falls within NMRC, these
regulations including FSI shall apply to the total area of such plot / plots.
(ii) Where less than 50% area of such plot / plots falls within NMRC, these
regulations including FSI shall be applicable to the part of plot / plots
falling within NMRC, whereas for the part of plot / plots falling outside
NMRC, these regulations except provisions regarding FSI shall be
applicable. The FSI permissible for the part falling outside NMRC shall
be as mentioned in chapter 6.
Moreover, the owner shall have option of either to opt for UDCPR
provisions in toto or opt for TOD regulations in toto. In case, the owner
opts for development as per UDCPR provisions, then he may be allowed
to utilise FSI as per TOD regulations over and above the maximum
potential mentioned in Table 6-A or 6-G.
e) Notwithstanding anything contained in any other provisions of these
regulations, TDR shall not be allowed to be received on the plots within
NMRC, irrespective of its location in congested area / non-congested
area as per the Sanction Development Plan of Nagpur.
iii) Permissible mixed use in NMRC:
Mixed use in the form of residential and commercial, fully commercial use may be
permissible on the residential plot in NMRC fronting on the road width of 12 m. and
above. Mix use on plot / plots in commercial zone of sanction Development Plan
falling under NMRC shall be permissible as per these Development Control and
Promotion Regulations and the FSI permissible as per his Regulation over and above
as mentioned in Chapter 6 shall be allowed on the payment of premium, as per subject
to Maximum building potential as mentioned in Regulation No. (ii) above
iv) Other provisions regarding marginal open spaces shall be governed by the proposed
height of structure, as given in the provisions (v) below and should conform to the
Maharashtra Fire Prevention and Life Safety Measures Act, 2006 (Maharashtra Act
No. III of 2007) as amended from time to time. No building permission shall be
issued without NOC of the Fire Officer. Other regulations regarding room sizes,
apertures for light and ventilation shall be as per these Development Control and
Promotion Regulations in force.
v) Marginal Spaces
Table No. 14 Q
Sr. Building Side and Rear Remark
No. Height Margins
a 15 m. and H/2-4 Minimum 3.0m. for Residential
below minimum 4.5 m. for Commercial and
Minimum 6.0m. for Special Buildings.
b Above 15 m. Minimum 4.5 m. for Residential and
and upto 24 m. Commercial Building and 6 m. for
H/5
Special Building.
c Above 24 m. Minimum 6.0 m.
Note-1. Maximum Side / Rear / Front Margin shall be 12.00 m. However if Developer /
Owners provides more than 12 m. side and rear margins it may be allowed.
Note-2. The Municipal Commissioner may relax the side & rear marginal distances as per
Regulation No. 2.4 of UDCPR subject to following provisions.
A) If clear minimum marginal distance is proposed from one side as per these
Regulation then other side marginal distance may be relaxed up to 50%.
B) Front margin relaxation to allow additional FSI may be granted subject to
condition that the Minimum road width shall be 12 m. and above.
Note-3. In case semi-detached construction as per these regulations, common wall
constructed is allowed and marginal distance shall be provided for other side as per
these regulations.
(v)(a) No projections shall be allowed in one side marginal spaces as mentioned in Note
2(A) above so that this marginal spaces remain free from all encumbrances for the
movement of fire tenders. However open balconies may be allowed in the marginal
spaces where concession as mentioned in Note No. 2(A) above is allowed, after
leaving minimum 3.0m. distance from the plot boundaries, subject to Fire NOC.
In case if ramp is necessary from accessibility, such ramp may be allowed after living
6 m. clear margin. However such Ramp may be allowed in side margin where
relaxation is to granted as per provision mentioned in Note No. 2(A) above subject to
NOC of the Fire Department.
(v)b) For calculation of marginal distances, the height of the parking floors (Maximum two
floors above the Ground Level) shall not be taken in account, However height of such
parking floors will be counted towards the total height of the building for deciding the
building as high rise building and for civil Aviation purpose.
(v)(c) Car lift / mechanical parking shall be permissible, as per these regulations as amended
from time to time.
vi) Parking
Parking in the NMRC shall be provided as per the table given below :-
Table No. 14 R
Sr. Transit Oriented
No. Occupancy One parking space for every Development Influence Zone
Car Scooter Cycle
/Motorcy
cle
1 Residential (a) Tenements having carpet
area
From 25 and upto 40 Sq.m.
0 1 2
For 2 units above 40 and
1 1 2
upto 60 Sq.m.
1 1 2
For every unit above 60 and
upto 80 Sq.m.
1 2 1
For every unit above 80
Sq.m..
2 Govt. & 100 Sq.m. carpet area or 1 2 2
Semi Govt. fraction thereof
Private
business
buildings
Note:-
1) Parking spaces for differently - abled persons shall be provided as stipulated in these
regulations in each new construction / development / re- development in the NMRC.
2) On street parking shall not be permissible, unless specifically allowed in the impact
assessment and mobility report.
(vi)(a) Incentive for providing Public Parking in the area falling within the radius of 200 m.
from the Metro Station.
If the owner / developer of the plot falling within the radius of 200 m. from the
Metro Station, is willing to provide Public Parking space over and above the parking
spaces required as per the table given in Regulation No. (vi) above of this regulation,
the same shall be allowed and in that case the premium to be paid by such developer
/ owner as per Regulation No. 14.2.3 (ii) (a) shall be reduced by the amount equal to
the premium worked out for 25% of the area earmarked for such additional Public
Parking space, subject to following conditions:-
i) Such parking area shall be in the built-up form and shall be handed over to
Planning Authority free of cost before granting the Occupation Certificate to
the project. The Planning Authority should enter into an agreement with
owner / developer for such parking space at the time of granting
Commencement Certificate to the project. Such Public Parking area shall be
clearly shown on the proposed building plan / layout and a condition to above
effect shall be incorporated in the Commencement Certificate.
ii) The parking area shall have independent access from major road adjacent to
the plot and with proper entry and exits.
iii) The parking area to be made available at individual site shall be at minimum
100 Sq.m. at one place either at Ground floor / Stilt floor or first floor.
iv) The maximum parking area that can be provided shall be decided by the
Commissioner, Nagpur Municipal Corporation / the Chairman, Nagpur
Improvement Trust, as the case may be, on considering the location of such
site and the parking requirement.
v) A board showing the location of such public parking space should be
displayed at suitable places by the Planning Authority.
vi) Area covered under such parking shall not be counted towards FSI
consumption.
vii) Concerned land owner / developer / society / public company shall not be
allowed to operate the public parking.
viii) The proposed development shall be further subject to such conditions as may
be decided by the Municipal Commissioner / Chairman, NIT, as the case may
be.
vii) In case of development or redevelopment, proposed by the Authority / individual
applicant / any other Planning Authority, from the edge of the Metro Rail, within
10m. distance from the Metro Rail, on its either side, the concerned Planning
Authority i.e. Nagpur Improvement Trust / Nagpur Municipal Corporation before
granting such permission for development / redevelopment shall seek prior NOC from
the Nagpur Metro Railway Corporation Ltd as required under the Metro Railways
(Construction of Works) Act, 1978 from the point of view of safety of the Metro
Railway and such other related matters.
viii) The provisions of these UDCPR shall be applicable except, express provisions of
these TOD regulations. However in case of any conflict between TOD Regulations
and any other Regulation/s of UDCPR, TOD Regulations shall prevail for the NMRC.
ix) No Compound wall / fencing shall be permissible on the boundary of plot facing the
road and 50% front marginal distance (subject to minimum and maximum of 3m.)
shall be kept accessible and to be used as foot paths for pedestrians. However, it shall
be permissible for the applicant to construct / erect fencing, on the boundary, after
leaving the space for pedestrians as specified above.
However for the plots situated on 9 m., 12 m.. & 15 m., wide Roads having 100%
residential use therefore above rule shall not be made applicable.
a) Large wholesale stores, auto dealer showrooms, warehouses/storages, auto
service centres, Garages etc. shall not be permissible in NMRC.
b) Provision of Inclusive housing shall not be applicable in NMRC.
c) For Gunthewari development regularized under the provisions of Maharashtra
Gunthewari Development Act, 2001 and falling in NMRC, seeking provisions
for Development / redevelopment, these regulations shall apply.
d) The width of passage shall be minimum 1.2 m. for residential use & 2 m. for
commercial use.
e) Above regulation shall be applicable to all the buildings (i.e. newly proposed
buildings as well as old buildings for utilization of FSI) in TOD.
f) In case of redevelopment scheme, size of tenement can be relaxed for Rehab
Component subject to other provisions of UDCPR. However for free sale
component TOD Regulation shall be made applicable.
g) In case of independent unit / Bungalow for self-use, such Development /
Redevelopment may be allowed within base FSI subject to UDCPR.
h) The layout of building / group housing layout or standalone building on a plot /
plots situated in NMRC over which construction is started and for which
occupancy certificate is not granted may be revised and balance potential if any
may be allowed as per the above provisions subject to following :-
Marginal Distance - The existing marginal distances including front margin
may be allowed for higher floor / floors and necessary relaxation to that extent
may be granted by the Municipal Commissioner subject to compliance of all
fire requirements and fire NOCs by charging hardship premium. Hardship
premium is to be decided by Municipal Commissioner. In any case sanctioned
existing marginal /front margin distance shall not be reduced.
14.2.4 For other Municipal Corporations and other Metropolitan Region Development
Authority (1)and CIDCO area.
For these areas, the regulations specified in Regulation No. 14.2.1shall be applicable.
14.2.5 Regulations for BRT Corridor in Pimpri-Chinchwad Municipal Corporation.
The Regulations for development along the BRT corridor in Pimpri-Chinchwad Municipal
Corporation area sanctioned vide Government Notification No. TPS-1812/737/12/CR
506/13/Reconstruction No. 110/UD-13, dated 03/03/2010and amended from time to time,
shall be applicable with following modifications.
FSI receiving or development potential of the plot shall be as below.
Sr. Road width in meters Basic FSI on Maximum Maximum
No. payment permissible building potential
FSI
of TDR on plot including
premium loading in-situ FSI
1 2 3 4 5 6
1 Below 9 m. 1.00 -- -- 1.00
2 9 m. and above but below 12 m. 1.00 0.50 0.75 2.25
3 12 m. and above but below 15 m. 1.00 0.50 1.00 2.50
4 15 m. and above but below 24 m. 1.00 0.50 1.25 2.75
5 24 and above but below 30 m. 1.00 0.50 1.50 3.00
6 30 and above 1.00 0.50 1.75 3.25
14.3 AFFORDABLE HOUSING SCHEME
i) The Authority may permit implementation of Affordable Housing Scheme in
accordance with the provisions of these Regulations. Affordable Housing Scheme
(hereinafter referred to as ‗the Scheme‘) shall be permissible only on the lands
situated within the limits of Municipal Corporation.
(1)
Inserted vide Notification u/s 37 (1AA)(c) No.CR 236/18 (Part 6), dt. 12th October, 2022
a) Affordable Housing Scheme shall be permissible in Residential Zone only
and on plots having access from an existing or proposed Development Plan
Road having width equal to or in excess of 18 m. or an existing road in
respect of which Regular Line of Street has been declared under the relevant
provisions of Maharashtra Municipal Corporation Act, for a width of 18 m.
or more. However in case of a proposed road, the land under the said
proposed road shall be acquired before the approval of building plans for the
Affordable Housing Scheme.
b) Minimum plot area for the Affordable Housing Scheme shall be 4000 Sq.m.,
excluding area under D.P. Roads and D.P. Reservations, if any.
c) The plot under the Scheme shall be independent, unencumbered and
contiguous.
d) The Scheme shall not be permissible in congested areas, demarcated as
such on the Development Plan.
e) Maximum permissible FSI (including the basic FSI of 1.00) under the
Scheme shall be 3.00 on the gross plot area, including mandatory layout
recreational open space and Amenity Space. The FSI to be utilized shall be
in the proportion of 1:3 for the Affordable Housing Component and the Free
Sale Housing Component on ¼th and ¾th part of the land respectively. Thus
Affordable Housing and Free Sale Housing shall be proposed on the same plot
of land but on two separate independently buildable pockets.
f) Under Affordable Housing Scheme, upto 15% of the total built-up area of the
Affordable Housing Component may be used for construction of
shops/commercial use as per the direction of Urban Local Body and such
commercial built-up area shall be handed over to the concerned ULB free of
cost.
g) An Affordable Housing Unit shall be a self-contained dwelling unit of 27.88
Sq.m. carpet area. However the carpet area of a Housing Unit shall be 160
Sq.ft.,/ (1)25 sq.mt. where the construction under the Rental Housing Scheme /
(1)Affordable Housing Scheme, as the case may be, has already commenced.
h) The amenity space for Affordable Housing shall be as per these regulations and
it shall be proportionately provided in the area earmarked for the Affordable
Housing Component and the area kept for Free Sale Housing component.
Provided that where the Scheme is to be implemented on a plot in Industrial
Zone where the Planning Authority has duly permitted Residential user under
the relevant provisions of the Development Control Regulations :-
i) no further area shall be required to be kept as amenity space under
this Regulation for the Scheme if the area prescribed to be kept as
amenity space while permitting residential user in Industrial Zone is
equal to or more than 10% of the gross plot area.
ii) only the balance area shall be required to be kept as amenity space
under this Regulation for the Scheme if the area of amenity space
prescribed by the Planning Authority, while permitting residential user
in Industrial zone, falls short of 10%.
(1) Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
ii) a) Notwithstanding anything contained in the relevant provisions of the
Development Control Regulations for the respective Municipal Corporation
regarding the provision of Amenity Space in general, and also regarding
permitting Residential User in Industrial Zone, it shall be obligatory on the
Developer / Owner to develop the amenity space for users (hereinafter referred
to as prescribed amenity users) such as School, Play Ground, Garden, Health
Care Facilities, Multipurpose Hall, Auditorium, etc. with the approval of
Authority as per the specifications prescribed by the said Authority, subject to
the condition that atleast 50% of such amenity space shall be kept for open
users, before seeking Occupancy Certificate for the Free Sale Housing
Component of the Scheme, failing which the land under such amenity space
shall be handed over free of cost to the Planning Authority and such land shall
be developed by the Authority for the aforesaid prescribed amenity users only.
No compensation in the form of TDR shall be admissible to the Owner /
Developer for development of such prescribed amenities under this Regulation.
b) Irrespective of whether the Owner / Developer develops the prescribed amenity
users as per the provisions of (1) Clause (ii) above or fails to do so, the
process of handing over the land under such amenity space, along with the
developed prescribed amenities, where such prescribed amenities have been
developed, shall be completed within one month from the date of application
by the Developer / Owner for seeking Occupancy Certificate for the free sale
housing component of the Scheme and if such handing over process is not
completed within the said period, the occupancy certificate for the free sale
housing component of the Scheme shall be withheld by the Authority till such
amenity space, along with developed prescribed amenities, where such
prescribed amenities have been developed, is handed over to the Authority.
c) Under the Affordable Housing Scheme, there shall be a welfare hall and a
Balwadi at the rate of 30 Sq.m. for every multiple or part of 200 residential
units and an office for Co-operative Housing Society at the rate of 30 Sq.m. per
every multiple or part of 500 residential units which shall be treated as a part
of Affordable Housing Component and shall not be counted towards the FSI
while computing 3.00 FSI on the site and shall be given along with
layout/DP roads and shops, free of cost to the concerned ULB. These facilities
shall be constructed at locations as suggested by the concerned ULB and shall
be transferred free of cost to it.
iii) Under the Affordable Housing Scheme, off-site infrastructure charges at the rate of
5% of the land rate as given in the Annual Statement of Rates (ASR) prepared by
the Inspector General of Registration, Maharashtra State, for the year in which
Commencement Certificate is issued (without applying guidelines of ASR),subject to
a minimum of Rs.2000 per Sq.m., shall be paid by the Developer for the built up
area, over and above the normal permissible FSI. This amount shall be paid to the
concerned ULB.
iv) Release of FSI under the Scheme shall be as follows:-
FSI for Affordable Housing Component and the Free Sale Housing
Component under the Scheme shall be released in accordance with the following
(1)Table No. 14 S.
(1) Substituted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
Table No. 14 S
Sr. Stages of Release of FSI Affordable Free Sale
No. Housing Compone
Component* nt*
1. On Grant of Building Permission / 3.00 1.00
Commencement Certificate up to plinth by
Commissioner to the Affordable Housing Project
2. On Completion of 50% BUA of Affordable -- 0.75
Component
3. On Completion of 100% BUA of Affordable -- 0.75
Component
4. On handing over of 25% land and completed -- 0.50
Affordable Component
Total 3.00* 3.00*
* Explanation - The FSI of 3.00 is to be calculated separately on the one-fourth of
plot area for Affordable Housing Component as well as three-fourth of plot area for
Free-Sale Housing component.
v) The Affordable Housing Component under the Scheme shall be handed over along with
the ¼th part of the total plot of land, free of cost to the concerned ULB.
vi)(a) The affordable housing stock created under the scheme shall be allotted by the
concerned ULB as follows :-
Table No. 14 T
Percentage Allotment to Category Rate of allotment
of stock
50 Respective ULBs for use as PAP O w n e r s h i p F ree of cost
ownership free of cost tenements or
staff quarters or transit
accommodation.
25 Government of Maharashtra and its Ownership Free of cost
statutory bodies/Govt. undertaking
for use as PAP tenements or staff
quarters or transit accommodation
25 As affordable housing by MHADA Ownership Free of cost to MHADA
subject to the general or specific which shall dispose of
direction of the Government the same as per its policy
and drawl of lots
b) The affordable housing stock shall be disposed of as per the prevailing policy
of MHADA regarding pricing and disposal of its housing stock meant for
affordable housing. Each project approved under the Scheme shall be brought
to the notice of the Government of Maharashtra and its statutory
bodies/Government undertakings by means of press advertisement and if the
Government of Maharashtra or any of its statutory bodies/Government
Undertakings doesn‘t place firm requirement for the housing stock earmarked
for them in the Scheme before the completion certificate / occupation certificate
for the said scheme is issued, the same shall come to the share of MHADA for
outright sale as per the prevailing policy of the MHADA.
vii) a) The other aspects of the development of affordable housing scheme, not
specifically dealt with hereinabove, shall be as per the relevant provisions of
UDCPR.
b) It shall also be permissible for the developer / owner to utilise the FSI available
for free sale housing component, fully / partly for any other user otherwise
permissible as per UDCPR.
c) In case owing to genuine hardship and site conditions, relaxation in
marginal open spaces is sought by the developer / owner, the authority may
consider such request, using its discretionary powers under the UDCPR,
subject to the condition that in no case shall the clear marginal open space be
reduced below 6 m. No premium shall be charged for granting such
relaxation in marginal open spaces in respect of affordable housing component
of the scheme.
14.4 PRADHAN MANTRI AWAS YOJANA
14.4.1 For Development Plan area.
i) For developable zone.
In any developable zone such as Residential / Commercial / Public semi-public /
Urbanisable Zone / Urbanisable Zone U-1, U-2 / Industrial etc., Affordable Housing
for the Economically Weaker Sections (EWS) &Low Income Group (LIG),
undertaken by Government / any Institutions authorized by the Government or Owner
/ any Private Developer (hereinafter referred to "the Project Proponent"), shall be
permitted, subject to the following conditions.
Conditions :-
1. These Regulations shall only be applicable for development undertaken under
"Pradhan Mantri Awas Yojana" wherein all the tenements shall be constructed
for EWS / LIG with the use of latest technology, subject to condition no.3
herein below.
2. Such Development shall be permitted in Industrial Zone only after leaving
amenity space as per Regulation No. 4.8.1. However, no premium shall be
charged for allowing residential use in the form of PMAY in Industrial Zone.
(#) 3. The permissible FSI for such projects shall be the maximum building potential
on the plot mentioned in Regulation No. 6.1 or 6.3 subject to maximum 2.5
which shall be treated as allowable basic FSI for such project. No premium FSI
or TDR shall be required to be loaded for availing this FSI upto 2.5. However,
where building potential as per Regulation No. 6.1 or 6.3 exceeds 2.5, in such
cases permissibility of availing building potential above 2.5 shall be in the form
of premium FSI or TDR or both which may be utilised for the permissible uses
under this UDCPR.
4. Out of the FSI allowed in PMAY, 10% of the basic FSI mentioned in Regulation
No. 6.1 or 6.3, shall be allowed for commercial use.
(#) Clarification issued vide Order No. CR 236/18 (Part 2), dt., 23rd December, 2021.
5. The Municipal Commissioner / Metropolitan Commissioner / Chief Executive
Officer/ Chief Officer, before granting development permission, shall verify
and satisfy himself in respect of the feasibility of providing basic infrastructure
facilities like electricity, water supply, sewerage etc. required for the project.
6. The project proponent shall plan proper internal Road network including major
linkage upto outside roads, wherever necessary.
7. The project proponent shall provide all the basic facilities and utilities, on-site
infrastructure such as Road, Water Line, Drainage Line, Street Light, Waste
Water Recycling Plant etc. at his own cost to the satisfaction of the Authority.
In no case the burden of providing infrastructure shall lie with the Authority.
Provided that the project proponent shall lay the water, drainage/sewage lines
up to the nearest existing lines which are laid by the concerned Planning
Authority.
8. The carpet area of the tenement shall not be more than the carpet area as may be
decided by the Government of Maharashtra from time to time in respect of
EWS /LIG Housing.
9. Amalgamation of two or more tenements shall not be permissible under any
circumstances.
10. All other guidelines and norms shall be followed as may be decided by the
Government of India or State Government, from time to time in respect of
"Pradhan Mantri Awas Yojana".
ii) For No Development Zone / Agricultural Zone / Green Zone-1.
All above Regulation No. 14.4.1(i) with following modification shall be applicable for
Pradhan Mantri Awas Yojana to be permitted in No Development Zone / Agricultural
Zone / Green Zone-1.
a) The minimum width of approach road shall be 9 m.
b) The permissible FSI for such projects shall be 1.0 on gross plot area.
14.4.2 For Regional Plan area.
The Regulations No.14.4.1 shall be applicable for Pradhan Mantri Awas Yojana to be
permitted in following areas of Regional Plan, in respective zones.
i) In Mumbai Metropolitan Regional Plan area
a) PMAY shall be permissible in urbanisable zone U-1, U-2 / Urbanisable Zone of
entire Mumbai Metropolitan Regional Plan, with FSI and other provisions
mentioned in Regulation No.14.4.1(i).
b) PMAY shall be permissible in zones, other than urbanisable zoneU-1, U-2 /
Urbanisable Zone, within distances mentioned in following table, with FSI and
other provisions mentioned in Regulation No.14.4.1(ii).
ii) In other Regional Plan Area.
PMAY shall be permissible in respective zones, within distances mentioned in
following table with FSI and other provisions mentioned in Regulation No.14.4.1(i) &
(ii).
Sr. Within distance from Outer peripheral distance from the
No. Boundary of the Urban Local Bodies
where PMAY is permissible
1 Municipal Corporations 2.0 k.m.
2 Municipal Councils / Nagarpanchayats 1.0 k.m.
14.5 CONSERVATION OF HERITAGE BUILDINGS / PRECINCTS / NATURAL
FEATURES
14.5.1 Applicability
This regulation will apply to heritage sites which means, artefacts, structures, areas and
precincts of historic and/or architectural and / or cultural significance (hereinafter as ‗Listed
Buildings / Heritage Buildings and Listed Precincts / Heritage Precincts‘‘) and those natural
features of environmental significance including scared graves, hills, hillocks, water bodies
(and the areas adjoining the same) etc. within the areas of Planning Authorities and Regional
Plan.
14.5.2 Preparation of List of Heritage Buildings, Heritage Precincts and Natural Features
The Authority on advice of Heritage Committee shall prepare heritage list and shall issue
public notice in the local newspapers declaring his intention to include the buildings or
modify such list of buildings, structures artefacts, areas and precincts of historic and /or
cultural significance and the list of natural features of environmental significance, including
sacred groves, hills, hillocks, water bodies etc. and invite objections and suggestions from
any person in respect of the proposed inclusion within a period of 30 days from the date of
such notice.
While preparing the list, the authority shall strictly insure that such structure / precinct has
heritage value and is liable for inclusion in the list in view of its national, regional, or local
importance as specified in Regulation No. 14.5.8. The structure / precinct which do not
comply the requirements specified in the said regulation shall not be included in the list.
Generally, the following aspects shall be ascertained while preparing the list.
a) Its value for architectural, historical or cultural reasons
b) The date and/or period and/or design and/or unique use of the building or artefact
c) Relevance to social or economic history
d) Association with well-known persons or events
e) A building or groups of buildings and/or areas of a distinct architectural design and/or
style, historic period or way of life having sociological interest and/or community value
f) The unique value of a building or architectural features or artefact and/or being part of a
chain of architectural development that would be broken if it were lost
(g) Its value as a part of a group of buildings
(h) Representing forms of technological development
(i) Vistas of natural/scenic beauty or interest, including water front areas, distinctive and/or
planned lines of sight, street line, skyline or topographical features.
(j) Open spaces sometimes integrally planned with their associated areas having a
distinctive way of life and for which they have the potential to be areas of recreation
(k) Industrial sites of historical interest
(l) Archaeological sites
(m) Natural heritage sites
(n) Sites of scenic beauty
All such heritage structures shall be documented in the Heritage List Card as given in
Appendix - L and the Heritage List Card shall be duly authenticated by the authorised
heritage conservationist upon his site visit, stating the significance of heritage site for its
appropriate grading.
The Authority shall issue notice to the owner of the buildings, artifacts, areas and precincts
of historic and/or cultural significance etc. and invite objections and suggestions from such
person in respect of proposed inclusion within 30 days from the date of such notice.
The Authority, in respect of any objections or suggestions, shall decide the same after giving
hearing to such persons and send the list as finalised by him to the State Government for
approval. The State Government may sanction the said heritage list with modification, if
required. This list will be called Final Heritage List. For this, modification under section 37
or 20 of the Maharashtra Regional and Town Planning Act, 1966 need not be necessary.
Thereafter, the Authority may amend the Final Heritage List from time to time as and when
required, on the advice of the Heritage Committee. In such case it shall not be necessary to
follow the procedure under Section 37 or section 20 of the Maharashtra Regional and Town
Planning Act of 1966, but the procedure as laid down above in this regulation shall be
followed.
The heritage lists which have been approved by the Government before coming into force
these regulations, shall remain valid and shall be the part of these regulations.
14.5.3 Restriction on development, Redevelopment/repairs etc.
No development or redevelopment or engineering operations or addition, repairs, renovation
including the painting of buildings, replacement of special features or plastering or
demolition of any part thereof of the said listed buildings, or listed precincts or listed natural
features shall be allowed except with the prior written permission of the Authority. Before
granting any such permission, the Authority shall consult the Heritage Conservation
Committee to be appointed by the State Government (hereinafter referred to as ‗the said
Heritage Conservation Committee‘) and shall act on the advice of the Heritage Conservation
Committee.
Provided that before granting any permission for demolition or major alterations/ addition to
listed buildings (or buildings within listed precincts) objections and suggestions from the
public shall be invited and duly considered by the Heritage Conservation Committee.
Provided that, in exceptional cases for reasons to be recorded in writing the Authority may
overrule the advice of the Heritage Conservation Committee.
Provided further that the power to overrule the advice of the Heritage Conservation
Committee shall not be delegated by the Authority to any other officer.
If the application for development, alteration, modification of the Heritage precincts or listed
building is rejected under this regulation or while granting such permission any conditions
are imposed on the owner which deprives him to use the FSI, the said owner shall be
compensated by grant of Development Right Certificate.
14.5.4 Incentive uses for Heritage Buildings.
After the commencement of this Regulation, the Heritage Precincts or the Listed Buildings
shall not be permitted to be used for any commercial or office purpose except with the
concurrence of the Heritage Conservation Committee. However, in cases of buildings
included in the Heritage Conservation List, if the owner /owners agree to maintain the listed
Heritage Building in an ideal state of preservation with due repairs / restorations and if the
owner / owners give a written undertaking to that effect, may be allowed by the Authority in
consultation with Heritage Conservation Committee to convert part or the whole of the
building to commercial / office use / any other different use that is beneficial to the
preservation of the same Provided that, if the heritage building is not maintained suitably or
if the heritage value of the building is allowed to be spoiled in any manner, the Authority
shall withdraw the permission forthwith.
14.5.5 Grant of Transferable Development Rights to Owners/ Lessees of Heritage
Buildings/Heritage Precincts.
If the owner is deprived of using permissible FSI on the said plot or development permission
is granted to him with conditions which deprive him of use of permissible FSI, then he shall
be entitled for TDR as decided by the Authority in consultation with Heritage Conservation
Committee. The utilization of this TDR shall be as per TDR Regulation.
14.5.6 Maintaining Skyline
Building included in heritage precinct shall maintain the skyline, roof profile, built form
edges, and respect the architectural style (without any high-rise development) as may be
existing in the surrounding area, so as not to diminish or destroy the value and beauty of the
said heritage building/ heritage precinct. The development within the precinct shall be in
accordance with the guidelines framed by the Authority on the advice of the Heritage
Conservation Committee.
14.5.7 Restrictive Covenants
Covenants, terms and conditions, imposed under Regulations existing as on the date of this
Regulation, on the leasehold plots either by the State Government or by the Planning
Authority, shall continue to be imposed, in addition to the UDCPR. However, in case of any
conflict with the heritage preservation interest/ environmental conservation and the said
Development Control and Promotion Regulations, this heritage regulation shall prevail.
14.5.8 Grading of the Listed Buildings/Listed Precincts.
Grade-I Grade-II Grade-III
(A) Definitions
Heritage Grade-I comprises Heritage Grade - II (A and B) Heritage Grade - III comprises
Buildings and precincts of comprises buildings and buildings and precincts of local
National or Historic importance, precincts of Regional importance for townscape, they
excellence in architectural style, importance, possessing special evoke architectural, aesthetic, or
design technology and material architectural or aesthetic merit, sociological interest though not
usage and/or aesthetics; or cultural or historical as in Heritage Grade - II. These
associated with a great historic significance though of a lower contribute to determine the
event, personality, movement or scale than Heritage Grade-I. character of the locality and can
institution. They have been and They are local landmarks, which be representative of life-style of a
are the prime landmarks of the contribute to the image and particular community or region
city and of National importance. identity of the region. They may and, may also be distinguished
be the work of master craftsmen by setting on a street line or
or may be models of proportion special character of the façade
and ornamentation or designed and uniformity of height width
to suit a particular climate. and scale.
(B) Objective
Heritage Grade-I richly Heritage Grade-II deserves Heritage Grade-III deserves
deserves careful preservation. intelligent conservation. intelligent conservation (though
on a lesser scale than Grade-II
and special protection to unique
features and attributes.)
(C) Scope for Change
No interventions be permitted Grade-II (A) External, internal changes and
either on exterior or interior adaptive reuse would by and
Internal changes and adaptive
unless it is necessary in the large be allowed. Changes can
reuse and external changes may by
interest of strengthening and include extensions, and
and large be allowed but subject to
prolonging the life of the additional buildings in the same
strict scrutiny. Care would be
buildings or precincts or any plot or compound. However any
taken to ensure the conservation of
part of features thereof. For changes should be such that they
all special aspects for which it is
this purpose absolutely do not detract from the existing
included in Heritage Grade-II
essential and minimum heritage building/ precinct.
Grade-II (B)
changes would be allowed and
they must be in accordance In addition to the above, extension
with the original. Repairs shall of Additional building in the same
be with the use of like to like plot or compound, in certain
material. circumstances be allowed,
provided that, the
extension/additional building is in
harmony with (and does not
detract from) the existing heritage
buildings or precincts especially in
terms of height, and facade.
(D) Procedure
Development permission for Development permission for the Development permission for the
the changes would be given by changes / additional construction changes / additional construction
the Authority on the advice of would be given by the Authority would be given by the Authority
the Heritage Conservation on the advice of Heritage on the advice of the Heritage
Committee. Conservation Committee. Conservation Committee.
(E) Vistas/ Surrounding
Development
All developments in areas
surrounding Heritage Grade-I
shall be regulated and
controlled by ensuring that it
does not mark the grandeur of
or view from Heritage Grade-I
14.5.9 Signs and Outdoor Display Structures
No display or advertising signs and outdoor display structures on listed building and / or the
Heritage Precincts shall be permitted except accordance with part X (sign and outdoor display
structure) National Building Code of India.
Prohibition of advertising signs and outdoor display structure in certain cases :
Notwithstanding the provisions mentioned above no advertising sign or outdoor display
structures shall be permitted on buildings of architectural, aesthetic, historic or heritage
importance as may be decided by the Authority, Committee or also on Government buildings,
save that in the case of Government buildings only such advertising signs or outdoor display
structures may be permitted that relate to the activities of the said buildings and related
programs.
Provided that, if the Heritage Conservation Committee so advises, the Authority shall refuse
permission for any sign or outdoor display structure.
14.5.10 Composition of Heritage Conservation Committee.
There shall be Heritage Conservation Committee for the areas within the jurisdiction of
Planning Authority and Regional Plan area. This Committee shall be constituted by the
Government in consultation with the Authority. The committee shall comprise of the following
members:-
i) Chairman Appointed by the Government Chairman
ii) Joint Director of Town Planning of the Concerned Division Member
(For the areas excluding Municipal Council and Regional Plan area)
(Assistant Director of Town Planning of the District for Municipal
Councils)
iii) Divisional/ District officer of Archaeological Survey of India Member
iv) Divisional/ District officer of Archaeological Survey of Maharashtra Member
v) Convenor, INTACH Local Chapter Member
vi) Heritage Conservation Architect having more than 10 years of experience Member
and membership of the Council of Architecture
vii) Historian having experience of more than 10 years in the field of History. Member
viii) Structural Engineer having experience of more than 10 years and member Member
of Institute of Engineers.
ix) City Engineer (Planning Authority)/ Chief Planner (Metropolitan Member
Authority or SPA or NTDA) / Chief Officer (Municipal Council) / secretary
Assistant Director of Town Planning of the District. (Regional Plan area)
The tenure of the Chairman and Members of categories (vi) to (viii) above shall change after
every three years provided however that, the same person shall be eligible for re-appointment as
Member.
The Heritage Conservation Committee shall come into existence with effect from the date of its
publication in the official Gazette. However, Heritage Committees constituted by the
Government before coming into force of these regulation, shall remain in operation till further
period as may be specified.
No act of the Committee done in good faith, shall be deemed to be invalid by reason only of
some defect subsequently discovered in the organization of the Committee or in the Constitution
of the Committee or in the appointment of the Member or on the ground that such member was
disqualified for being appointed.
The Chairman and in his absence the chosen Member of the Committee shall preside over the
meeting of the Committee.
14.5.11 The Terms of reference of the Committee :-
i) To advise whether development permission should be granted under this Regulation and
the conditions of such permission.
ii) To prepare a list or supplementary list of buildings, artefacts, structures, areas/ precincts
of historic, aesthetic, architectural, cultural significance and a supplementary list of
natural features of environmental significance including sacred groves, hills, hillocks etc.,
water bodies (and the areas adjoining the same) to which this regulation would apply.
iii) To advise whether any relaxation, modification, alteration, or variance of any of the
Development Control and Promotion Regulations is called for.
iv) To suggest amendments, changes or special regulations or modification to regulations for
listed buildings and the heritage precincts regulated under these regulations
v) To advise on the extent of Development Rights to be granted to the owners of listed
Buildings or Heritage Precincts.
vi) To advise whether development Rights Certificates may be allowed to be consumed in a
heritage precinct.
vii) To advise whether to allow commercial /office user of any listed building of Heritage
Precincts and when to terminate the same.
viii) To advise on erection of outside advertisement/ bill boards.
ix) To recommend guidelines to be adopted by those private parties or any other agency,
who sponsor beautification schemes at public intersections and elsewhere.
x) To advise on the cost of repairs to be given to the owners to bring the existing building
back to the original condition. For this purpose, the Committee may suggest ways to raise
funds through private sources.
xi) To advise on special designs and elements and guidelines for listed buildings and control
of height and essential façade characteristics such as maintenance of the buildings and to
suggest suitable design adopting new materials for replacements keeping the old form
intact to the extent possible.
xii) To advise on preparation of guideline relating to design elements and conservation
principles to be adhered to and to advise on other guideline for the purpose of this
regulation.
xiii) To consider any other issue as may be required from time to time during course of
scrutiny of development permissions and in overall interest of heritage/ environmental
conservation.
In the absence of Heritage Conservation Committee, the Authority shall consult the Government
before giving such permission.
14.5.12 Heritage Conservation Fund
i) Heritage buildings included in the said list shall be maintained by the owners of the said
buildings themselves, with a view to give monetary help for such maintenance/repairs a
separate fund may be created which would be kept at the disposal of the Authority, who
will utilise these funds on the advice of the Heritage conservation Committee. The
Authority may, in such cases disburse appropriate amount to the owner or may get
maintenance/ repair work done through Planning Authority/ Collector.
ii) 2% of total development charges collected shall be transferred to the Heritage
Conservation Fund.
iii) The fund may also be used to support the cost of listing of heritage sites and cost towards
expert guidance and fees for architects, engineers and other expert.
iv) The Authority shall have right to remove any unauthorized construction in the property
enlisted as heritage property and recover the expenses of such removal/ demolition work
from the owner as per provisions of the Act.
v) The Authority shall have right to enter into any such heritage property to repair such
property to avoid any damage or injury, and the amount shall be spent form Heritage
Conservation Fund and shall be recovered from the owner as arrears of taxes due to the
Authority.
vi) If Heritage structure listed in Grade I needs conservation, preservation and immediate
repairs and if the structure is affected due to vandalism by occupier/ owner, then the
Authority shall have right to acquire such heritage property and conserve its heritage
value.
14.6 SLUM REHABILITATION SCHEME FOR PUNE, PCMC, PCNTDA AND NAGPUR.
The slum Rehabilitation Scheme Regulations for Pune, Pimpri-Chinchwad and Nagpur
Municipal Corporation shall be applicable as sanctioned by the Government from time to time.
14.7 SLUM REHABILITATION SCHEME FOR OTHER MUNICIPAL CORPORATIONS.
Slum rehabilitation scheme for other Municipal Corporations, excluding covered in Regulation
No. 14.6, shall be as below.
14.7.1 Eligibility for redevelopment scheme
i) A person eligible for redevelopment scheme shall mean a protected occupier as defined
in Chapter IB of Maharashtra Slums Areas (Improvement, Clearance and
Redevelopment) Act, 1971 as amended time to time, (hereinafter referred to as the Slum
Act) and orders issued there under.
ii) Subject to the foregoing provisions, only the actual occupants of the hutment shall be
held eligible, and the so-called structure-owner other than the actual occupant if any,
even if his name is shown in the electoral roll for the structure, shall have no right
whatsoever to the reconstructed tenement against that structure.
14.7.2 Definition of Slum, Pavement, and Structure of hut
i) Slums shall mean those censused, or declared and notified, in the past or hereinafter
under the Slum Act. Slum shall also mean area/pavement stretches hereinafter notified or
deemed to be and treated as Slum Rehabilitation Areas.
ii) If any area fulfils the condition laid down in section 4 of the Slum Act, to qualify as slum
area and has been censused or declared and notified shall be deemed to be and treated as
Slum Rehabilitation Areas.
iii) Slum Rehabilitation area shall also mean any area declared as such by the SRA though
preferably fulfilling conditions laid down in section 4 of the Slum Act, to qualify as slum
area and/or required for implementation of any slum rehabilitation project. Any area
where a project under Slum Rehabilitation Scheme (SRS) has been approved by CEO,
SRA shall be a deemed slum rehabilitation area.
iv) Any area required or proposed for the purpose of construction of temporary or permanent
transit camps and so approved by the SRA shall also be deemed to be and treated as Slum
Rehabilitation Areas, and projects approved in such areas by the SRA shall be deemed to
be Slum Rehabilitation Projects.
v) A pavement shall mean any Municipal/Govt. /Semi-Govt. pavement, and shall include
any viable stretch of the pavement as may be considered viable for the purpose of SRS.
vi) A structure shall mean all the dwelling area of a protected occupier as defined in Chapter
I-B of Slums Act, and orders issued thereunder.
vii) A composite building shall mean a building comprising both rehab and free-sale
components and part thereof in the same building.
viii) Censused shall mean those slums located on lands belonging to Govt., any undertaking of
Govt., or Corporation and incorporated in the records of the land-owning authority as
having been censused in 1976, 1980, or 1985 or prior to 1st January, 1995, and 1st Jan
14.7.3 Joint ownership with spouse
The reconstructed tenement shall be of the ownership of the hutment dweller and spouse
conjointly, and shall be so entered and be deemed to be so entered in the records of the co-
operative housing society, including the share certificates or all other relevant documents.
14.7.4 De-notification as Slum Rehabilitation Area
SRA on being satisfied that it is necessary to do so, or when directed by the State Govt., shall
de-notify the Slum Rehabilitation Area.
14.7.5 Applicability
The following provisions will apply for redevelopment/construction of accommodation for
hutment/pavement-dwellers through owners/developers/co-operative housing societies of
hutment/pavement-dwellers/public authorities such as MHADA, MIDC, MMRDA etc./Non-
Governmental Organizations anywhere within the limits of Municipal Corporation. However,
NGO should be registered under the Maharashtra Public Charitable Trusts Act, 1961 and the
Societies Registration Act, 1960 at least for the last five years and should also be approved by
SRA.
14.7.6 Right of the Hutment Dwellers
i) Hutment-dwellers, in the slum or on the pavement, eligible in accordance with the
provisions of this Regulation shall in exchange of the protected dwelling structure, be
given free of cost a residential tenement having a carpet area of 27.88 Sq.m. including
balcony, bath and water closet, but excluding common areas.
For this purpose, "carpet area" means the net usable floor area within a tenement
excluding that covered by the walls or any other areas specifically exempted from floor
space index computation as per prevailing Regulation.
ii) Even those protected dwelling structures having residential areas more than 27.88 Sq.m.
shall be eligible only for 27.88 Sq.m. of carpet area where Carpet area means area of
tenements as mentioned in (i) above.
iii) All eligible hutment dwellers taking part in the SRS shall have to be rehabilitated in
accordance with the provisions of these Regulations. It may be in situ and in the same
scheme as far as possible.
iv) Pavement dwellers and hutment dwellers in the slum on land required for vital public
purpose or such location which are otherwise unsuitable for human habitation or non-
suitable due to other statutory restriction shall not be rehabilitated in-situ but in other
available location and in accordance with these Regulations. Competent Authority
appointed by the State Government in Housing Department shall on the basis of
verification of documents, as may be prescribed, shall decide on the eligibility of hutment
dwellers.
v) The eligibility of a person including a transferee, under a scheme of Slum redevelopment
shall be established in accordance with Chapter I B of Slum Act, and orders issued
thereunder.
vi) An individual agreement shall be entered into by the owner/developer/co-operative
housing society/NGO with the eligible hutment-dwellers in the slum/pavement.
vii) An individual agreement entered into between hutment-dweller and the
owner/developer/co-operative society/ NGO shall be in the joint names of pramukh
hutment dweller and spouse for every protected dwelling structure
viii) Hutments dwellers in category having a differently abled person or female headed
households shall be given first preference in allotment of tenements. Thereafter lots shall
be drawn for allotment of tenements from the remaining tenements to the other eligible
hutment-dwellers before grant of occupation certificate to rehab Building.
ix) Transfer of Photo passes- Since, only the actual occupant at present will be eligible for
redevelopment; there shall be no need to regularize the transfers of photo passes that have
occurred so far. A photo pass will be given after the new tenement has been occupied.
x) Any person who owns a dwelling unit on ownership basis in Municipal Corporation
areas, shall not be held eligible under the scheme. Any person who can be held eligible
under more than one SRS, shall be held eligible in only one scheme.
xi) Premium for ownership and terms of lease -That part of Government / Municipal
Corporation /MHADA land on which the rehabilitation component of the SRS will be
constructed, shall be leased to the Co-operative Housing Society of the slum-dwellers on
30 years lease period. Annual lease rent of Rs. 1001 for 4000 per Sq.m. of land or part
thereof shall be payable and lease shall be renewable for a further period of 30 years at a
time. Simultaneously land under free sale component shall be leased directly to the
Society/Association of the purchasers of the tenement under free sale component for 30
years with a provision for further renewal for a period of 30 years at a time. The lease
rent for the free sale component shall be fixed by SRA.
Further, the Developer/Co-op. Housing Society shall pay premium at the rate of 25% of
ASR of the year of issue of LOI, in respect of SRS proposed to be undertaken on lands
owned by Government, Semi-Government undertakings and Local Bodies and premium
shall go to land owing authority such as MHADA, Municipal Corporation, MMRDA, as
the case may be. The premium instalment so recovered shall be remitted to concerned
land owing authority within 30 days from the date of recovery.
In the case of Government land, the premium shall be deposited in Nivara Nidhi.
The amount of premium shall be recovered in instalment as may be prescribed by Govt.
from time to time. Land owning authority such as Municipal Corporation, MMRDA,
MHADA shall not recover land premium in any other form. Proposals for SRS on land
owned by Central Government shall not be accepted unless NOC for the scheme is
obtained from Central Government.
xii) Automatic cancellation of Vacant Land Tenure and leases- If any land or part of any land
on which slum is located is under vacant land tenure, the said tenure/lease created by
Municipal Corporation or Authority shall stand automatically terminated as soon as letter
of Intent is issued by SRA for a SRS, which is a public purpose, on such land is prepared
and submitted for approval to the SRA. Any arrears of dues to be collected by Municipal
Corporation shall not be linked to the issue of any certificate or NOC relating to the Slum
Rehabilitation Scheme.
On sanction of SRS, rights of Imla malik, municipal tenants or any other tenancy shall
stand terminated in respect of the sanctioned SRS.
xiii) Recovery of pending dues such as assessment, compensation, occupational charges, non-
agricultural tax/dues etc. pending with public authorities such as State Govt., MHADA,
and/or Municipal Corporation shall be dealt with separately and not be linked to grant of
approval or building permission to the slum rehabilitation projects.
xiv) A Slum Rehabilitation Project shall be considered preferably when submitted through a
proposed or registered co-operative housing society of hutment dwellers on site. The said
society shall include all the eligible hutment on site while submitting the S.R. Scheme
and give an undertaking to that effect to SRA.
xv) Where 51% percent or more of the eligible hutment-dwellers in a slum and stretch of
road or pavement contiguous to it at one place agree to join a rehabilitation scheme, it
may be considered for approval, subject to submission of irrecoverable written
agreements of eligible hutment-dwellers before LOI. Provided that nothing contained
herein shall apply to Slum Rehabilitation Projects undertaken by the State Government or
Public authority or as the case may be a Govt. Company as defined in Sec. 617 of the
Companies Act 1956 and being owned & controlled by the State Government
xvi) In respect of those eligible hutment-dwellers on site who do not join the Project willingly
the following steps shall be taken:
a) Provision for all of them shall be made in the rehabilitation component of the
scheme.
b) The details of the tenement that would be given to them by way of allotment by
drawing lots for them on the same basis as for those who have joined the Project,
will be communicated to them in writing by the Managing Committee of the Co-
operative Housing Society if it is registered, or the developer. In case of dispute,
decision of the CEO, SRA shall be final and binding on all the parties concerned.
c) The transit tenement that would be allotted to them or rent payable would also be
indicated along with those who have joined the Project.
d) If they do not join the scheme within 15 days after the approval has been given to
the Slum Rehabilitation Project on that site, then action under the relevant
provision including Sections 33, 33(A) and 38 of the Slum Act, as amended from
time to time, shall be taken and their hutments will be removed, and it shall be
ensured that no obstruction is caused to the scheme of the majority of persons who
have joined the scheme willingly.
e) After this action under the foregoing clause is initiated, they will not be eligible for
transit tenement along with the others, and they will not be eligible for the
reconstructed tenement by lots, but they will still be entitled only to what is
available after others have chosen which may be on the same or some other site.
f) If they do not join till the building permission to the Project is given, they will
completely lose the right to any built-up tenement, and their tenement shall be
taken over by the SRA, and used for the purpose of accommodating pavement-
dwellers and other slum dwellers who cannot be accommodated in-situ etc.
xvii) The Managing Committee of the proposed as well as registered Co-operative housing
society of hutment dwellers shall have women to the extent of one-third of the total
strength of actual members on the committee at any time.
xviii) Restriction on Transfer of Tenements; the tenement obtained under this scheme cannot be
sold/leased/assigned or transferred (except to legal heir) in any manner for a period of ten
years from the date of allotment/possession of the tenement. In case of breach of
conditions, except transfer to legal heir, the tenement will be taken over by SRA.
14.7.7 Building Permission for Slum Rehabilitation Project
i) The proposal for each Slum Rehabilitation Project shall be submitted to the SRA with all
the necessary documents, no-objection certificates, and the plans as may be decided by
the SRA from time to time.
ii) Approval to the Project shall be given by the SRA within a period of 60 days from the
date of submission of all relevant documents. In the event of failure by SRA to do so, the
said approval shall be deemed to have been given, provided the Project is in accordance
with the provisions of these Regulations.
iii) The SRA while giving the approval may lay down terms and conditions as may be
necessary.
iv) The SRA shall adopt the procedure laid down in the MR & TP Act, 1966 for giving
building permission to any Slum Rehabilitation Project under this Scheme.
v) On compliance with the terms and conditions, the building permission shall be given, in
accordance with the provisions under section 45 of the MR & TP Act, 1966 to the Project
under the SRS, first to the Rehabilitation component and thereafter to the free-sale
component subject to the provisions in clause below.
vi) Correlation between Rehabilitation and free-sale components: Building permission, for
10 percent of BUA of both the rehab and free-sale components may be given
simultaneously and thereafter proportionately or as may be decided by the CEO, SRA.
vii) Where the Project is being implemented directly by an NGO approved by SRA, CEO
(SRA) may sanction 20 percent of the free-sale component without waiting for any
expenditure on the rehabilitation component. The approval for remaining part of free-sale
component will be given only after at least 30 percent of rehabilitation component is
completed on site.
viii) As soon as the approval is given to the Project, the NOC for building permission of the
landowning authority shall be given in respect of that slum located on lands belonging to
any department, undertaking, agency of the State Govt. including MHADA, or any local
self-Government such as the Municipal Corporation within 60 days after the intimation
of such approval to the Project is communicated. In the event of its refusal to grant NOC,
reasons thereof shall be stated and in the event of its not being given within the period, it
shall be deemed to have been given‘.
ix) Occupation certificate shall not be held up only for want of lease documents to be
executed, in all slum rehabilitation projects taken up on lands belonging to any
department, undertaking, agency of the State Govt., including MHADA, and any local
self-Government such as the Municipal Corporation.
14.7.8 Rehabilitation and Free-Sale Component
i) FSI for rehabilitation of eligible slum/pavement-dwellers includes the FSI for the rehab
component, and for the free-sale component. The ratio between the two components shall
be as laid down herein below.
ii) Built up area (BUA) for rehabilitation component shall mean total construction area of
rehabilitation component, excluding what is set down in Regulation 14.7.9 (vi) of these
Regulations, but including areas under staircases, passages, anganwadi, health center /
outpost, community hall /gymnasium / fitness center, skill development center, women
entrepreneurship center, yuva kendra/ library, Balwadi/s society office, religious
structures as permitted under Government Home Department Resolution dt.05/05/2011
and 18/11/2015, other social infrastructure like School, Dispensary, Gymnasium run by
Public Authority or Charitable Trust, 5 percent incentive commercial areas for the Co-
operative society, and the further 5 percent incentive commercial area for the NGO,
Govt./Public Authority/Govt. Company wherever eligible.
iii) The incentive FSI/BUA shall depend on size of the scheme and rate of developed land
and rate of construction as per ASR of year in which LOI is sanctioned.
Basic Ratio Incentive as per scheme
(LR/RC*) Upto 0.20 More than More than More than For more
ha 0.20 ha upto 0.40 ha 1 ha upto 5 than 5 ha
0.40 ha upto 1 ha ha
Above 2.00 (1)1.50 (1)1.60 (1)1.75 (1)2.00 (1)2.25
Above 1.50 and (1)1.60 (1)1.75 (1)2.00 (1)2.25 (1)2.50
upto 2.00
Above 1.00 and (1)1.75 (1)2.00 (1)2.25 (1)2.50 (1)2.75
upto 1.50
upto 1.00 (1)2.00 (1)2.25 (1)2.50 (1)2.75 (1)3.00
 RC is the rate of construction in respect of RCC Construction and LR is the Land Rate of
open Land. FSI to be sanctioned on a Slum Rehabilitation scheme site may exceed 4.00.
(1)Note - 1 : In Case of any Slum Redevelopment Scheme is in progress and any Slum
redevelopment scheme where LOI has been issued, envisaging construction of rehabilitation
tenements having individual carpet area of 25.0 sq.mt., if full occupation permission has not
been granted and if it is structurally not feasible to provide rehabilitation tenements having
individual carpet area as per these regulation, without having completely pull down and
reconstructed the on-going rehabilitation building(s). Permissible sale component vis-à-vis
rehab component shall be 1.25:1 subject to maximum in-situ FSI of 4.0.
(1)
Inserted vide Notification u/s 37 (1AA)(c) & 20(4) No.CR 236/18 (Part-3), dt.3rd February, 2022
iv) (1)Maximum FSI permissible that can be sanctioned on any slum site shall be 4.0 or
sum of total of rehabilitation BUA plus incentive BUA, whichever is more, with
minimum tenement density of 650 per net hectare. Due to local planning constraints
and viability of Slum Rehabilitation Project, the tenement density norms of 650 per net
hectare may be reduced upto 25% by Chief Executive Officer, SRA, subject to
minimum tenement density of 500 per net hectare. In such cases, maximum
permissible in-situ / total FSI shall be restricted to sum of rehabilitation and incentive
BUA which may be generated in the scheme after such relaxation of tenement density.
The computation of FSI shall be done for both rehab and free-sale components in the
normal manner, that is giving the benefit of what is set down in Regulation No. 14.7.9
(vi). While the areas referred in sub Regulations No.14.7.11 (vi) and 14.7.13 (ii) of this
Regulation shall not be included for computation of FSI, and the said areas shall be
included for computation of the rehab component. In all cases where permissible in-situ
FSI cannot be utilised in situ the difference between permissible FSI and that can be
constructed in-situ, will be made available in the form of TDR in accordance with the
provisions of Regulation 11.2.
v) Notwithstanding the provisions in (iv) above, the slum dweller society/NGO/Developer
undertaking the scheme may opt to claim TDR in lieu of sale component available for the
scheme, on account of constraints such as height restrictions, uneconomical site
conditions, etc.; if the full permissible FSI cannot be used on the same site, TDR may be
allowed as may be necessary without consuming permissible FSI on the same site.
However, TDR may be allowed only when the frame work for one complete building in
rehab component is constructed or when 10% of the rehab component has been
constructed on site and the said TDR will not exceed 50 percent of the construction of
rehab component at any point of time till the total rehab component has been completed.
On completion of the total rehab component balance TDR will be allowed.
vi) The rehabilitation component shall mean all residential tenements as well as non-
residential built-up premises given free of cost in accordance with the provisions of the
SRS outlined in this Regulation excluding what is set down in Regulation 14.7.9 (vi) and
including anganwadi, health centre / outpost, community hall /gymnasium / fitness
centre, skill development centre, women entrepreneurship centre, yuva kendra /library
existing eligible religious structure, school, dispensary, gymnasium run by Public
Authority or charitable trust etc. as per provision of 14.7.13 (i) &(ii) but excluding built-
up area given for buildable DP reservations.
vii) Notwithstanding anything contained in this regulation, if rehabilitation project of a slum
located on land belonging to public authority and needed for a vital public purpose and
where eligible slum dwellers which cannot be accommodated in the in-situ SRS of land
under non-buildable reservations, is taken up on an unencumbered plot, TDR as per
Regulation No.11.2 for the area of the land spared for this purpose shall be sanctioned to
the owner of the said unencumbered plot and the TDR in lieu of cost of construction of
BUA as per Regulation No. 11.2 shall be permissible. For the purpose of this regulation
BUA shall be as per Regulation No. 14.7.8 (ii) of this Regulation. Following conditions
shall be applicable for such scheme.
a) The Rehabilitation Project is approved by the SRA.
b) The tenements so constructed in execution of the Project are offered to slum
dwellers located on land belonging to Govt. or Public Authority and needed for
(1)
Inserted vide Notification u/s 37 (1AA)(c) & 20(4) No.CR 236/18 (Part-3), dt.3rd February, 2022
vital public purpose and within 270 days from the date of issue of LOI the Agency
shall identify the slum dwellers.
c) If the Agency fails to identify the slum dwellers needed to be shifted for a vital
public purpose, as above, then the tenements so constructed shall be offered;
i) To the slum dwellers located on land belonging to Government or Public
Authority within a distance of 2 km. from the land on which the Project is
undertaken, or
ii) To the slum dwellers located anywhere in the Corporation limit on lands
belonging to Govt. or Public Authority,
d) Further provided that in all above cases the relocation of. slum dwellers in any case
will be undertaken not with reference to individuals but reference to assembly of
slum dwellers for the purpose of releasing the plot of land wholly from slums and
not only the patches of land.
Provided further that, these provisions are also applicable to lands belonging to or
leased out to or leased out by a Public Authority, a Statutory Authority, a Public
Sector undertaking or any Department of Government of India and a Joint Venture
with any of them, subject to payment of premium for infrastructure development as
applicable under Regulation No. 14.7.14 (ii) of this Regulation.
e) No sale component shall be permissible.
f) In case of slums on municipal lands, there will be as option to exercise the powers
of CEO, SRA by the Municipal Commissioner with the prior approval of the
Government.
viii) All non-residential built-up areas shall be included in the computation of minimum
density but on the scale of 20.90 sq. m of carpet area being one tenement.
Provided further that in case of slum redevelopment where there are no eligible
commercial slum dwellers and where it is possible to provide commercial tenements on
ground floor, then in such cases commercial PAP tenements of size of carpet area 20.90
Sq.m. (225 Sq.ft.) or of required size shall be provided as decided by CEO(SRA) and
same shall be handed over free of cost to SRA.‘
Provided if SRS is undertaken by a Federation, Co-Op. Housing society consisting of
members who are serving or retired State Govt. Employees/Employees of the State Govt.
Undertakings/Employees of local bodies of State Government for providing housing to
its members, such tenements which are generated over and above the tenements to be
provided to the existing eligible hutment dwellers, shall be handed over back to the said
Federation/Co.-operative Housing Society for providing housing to its above mentioned
members and subject to further additional terms and conditions as would be imposed by
the CEO, SRA to ensure adequate membership of class III and class IV employees.
ix) Any land declared as slum rehabilitation area or on which slum rehabilitation project has
been sanctioned, if it is spread on part or parts of C.S. Nos. or CTS Nos. or S.Nos. or F.P.
Nos. shall be treated as natural amalgamation/subdivision/s of that C.S. or CTS or S. No.
or F.P. No. for which no separate approval for amalgamation/subdivision of land would
be necessary.
x) Boundaries and the Slum Rehabilitation Area shall be declared by the competent authority
after actual measurement of plot area on site and the same shall be adopted for planning
purpose for calculation of density and floor space index.
xi) The CEO, SRA may if required, adjust the boundary of the plot declared as slum
rehabilitation area so as to suit the building design and provide proper access to these
Scheme. Provided further that the encumbered area under D P Road/Sanctioned Regular
line road abutting the SRS shall be included in the scheme to be developed.
xii) After approval is given to the Slum Rehabilitation scheme, the area may be further
subdivided if necessary to earmark separate plots for the rehab component and the free
sale component. The Plot area and the built-up area in terms of square meters on the said
plot shall be separately mentioned in the lease agreements and Record of Rights.
xiii) The CTSO/SLR, of the district on payment of such fees as may be decided by the Govt.
ensure that the City Survey sheet and property cards are corrected accordingly and fresh
property cards are opened for each of the plots giving details regarding the area of the
plots and the total area of the floors of the built-up property and TDR given that is, the
FSI used on that plot.
14.7.9 Temporary Transit Camps
i) The multi-storeyed temporary transit camp shall be provided on the site itself or outside
the SRA project site on portion of plot which is not designated/reserved for public
purpose or not affected by road widening and is preferably close to the site.
ii) The eligible slum dwellers shall be shifted to temporary transit camp or on rent as may be
mutually decided between the proposed society and developer.
ii) The area of temporary transit tenements shall be excluded from the computation of FSI,
but the safety of the structure shall be ensured by a license structural consultants. The
minimum area of individual transit tenement shall be14.5 Sq.m.
iv) Such building permission shall be given within 15 days from the date of application and
after approval to the project by Slum Rehabilitation Authority, failing which it shall be
deemed to be given.
v) On any nearby vacant site without any reservation in the DP construction of temporary
transit tenements made of light material with the consent of the landowners, shall be
allowed upto an FSI of 3.0 and this shall be applicable. Temporary shall mean made of
detachable material such as tubular/prefabricated light structures.
vi) In all such cases where the temporary transit camp is erected, the condition shall be that
the structures shall be demolished by the Developer/Society/NGO within 30 days of
granting Occupation Certificate to the rehab buildings and the site should be brought
back to the original state. Till the transit camps are fully demolished, development rights
for the free sale area shall not be permitted to be used beyond 75% of the total admissible
free sale area permissible under this Regulation.
14.7.10 Commercial / Office / Shop / Economic Activity Free of Cost
i) The eligible existing area under commercial/office/economic activity shall be computed
on actual measurement/inspection, and/or on the basis of official documents such as
License under the Shops and Establishment Act, Electricity bills, Photo pass etc.
ii) In the rehabilitation component, the BUA for commercial/office/shop/economic activity
that existed prior to the date as decided by the Government subject to the provisions in
the sub-regulation below shall be given. Where a person has both residential and
commercial premises without common wall between residential and commercial
premises, for commercial/office/shop/economic activity in the slum/ pavement, he shall
be considered eligible for a residential/Commercial unit including BUA for
commercial/office/shop/economic activity, both free of cost and carpet area of such unit
shall not exceed 27.88 Sq.m.
iii) BUA for commercial/office/shop/economic activity upto 20.90 Sq.m. (225 Sq.ft.) carpet
area or actual area whichever is less, shall be provided to the eligible person free of cost
as part of the rehabilitation project. Any area in excess of 20.90 Sq.m. to the extent of
existing area may, if required, be sold on preferential basis at the rate for commercial area
in the free-sale component.
For this purpose, "carpet area" as per (i) and (ii) above means the net usable floor area
within a tenement excluding that covered by the walls or any other areas specifically
exempted from floor space index computation as per prevailing Regulation.
iv) Such area may be allowed on any side of the plot abutting 3.0 m. wide pathway and
deriving access from 3.0 m. wide pathway/open space. Back-to-back shopping on ground
floor shall also be allowed for the purpose of rehabilitation. After exhausting these
provisions, it may be allowed on the first floor to the extent necessary.
v) All activities which were previously existing shall be allowed to be relocated regardless
of the non-conforming nature of the activities, except those which are hazardous and
highly polluting, and except in cases where the alternative accommodation has already
been allotted elsewhere by the Municipal Corporation.
vi) Convenience shopping in the free-sale component shall be permitted along the layout
roads. The CEO, SRA may add to alter or amend the said list for convenience shopping.
vii) Incentive Commercial Areas for Society and NGO
a) The scheme, when undertaken by a Co-operative Housing Society of slum dwellers,
may provide an additional 5 per cent built-up area on the rehabilitation area free of
cost for commercial purpose. This area will be at the disposal of the Co-operative
Housing Society of the hutment-dwellers. The corpus amount shall not be spent,
but the income from the property/corpus alone shall be used by the Society for
maintenance of the building and premises, and such other purposes as may be laid
down by the SRA.
b) Where the scheme is undertaken by a Non-Government Organization Govt. or
Public Authority or Govt. Company another additional 5 per cent BUA on the
rehabilitation area may be given free of cost for commercial purpose. This area
shall be at the disposal of the Non-Governmental Organization Govt. or Public
Authority or Govt. Company in consultation with the cooperative housing society.
14.7.11 Relaxation in Building and Other Requirements
i) Separate kitchen shall not be necessary. Cooking space (alcove) shall be allowed without
any minimum size restrictions. Where a kitchen is provided, the minimum area shall be 5
Sq.m. provided the width shall be at least 1.5 m.
ii) There shall be no size restriction for bath or water closet unit. Moreover, for bathroom,
water closet or kitchen, there shall be no stipulation of one wall abutting open space, etc.
as long as artificial light & ventilation through any means are provided.
iii) In water closet flushing system shall be provided with minimum seat size of 0.46 m. (18
inches).
iv) A septic tank filter bed shall be permitted with a capacity of 150 litters per capita, where
the municipal services are likely to be available within 4-5 years.
v) In the rehabilitation component, lift shall not be insisted upon, upto ground plus five
floors.
vi) Notwithstanding anything contained in this regulation areas of common passages not
exceeding 2.0 m. in width provided in rehabilitation component to give access shall not
be counted towards FSI even while computing FSI on site.
vii) Where the location of the plot abuts a nallah, the marginal open space along the nallah
shall not be insisted upon beyond 3m. from the edge of the trained nallah provided at
least on one side of nallah, marginal open space of 6 m. is provided.
viii) The distance between any two rehab/composite buildings shall be as follows,
a) For building with height up to 40 m. - Min 6m.
b) For building with height above 40 m upto 50 m. - Min. 7.50 m.
c) For building with height above 50 m upto 70 m. - Min. 9.00 m.
d) For building with height above 70 m. - Min. 12.00 m.
(1) The marginal distances from the front side and rear boundaries of the plot shall be
maintained as follows-
a) If the slum rehabilitation site fronts on one or more roads, every side abutting on
such roads shall be treated as front side & marginal distances prescribed below for
such front side shall apply. The front marginal distance shall be measured from the
proposed road widening line in the plot, if any.
b) In congested area, the front marginal distance shall be minimum 1.5 m.
c) In non-congested area the front marginal distance shall be minimum 4.5 m. for
purely residential building and 6.00 m. for mixed use buildings.
d) Side and rear marginal distances from the side and rear boundaries of the plot shall
be minimum 3.0 m. for height upto 24.00 m. It shall be increased proportionately
with increase in height above 24.00 m, but shall not exceed 6.0 m. for height upto
45.00 m. For building height more than 45.00 m. relaxation to the extent of 50% in
all marginal distances may be given, subject to minimum 6.0 m.
e) Front marginal open spaces for building having height upto 24.00 m. in the rehab-
component or composite building shall be 4.5 m. & 6.00 m. for buildings having
height more than 24.00 m.
ix) A composite building shall contain at least 50 percent of the built-up area as
rehabilitation components.
x) Wherever more than the minimum front and marginal spaces have been provided, such
additional area provided may be considered as part of the amenity open space in the
project comprising both rehabilitation and free sale components, and without charging
any premium.
xi) Even if the amenity space is reduced to make the project viable a minimum of at least 8%
of amenity open space shall be maintained at ground level.
xii) Between the dimensions prescribed for the pathway and marginal distances, the larger of
the two shall prevail. The pathway shall act as access wherever necessary. The building
shall be permitted to touch pathways.
(1) Inserted Vide Corrigendum / Addendum No.CR 79/2021, dt. 02nd December 2021.
xiii) The means of access shall be normally governed by the provisions of Regulation No.3.2.
However, in the project, wherever the design of the buildings in the same land requires
relaxation, it may be given. Access through existing pathways including the roads
maintained under relevant section of the MMC Act, 1949 but not less than 3.6 m. in
width, shall be considered adequate for any slum rehabilitation project, containing
buildings having height up to 24 m. including stilts.
xiv) Premium shall not be charged for exclusion of staircase and lift-well etc.
xv) All relaxations outlined hereinabove shall be given to the rehabilitation component, and
also to the composite buildings in the project. Premium shall not be charged for all or
any of the relaxations given hereinabove. Provided that if any further relaxation in open
spaces is granted by Chief Executive Officer then the same shall be subject to compliance
of CFO requirement and recovery of premium at the rate 2.5% of ASR. . In case of Slum
Rehabilitation Schemes under this regulation, the amount of premium shall be computed
as per the ASR rate prevailing at the time of issue of IOA and the same shall be
recovered at the time of grant of full occupation permission to the respective building.
All other redevelopment schemes shall be governed by their respective regulations.
xvi) Relaxations for the free sale component-Relaxation contained in sub Regulation No. (viii)
above, as well as other necessary relaxation shall be given to the free sale components on
payment of premium at the rate of 2.5% of Ready Reckoner Rate or 10% of normal
premium whichever is more.
xvii) In order to make the SRS viable, the CEO of SRA shall be competent to make any
relaxation wherever necessary for reasons to be recorded in writing.
xviii) For rehabilitation tenements, car parking at the rate mentioned in these Regulation shall
be provided or one parking spaces per tenement for two-wheeler shall be provided. The
above parking spaces may be provided in any combination.
14.7.12 Slums and Development Plan Reservations:
Slums situated in lands falling under various reservations/zones in the DP shall be developed in
accordance with the following provisions.
i) Slums in any zone shall be allowed to be redeveloped in-situ without going through the
process of change of zone. In the free-sale component in any zone, in addition to
residential uses, all the uses permitted for the original zone shall be permitted. For
industrial uses, the segregating distance shall be maintained from the existing industrial
unit.
a) Any plot / layout having area under non-buildable/open space reservations
admeasuring up to 500 Sq.m. shall be cleared by shifting the slum-dwellers from
that site.
b) Where the area of site having non-buildable/open space reservation, is more than
500 Sq.m. such sites may be allowed to be developed for slum redevelopment
subject to condition that the ground area of the land so used shall not be more than
65% of the reservation and leaving 35% rendered clear thereafter for the
reservation.
ii) Existing slum structures on lands reserved for Municipal School/ Primary and secondary
school or a Higher Education may be developed subject to the following:-
a) In case of land reserved for Municipal School, Primary and secondary school in the
DP, a building for accommodating such number of students as may be decided by
the Municipal Commissioner, nor in any case for less than 500 students, shall be
constructed by the owner or developer at his cost according to the size, design,
specification and conditions prescribed by the Municipal Commissioner. The built-
up area occupied by the constructed building shall be excluded for the purpose of
FSI computation, and where it is intended for a Municipal School, the building or
part thereof intended for the school use shall be handed over free of cost and
charge to the Corporation. Thereafter, the land may be allowed to be redeveloped
with the full permissible FSI of the plot according to this Regulation
b) In the case of lands affected by the designation or reservation of a Higher
Education in the DP, a building for accommodating such number of students as
may be decided by the Municipal Commissioner, not in any case for less than 800
students, shall be constructed by the owner or developer at his cost according to
the size , design, specification and conditions prescribed by the Municipal
Commissioner, the built-up area occupied by the constructed building shall be
excluded for the purpose of FSI computation. The constructed building shall be
handed over to the Corporation free of cost and charge and the Authority may hand
over the same or part thereof intended for the School use to a recognized and
registered educational institution for operation and maintenance on terms decided
by him. Thereafter the land may be allowed to be redeveloped with full permissible
FSI of the plot according to this Regulation.
c) In case area under reservation of Municipal School/ Primary and secondary school
or a Higher Education is spread on adjoining plot and the plot under development,
then in such cases Commissioner with special permission may insist upon
construction of Municipal School or a Higher Education in proportion to the area
under reservation affecting the plot under development. Requirements of Play
Ground as per these regulations may not be insisted for (i) above.
iii) For other buildable reservations excluding Municipal School or a Higher Education on
lands under slum built-up area equal to 25 percent of the area under that reservation in
that plot, shall be demanded free of cost by the Slum Rehabilitation Authority for the
Municipal Corporation or for any other appropriate Authority.
iv) In case of the plot reserved for the Parking Lot 125% built up area as per zonal basic
permissible FSI of such reserved area shall be handed over to the Municipal Corporation.
The developer/owner shall be entitled for the Built up Area (BUA) in lieu of cost of
construction against handing over of built up amenity.
v) Existing slum structures on lands reserved for Rehabilitation & Resettlement shall be
treated as sites for development of slum structures and shall be allowed for
redevelopment according to this Regulation.
vi) Slum Rehabilitation Permissible on Town Planning Scheme Plots :-
Slum Rehabilitation scheme can be taken up on the final plots of the Town Planning
Scheme, as per these regulations and further as per conditions given below.
a) Such slum should be notified slum.
b) If the owner of a final plot in the Town Planning Scheme has already accepted or
accepts the possession of the plot along with encroachments and has developed /
develops the remaining vacant plot with full permissible FSI of the entire Final Plot
retaining encroachments on his plot, then the slum rehabilitation scheme on
encroached plot shall be developed as follows :-
i) The Slum Rehabilitation Scheme shall be entitled for FSI as per these
regulations.
ii) The owner of Final plot can develop the slum rehabilitation scheme subject to
condition that in-situ FSI of the scheme shall be reduced to the extent of the
FSI of such encroached plot already utilized in the remaining vacant plot.
iii) The owner shall demarcate the area in his plot which is occupied by the slum
encroachments and transfer such land in the name of the Authority. The
Authority on its own or through the Co-Op Housing of Hutment dwellers may
initiate Slum Rehabilitation Scheme on the encroached area of Final Plot.
Further, the Authority shall record the number of tenements, names of
occupiers, area occupied of the time of granting permission.
14.7.13 Anganwadi, Health Centre / Outpost, Community Hall /Gymnasium / Fitness Centre, Skill
Development Centre, Women Entrepreneurship Centre, Yuva Kendra / Library Society
Office, and Religious Structures:
i) There shall be Balwadi, Welfare hall and any of two amenities mentioned above. There
shall be health Centre/ outpost, Anganwadi, skill development centre, women
entrepreneurship centre, yuva kendra / library of size 27.88sq.m. for every multiple or
part of 250 hutment dwellers. In case of misuse, it shall be taken over by the SRA which
will be competent to allot the same to some other organization /institution for public use.
Balwadi shall also be provided for on a similar scale. An office for the Co-operative
housing society shall be also constructed for every 100 rehab tenements in accordance
with these Regulations. However, if the number of rehab tenements exceeds 100 then for
every 100 rehab tenements such additional society office shall be constructed. There shall
be a community hall for rehab bldg. of the Project as a part of the rehabilitation
component. The area of such hall shall be 2% of rehab built up area of all the buildings or
200 Sq.m. whichever is less.
Religious structures existing prior to redevelopment, if allowed in accordance with the
guidelines issued by Government from time to time as part of redevelopment shall not
exceed the area that existed prior to redevelopment. Other social infrastructure like
School, Dispensary and Gymnasium run by Public Authority or Charitable Trust that
existed prior to the redevelopment shall be allowed without increase in existing area.
However, it is provided that in the slum rehabilitation project of less than 250 hutments,
there shall be Balwadi, Welfare hall and any of two amenities mentioned above, as
decided by co-operative housing society of slum dwellers, of size of 27.88 Sq.m. and
office for the Co-operative housing society in accordance with these Regulations. CEO,
SRA may permit accumulation of the amenities mentioned above but ensure that it shall
serve equitably to the rehab area.
ii) All the areas underlying Anganwadi, health centre / outpost, community hall /gymnasium
/ fitness centre, skill development centre, women entrepreneurship centre, yuva kendra /
library community hall/s, society office, balwadi/s, religious structure/s, social
infrastructure like School, Dispensary, Gymnasium run by Public Authority or Charitable
Trust, the commercial areas given by way of incentives to the co-operative society and
the non-government organisation shall be free of cost and shall form part of rehabilitation
component and it is on this basis the free-sale component will be computed.
iii) Anganwadi, health centre/ outpost, community hall /gymnasium / fitness centre, skill
development centre, women entrepreneurship centre, yuva kendra / library society office,
Balwadi/s and religious structures, social infrastructure like School, Dispensary and
Gymnasium run by Public Authority or Charitable Trust in the rehab component shall not
be counted towards the FSI even while computing permissible FSI on site.
14.7.14 Payments to be made to SRA and Instalments:
i) An amount of Rs.40,000/- or such an amount as may be decided by the Planning
Authority from time to time per tenement including the welfare hall and balwadi in the
rehab component as well as in the case of permanent transit camp tenements will have to
be deposited by the owner/developer/society with the Slum Rehabilitation Authority, in
accordance with the time-schedule for such payment as may be laid down by the CEO,
SRA. However, by the time of completion of construction for occupation of tenements by
the hutment dwellers, the total amount at the rate of Rs.40,000/- per tenement completed
should have been deposited in full. The building permission for the last 25 percent of the
free-sale component would be given only after all the required amount is deposited in full
with SRA.
ii) An amount at the rate of 2% of ready reckoner rate as prevailing on the date of issue of
LOI per Sq.m. such an amount as may be decided by GOM from time to time shall be
paid by the Owner/Developer/Society/NGO for the BUA over and above the Zonal
(basic) FSI, for the rehabilitation and free-sale components. This amount shall be paid to
the SRA in accordance with the time-schedule for such payment as may be laid down by
the CEO, SRA provided the instalments shall not exceed beyond the completion of
construction. This amount shall be used for Schemes to be prepared for the improvement
of infrastructure in slum or slum rehabilitation areas. These infrastructural charges shall
be in addition to development charges levied as per section 124 of MR&TP Act 1966.
Provided that out of amount so recovered as Infrastructural charges, 90% amount will go
to Municipal Corporation and 10% amount will remain with SRA
14.7.15 Conversion of Old Project into New Project:
i) Projects, where LOI has been granted, shall be treated as per the provisions existing on
the date of LOI. In case such a project comes up for revised LOI or change of developer
or any other change, including recording and resubmission without change in slum
boundary, these regulations shall apply. Provided further that for amalgamation of
schemes being sought and for schemes that have been sanctioned under different
regulations (earlier as well as current one), FSI calculations shall apply as per these
regulations.
ii) Exceptions
a) Schemes approved prior to coming into force of these Regulations:-
The slum rehab schemes where LOI has been issued by SRA prior to the date of
coming into force of these Regulations and which is valid may continue to be
governed by the regulation applicable prior to these Regulations.
b) Wherever the S.R. Scheme sanctioned by CEO (SRA) is under progress on
reservations shall be valid & continue.
iii) In case of conversion of old SRD Scheme to new S.R.Scheme on land owned by Govt.
Semi Govt. undertaking and local bodies, the developer shall pay the premium at the rate
of Twenty Five percent of land value as per the ASR in proportionate to difference of FSI
sanctioned in old SRD Scheme and new S.R.Scheme. Payment of premium shall not be
applicable to those schemes wherein lease already executed by concerned authorities.
14.7.16 Provision relating to Permanent Transit Camp Tenements for Slum Rehabilitation Scheme
implemented on open plot / non-slum plot.
Total FSI on plot area may be allowed to be exceeded upto 4 for construction of Transit Camp
tenements for SRA.
i) The FSI and distribution of additional FSI for the construction of Transit Camp
Tenements shall be as shown below -
Minimum Total Zonal Additional RSI for transit % FSI for
Road Permissible FSI FSI tenements for sale
Width FSI SRA of total component of
additional FSI total add FSI
Below upto 3.00 1.00 upto 2.00 50% 50%
9.00 m.
9.00 m. upto 4.00 1.00 upto 3.00 50% 50%
and above
ii) Such schemes shall not be permissible on lands reserved in the Development Plan and
Zone in which Residential development is not permissible.
iii) Transit tenements for SRA out of additional FSI could be used for construction of Transit
Camp of tenements having carpet area of 27.88 Sq.m. Ground floor shall be used for
commercial tenement having carpet area of 20.90 Sq.m. (225sq.ft.) for project affected
commercial tenements and same shall be handed over free of cost to SRA. Alternatively,
residential tenements can be used for Government Staff Quarters etc.
iv) Provision of Anganwadi, Health Centre / Outpost, Community Hall / Gymnasium /
Fitness Centre, Skill Development Centre, Women Entrepreneurship Centre, Yuva
Kendra / Library, Society Office, Balwadi, shall be as per Regulation No. 6.14.4 of this
DCR to these transit camps 25% of basic FSI shall be exclusively used for the purpose of
shops along layout road for use of residential occupants of layout.
v) Additional FSI over and above basic FSI may be released in co-relation to the BUA of the
tenements that are required to be handed over free of cost to SRA / Authority as the case
may be. Alternatively, TDR in lieu of unconsumed sale component of additional FSI, as
per this Regulation, may be permitted for Permanent Transit Camp (PTC) for which SRA
will be the Planning Authority.
vi) Only after the Transit Camps are handed over free of cost to the SRA, the Occupation
Certificate, water connection, power connection etc. for the other portion shall be given
by the Appropriate Authority.
vii) Clubbing - The entire rehabilitation components including base FSI may be categorised as
rental housing and permanent transit component as applicable and the corresponding sale
components from the additional FSI amongst two or more schemes under this regulation
can be permitted to be interchanged. A developer / developers making an application
under this regulation may club more than one plot belonging to single or multiple owners
and offer permanent transit component on a single plot while shifting sale component as
well as base FSI of the plot to other plot agree and make a joint application. However,
clubbing shall be allowed only if it leads to an independent plot / building / wing as the
case may be with permanent transit component being handed over to Authority.
The developer shall have to pay premium equal to 40% of unearned income calculated
with the rates of construction as well as sale given in ASR of the year of payment. The
unearned income shall be computed by calculating valuation of sale component awarded
in lieu of component for Authority after deducting cost of construction of sale as well as
Authority's component and the cost incurred to various authorities towards statutory
payments relating to Authority as well as sale component. In case there is shifting of
base FSI within plots in clubbing scheme, difference of land valued in ASR shall be
taken into account while finalising unearned income, and this difference shall be
calculated as 100% towards premium.
Such clubbing can be allowed for the schemes falling within the distance of 5Km.
The premium shall be paid to the Authority in two stages 50% at the time IOA and 50%
at the time of issuing C.C. for the incentive FSI, or the developer has to surrender
equivalent sale FSI in form of constructed BUA to the extent of premium in the scheme
to be valued at ASR rate of sale in the year of such surrender of built-up area.
Note - Out of the total premium amount so collected under rehabilitation scheme under this
these Regulations, 2/3 shall be kept in a separate account to be utilized as shelter fund for
the State of Maharashtra and 1/3 shall be deposited at the District Office of the Town
Planning Department.
14.8 URBAN RENEWAL SCHEME
Urban Renewal Scheme (URS) shall be applicable for all Corporation as given below.
14.8.1 Urban Renewal Scheme (URS) for Municipal Corporation Area.
i) "Urban Renewal Scheme" (URS) means any scheme for redevelopment of a cluster or
clusters of buildings and structures in Municipal Corporation Area, over a minimum area
of 10,000 Sq.m., in non-congested area and 4000 Sq.m. in congested area, bounded by
existing distinguishing physical boundaries such as roads, Nallahs, railway lines etc.
accessible by an existing or proposed D P road which is at least 18 m. wide and identified
for urban renewal:-
(1)However, in specific cases, in which URS is not bounded by roads, Nallahs and
railway lines etc. and / or, areas of any vacant or encroached land situated in the
periphery of 400 mt. belonging to Municipal Corporation / any Public Authority /
Planning Authority / Special Planning Authority, which is not contiguous, is proposed
to be included in the URS, then the boundaries of such cluster having non-contiguous
area can be decided/ finalised the by Municipal Commissioner, in consultation with
High Power Committee (H.P.C.).
However, in specific cases, in which URS is not bounded by roads, Nallahs and railway
lines, then the boundary of the cluster can be decided/ finalised by Municipal
Commissioner, in consultation with High Power Committee (H.P.C.)
(1)
Inserted vide Notification u/s 37 (1AA)(c) & 20(4) No.CR 236/18 (Part-4), dt.28th December, 2022
In case of demonstrable hardship such as natural sub division by roads, Nallahs, river,
railway lines, the area of the cluster can be allowed up to an area of 8000 Sq.m. in non-
congested area which shall be allowed by Municipal Commissioner in consultation with
H.P.C.
However no forest land shall be included in such URS.
(2)Provided that encroached forest land may be included in such URS for clearance of
encroachment on such forest land with NOC of Forest Department. However after
clearance of encroachment, such forest land shall be used as mentioned in regulation
14.8.7 (i) (g) with NOC of Forest Department.
ii) Such URs may be :-
a) Under the Development Plan (DP), where the DP contains such well-defined
Clusters ; or
b) Under the Urban Renewal Plan (URP) for the concerned area, prepared and
notified by the Commissioner, who may revise the same, as and when required ; or
c) By the Promoter of the Urban Renewal Scheme over a cluster or clusters of
buildings, where such clusters are not shown on the DP and the URP is yet to be
prepared. If such plans are submitted and approved, these shall mean to be URP
within the meaning of this Regulation.
iii) Building Age Criteria for URC shall be as under :-
The Urban Renewal Cluster (URC) may consist of a mix of structures of different
characteristics such as -
a) Unauthorized buildings which are at least 30 years of age ;
b) Authorized dilapidated buildings, as determined by (1) the Designated Officer
appointed by Municipal Commissioner or as per the Regulation of Redevelopment
of Dilapidated Buildings;
c) Authorized buildings which are at least 30 years of age;
d) Buildings belonging to the Central Government, the State Government, Semi-
Government Organizations and Municipal Corporations, as well as Institutional
Buildings, Office Buildings, tenanted Municipal Buildings, Staff Quarter Buildings
of Municipal Corporation , that are at least 30 years of age with prior consent of
the respective Authority ;
e) Any land belonging to the State Government, any Semi-Government Organization,
Municipal Corporation and MHADA (either vacant or built upon) which falls
within the area of the proposed Urban Renewal Scheme including that which has
been given on lease or granted on the tenure of Occupant Class II, provided that if
built upon, these building shall be at least 30 years of age ;
f) Any other buildings which may be less than 30 years of age but which by reasons
of dis-repair or because of structural / sanitary defects, are unfit for human
habitation or by reasons of their bad or sub-optimal configuration or the
narrowness of streets are dangerous or injurious to the health or safety of the
inhabitants of the area, as certified by the (1) by the Designated Officer appointed
by Municipal Commissioner or as per the Regulation of Redevelopment of
Dilapidated Buildings;
(1)
Substituted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021
(2)
Inserted vide Notification u/s 37 (1AA)(c) & 20(4) No.CR 236/18 (Part-4), dt.28th December, 2022
g) Slum areas declared as slums under section 4 of the Maharashtra Slum Areas
(Improvement, Clearance and Redevelopment) Act, 1971 or slums on Public lands
prior to 1st January 1995 or such other reference date notified by the Government.
However such slum area shall be maximum 25% of cluster area;
In case of Ulhasnagar Municipal Corporation, minimum area shall be 4000 Sq.m.
for non-congested and congested area.
(2)Notwithstanding Anything Contained in these regulation, it shall not be
permissible to develop declared slum under Regulation No. 14.7 which is
included in URP / URS prepared & notified as per Regulation No. 14.8.1 (ii).
h) The lands belonging to MIDC can be included in the URS after obtaining necessary
clearance from Industries Department.
Explanation-1. - Age of a building shall be as on the 1stof January of the year in which URC
involving such building, complete in all respect is submitted to the Commissioner or prepared
and notified by the Commissioner and shall be calculated from the date of occupation certificate
or, where such occupation certificate is not available, from the date of assessment as per the
property tax record in respect of such building, available with the Municipal Corporation.
Explanation-2.-Whenever any authorized building, more than 30 years of age, is included in
a URC, the same shall not be done without evaluation of its state of dis-repair by Municipal
Corporation and if such building is found in a state of disrepair, only after giving the
owner/occupier(s) thereof, a notice of three months to cause any repairs needed. At the end of
three months, if such building is found to be habitable and safe, such building shall be treated at
par with authorized buildings which are less than 30 years of age. If at the end of three month,
such building is found and certified by (1) the Designated Officer appointed by Municipal
Commissioner or as per the Regulation of Redevelopment of Dilapidated Buildings as
dilapidated and unsafe for habitation, such building shall be included in the URC without the
requirement of consents.
Explanation-3.-If some authorized buildings which are less than 30 years of age or buildings
which are developed or in the process of development, under the different provisions of the
DCR, are required to be included in the URC for the purpose of wholesome planning, they may
be so included, provided the area under such buildings does not exceed 40% of the total area of
URC. If any such building is included in the URC without the requisite consent of 70% of all
title holders of such building, the Commissioner shall retain such building while designing/
sanctioning URS and area of such building shall be excluded from calculation of FSI under this
Regulation.
However, the area under slum mentioned in Regulation No.14.8.1(iii)(G) and area under
authorised structure mentioned above shall not be more than 50% in aggregate.
Explanation 4.-When any private land owner / developer submits such scheme will be given
priority while implementation.
14.8.2 Eligibility for Urban Renewal Cluster (URC)-
i) For Buildings outside Slums -Every occupant of every building falling under a URC on
the date of sanction of this Regulation (hereinafter referred to as the cut-off date), shall be
eligible for rehabilitation and relocation under the Scheme, in accordance with the
(1)
Substituted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021
(2)
Inserted vide directives u/s 154 No.CR 70/22/UD-12, dt.27th June 2022.
provisions of Regulation No. 14.8.4 and 14.8.5, subject to the ineligibility criteria
mentioned herein below.
a) No new Tenancy, occupancy or any other right created after the cut-off date shall be
taken into account in any illegal or unauthorized construction. No unauthorized
construction made after the cut-off date in any existing building or in the form of
new building shall be considered while doing computation of existing FSI or
liability of rehabilitation on the URC.
b) Any occupant, who has been allotted any subsidized housing in the (1) respective
Metropolitan Region, or in the Corporation area as the case may be, by any public
or semi-public authority in the past shall not be eligible for subsidized
rehabilitation under a URC as mentioned in Regulation No. 14.8.5. For this, a self-
declaration in the form of Registered Affidavit shall be considered sufficient
which, if ever found to be false, shall render the concerned allottee liable for
eviction and prosecution as per law.
c) Subject to the forgoing provisions, only the actual (1) owners of residential unit of
authorized building and the occupants of unauthorized buildings fulfilling the
eligibility criteria mentioned under this Regulation shall be held eligible for
rehabilitation and any person, other than the actual occupant, claiming rights as
owner/ promoter/ developer/lessee over any land/ building/ structure included in
the URC, shall have no right whatsoever to rehabilitation under the URC in the
reconstructed tenements against such land/building/structure. In case of an
unoccupied building or a building occupied illegally, no one shall have right
whatsoever to rehabilitation under the URC, against such building/structure.
ii) Slum Areas - Whenever a Slum area or part thereof is included in a URC,
eligibility of the hutment dwellers of such slum area rehabilitation under the URC,
shall be governed by corresponding provisions of Slum Rehabilitation Scheme.
Eligibility of any hutment dweller of a Slum area included in the URC shall be
certified by the Competent Authorities as notified under the Maharashtra Slum
Areas (Improvement, Clearance and Redevelopment Act, 1971). For slum dwellers
not covered under Slum Rehabilitation Scheme, the eligibility for rehab area shall
be the same as under Slum Rehabilitation Scheme.
14.8.3 Determination of eligibility and requirement of Rehabilitation and Relocation areas under
URS
i) Municipal Commissioner shall initiate the process for determination of eligibility and
requirement of alternative area of Rehabilitation and relocation of each occupant under
any URS, along with determination of rights over lands falling under the Urban Renewal
Cluster(s) and the consideration thereof.
ii) Municipal Commissioner shall designate officer(s), not below the rank of Assistant
Municipal Commissioner, who shall be called Authorized Officer(s) and shall
cause to be done the survey required for the purpose mentioned in Clause (i) above
and declare and publish the list of buildings/ structures and their owners/lessees,
occupants/ tenants etc., for inviting suggestions and objections along with relevant
records, within one month of such publication for determination of entitled area
and the consideration to be offered to the owners/ lessees and other right-holders as
(1)
Substituted vide Corrigendum / Addendum No.CR 121/21, dt. 02nd December, 2021.
well as eligibility and admissible area for the occupants, in accordance with the
provisions in this Regulation. Authorized Officer(s) shall, after due enquiry and hearing,
finalize the said list(s) and cause the same to be published. Appeal against any decision
leading to finalization of the said list shall lie with an officer not below the rank of
Deputy Municipal Commissioner who is authorized in this regard by the Municipal
Commissioner, in writing.
14.8.4 Entitlement of Rehabilitation
i) All the eligible occupants of the building(s)/slums undergoing redevelopment under a
URC shall be rehabilitated in the redeveloped building(s) :
Provided that the Municipal Commissioner may also rehabilitate, in the rehabilitation
buildings of the URC, one or more persons declared eligible for allotment of tenement
under any other Scheme or Project of the Government or Corporation, Project Affected
Persons, outside the area of URC.
ii) Each eligible residential occupant, other than occupants of Slums included in URC, shall
be rehabilitated on a carpet area equivalent to the area occupied by such occupant in the
old building. However in case of residential occupants, such carpet area shall not be less
than 30sq.m. and in case of commercial, such carpet area shall be as per actual area in
possession.
And further the residential occupants belonging to authorised buildings shall be entitled
additional 25% of the eligible area.
iii) Any occupant of a slum structure included in URC, either residential or commercial,
whether eligible under Slum Rehabilitation Scheme or not but eligible under this
Regulation, shall be entitled for a carpet area as prescribed in Slum Rehabilitation
Scheme.
iv) All the eligible occupants shall be rehabilitated in the redeveloped buildings of URC as far
as possible. However at the request of or with the consent of an occupant, he may be
allotted alternative rehabilitation in a location outside URC, up to the extent of his
eligibility, at the discretion of the Municipal Commissioner. Request or consent under
this provision shall however be irrevocable.
Explanation - Though Commissioner shall endeavour to make provision for rehabilitation
areas as per the entitlement of each and every eligible occupant, whenever such area, whether
for residential user or non-residential user, within a range of 10% of the individual entitlement
of any occupant, is not available in the URC, he shall be entitled for rehabilitation in an
available tenement of immediately next higher area, subject to the allottee paying for the
differential area.
If the beneficiary refuses to pay the specified amount towards such differential area, he will be
entitled for an available rehabilitation tenement of immediately lower area, without any
consideration towards such reduction in area.
14.8.5 Terms of Allotment of Rehabilitation Tenements
i) Allotment of rehabilitation tenements for owners belonging to authorised buildings shall
be free of cost and without any consideration for the original area and additional 25%
area over and above the eligible area Shall be allowed for the occupants of the authorised
buildings, free of Cost.
If any non-residential unit holder demands residential unit against his non-residential
previous holding, such request may be considered by Commissioner in consultation with
HPC. However to consider such request shall not be obligatory on the part of the
Commissioner.
Allotment of rehabilitation tenements to occupants belonging to unauthorized / illegal
buildings and slums shall be at a consideration in accordance with the following Table
No. 14 X :-
Table No. 14 X
Minimum Carpet Area of Type of Rehab Consideration (i.e. Amount payable
Rehab Tenement Tenement by the Allottee to Municipal
Corporation)
(1) (2) (3)
For Slum Area
27.88sq. m. Residential Zero Payment if eligible under Slum
Rehabilitation Scheme Or else
Construction Cost as per ASR rates or
as per any policy decided by the
Government of Maharashtra under the
Slum Act, 1971.
For Non-Slum Area
30 Sq.m. Residential Free of Cost
>30 Sq.m. but less than or equal Residential Upto 30 Sq.m. as above. Beyond 30
to 50 Sq.m. Sq.m. at Construction Cost as per ASR
rates.
>50 Sq.m. Residential Up to 50 Sq.m. as above. Beyond 50
Sq.m. at Full Market Rate as per ASR.
Non-Residential/ Commercial
Area
16.75 Sq.m. Non - Free if eligible under Slum
Residential/ Rehabilitation Scheme. Or else,
Construction Cost as per ASR rates.
commercial Area
>16.75 Sq.m. but less than or -do-- Upto 16.75 Sq.m. as above and
equal to 40 Sq.m. beyond 16.75 Sq.m. at 100% of
Construction Cost as per ASR rates
>40 Sq.m. -do-- Upto 40 Sq.m. as above and Beyond
40 Sq.m. at 100% of market rate as per
ASR.
Note for Thane Corporation Area - The erstwhile structures within the gaothans which
subsequently merged with the Municipal Corporation in 1982 will be considered as
protected and legal structures.
ii) If an eligible occupant finds it financially unaffordable to pay the amounts as mentioned
herein, Commissioner may allot him a tenement of immediately lower area. If any
eligible beneficiary finds it financially unaffordable to pay even the amount required for
the minimum area, or fails to make payment as per the Schedule of payment given by the
Commissioner, the Commissioner may allot him a tenement of minimum area on hire-
cum-purchase basis, till such allottee pays the requisite amount in one or more
instalments or through EMI payments. Rent in such cases would be decided by Municipal
Commissioner and EMI shall be calculated for such number of years at such rate of
interest as may be fixed by Municipal Commissioner.
iii) Any existing amenity in the URC on the date of coming into force of this regulation
which is under control of a private person/ organization and Charitable Trust/ religious
organization shall be entitled for an area equal to the existing area of such amenity,
subject to the following :-
a) for an amenity being used for non-residential activities and under the control of
private person(s)/ organization(s), allotment of equivalent area under URS shall be
at 50% of ASR Rate for commercial area up to 40 Sq. Meters and at 100% of ASR
Rate for commercial area above 40 Sq.m.;
b) for an amenity being used for non - residential and in control of any Charitable
Trust or religious organization for purpose of raising fund for public welfare
activities, such allotment shall be free for area up to 40 Sq. meters and at 50% of
ASR Rate for construction above 40 Sq. Meters.
c) for an amenity having users like (e.g. Educational / Health-care facility etc.) and
under control of private person(s)/ organization(s) such allotment shall be at 25 %
of ASR Rate for constructed area up to 40 Sq. Meters and at 50% of ASR Rate for
constructed area above 40 Sq. Meters.
iv) Process of Allotment to Beneficiaries and Conditions thereof :-
a) Process of allotment of tenements to beneficiaries, lease conditions including those
pertaining to transfer, formation of co-operative housing societies and policy of
maintenance of common amenities of buildings and layout as well as policy
regarding any other relevant matter shall be as determined by Corporation from
time to time.
b) Allotment of land shall be on lease for the period of 30 years, which shall be
renewable for further period of 30 years at a time. However, Allotment of
rehabilitation tenements for owners and beneficiaries shall be on ownership basis.
This provision of lease shall not apply for the authorised building constructed on
private land.
c) Rehabilitation tenements allotted to beneficiaries shall not be transferable for first
fifteen years, except with prior permission of Commissioner, who may grant such
permission in case of hardship, on payment of premium as below :
i) For the transfer of Rehabilitation tenements allotted to Occupants belonging
to the authorised buildings, no premium shall be charged
ii) For carpet area less than 30.00 Sq.m. premium shall be 10% of the
differential amount calculated as per clause (iv) below;
iii) For the transfer of Residential and non-residential Rehabilitation tenements
other than those covered under (a) and (b) above, premium shall be 25% of
differential amount calculated as per explanation below;
iv) Differential amount for the purpose of clause (ii) and (iii) shall be equal to
difference in the Annual Statement of Rates (ASR) valuation in the year of
transfer and the original consideration paid for the allotment of a Tenement
brought forward to the year of transfer through capital inflation index.
Provided that, In case of unauthorized transfer of any Rehabilitation
tenement, the Commissioner may regularize the transfer by charging double
the premium as mentioned above, with 12% interest from the date of
transfer.
Provided further that, If the transferee refuses to pay the premium demanded
within 3 months of demand, the Commissioner shall initiate process of
vacating the premises, though in cases of willingness but hardship,
Commissioner may grant instalments with 12% interest rate.
v) (1)After consideration for land falling under URC to the person(s) having
legal rights in land as per regulation No.14.8.8(iv)(c) is offered and
provision for rehabilitation all the eligible beneficiaries of the building(s)
under URC is proposed in redeveloped building(s) in URC area as per
Regulation No.14.8.4.
In respect of those eligible beneficiaries of (2)(--) unauthorized / illegal
buildings and slums entitled for rehabilitation tenement in URC, who do
not join the scheme willingly, the following steps shall be taken:-
i) Provision for all of them shall be made in the rehabilitation
component of the scheme.
ii) The details of the tenement that would be given to them by way of
allotment on the same basis as for those who have joined the scheme
will be communicated to them in writing by the Implementation
Agency.
iii) The transit tenement that would be allotted to them would also be
indicated along with those who have joined the scheme.
iv) If they do not join the scheme within 15 days after the approval for
Implementation Agency has been given to the scheme, then action
under the relevant provision of the M.R. & T.P. Act, as amended
from time to time, shall be taken and their structures will be removed
and it shall be ensured that no obstruction is caused to the scheme of
the majority of persons, who have joined the scheme willingly.
v) After this action under the foregoing clause is initiated, they will not
be eligible for transit tenement along with the others and they will
not be eligible for the reconstructed tenement, but they will still be
entitled only to what is available after others have chosen, which
may be on the same or some other site.
vi) If they do not join till the building permission to the scheme is given,
they will completely lose the right to any built-up tenement and their
tenement shall be taken over by the Commissioner and to be disposed
off as per MMC Act or as per guidelines issued by the Government
from time to time and used for the purpose of accommodating
Project Affected Persons and other beneficiaries etc. who cannot be
accommodated in-situ.
(1)
Inserted vide Notification u/s 37 (1AA)(c) & 20(4) No.CR 236/18 (Part-4), dt.28th December, 2022
(2)
Word “authorized” is deleted vide Corrigendum No. CR 236/18 (Part-4) dt. 11th January 2023.
14.8.6 The permissible FSI for URC
i) (1)The FSI permissible in the URS shall be the FSI required for rehabilitation of existing
occupiers/tenants + incentive FSI under this Regulation, or 4.00 whichever is higher.
Provided that Incentive FSI shall be governed by the ratio of Land Rate (LR) (in Rs.
Per Sq.m.) of the URC under redevelopment to the Rate of Construction (RC) (in Rs.
Per Sq.m.), as per the Annual Statement of Rates (ASR) applicable to the area and size
of the URC as given in table below.
Basic Ratio (LR/RC*) Incentive as per scheme
More than 0.40 More than 1.0 For more 5.0
ha upto 1.0 ha. ha. upto 5.0 ha.
1.75 2.00 2.25
Above 2.00
2.00 2.25 2.50
Above 1.50 and upto 2.00
2.25 2.50 2.75
Above 1 1and upto 1.50
2.50 2.75 3.00
Upto 1.00
Explanation:-
(a) In case of different land rates area applicable to different parts of the URC,
weighted average of all the applicable rates shall be taken for calculating the
Average land rate and basic ratio.
(b) The land rate and the rate of construction for calculation of the basic ratio shall
be taken for the year in which the URS is approved by the competent authority
and shall remain unchanged during the entire project cycle of the URS.
FSI shall be calculated over the gross area of the URC, deducting area falling in
CRZ and Forest areas if any. However, if the area in CRZ-II is upto 25% of the
URC then the FSI shall be allowed to be used in non CRZ area. However no FSI
shall be allowed for the area from CRZ-1. Out of the construction area allowed
as per Global FSI, FSI that cannot be actually utilized in URC, due to
constraints imposed by different provisions of UDCPR, or otherwise, shall be
converted into Urban Renewal TDR (URT) which shall be utilisable on a
receiving plot.
ii) The URT may be released by the Commissioner in stages to be decided by him but URT
released at any point of time shall never exceed construction done in URC with respect
to buildings where Occupation Certificates have been granted and 50% of construction
done in URC with respect to buildings where Occupation Certificates are not granted.
iii) The FSI for an Urban Renewal Scheme in CRZ area shall be governed by the MOEF
Notifications issued from time to time, and the same shall be taken into account while
computing permissible FSI as per Clause (i) above.
Plot area, considered after deducting the area of URC falling in CRZ/ Forest area and
area under unbuildable reservations, etc. shall be primarily used for rehabilitation of
existing occupants and development of buildable reservations and public amenities with
required FSI. After the said development, if there are any eligible occupants left who
could not be rehabilitated due to inability to construct the requisite area for rehabilitation
and relocation, owing to constraints imposed by UDCPR, shall be rehabilitated in any
nearby URS or in the PAP tenements available with the Corporation; as per the policy
guidelines decided by the Corporation.
(1)
Inserted vide Notification u/s 37 (1AA)(c) & 20(4) No.CR 236/18 (Part-3), dt.3rd February, 2022
iv) If after construction of rehabilitation tenements and other areas of entitlement as per the
provisions of this Regulation, there is still some building potential left as per the ceiling of 4.0
FSI, construction can be done for free sale, either in independent buildings, or on sub-plots or in
composite buildings or in undivided plots along with rehabilitation component.
v) When the FSI available in URC in case less than 4.0 then50 %of the difference in FSI shall be
constructed in the form of EWS/LIG tenements and shall be handed over to the Commissioner.
Commissioner may use these tenements preferably for transit accommodation, PAP tenements or
staff quarters. However if tenements are not needed for above purpose then Municipal
Commissioner shall after realisation of proceeds from disposal of these tenements, deposit such
proceeds in Shelter Fund setup under this Regulation.
14.8.7 (#) Development of Reservations contemplated in Development Plan falling in the area of
URC
i) All the reservations in the Development plan falling in the area of URC shall be provided
and may be rearranged / relocated, under URS as follows :-
a) Redevelopment / reconstruction in any zone shall be allowed to be undertaken
without going through the process of change of zone. However, for the industrial
user, the existing segregating distance shall be maintained from the existing
industrial unit.
b) Any land under non-buildable reservations, admeasuring only upto 500 sq.mt. may
be cleared by shifting the existing tenants from that site.
c) If the area under a non-buildable reservation is more than 500 sq.mt. minimum
50% of the area under reservation shall be developed for the same purpose and
handed over to Municipal Corporation, subject to minimum of 500 sq.mt. and
remaining land shall be allowed for development.
d) For the reservation of parking lot on a land included in URC, built up area
equivalent to zonal permissible FSI for the area under reservation in that plot shall
be made available free of cost to the Corporation or to any other Appropriate
Authority. Such built up area to be handed over shall be free of FSI.
e) For other buildable reservations on land, built up area equal to 60% of the zonal
permissible FSI under such reservations or existing built up area of the amenity
whichever is more, on that plot shall be made available free of FSI and free of cost
to the Municipal Corporation or to the Appropriate Authority. The reservations of
compatible nature can be preferably constructed in one or more separate blocks,
depending on the area and nature of such reservations and Municipal
Commissioner may permit composite development of reservations in case of such
reservations. However, if the HPC/Planning Authority requires built-up area under
any designation /reservation in excess of the zonal permissible FSI, then such
excess area shall be considered as rehabilitation FSI and incentive FSI as
admissible under this Regulation shall be permissible :
Provided that in case of development of reservations of PH/HDH & HD under the
Urban Renewal Scheme, built-up area equal to 30% of the zonal permissible FSI
shall be handed over to the Municipal Corporation free of FSI and free of cost, in
addition to the rehabilitation of the existing tenements or users if any.
f) Where a proposed Development Plan Road or Regular line of street passes through
the Urban Renewal Scheme area, the entire FSI admissible under this Regulation
for the area of the road may be given in the same Scheme.
(#) Clarification issued vide Order No. CR 236/18 (Part 2), dt, 23rd December, 2021.
g) Built up area required for development of public amenities/ reservations shall not be
counted while computing permissible FSI under URS. If URS includes areas
falling under CRZ and Forest, subject to NOCs of the concerned Authority, these
areas may be considered against the compulsory open space to be kept as per DCR.
h) The multiuser mix user in High rise or composite building for public purpose
amenities shall be permitted.
ii) If the area under non-buildable reservation except Play Ground in the URS area is more
than 2000 Sq.m. minimum 50% of the area of such reservation or 2000 Sq.m. whichever
is more shall be developed for the said purpose.
14.8.8 Preparation and Approval of URS
i) Subject to the provisions of Development Plan and the URP prepared and notified by the
Commissioner, the Commissioner may prepare detailed plan, for one or more URCs
contained therein, showing proposals for development/ reconstruction of cluster of
buildings and/or structures, which in the opinion of the Commissioner should be
developed or redeveloped under a URS. Such plan shall include -
(a) Plan for overall development/Redevelopment of specific areas for urban renewal.
(b) Strategies and plan for dealing satisfactorily with areas of bad layout, obsolete
development and slum areas and relocation and rehabilitation of population.
(c) Open spaces, gardens, playgrounds and recreation areas.
(d) Area or areas required for making the implementation of such plan for Urban
Renewal viable.
ii) After preparation of detailed plans of URC(s), the Commissioner shall place the same for
approval of a High Power Committee (HPC) constituted under this Regulation as
follows-
Municipal Commissioner - Chairman
Collector - Member
Joint Director Town Planning of the Division - Member
DCP (Traffic) - Member
Chief Officer, MHADA - Member
Joint Director / Deputy Director /Assistant Director - Member Secretary
Town Planning of the Corporation
After approval of detailed plans of URC(s) as aforesaid, the Commissioner shall proceed
to select an Implementation Agency for executing URS in the manner described herein.
Proposal to finalise Implementation Agency shall be put to HPC which will forward the
same with the recommendations to the State Government for final approval.
iii) Entitlement for consideration under URS :
Anyone having any legal rights over any parcel of land falling under URS shall, after
establishment of his rights, be offered consideration for such land as per the following
provisions which, if declined by any rights holder (s), shall give liberty to the
Commissioner to initiate process of acquisition of such rights under appropriate law.
Implementation of URS shall be regarded as a public purpose.
iv) Consideration for Land falling under URS.
a) Person(s) having legal rights in any land required for URS under this Regulation
shall be offered (1)consideration for the entitled area (1)of land as provided
hereinafter.
b) Basis for determination of entitled area towards consideration under URS Scheme
shall be as follows :-
i) Person (s) in legal possession and ownership of unencumbered land: -
Entitled area collectively against this parcel of land shall be equivalent to the
area of the land.
ii) Person(s) in legal possession and ownership of encumbered land where
authorized buildings have consumed FSI less than the permissible FSI :-If
liability of rehabilitation of the occupants of the building(s)/Structure(s) on
the land in question is being taken on URS, entitled area collectively against
such parcel of land shall be 25% of the area of encumbered land plus
difference of FSI available on such parcel land and the encumbrance; if the
occupants of the building(s) are being independently rehabilitated/
compensated by the person(s)/rights holders in legal possession and
ownership of the land, and not being rehabilitated in URS, entitled area
collectively against such parcel of land towards consideration shall be equal
to FSI available on the vacated land area :
Provided where the area of rehab is less than the component of free sale, the
component for free sale could be enhance upto 30% by the Municipal
Commissioner in consultation with HPC.
iii) Person(s) in possession and ownership of authorized encumbered land where
buildings have consumed FSI more than permissible FSI :- If liability of
rehabilitation of the occupants of the building(s)/Structure(s) in question is
on the land being taken on URS, entitled area collectively against such
parcel of land shall be 25% of land area, if the occupants of the building(s)/
Structure(s) are being independently rehabilitated / compensated by the
person(s)/rights holder (s ) ; in possession and ownership of the land, and
not being rehabilitated in URS, entitled area collectively against such parcel
of land towards consideration shall be equal to FSI /(1) (--) available on the
vacated land area.
iv) Person(s) having right over unauthorisedly encumbered land:- Entitled area
collectively against this parcel of land shall be calculated at 50% of entitled
area calculated as per clause (ii) and (iii) above, except when occupant(s) of
building(s) are being rehabilitated/ compensated by such Person(s) and are
not being rehabilitated in URS, entitled area towards consideration shall be
equal to FSI / (1) (--) available on the vacated land area
c) Consideration for Acquisition of land under URP
i) Consideration for any land required to be procured for URP shall be either in
terms of payment due for entitled area collectively against that parcel of
land, as calculated in Regulation No. 14.8.8 (iv) (b) above as per ASR, along
with 100% solatium, as applicable for the year of possession, along with
(1) Inserted / Substituted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
(1) The word ‗TDR‘ deleted vide Corrigendum / Addendum CR 121/21, dt. 02nd December, 2021.
12% annual (2) simple interest from date of possession to date of payment, or
in terms of TDR equivalent to the entitled area (2) as per TDR Regulation
No.11.2 or in terms of equivalent area constructed in URS (3) or in terms of
developed free sale vacant plot of area equal to 50% of entitled area
calculated as per clause (i), (ii), (iii) and (iv) of Regulation No.14.8.8 (iv)
(b) above, with base FSI of 1.1 in the same URC fronting on same road
width as original plot, subject to availability of land. Concerned person(s)
shall have option to choose from amongst these (3)four modes of
consideration. The option once chosen shall be registered and shall be
irrevocable.
ii) Once consideration as above, has been accepted by a person having any
interest in the land on which any unauthorised construction exists or existed,
the Commissioner may consider such person eligible for Compounding of
any offence under relevant provisions of MRTP Act with respect to the
concerned land/ plot.
iii) Wherever any person having demonstrable legal rights over any area falling
under URP rejects the consideration being offered, the Commissioner shall
forward the proposal for Land Acquisition under "Right to Fair
Compensation and Transparency in Land Acquisition, Rehabilitation and
Resettlement Act, 2013" (2) read with section 126 (1) (c) of Maharashtra
Regional and Town Planning Act, 1966. In such an eventuality, the
Commissioner may move the competent authority for advance possession of
the land(s) so as to ensure smooth implementation of URS and shall pay
requisite advance, rent etc. under the "Right to Fair Compensation and
Transparency in Land Acquisition, Rehabilitation and Resettlement Act,
2013", as determined by the Competent Authority. If, however there is any
dispute only about apportionment of consideration among person(s) having
demonstrable legal rights over any land falling under URS, the
Commissioner shall ask the disputing parties to approach Competent Civil
Court to get their disputes resolved and to settle apportionment of
consideration as offered under this Regulation. Till the final decision in this
regard is received, in order to ensure that URS does not get delayed and
adversely affect other parties to the URS; the Commissioner shall cause an
area, equivalent to the entitled area corresponding to such land, to be
constructed as part of URS and in case the claimant(s) of ownership finally
declared eligible by the Competent Court decide upon an option other than
constructed area and exercise such other option, as mentioned in Regulation
No.14.8.8(iv)(b),the Commissioner shall pay consideration as per such
option exercised and such reserved constructed area in URS shall vest with
the Corporation.
iv) In any proposed URC, any open plot is included and if the concerned owner
is not willing to participate in URC, the compensation payable shall be as
per Land Acquisition, Rehabilitation and Resettlement Act, (1) 2013 read
with section 126(1)(c) of Maharashtra Regional and Town Planning Act,
1966 .
(1)
The word ‗TDR‘ deleted vide Corrigendum / Addendum CR 121/21, dt. 02nd December, 2021.
(2)
Substituted / Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
(3)
Inserted vide Notification u/s 37 (1AA)(c) & 20(4) No.CR 236/18 (Part-4), dt.28th December, 2022
v) In case of buildings or lands belonging to the Central Govt., the State
Government, Semi-Government Organizations and Municipal Corporation
or MHADA or any Local Government or any Corporation or Company
owned by the Central/State Government or any Local Government
(hereinafter collectively referred to as Public Authority), prior consent of
such Public Authority shall have to be obtained for their inclusion in the
URS. For such lands or buildings, the Commissioner may either offer
Market Price, to be decided by mutual consent, subject to ratification by the
Municipal Corporation, or may offer constructed area, in-situ or ex-situ, in a
composite or independent building or may, alternatively, offer equivalent
TDR as per TDR regulations (1)No. 11.2 or may offer an exchange of
suitable land as per mutual consent, subject to ratification by the Municipal
Corporation and thereafter such land(s)/building(s) shall vest with the
Municipal Corporation and shall form the part of URS.
14.8.9 Planning for Rehabilitation and Free Sale Plots in URS
i) Net area of URC shall be calculated after deducting the area under CRZ and Forest, if
any. Out of total net area of the URC, maximum of 50% area in terms of one or more
plots, to be called Free Sale Plots, shall be carved out for raising resources to cover the
cost of construction of rehabilitation component and development of all the reservations
and amenities. While carving out Free Sale Plots, due weight-age shall be given to the
fact that the higher is the percentage of these plots in terms of area, the more dense is the
Rehabilitation Area, and in exceptional cases, Commissioner may reduce these Free Sale
Plots to zero. The percentage of the free sale plot may be enhanced upto 50% subject to
approval by the HPC by considering 100% in-situ Rehabilitation with consumption of
minimum FSI of 2.5 and if net plot area excluding Recreation Ground area is more than
8000 Sq.mt. under URS. Constructed area available on this Free Sale Plot collectively
shall be equal to that available over the whole URC minus that required for rehabilitation
and relocation. If Free Sale Plots, are more than one, the Commissioner may distribute
the available free sale construction area under URS over such plots, as he may deem fit.
Such Free Sale Plots shall be deemed to belong to C1/C2 Zone for the purposes of
permissible users thereon.
(3)Provided that, in exceptional cases, the above percentage of free sale plot may further
be enhanced beyond 50% in order to make scheme viable and minimize generation of
URT, subject to fulfilment of following conditions, subject to the approval of HPC:-
a) 100% in-situ rehabilitation;
b) no dilution more than what is mentioned in Regulation No.14.8.7, in the area of
development plan reservations.
ii) After the development of reservations, any occupants who could not be settled due to
non-buildability of required construction area for rehabilitation and relocation, owing to
constraints impose by DCR, shall be rehabilitated in the nearby URS or PAP tenements
available with the Corporation; as per policy guidelines decided by the Corporation.
iii) Two or more (1) (--) URCs (1)within a notified URP having different densities may be
permitted to get clubbed for implementation purpose sharing the densities in order to
ensure balanced development increasing the viability of clusters.
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
(1)
The word ‗contiguous‘ deleted vide Corrigendum / Addendum CR 121/21, dt. 02nd December, 2021.
(3)
Inserted vide Notification u/s 37 (1AA)(c) & 20(4) No.CR 236/18 (Part-4), dt.28th December, 2022
14.8.10 Selection of Implementation Agency
If an owner or group of owners or proposed co-op. Hsg. Society of occupants or federation of
occupants, either directly or through a Power of Attorney Holder, collectively owning more than
51% of the area of URC or a part thereof, come forward for implementation of URS as per the
Detailed Plan prepared by the Commissioner for such URC, within 3 months of declaration of
the detailed plans of URC, or within such extended period as may be granted by the
Commissioner, they may be selected as Implementation Agency for implementation of URS on
such URC. In such a case (2) the infrastructure should be developed by the Implementing
Agency at their own cost, otherwise an Infrastructural charges at the rate of 10% of construction
cost (2)of buildings of rehab & free sale component (excluding infrastructure) as per
prevailing ASR to be received by the corporation. In case owners / stakeholders owning more
than 51% of whole or part area of URS as mentioned above fail to come together, selection of
an implementation agency for the URS shall be done through a transparent bid process.
14.8.11 URS by Private Promoters/ MHADA/ Co-operative Housing Societies
i) Whenever there is no URP made by Commissioner or wherever there is no URS floated by
the Commissioner over one or more URCs falling under URP made by Commissioner,
any Private Promoter, MHADA, Co-operative Housing Society, federation of occupants
etc. may approach Commissioner with consent of owners / stakeholders of 51% of any
area requiring Urban Renewal, for implementation of URS thereon and Commissioner
may, after satisfying himself that conditions mentioned herein, which make an area fit for
redevelopment under URS are met, decide to implement URS thereon and, subject to
other conditions and processes mentioned in this Regulation, appoint such applicant as
implementation agency at the Base Premium. (1) The Authority shall decide base
premium with the approval of High Power Committee (HPC).
ii) In case where there are some owners (pertaining to less than 30% area) who have not
given their consent to the Private Promoter, MHADA, Co-operative Housing Societies
etc. for URS, who are appointed as per Clause (i) above by Commissioner as
Implementing Agency, the Commissioner shall offer remaining owners and right holders
consideration for their rights as mentioned in the provisions for URS being designed and
implemented by Commissioner, and if these considerations are rejected by these
dissenting owners or right holders the Commissioner shall forward proposals for Land
Acquisition to competent authority. In such cases, if final compensation is in terms of
money, the same shall be recovered from the Implementation Agency and if final
compensation is in terms of TDR, market value of such plots as per ASR rates shall be
recovered from the Implementation Agency, in addition to the Base Premium.
iii) A Surcharge on Development undertaken by the promoter/Developer at the rate of 100%
of Development charge shall be leviable, which may be paid in stages in proportionate
with the progress of work. This surcharge shall not be applicable to the construction
within basic FSI, the built up area to be handed over to Municipal Corporation or any
Public Authority in lieu of any reservation and also to the amenity areas to be handed
over to the Municipal Corporations per the requirement indicated by the Municipal
Corporation or the High Power Committee.
(1)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
(2)
Inserted vide Notification u/s 37 (1AA)(c) & 20(4) No.CR 236/18 (Part-4), dt.28th December, 2022
Explanation 1.-In case of inclusion of a Slum in URS, any person/ agency having
consent of more than 51%eligible Slum dwellers shall be construed to be appropriate
person/ agency to deal with the issues regarding the whole area of Slum for the purposes
of this sub-section only. i.e. for the purposes of decision about Implementation Agency.
14.8.12 Transit Camps - For smooth implementation of the URS, construction of temporary transit
camps may be permitted on the same land or a land situated elsewhere as given here-under :
i) Irrespective of its land-use classification under Development Plan, construction of
temporary transit tenements made of light detachable material such as tubular/
prefabricated light structures shall be allowed upto an FSI of 4.0 on any nearby vacant
site without any reservation in the Development Plan, with the consent of the land-owner.
ii) The temporary transit camp shall be provided on or close to the site of URS itself.
However in exceptional circumstances to be recorded in writing, construction of
Temporary Transit Camps may be permitted on the area of open space required to be kept
in accordance with Regulation No. 3.4.
iii) Multi-storeyed temporary transit tenements may be allowed to be constructed with 4.00
FSI on the site of URS.
iv) The area of temporary transit tenements shall be excluded from the computation of FSI,
but structural safety of such tenements shall be ensured.
v) Building permission for Temporary Transit Tenements shall be given within 45 days
from the date of application but only after approval to the URS, failing which such
permission shall be deemed to have been granted.
vi) If a site, reserved in Development Plan for any public purpose is vacant or partly
encumbered, or it happens to be the unused portion of such public purpose for which
such site is reserved, and there is no other option for locating temporary transit
tenements, then such site or unused portion may be utilized for building temporary transit
tenements, with the permission of Commissioner, on payment of such rent and subject to
such conditions/ as the Commissioner may prescribe.
vii) Temporary transit camp erected, under this Regulation shall have to be demolished by the
Developer within 30 days from grant of Occupation Certificate to the Rehabilitation
buildings and the land there under shall be brought back to the original state.
14.8.13 Non-conforming activities.-All activities which are existing shall be allowed to be re-
accommodated regardless of the non-conforming nature of such activities, excepting those
which are hazardous and highly polluting and those where alternative accommodation has
already been provided elsewhere by the Promoter/Developer/Municipal Corporation.
14.8.14 Relaxation in Building and other requirements.-
i) The calculation of FSI for all purposes shall be on gross area i.e. without deducting any
percentage for recreational open space. This shall not affect the requirement of physical
open space in terms of keeping aside the said recreational open space on site as per the
UDCPR.
ii) The provisions in UDCPR relating to balcony shall apply to the URS with the
modification that there shall be no restriction on Zone and balcony shall not reduce
marginal open space to less than 3.00 meters However, at ground level, clear margin of
minimum 4.5 mtr shall be maintained. Enclosed balcony shall be included while
calculating the entitled area.
iii) Front and marginal open spaces: For a building in the Rehabilitation Component or
composite building having height upto 24.0 m., front and marginal open space shall be
4.5 mtr and for buildings having height more than 24.0 m., the same shall be 6.00m.
iv) Notwithstanding the provisions in UDCPR, where the plot abuts a DP Road having width
of 18.0mt and above, the front marginal open space shall not be insisted upon beyond 4.5
mtr, provided such road is not a Highway.
v) Where the plot abuts a trained nallah, the marginal open space along the nallah shall not
be insisted upon beyond 4.5 mtr from the edge of the trained nallah Or as per requirement
of SWD Department of, whichever is greater.
vi) The distance between any two rehabilitation buildings shall not be less than 6.00 mt.
vii) If the height of a building in URS is more than 25 mtr, 6 mtr wide marginal open space or
marginal open space as per the requirement of CFO, whichever is greater, shall be
considered.
viii) A Composite building shall contain at least 50 percent of the built up area as
Rehabilitation Component.
ix) The means of access shall be normally governed by the provisions of UDCPR. However,
in the URS, wherever the design of the buildings up to 24 m. height in the same land
requires some relaxation, the same may be given by the Commissioner; buildings having
height exceeding 24 m. Shall be permissible only on access having width of 9 m. or
more.
x) Even if the recreational open space is reduced to make the URS viable, a minimum of at
least 10 percent of the area of URC shall be provided as recreational open space. In
addition to this, 10 percent of URC area shall be earmarked for amenity space which can
be adjusted against the DP reservation(excluding roads), if any provided the area of such
reservation exceeds 25% of the area of the URP.
xi) Amenities not available in the periphery of 400m. from boundaries of URC shall be
developed on Amenity Plot, subject to the minimum area specified for such amenities
under this Regulation and handed over free of cost to the Corporation without any
consideration.
xii) Area to be excluded from computation of FSI shall be as per these Regulations
(UDCPR).
xiii) In order to make the URS viable, the Municipal Commissioner shall be competent to
sanction any relaxation in the parking requirements and marginal open spaces, except for
front marginal open spaces, wherever required on account of bonafide demonstrable
hardship and for reasons to be recorded in writing, which shall not affect general safety
and fire safety requirements.
xiv) All relaxations outlined hereinabove shall be admissible only to buildings in the
Rehabilitation Component of URS and also to the composite buildings therein. Premium
at the concessional rate shall be charged by the Municipal Commissioner for all or any of
the relaxations given hereinabove or for any other mentioned in UDCPR.
xv) The parking in the URS shall be provided as per the provisions of UDCPR.
xvi) Any aspect of development under URS, which is not specified under this Regulation shall
be governed by the relevant provisions of the UDCPR.
xvii) In order to facilitate redevelopment and to decongest the redeveloped area in the URC,
the Commissioner may insist on additional road width, over and above that prescribed in
the sanctioned D.P. or the width of the existing roads.
xviii) Provisions of Public amenities and roads under the URS shall be considered at par with
reservations and the roads in the Development Plan.
xix) Portion of URC falling under No Development Zone, Buffer Zone, CRZ- I & III and
Private Forest shall form a part of the required Recreational Area in the URS.
14.8.15 The approving/sanctioning authority for the building plans under the URS shall be the
Municipal Commissioner as per the MRTP Act, 1966, even if the URS partly consists of
declared slums or slums on Municipal / Govt. lands, existing prior to 1st January1995 or such
other reference date as may be notified by the Government.
14.8.16 Religious structures existing on the site of URS prior to redevelopment, if allowed to be
redeveloped in accordance with the guidelines issued by the Government from time to time;
following such redevelopment, shall not have area exceeding their area prior to redevelopment.
14.8.17 Heritage buildings of Grade-I and II may be included in the area of Urban Renewal Cluster, but
have to be kept as they are, along with land appurtenant, but shall not be considered for FSI
under this Regulation. As regards such Heritage Structures, the Promoter / Developer shall have
to contribute Heritage Cess at 5% of ASR Rates on the basis of built-up area of the Heritage
structure. Existing provisions under these Development Control Regulations shall apply to
Heritage Buildings of Grade-III. However, before granting the approval for such buildings, the
HPC shall consult the Heritage Committee appointed for that purpose.
14.8.18 If HPC approves areas for amenities such as Fire Stations/ Hospitals/ Police Stations/ Schools,
etc. other than reservations/ designations as per Development Plan, such amenities shall be
handed over to the concerned Authority, free of cost and the built up area of such amenity shall
be considered as rehabilitation F.S.I. and incentive FSI as admissible under this Regulation shall
be permissible.
The decision of HPC shall be appealable, as if, it is an appeal under section 47 of the MRTP
Act, 1966.
14.8.19 Formation of Co-operative Housing Societies, and their Federations for buildings in URS:
Commissioner shall cause formation of Co-operative Housing Society for each and every
building, either separately or collectively as he may deem fit and shall cause to be deposited
25% of the amount of consideration received from the allottees of such building, in a "Building
Maintenance Fund" to be utilised by the Co-operative Housing Society of the allottees of such
Building, as per the guidelines framed by the Corporation. In addition, the Commissioner shall
cause to be deposited 25% of the amount of consideration received from the allottees of each
and every rehabilitation and relocation in URC building, in another Maintenance Fund called
"URC Maintenance Fund" to be set up, by the Commissioner, for the dedicated use of
maintenance of common facilities/ amenities in the URC by the Corporation. The utilisation of
the URC maintenance Fund shall be in accordance with the guidelines framed by the
Corporation.
14.8.20 Formation of Shelter Fund:
Commissioner shall cause to be deposited 50% of amount of consideration received from the
allottees and amount received from bidding process in a separate fund to be named as "Shelter
Fund", which may be used as per the policy to be formulated by the Corporation for payment of
consideration for acquisition of land falling under URC, providing financial assistance to
beneficiaries under URC, procurement of land for creation of affordable Housing, and
promoting affordable housing in the city limits.
(1) Note - If any correction / changes are needed in URS Regulation for the benefit of URC or
for success of URC scheme, the decision can be taken at HPC level and subsequently should
be communicated to the Government to incorporate such decision in this Regulation.
14.9 DEVELOPMENT OF TOURISM AND HOSPITALITY SERVICES UNDER
COMMUNITY NATURE CONSERVANCY AROUND WILD LIFE SANCTUARIES
AND NATIONAL PARKS.
14.9.1 Applicability- These regulations shall apply to the privately owned (not applicable to forest
land) lands falling in Agriculture/ No Development Zone situated within 5 km distance from the
boundaries of wildlife sanctuaries and national parks in the State of Maharashtra. The provisions
of existing Regional Plans / Development Plans will prevail over these regulations, wherever
lands are earmarked for urbanisable zones in such plans.
14.9.2 Regulation- For the lands situated within 5 km distance (or up to a limit of notified eco-
sensitive zone, whichever is more) from the boundaries of wildlife sanctuaries and national
parks, if the land owner applies for development permission, for development of eco-tourism,
nature tourism, adventure tourism, same may be allowed; provided the land under consideration
has minimum area of one hectare in contiguous manner.
i) Permissible users and built up area-
The users permissible in Agricultural Zone/ No Development Zone area shall be as follows:-
a) Agriculture, Farming, development of wild animal shelters, plantation and allied
uses.
b) Tourist homes, Resorts, Hotels etc. with Rooms/ suites, support areas for reception,
kitchen, utility services etc. along with ancillary structures like covered parking,
Watchman‘s quarter, guard cabin, landscape elements, and only one observation
tower per tourist resort up to the height of 15 m. with platform area up to 10 sq.mt.
in permanent/ semi-permanent structural components.
ii) The norms for buildings shall be as follows-
a) The construction activities shall be as per Zonal Master Plan / Regional Plan /
Development Plan of the concerned protected area.
b) The maximum permissible total built up area shall not exceed 10% of gross area
with only G+1 structure having height not more than 9 m. and it should blend with
surrounding.
c) The Fencing / fortification may be permissible for only 10% of total land area
around built up structures in the form of chain link without masonry walls thereby
keeping the remaining area free for movement of wildlife.
d) Tourism infrastructure must conform to environment friendly, low height, aesthetic
architecture, natural cross ventilation; no use of asbestos, no air pollution,
minimum outdoor lighting and merging with the surrounding landscape. They
should generate at least 50% of their total energy and fuel requirement from non-
conventional energy sources like solar and biogas, etc.
(1)
Inserted vide Notification u/s 37 (1AA)(c) & 20(4) No.CR 236/18 (Part-4), dt.28th December, 2022
e) The owner shall establish effective sewage disposal and recycling system during the
construction and operational phase of the development. No sewage shall be
allowed to be discharged into natural stream.
If in cases, where lack of compliance is observed, the concerned authority should
issue a notice to the resort owner/ operator for corrective action within 15 days,
failing to do so or having not been satisfied with the action taken or reply/
justification received, any decision to shut down the unit may be taken, by the
respective authority.
f) The owner shall establish effective systems for collection, segregation, composting
and /or reuse of different types of solid waste collected during the construction and
operational phase of the development.
g) The plastic components used within the area shall be recycled; failing which the
resort shall be closed down within 48 hours.
h) Natural streams/ slopes/ terrain shall be kept as it is, except for the built-up area.
i) On the area other than 10% area, only local trees shall be planted and only natural
vegetation shall be allowed.
j) For the development of such type already taken place, Condition no. (c) above shall
be applicable retrospectively to the extent of restricting the fencing and keeping the
remaining area free for movement of wildlife.
k) While allowing such development, principles given in the National Tiger
Conservation Authority, New Delhi Notification No.15-31/2012-NTCA, dated
15/10/2012 published in the Gazette of India Ext. pt. III S-4 dated 08/11/2012 and
Government of Maharashtra as amended time to time shall be used as guidelines.
l) All regulations prescribed in Eco-Sensitive zone Notification of concerned National
Park/ Wildlife Sanctuary should be strictly followed and all clearances required
should be taken.
14.10 INTEGRATED INFORMATION TECHNOLOGY TOWNSHIP (IITP)
Integrated Information Technology Township (IITP) shall be allowed in Residential,
Commercial, Public Semi-public, Industrial and Agricultural Zone in Development Plan and
Regional Plan areas and shall be governed by the provisions mentioned herein below.
14.10.1 Area Requirement
Any suitable area in Regional plan or Development plan having access by means of an existing
road or a proposed Regional plan/Development Plan road having a minimum width of 18.0 m.
can be identified for the purpose of development as Integrated IT Township. The area notified
under the Integrated IT Township shall be one continuous, unbroken and uninterrupted and in
any case shall not be less than 10 Ha. (25 acres) at one place.
(Explanation- If such minimum 10Ha. (25Acre) area proposed to be developed under a
Integrated IT Township is divided by one or more water courses (such as nallahs, canal, etc.)
existing or proposed roads of any width or railways, etc. then such area shall be considered to be
continuous, unbroken and uninterrupted, subject to the condition that the developer shall
construct necessary connecting roads or bridges as per site requirements at his own cost with
due permission from concerned authorities.)The area under any Integrated IT Township shall
not include the area under notified forest, water bodies like river, creek, canal, reservoir, tribal
lands, lands falling within the belt of500 m. from the High Flood Line (HFL) of major lakes,
lands in the command area of irrigation projects, land falling within the belt of 200 m. from the
historical monuments and places of Archeological importance, Archeological monuments,
heritage precincts and places, any restricted areas, notified national parks, gaothan areas or
congested areas, Defense areas, Cantonment areas, truck terminus especially earmarked on
Development plan, area under Eco-sensitive Zone, other environmentally sensitive areas,
Quarry Zone, notified areas of Special Economic Zone (SEZ) and designated airport areas.
However, such Integrated IT Township may include private land under Hill-Top and Hill-Slope
Zone, whether earmarked on Regional plan/Development plan or not and private land in A
forestation Zone. Provided that, the area of lands in such Hill-Top and Hill-Slope Zone and a
forestation Zone shall not exceed 40 percent of the gross area of the project and such area shall
be shown towards 50% area to be kept permanently open where no development activity shall
be permissible under such project. The said areas shall be developed for tree plantation as per
the norms specified. However, for the purpose of calculation of Floor Space Index (FSI), such
areas shall be excluded.
14.10.2 Planning Considerations
The project has to be an integrated project. The Integrated IT Township should necessarily
provide land for following users:-
1. Information Technology (Industrial)
2. Residential
3. Commercial
4. Educational
5. Amenity Spaces
6. Health Facilities
7. Parks, Gardens & Playgrounds
8. Public Utilities
9. Transport and Communication
14.10.3 General Norms for Different Land Use
Out of the total area notified as "Integrated IT Township" 60% FSI shall be used for IT/ ITES
activities and 40% FSI for the development of residential and commercial activities provided
that 20% area shall be kept for Park / Play Ground / Garden of total IITP.
Residential and commercial activities shall include malls, cinema, theaters, public auditorium
and multiplexes, showrooms for all types of merchandise, hospitals, nursing homes, schools and
colleges, training institutes and hostels related to them, hotels. The development of entire
township, i.e., 60% area for IT/ITES and 40% other area can take place simultaneously but the
developer will have to ensure that sale / lease of both areas is proportionate. To ensure this
occupation certificate for commercial, residential and support services shall be given only after
the development of infrastructure facilities on the area earmarked for IT/ITE activities and
occupation certificate is granted by the Authority and after 1/3rd area kept for IT/ ITES activity
is occupied.
14.10.4 FSI In integrated I.T. Township
The maximum permissible FSI on the gross area of the notified Integrated IT Township shall
vary as follows:-
For Integrated IT Township located in Pune, Pimpri-Chinchwad, Greater Mumbai, Thane, Navi
Mumbai, Kalyan-Dombivali, Mira-Bhayandar, Ulhasnagar, Nagpur Municipal Corporations and
Ambarnath Municipal Council limits the permissible FSI shall be 2.5. For rest of the areas in the
State, the permissible FSI shall be 2.00. For land in Agricultural zone in all areas, it shall be
1.00. The premium chargeable shall be as in para. 5 (ii) of Annexure-I Maharashtra's
Information Technology/ Information Technology Enabled Services Policy (IT/ITES) - 2015
issued by Industries, Energy &Labour Department vide Government Resolution No. ITP-2013/
(CR-265)/Ind-2, dated 25th August, 2015 as amended from time to time. Floating of FSI shall
not be permissible from the area of IT /IT use to the area of Support Activities or vice versa, but
floating of FSI shall be permitted within the respective areas of IT / ITES and Support Activities
separately.
14.10.5 i) Provisions of these DCPR as well as provisions of MOEF and CRZ notification, wherever
applicable, issued & as amended from time to time shall be applicable mutatis-mutandis to
the Integrated IT Township except those expressly provided in these Regulations.
ii) In the event the Integrated IT Township contains sites reserved for public purposes
(buildable reservations) in Regional plan/Development plan, for which the Appropriate
Authority is any department of State Govt./Central Govt. or any Government undertaking,
the developer shall construct the amenity as per requirement of the concerned department
and handover the constructed amenity free of cost to that Department. Upon such handing
over the constructed amenity the developer would be entitled to utilise additional floor
space over and above the FSI permissible within the Integrated IT Township (equivalent
to the built up area of the constructed amenity) anywhere within the Integrated IT
Township.
iii) In every Integrated IT Township proposal the Structural Designer of developer has to
submit declaration with project report to the Authority about the construction of buildings
below:
`I have confirmed that the proposed construction in the scheme is as per norms as
specified by Bureau of Indian Standard for the resistance of earthquake, fire safety
&natural calamities'.
iv) In Integrated IT Township being developed in Residential and other zones mentioned
above and Agricultural/Green Zone/ No Development Zone, trees at rate of minimum 100
trees per Ha. And200 trees per Ha. respectively shall be planted and maintained by the
developer.
14.10.6 Infrastructure Facilities
The entire onsite infrastructure in the Integrated IT Township along with access road shall be
provided and maintained by the developer. However, it would be obligatory on the part of the
developer to provide all basic infrastructures on at least 75%area under the Integrated IT
Township within 3 years from the date of sanction of development proposals by the Authority;
failing which bank guarantee submitted by the project proponent/s shall be forfeited.
The Project Proponent/s shall submit a bank guarantee of an amount equal to the15% of
estimated development cost required for development of the basic infrastructure such as roads,
water supply, drainage & garbage disposal, installations for power supply, fire brigade station &
fire engines. Such development cost be worked out as per respective phases taking into
consideration the phased program for development of infrastructure with amenities under
project as submitted. Certificate regarding estimated development cost shall be produced by the
respective Architect of the project.
14.10.7 Water Supply
The developer shall be required to develop the source for drinking water (excluding the
groundwater source) or secure firm commitment from any water supply Authority for meeting
the daily water requirement of minimum 140 liters per capita per day, exclusive of requirement
of water for firefighting and gardening. The storage capacity of the same shall be at least 1.5
times of the actual required quantity as determined by expected population (Resident and
Floating) and other uses. The developer would be required to develop proper internal
distribution and maintenance systems and shall specially undertake rain water harvesting,
groundwater recharging and waste water recycling projects within the Integrated IT Township.
14.10.8 Drainage and Garbage Disposal
The developer shall make suitable and environment friendly arrangements for the disposal and
treatment of sewage and solid waste as per requirements of Maharashtra Pollution Control
Board. Recycling of grey water for gardening shall be undertaken by the developer.
The developer shall develop eco-friendly garbage disposal system by adopting the recycling and
bio-degradation system in consultation with Maharashtra Pollution Control Board.
14.10.9 Power
The developer shall ensure continuous and good quality power supply to the Integrated IT
Township area. The developer may draw the power from existing supply system or may go in
for arrangement of captive power generation with the approval from concerned Authorities. If
the power is drawn from an existing supply system, the developer shall before commencement
of development, procure a firm commitment of power for the entire Integrated IT Township
from the power supply company.
14.10.10 Environment
The development contemplated in Integrated IT Township shall not cause damage to ecology. In
no case, it shall involve topographical changes, changes in alignment of cross-section of existing
water course, if any in the scheme are or adjustment to scheme area. Environmental clearance
shall be obtained from the Ministry of Environment and Forest, Government of India as per
directions issued by the MoEF's Notification dated 7th July, 2004 and as amended from time to
time. The Integrated IT Township shall provide at least20% of the total area as park/ garden/
playground, with proper landscaping and open uses designated in the Integrated IT Township
shall be duly developed by owner / developer. This amenity shall be open to general public
without any restriction or discrimination.
14.10.11 Special Concession
a) N.A. Permission: Non-agriculture permission will be automatic. As soon as the scheme is
approved, lands under such Integrated IT Townships area shall be deemed to have been
converted into non-agriculture and no separate permission is required.
b) Grant of Government Land: Any Government land falling under Integrated IT Township
area shall be leased out to the developer at the prevailing market rate on usual terms
conditions, without any subsidy.
c) Relaxation from Mumbai Tenancy and Agriculture Land Act: The condition that only the
agriculturist will be eligible to buy the agriculture land shall not be applicable in
Integrated IT Township area.
d) Ceiling of agriculture land: - There shall be no ceiling limit for holding agriculture land to
be purchased by the owner / developer for Integrated IT Township project.
e) Exemption from Urban Land (Ceiling and Regulation) Act, 1976: Integrated IT Township
projects will be exempted from the purview of Urban Land (Ceiling and Regulation) Act,
1976.
14.10.12 Sale Permission
It would be obligatory on the part of the developer firstly to provide for basic infrastructure and
as such no permission for sale of plot/ flat shall be allowed unless the basic infrastructure is
provided by the developer to the satisfaction of the Authority. In case the development is
provided in phases & sale permission is expected after completion of phase-wise basic
infrastructure, such permission may be granted by the Authority. Before granting such sale
permission, developer has to submit undertaking about the basic infrastructure to be provided
and completed phase wise. The plots earmarked for amenities, facilities and utilities shall also
be simultaneously developed phase-wise along with IT/support services development.
14.10.13 Implementation and Completion
Development of any notified Integrated IT Township shall be completed within 5 years from the
date of final sanction to the layout plan of the area.
14.10.14 Interpretation
If any question or dispute arises with regard to interpretation of any of these regulations, the
matter shall be referred to the State Government. The Government after considering the matter
and if necessary, after giving hearing to the parties, shall give a decision on the interpretation of
the provisions of the Regulations. The decision of Government on the interpretation of these
regulations shall be final and binding on all concerned.
14.11 INTEGRATED LOGISTIC PARK (ILP)
Integrated Logistic Parkshall be allowed in Commercial, Industrial and Agricultural Zone in
Development Plan and Regional Plan areas and shall be governed by the provisions mentioned
herein below.
14.11.1 Eligibility for establishment of Logistic Park
Private land owner or developer appointed by him or any Company with legal entity may apply
for permission for Integrated Logistic Park.
14.11.2 Activities Constituting Logistic Park
A logistic Park can include the following activities. (The list is indicative)
i) Logistic Services.
a) Cargo aggregation/ segregation.
b) Sorting, grading, packaging/ repackaging, tagging/ labelling.
c) Distribution/ Consumer Distribution.
d) Inter-model transfer of material and container.
e) Open and closed storage for transit period.
f) Custom bonded warehouse.
g) Container freight station.
h) Container terminals.
i) Material handling equipment facilities for efficient movement and distribution of
Semi-finished or finished products.
ii) Infrastructure
a) Internal roads
b) Power line
c) Communication facilities
d) Internal Public Transportation System
e) Water distribution and water augmentation facilities
f) Sewage and drainage lines
g) Effluent treatment and disposal facilities
h) Fire Tenders arrangements - Parking
iii) Business and commercial facilities
a) Dormitories
b) Guest Houses
c) Canteen
d) Medical Centre
e) Petrol Pump
f) Banking and finance
g) Office Space
h) Hotel
i) Restaurants
j) Hospital/Dispensary
k) Administration office
iv) Common Facilities
a) Weigh Bridge
b) Skill Development center
c) Computer center
d) Sub contract exchange
e) Container freight station
f) Production Inspection Centre
g) Repair workshop for vehicles & production machinery in the park.
The list of permissible activities as revise by the department of Industries,
Government of Maharashtra, from time to time, shall be applicable.
14.11.3 Procedure for Development of Logistic Parks
Private land owner or developer appointed by him may apply to the Authority for development
of Logistic Park under this Regulation. After sanction of permission by the Authority for setting
up Logistic Park, such area shall be deemed to be converted for industrial use in the respective
Development Plan or Regional Plan and shall be available for development of Logistic Park.
However, in case of land in Agricultural zone, the premium shall be charged at the rate of 15%
of land value as per ASR, without considering guideline therein.
14.11.4 Integrated Logistics Park (ILP) :-
An "Integrated logistic park" will be defined as one that is spread over a minimum of 5 acres of
land and having minimum 15 meters wide access road. A minimum of 70% of the total area of
‗Integrated Logistic Park‘ shall be used for providing logistic services, and remaining area shall
be permitted for support services and common facilities. Floating of FSI shall not be permissible
from the area of industrial zone to the area of support services or vice versa, but floating of FSI
shall be permitted within the respective areas of industrial zone and support activity zone
separately. The Integrated Logistics Park shall provide following minimum infrastructure and
common facilities.
i) Infrastructure :
a) Internal roads
b) Power line
c) Communication facilities
d) Water distribution and water augmentation facilities
e) Sewage and drainage lines
f) Effluent treatment & disposal facilities
g) Fire tender arrangements h. Parking
ii) Common facilities:
a) Dormitories
b) Canteen
c) Medical Centre
d) Weigh Bridge
The parking and other essential services mentioned in Regulation No 14.11.2 (ii) will be free of
FSI. The letter of Intent for development of an Integrated Logistics Park shall be issued by
Directorate of Industries. The development in the said Logistics Park shall be completed within
5 years from date of issue of Letter of Intent (LOI). The extension to time limit upto a minimum
of one year at a time and not more than 3 times may be granted on merits. Directorate of
Industries will be the registering agency for all Integrated logistic parks. The procedure adopted
for issue of letter of intent and registration would be in line with that adopted under the
Integrated Industrial Area. The developer of Integrated Logistics Park will have to develop the
infrastructure and create and maintain the facilities. Such facilities can be hired/leased/rented or
put to own use by the Developer.
14.11.5 Logistics Park (LP)
Logistics park/building with a minimum of 20000 sq. feet Built up Area with basic FSI will be
designated as Logistics Park (LP). The 80% of the total area of ‗Logistic Park‘ should be used
for providing logistic services and up to 20% of the total area will be permitted for support
services and common facilities mentioned in Regulation No.14.11.2 (iii and iv). Logistics Parks
will be allowed applicable FSI in these Regulations. The letter of Intent for development of a
Logistics Park shall be issued by Directorate of Industries. The development in the said
Logistics Park shall be completed within 3 years from date of issue of Letter of Intent (LOI).
The extension to time limit upto a minimum of one year at a time and not more than 3 times
may be granted on merits. Directorate of Industries will be the registering agency for all logistic
parks. The procedure adopted for registration would be in line with that adopted under the
IT/ITES Policy 2015. The developer of Logistics Park will have to develop the infrastructure
and create and maintain the facilities. Such facilities can be hired/leased/rented or put to own
use by the Developer.
14.11.6 Upto 200% Additional FSI for Integrated Logistics Park & Logistics Park
For Integrated Logistic Parks & Logistic Parks, the FSI permissible for Industrial Zone as per
these regulations shall be applicable. Upto 200% of additional FSI shall be admissible over and
above the basic FSI for development of Integrated Logistic Park & Logistics Park with or
without premium as follows :-
Sr. No. Location of Parks (As defined under PSI 2013) Premium
1 No industries district and Naxalism affected areas Nil
2 Areas other than PMC, TMC, Kalyan Dombivali, Mira 10%
Bhayendar, Panvel, Ulhasnagar, Ambarnath, Navi
Mumbai Municipal Corporation, NID and Naxalism
Affected Areas
3 PMC, TMC, Kalyan-Dombivali, Mira Bhayendar, Panvel, 15%
Ulhasnagar, Ambarnath, Navi Mumbai Municipal
Corporation
Note : However premium charged will be limited upto the demand made by the developer for
additional FSI.
14.11.7 Permissible Height
For Integrated Logistic Park & Logistics Park, height of building upto 24.mt. or as per
requirement shall be permitted.
14.12 INDUSTRIAL TOWNSHIP UNDER AEROSPACE AND DEFENSE
MANUFACTURING POLICY
Industrial Township under Aerospace and Defense Manufacturing Policy shall be permitted in
Commercial, Industrial and Agricultural Zone in Development Plan and Regional Plan areas.
Other stipulations for Industrial Township under Aerospace and Defense Manufacturing Policy-
2018, declared by the State Government in Industry, Energy Labour Department vide
Government Resolution No. Asangho2015/Pra.Kra.98/Udyog-2, dated 14/02/2018, shall be
applicable.
The FSI permissible for this Industrial Township shall be as per FSI permissible in Industrial
Zone. The lands which are included in Agricultural Zone in the Development or Regional Plan
shall be treated as included in Industrial Zone after the permission is granted for this Industrial
Township.
Provided that upto 20% of total built up area of such Industrial Township may be used for
residential / commercial purpose / support activities.
Provided further that the Research and Development Institutions in such Industrial Township
shall be eligible for additional 0.50 FSI over permissible FSI as per these Regulations.
14.13 DEVELOPMENT OF INTEGRATED INDUSTRIAL AREA
The development of Integrated Industrial Area within the jurisdiction of Maharashtra Industrial
Development Corporation shall be allowed as per Urban Development Department‘s
Notification No. TPB4314/20/CR-32/2014/UD-11, dated 1st August, 2015. The Principal
Regulation‘s referred in the said notification shall be deemed to have reference to provisions of
UDCPR alongwith specific regulations related to MIDC mentioned in Chapter 10.
-*-*-*-*-*-