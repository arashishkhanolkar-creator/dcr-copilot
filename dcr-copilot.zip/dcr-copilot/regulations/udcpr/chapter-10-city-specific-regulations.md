# Chapter 10: City Specific Regulations

CHAPTER -10
CITY SPECIFIC REGULATIONS
10.0 GENERAL
Notwithstanding anything contained in these regulations, following city / authority specific
regulations shall be applicable to respective planning authorities/ areas.
10.1 PUNE CITY MUNICIPAL CORPORATION.
10.1.1 Height of Building
For the building having height more than 36 m., the minimum road width shall be 12 m. and for
building having height equal to or more than 50 m., the minimum road width shall be 15 m.
10.1.2 The height restriction in Koregaon Park Area shall be as per special regulations applicable in
Koregaon Park Area as below.
a) Koregaon Park Area is bounded as below :-
i) The Koregaon Park North Road on the north;
ii) The Ghorpadi village boundary on the east;
iii) The Southern Railway line on the south ; and
iv) The Circuit House - Fitzgerald Bridge Road on the west.
b) Special Building Rules framed by the Collector of Pune for this area shall be
applicable which are as given below.
i) The minimum area of a building plot shall be as mentioned in the layout. No building
plot as shown in the layout shall be sub-divided.
No building shall be allowed to be erected in any plot unless the said plot has suitable
access by an existing metalled road or by projected road which shall be previously
constructed ( i.e. metalled in conformity with the layout sanctioned by the Collector )
ii) Only one main building together with such outhouses as are reasonably required for the
bonafide use and enjoyment by its occupants and their domestic servants shall be
permitted to be erected in any building plot. Provided that this restriction shall not
prevent the erection of two or more building on the same plot, if the plot admeasures at
least twice or thrice as the case may be (according to the number of buildings) the
minimum size required. Provided also that the same open space shall be required
around each main building as if each of these were in a separate building plot.
iii) Every building to be built shall face the road and where the plot has frontage on more
than one road the building shall face the more important road.
iv) Every building shall be set back at least 20 feet from the boundary of any road, 40 feet
or more in width and 15 feet from the other roads as shown in the layout.
v) No building shall be constructed within 10 feet of the side boundaries of the plot.
vi) The distance between the main building and the rear boundary of the plot shall be; not
less than 20 feet. Provided that , subsidiary buildings such as outhouse, a garage, stable,
privy and the like may be permitted at the rear of the main building subject to the
condition that such building shall be at a distance of not less than 10 feet from either
any building in the compound or boundary of the plot.
vii) The open space to be kept around every building shall be open to sky and free from any
erection except projection of roof, chajja or weather sheds, steps or hounds or fountains
with parapet walls not more than 4 feet high. Provided that balcony or gallery may be
allowed to project over such open space if the distance between the outer edge of such
a projection and the boundary of the plot is not less than 10 feet.
viii) Not more than one-third of the total area of any building plot shall be built upon. In
calculating the area covered by buildings the plinth area of the; buildings and other
structures excepting compound walls, steps, open ottas and open hounds or wells with
parapet walls not more than 4 feet high or Chajja and weather sheds shall be taken into
account. Area covered by a staircase and projections of any kind shall be considered as
built over. Provided a balcony or gallery which
a. is open on three sides;
b. has no structure underneath on ground floor;
c. projects not more than 4 feet from the walls; and
d. length of which measured in a straight line does not exceed 2/3rd the length of the
wall to which it is attached; shall not be counted in calculating the built over
area.
ix) No building shall contain more than two storeys including the ground floor.
x) If flats are constructed there shall be not more than two self-contained flats on each
floor, each flat being occupied by one family only.
xi) The minimum standard of accommodation to be provided exclusively for one family
shall consist of one living room and one bed room together admeasuring not less than
250 Sq.ft. one kitchen, one verandah not less than 6 feet in width in front and rear, a
bathroom and a water-closet or latrine.
xii) In no circumstances shall one roomed tenements be allowed to be constructed or used
as residence. No chawls or temporary sheds shall be allowed to be constructed.
xiii) Every building shall have a plinth of at least 2 feet above the general level of the
ground.
xiv) No building shall exceed 100 feet in length in any direction.
xv) All subsidiary buildings such as an outhouse providing auxiliary accommodation such
as a garage, servant's quarter, stable, storeroom, privy etc. appurtenant to the main
building but detached thereon shall be ground floor structures only and shall be
constructed at the rear of the plot at a distance of not less than 10 feet from one another
or from the main building or from the boundary of the plot.
xvi) Owner of the adjoining plots may be permitted with their mutual consent to group the
subsidiary ground floor buildings, such as outhouses, stables, privies etc. along the
common boundary in the rear of their plots provided that such building shall be at a
distance of not less than 10 feet from any other building in the compound.
xvii) The minimum floor area of any room intended for human habitation shall be not less
than 120 Sq.ft.
xviii) No sides of a room for residential purposes shall be less than 10 feet long at least one
side of every such room shall be an external wall abutting on the surrounding open
space through its length or on an interior open yard (chowk) not less than 300 Sq.ft. in
area and l5 feet in any direction or on an open verandah.
xix) The height of every room inside the building shall be not less than 10 feet from the
floor to ceiling and in the case of a sloping roof the height of the lowest point thereof
shall be not less than 7 feet and 6 inches from the floor.
xx) Every room shall be provided with windows or other apertures other than doors
opening out into the internal air for the admission of light and air and the aggregate
area of such openings shall not be less than 1/7th of the floor area of the room in which
they are provided.
xxi) Privies shall be at the rear of the main building and not less than 10 feet from it. They
shall be innocuous to the neighbors. They shall not be within 30 feet of a well and shall
be screened from public view.
xxii) No cesspools shall be allowed to be constructed unless there exists an agency for
clearing them regularly and properly.
xxiii) No cesspool shall be used or made within 100 feet of any well.
xxiv) No Khalkuwa Khalketi shall be used for reception of night soil.
xxv) No cattle shall be kept in any part of the residential buildings. No stable or cattle shed
shall be constructed within 10 feet of a residential building.
xxvi) Shops may be allowed on the ground floor of the building in the plots reserved for
shops only. The upper floor of the building may be used for residence. Provided all
regulations applicable to residential building are adopted.
xxvii) The Collector may within his discretion sanction or license the erection of any building
other than a dwelling house if he is satisfied after necessary inquiry in the locality that
the erection and user of such building will not adversely affect the amenities of the
adjoining lands or buildings.
xxviii) All buildings shall be of pucca construction and no easily combustible materials shall
be used in their construction.
xxix) No boundary or compound wall or fence shall be erected on the boundary not to any
street of a greater height than 4 feet measured from the center of the road in front.
xxx) No addition to or alterations in a building shall be carried out without the previous
written permission of the Collector.
xxxi) In the case of land or building situate within the limits of a Municipal Corporation or
any other local authority, the rules and bylaws of the Municipal Corporation or local
Authority in that behalf shall apply in addition to regulations prescribed above.
xxxii) The permission shall be liable to be revoked on breach of any of the conditions.
xxxiii) All the roads within lay-out will be constructed and got ready within six months from
the date of sanctioning the layout.
xxxiv) Central arrangements for the delivery of water to the individual plot holder will be
made and got ready within six months from the date of sanctioning the layout.
xxxv) No building shall be used for other than the residential purposes.
Note - This regulation stand modify if modified by the Government / Collector.
10.1.3 Notwithstanding anything contained in these regulations, height of building shall not be more
than 21 m. in following area. This height may be relaxed by Government in special cases.
a) Parvati - Area bounded by Singhagad Road on the north, Singhagad Road on the west,
Southern boundary of P.L. Deshpande Udyan on the south, and Road from over bridge
upto Laxminagar and western boundary of Tulsibagwale Colony in S.No. 89, 90 etc. of
Parvati on the east.
b) Chatushrungi - S.No. 105, 106 pt., 107 pt. etc. of village Bhamburda.
Area bounded by Ganeshkhind Road on the North, Senapati Bapat Road on the east,
S.No.106 - South boundary on the south, Western boundary of S.No. 107,105,106 - on the
west.
10.1.4 No piece of land shall be used as site for the construction of building,
(a) If the land is within a prohibited distance (currently of seventy five meters) from the crest
of the outer parapet of the Armament Research and Development Establishment (ARDE),
Range Pashan, Pune;
(b) If the land is within a prohibited distance of approximately 457.2 m. (500 yards) from the
crest of the outer parapet of the High Energy Materials Research Laboratory (HEMRL),
Sutarwadi, Pune as shown on Development Plan;
10.2 THANE MUNICIPAL CORPORATION AREA.
($)10.2.1 Development along Ram Maruti Road and Gokhale Road.
Front set-backs for development on above roads shall be as below :-
i) In the case of plots fronting on Ram Maruti Road, only ground floor of the structure shall
be set back by 3.05 m. from the road line and rest of the floors shall be set back at a
distance of 4.5 m. (1) The front terrace so formed shall be allowed to be accessible.
ii) In case of any plot fronting on Gokhale Road, from the portion between Ashok Talkies and
its junction with M.G. Road, the ground floor of the building shall be set back by 2.3 m.
from the road line and the upper floors shall be set back at a distance of 4.5 m. subject to
condition that the owner of the plot shall pave the front open space. (1) The front terrace
so formed shall be allowed to be accessible.
10.2.2 Setbacks from Eastern Express Highway and Roads more than 52.5 m. in width.
No construction of building shall be undertaken within 7.5 m. from the boundary of the Eastern
Express Highway and other roads having prescribed width more than 52.5 m.
10.2.3 a) Development of Multi Storey Public Parking Lot (PPL) near Metro Stations.
For development of Multi-storied PPL on any plot abutting a road of minimum width of 18 m.,
additional FSI ( hereinafter referred to as "Incentive FSI" ) as specified below on built up
parking area, created and handed over to the Thane Municipal Corporation (TMC) free of cost
with amenities required for parking area as prescribed by the Commissioner such PPL shall be
allowed, on the land belonging to a private owner/Lease hold plots of Govt. and TMC with prior
consent, which is not reserved for any public purpose, subject to the conditions contained herein
below:
I. The minimum area of plot shall be 1000 Sq.m. in sector - 1, 2, 3 and 2000 Sq.m. in
remaining sectors. The minimum number of Motor Vehicle public parking spaces
provided shall not be less than 50. The location of parking spaces can be in 2 level
basement, ground floor or upper 2 floors maximum, with access through ramp/lift or
combination of both subject to clearance from CFO with special emphasis on fire hazard.
II. A Committee under the Chairmanship of Municipal Commissioner, TMC shall earmark/
select the plots for public parking, on the basis of their suitability. The Committee shall
comprise the following or their representatives (i) Metropolitan Commissioner,
MMRDA. (ii) Dy. Commissioner of Police (Traffic), (iii) Joint Director of Town
Planning, Konkan Division (iv) Assistant Director of Town Planning, TMC (Member
Secretary).
(1)
Inserted vide Notification U/s 37 (2) No. CR 236/18 (Part 5) dt. 16th December 2022 & ($) Directives u/s 154 dt. 16th December, 2022.
III. The incentive FSI given on this account will be over and above the base FSI permissible
under any other provisions of UDCPR. This incentive FSI shall be allowed to be used on
the same plot in conformity with UDCPR/ DP, within the overall cap/ limit of total
maximum permissible FSI as given at (vii) below.
IV. The proposed development shall be subject to any other conditions prescribed by the
Municipal Commissioner.
V. Concerned land owner/ developer/ society/ company shall not be allowed to operate the
public parking lot.
VI. Area covered under parking shall not be counted towards FSI consumption.
VII. The incentive FSI permissible under this Regulation against BUA of the PPL shall be
50% of the BUA of the PPL, such that the total permissible FSI including the incentive
FSI under this Regulation does not exceed the limit as per Regulation 6.3.
VIII. The maximum cap on BUA per parking shall be 50 Sq.m. for LMVs, 65 Sq.m. for LCVs
and 120 Sq.m. for HMVs/Buses. Incentive FSI shall be calculated as per BUA of the
PPL, based on these norms or the actual BUA of the PPL, whichever is less.
IX. The developer of the PPL shall pay ‗premium‘, worked out as per the following
formula:-
Premium = 60% of [ Value of the additional BUA corresponding to the incentive FSI
admissible under this Regulation, as per A.S.R. - (Cost of construction of PPL + cost of
any extra amenities/facilities provided + cost of construction of BUA corresponding to
the incentive F.S.I. admissible under this Regulation) ]
For the purpose of calculating premium as above, the cost of construction of PPL
including amenities/ facilities and the cost of construction of BUA corresponding to the
Incentive FSI admissible under this Regulation shall be 75% and 125% respectively of
the rate of RCC construction as per ASR.
X. The Premium shall be paid before the issuance of building permission for the incentive
FSI admissible under this Regulation.
Upon Payment of 100% premium as aforesaid, building permission shall be issued in
respect of 50% of incentive FSI. In no case, Incentive FSI be released without handing
over of the PPL, complete in all respects, to TMC.
The year in which premium is paid before the issuance of building permission for the
PPL shall be taken as the year for determination of construction cost as well as ASR for
calculation of the premium. Out of the total premium payable, 50% shall be paid to the
GoM and the remaining 50% to TMC.
Provision of this Regulation may also be applicable to lease hold plots of Govt. and
TMC with prior approval from Government/ Municipal Corporation.
XI. The land owner/ developer/ Society/ company shall hand over PPL with separate
entrance and exit for the dedicated use of TMC by way of registered conveyance deed.
Such PPL will not be part of proposed society/ apartment/ owners association.
XII. The PPL shall not be permissible in combination with other regulations.
XIII. Public Parking shall be developed in independent building as far as possible, but it may
permissible in composite buildings subject to compliance of these regulations.
XIV. The Commissioner may hand over such PPL to any agency to transparent bidding
procedures for its operations and maintenance upon such terms and conditions as deem
fit and proper. However in any condition such PPL shall not be allotted to concerned
land owners/ housing society/ association of apartment owners of occupiers in the plot of
PPL.
XV. No public parking lots shall generally be more than 500 vehicles. However in
exceptional cases Commissioner may permit PPL for 1000 vehicles for the reasons to be
recorded in writing.
XVI. PPL connectivity to nearest station of Local/ Mono/ Metro/ BRTS etc. may also be
insisted if propose PPL is within 250 m. by skywalk and underground connectivity
within 100 m. These area shall also be counted for giving incentive FSI and shall not be
included for calculating limits of vehicles.
XVII. For every sectors Commissioner shall endeavour to evaluate total need of PPL and shall
cause it to be declared in local newspaper within three months of promulgation of these
regulation for every 5 years. Total PPL sanctioned in any sector shall not increase
beyond that for next 5 years. PPL shall be allowed only after studying traffic impact
analysis of area with the periphery of 250 m. of PPL.
10.2.4 Development around Hazardous Industries (Chemical Zone Areas).
a) Green Belt -
i) There shall be green belt of 100 m. around the boundary of the Hazardous Chemical
Industries as shown on plan attached with the report of authority.
ii) The creation of the green belt, its development and maintenance as per report of authority
will be the responsibility of Municipal Corporation.
iii) The cost of acquisition of land for the green belt, around the Hazardous Chemical
Industries will be borne by the Industry / Industry Association. The private land owner
will be given Transfer of Development Rights based on FSI for the present land usage.
The cost of acquisition to be borne by industry will be exclusive of the value of TDR.
iv) The existing authorised structures should be tolerated. However, only repairs to such
existing structures should be allowed in future and no reconstruction or new construction
should be allowed in the Green Belt.
v) Unauthorised structures should be removed or relocated by the Thane Municipal
Corporation as per the existing Public Policy.
b) Creation of Low Density Zone
i) Beyond the Green Belt, another belt of 150 m. should be created as "Low Density Zone"
as shown on plan, attached with the report of the Authority.
ii) The FSI in the Low Density Zone shall be 0.5 and only Ground plus two storey structures
should be allowed.
iii) The existing buildings if already authorised with the higher FSI and plan of the proposed
building already approved by the Thane Municipal Corporation and Commencement
Certificate have been given to such structure should be allowed to continue, be completed
and occupied by the issuing Occupation Certificate. Where the plans have been approved
by the Thane Municipal Corporation but commencement certificates have not been
issued, they should be reviewed and the permission should be revised in accordance with
the Low Density Zone Regulation, now be prescribed.
iv) The development proposals in Low Density Zone shall be scrutinised and permission
shall be granted as per these UDCPR.
c) Development between 250 and 1000 Meters.
The Development proposals beyond the area of 250 m. shall be scrutinised and
permissions shall be granted as per these UDCPR.
d) Other Stipulations -
i) The original land under Chemical Industry, which has been certified by the Director
of Industries/ Director of Industrial Safety and Health/ Competent Authority as
permanently closed or having shifted elsewhere shall be allowed to be developed as per
the relevant provisions in the prevailing Development Control Regulations.
Upon certification by the Director of Industries/ Director of Industrial Safety and Health/
Competent Authority that the Chemical Industry has been permanently closed or has
shifted elsewhere, the 100 m. Green belt and the further 150 m. low density belt around
the plot boundary of such Chemical Industry shall suo-moto cease to exist.
10.2.5 Development around Air Force Stations.
i) As per Government of India, MoD SRO No. 4, dated 13 January, 2010 which was
published in Part-II Section 4 of Gazette Notification dated 23 January, 2010. Air Force
Station Thane falls within the 100 m. restriction zone. As per notification, no
construction should be permitted within the restricted zone of 100 m. from the outer
parapet of the Air Force boundary. Similarly, live hedges, tree/rows or clumps of trees or
orchards shall not be maintained, planted, added to or altered within the 100 m. restricted
zone. The restriction is equally applicable for construction of underground structure,
wherein no digging and/ or change in the level of ground is permitted within the notified
zone.
ii) Beyond the notified zone of 100 m., no restriction is required to be imposed as per the
Works of Defence Act 1903 and no NOC from Air Force Station, Thane is necessary.
(1) (--)
(2) 10.2.6 Development around Defence Establishment.
Following restrictions are imposed in and around the land in the vicinity of the said unit as per
the plan enclosed with Notification No.TPS-1203/1254/C.R.193/05/UD-12, Dt.30/12/2006.
Village : Kolshet/Kavesar/Waghbil (within the limit of Thane Corporation)
Circle / Taluka : Thane, District : Thane, State: Maharashtra
Height Restrictions:-
(a) The height restrictions to any of the future constructions on North, North-West, West and
South-West sides will be as follows:-
Sr. Height Limiting zones from unit Permissible Remarks.
No. boundary (Zones indicated by colours) height in
meters
A Red Nil Unit Area
B Brown Nil Buffer Zone
(No Dev. Zone)
C Orange 18 --
(1)
No. (iii) & (iv) deleted vide Govt. Corrigendum No. CR 236/18, dt. 9th Dec. 2020.
(2)
Substituted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
D Pink 27 --
E Navy Blue 32 --
F Yellow 46 --
G Violet 64 --
H Green 84 --
(2) (b) The height restrictions to any of the future constructions on North East, East and South-
East sides will be as follows :-
Sr. Height Limiting zones from unit Permissible Remarks.
No. boundary (Zones indicated by colours) height in
meters
A Red Nil Unit Area
B Brown Nil Buffer Zone
(No Dev. Zone)
C Orange 15 --
D Pink 20 --
E Yellow 35 --
F Violet 40 --
G Sky Blue 45 --
Other Restrictions :- In addition to the above restrictions, following general restrictions are also
enforced :-
a) No high tension power line up to 22 KV is to be setup within 1500 meters from unit
boundary.
b) Open wires, overhead lines, including telephone cables are to be outside 500 meters from
unit boundary. However, UG cables. (below 5 meters) are permissible.
c) No rail line with electric traction is permitted within two kilometers from the unit.
d) Area within one kilometer radius from unit boundary is to be clear of all metallic structures
including bridges.
e) Ground water level is to remain constant. No efforts are to be made to change the electrical
conductivity of the designated zone.
f) No industry/equipment, which generates any kind of RG noise, are permitted to operate
within 1 km. Radius from unit boundary.
10.2.7 Regulations for G-1 Zone (Yeur village Section-VII only)
Following uses shall be permitted in G-1 Zone.
The residential Building on the lands which are actually under cultivation and the holiday homes
for weekend stay and the Rest Houses subject to following conditions :-
1) The plot to be permitted for such development shall be not less than 4000 Sq.m. with the
maximum FSI of 0.025.
(2)
Substituted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
2) Each building to be not more than ground plus one storey with height not
exceeding 9.75 m. including the height of stilt portion if any, subject to maximum built
up area 100 Sq.m. excluding stilt.
3) To permit Club House, open play Grounds and other recreational purposes as normally
permissible under green zone with permissible FSI as per these Regulations.
4) To insist plantation at the rate of two fast growing trees per 100 Sq.m. of land under
development.
10.2.8 Regulations for G-3 Zone for Forest Area.
No development of any sort shall be allowed in this zone except the project of the Forest
Department. In case of pockets of private lands in G-3 zone, development shall be permitted as
per the provisions of Green Zone / as per the provisions of G-1/G-2 Zone subject to concurrence
of Forest Department.
10.2.9 (1) For the sake of Regulations No.1.3.74, No. 1.3.93 (xiv)(i) and No.6.2.3(b) High Rise Building
/ Special Building means any multi-storied Residential Building, which is under redevelopment,
and which is more than 25 m. in height above average surrounding ground level.
10.2.10 (2) Redevelopment of Old Dilapidated / Dangerous Buildings
Reconstruction / Redevelopment in whole or in part of any building which has ceased to exist in
consequence of accidental fire / natural collapse or demolition for the reasons of the same
having been declared dangerous or dilapidated or unsafe by or under a lawful order of the
Authority or building having age of more than 30 years, shall be allowed subject to following
conditions.
Redevelopment of multi-dwelling buildings of society/ Co-Operative Housing Societies /
Apartments -
i) The FSI allowed for redevelopment of such building shall be FSI permissible under
Regulation No.6.1 or 6.3 including FSI on payment of premium and maximum
permissible TDR loading as per Table 6-A or 6-G, or the FSI consumed by the existing
authorized building including TDR, premium FSI etc., whichever is more. (Such TDR,
Premium FSI etc. utilised in existing building shall be treated as a basic FSI for
redevelopment.) In addition to this, incentive FSI to the extent of 50% of the existing
authorised built up area or 15 Sq.m. per tenement, whichever is more, shall be allowed.
Provided that in cases where carpet area occupied by residential tenement in the existing
building is less than the carpet area of 27.87 Sq.m. then such tenement shall be entitled
for minimum carpet area of 27.87 Sq.m. and difference of these areas shall be allowed
as additional FSI without any premium.
In case of non-residential occupier the area to be given in the reconstructed building
shall be equivalent to the area occupied in the old building.
Such incentive FSI shall not be applicable for redevelopment of existing bunglow.
ii) This regulation shall be applicable only when existing members of the societies are
proposed to be re-accommodated.
iii) If tenanted building/s and building/s of co-operative housing society/non-tenanted
building/s coexist on the plot under development, then proportionate land component as
per existing authorized built up area of existing tenanted building on the plot shall be
developed as per Regulation No.7.6.2. and remainder notional plot shall be developed
as per this regulation.
iv) Notes below Regulation No.7.6 shall be applicable to this regulation.
(1) Inserted Vide Corrigendum / Addendum No.CR 79/2021, dt. 02nd December 2021.
(2)
Inserted Vide Order No.CR 236/18 (Part 3), dt. 02nd December 2021.
10.2.11 (1) Height of Building Permissible for Re-development Proposals / SRA Proposals
For all re-development proposals and slum-rehabilitation schemes in Municipal Corporation
area, the building height upto 70.0 m. shall be permissible on roads having width between 9.0 to
12.0 m. subject to minimum front margin as per these regulations or minimum 6.0 m.,
whichever is less and subject to condition that such road shall be widened to 12.0 m. under the
provisions of the Municipal Corporation Act, by prescribing line of street before granting
occupation certificate to such buildings of re-development or slum-rehabilitation schemes. This
shall be subject to Fire prevention, protection and life safety requirements and Fire NOC from
Chief Fire Officer.
10.2.12 (1) Podium
Podium for parking alongwith ramp may be permitted with side and rear marginal distance of
1.5 m. from plot boundary, subject to following conditions :-
a) Top of the Podium shall be accessible for Fire Engine by 7.5 m. Ramp with gradient 1:10.
b) Structural Stability Certificate regarding such Podium and Ramp shall be submitted with
respect to stand Fire Engine over it & sustain load of Fire Engine.
c) Minimum 6 m. marginal distances with required turning circle over the Podium shall be
provided for manoeuvring of Fire Engine.
Provided that, if the podium is not accessible for Fire Engine then 6.0 m. marginal open
space shall be provided all around the building excluding front margin. Turning circle
shall not be less than 9.0 m. The refuge area in such cases shall be facing front road and
shall be connected to Fire Tower as per Clause 2.24 of Part 4 of NBC 2016.
d) Provisions mentioned in Regulation No.9.13 shall be applicable except (ii).
10.2.13 (1) Front Marginal Distances / Set-back / Road side margin/s in congested area -
minimum front marginal distance for buildings under re-development proposal shall be
1.5 m. for roads having width 6 m. or more.
10.2.14 (1) Off street parking requirement - For Redevelopment Projects in Thane Municipal
Corporation area, multiplying factor for off street parking requirement as per regulation
no.8.2.2 shall be 0.8.
10.2.15 (a) For Redevelopment of smaller plots having area upto 1500 Sq.m. with
multistoried building upto 24.0 m. height plus height of parking upto 6.0 m., side
/ rear margin of 6.0 m. shall be relaxed upto 3.0 m. subject to Fire NOC, in case
of bonafide hardship and such building shall not be considered as special
building.
(b) Other provisions mentioned in Regulation No.6.2.3 shall be applicable.
(1)
Inserted Vide Corrigendum / Addendum No.CR 79/2021, dt. 02nd December 2021
10.3 NAGPUR MUNICIPAL CORPORATION
The following regulations shall be applicable
10.3.1 Buildings in Commercial Zone :
(a) In non-congested area :
FSI for buildings outside congested area in commercial zone - the basic FSI permissible
shall be 2.00 for commercial cum residential use or purely residential use and 2.50 for
purely commercial use.
(b) In congested area :
The permissible FSI for commercial use shall be 1.50 for the plots fronting on the road
having width less than 9 m. and 2.00 for the plots fronting on the road having width 9 m.
or more.
10.3.2 Buildings in Industrial Zone
a) In congested area, the permissible FSI for industrial use shall be 1.00.
b) In non-congested area, the permissible FSI for industrial use shall be 2.5.
10.3.3 I to R provisions - Allowing Residential/ Commercial uses in Industrial Zone.
The Regulation No. 4.8.1 in these regulations shall be applicable to Nagpur Municipal
Corporation area with following modifications.
i) Any open land or lands of closed Industrial unit/ units in the Industrial Zone (Excluding
the leased out plots by NIT/ NMC) may be permitted to be utilized for all the users
permissible in the Residential zone with permissible FSI in Residential Zone, subject to
payment of premium to be paid equal to 15% of the rate of developed land as given in the
Annual Statement of Rates published by IGR every year.
However, for the Industrial Plots leased out by Planning Authority, (NIT / NMC) while
granting I to R permission on these plots, FSI of 2.5 for purely commercial use and 2.00
for Mix use shall be permissible subject to payment of premium at the rate of 15% for
Residential and 20% for Commercial use. Premium charges shall be as per rate of
developed lands as given in the Annual Statement of Rates published by IGR every year.
ii) Provisions of Regulation No. 4.8.1 (b) (iv) shall not be applicable where the Industrial
layout has already been approved, and where in amenity space has already been provided
in the approved layout.
10.3.4 For Plots admeasuring 1000 Sq.m. and above (including amalgamated plots) in Residential
Zone, basic FSI shall be 1.25, in congested and non-congested area, irrespective of road width.
In cases covered in Regulation No. 10.3.1 and 10.3.4 maximum building potential on plot
including in-situ FSI shall remain the same, as mentioned in Table No. 6 A and 6 G. However,
the owner shall be at liberty to avail, the difference of potential if any, out of column 4 or/ and 5.
10.4 NAGPUR METROPOLITAN REGION DEVELOPMENT AUTHORITY
10.4.1 (#) Development along Ring Road:
250 m. Residential Zone/ Residential Belt proposed along the 60 m. wide Outer Ring Road as a
corridor development is sanctioned, subject to payment of premium. The development in this
250 m. corridor is permitted on payment of premium as decided by the Government on the total
area of land under development or building permission. Such premium shall be deposited with
the concerned Authority.
(#) Clarification issued vide Order No. CR 236/18 (Part 2), dt., 23rd December, 2021
10.4.2 Special Regulations for the Improvement Schemes :
The improvement schemes by Public participation which are sanctioned by the Government
under the provisions of the Nagpur Improvement Act 1936 and which comes under the
jurisdiction of the NMA area shall be valid and continue to be valid for the said purpose under
the said Act. The Special Development Control Regulations for these schemes shall be as
mentioned below :-
Any changes/ Modifications/ Amendments in the details layout or in the master plan shall be
carried out by the Metropolitan Commissioner at his own level. However the Public Amenity/
Public Utility Areas and their percentage as per original sanction shall not be changed while
making Modifications/ Amendments in the Schemes.
i) Improvement Scheme - The scheme is prepared under the NIT Act 1936 for the notified
area and is duly approved by the State Government and which is now included in
NMRDA area.
ii) Original Plot - A plot consisting of nearby khasras calculated as a single record in a
village which is under same ownership and has the same tenure status as defined in the
respective 7 / 12 documents of the khasras.
iii) Final Plot - The plot which is reconstituted or reshaped from the Original Plot within a
draft/ sanctioned Improvement Scheme in a manner appropriate for development and
given access from the public right of way. The Final Plots is reconstituted as per the
relevant regulations/ Act as Final plots for Authorities share and owners share.
iv) Owner - An owner is a person who has legal title for land or building. The definition also
includes :-
a) An agent or trustee who receives the rent on behalf of the owner;
b) An agent or trustee who receives the rent of a or is entrusted with or is concerned
with any building devoted to religious or charitable purposes;
c) A receiver, executor or administrator or a manager appointed by any court of
competent jurisdiction to have the charge of, or to exercise the rights of the owner;
and
d) A mortgage in possession.
v) Permissible FSI For Final Plot -
i) The Metropolitan Commissioner may allow the owner to develop the final plot in
possession of the owner subject to handing over to the Planning Authorities share as
independent plot free of cost as per norms prescribed by Metropolitan
Commissioner.
ii) The owner shall thereafter be entitled to develop his final plot for the uses
permissible in adjoining zone as per the this DCPR with full permissible FSI of the
entire Plot alongwith Additional FSI/TDR potential permissible for his Final plot
share as per Chapter No. 6 of this DCPR .
iii) The Metropolitan Commissioner shall develop the Final Plot in his possession
(Authorities Share) for the purpose for which the scheme is sanctioned. This plot
shall be entitled to be developed as per potential permissible for Authorities Final
plot share as per Chapter No. 6 of this UDCPR.
vi) Net Plot area for Computation of FSI - For the purpose of computing FSI/Built -
up area, the net area of the plot shall be as defined in these regulations.
vii) Special Regulations For Inclusive Housing - The provision regarding inclusive
housing in development proposal shall be not made applicable in Improvement
scheme if the Final Plot in the possession of Authority is to be designed and develop
for the purpose of any affordable housing scheme.
viii) Height of Building - The maximum height of building for all users shall be as per
Chapter No. 6 of this UDCPR.
ix) Amenities Space - If the Amenity space has already provided in the scheme at the
time of approval of scheme/ layout, in such cases the amenity space as required
under this UDCPR shall not be insisted.
x) Land Use Permissible - All land uses mentioned in this UDCPR shall be
permissible in the Improvement Schemes.
xi) Development Charges - The Development charges shall be recovered as mentioned
in these regulations.
xii) Power to Authority - For the smooth implementation of the schemes, the
Metropolitan Commissioner with the Approval of the Authority, makes / amends
the rule in consistent to the relevant Act and Regulations assigned to it with prior
approval of by the Government.
xiii) UDCPR - All regulations of UDCPR shall apply except above special regulations.
(#) 10.4.3 The following regulation shall be applicable only for the reference of Regulation No. 25.6
(xxxx) mentioned in the notification of sanctioning the Development Plan of Nagpur
Metropolitan Region Development Authority.
In Agriculture zone, Residential use shall be allowed subject to following conditions.
a) Minimum area of land shall be 15.0 hect.
b) Land shall front on minimum 12 m. wide existing road.
c) Permissible FSI/ TDR shall be as that of Residential zone.
d) The offsite infrastructure like road, water supply, sewerage treatment plant having
zero discharge shall be developed by land owner at his own cost, unless this
infrastructure is provided by Authority.
e) 10% of the entire holding area shall be handed over to the Authority free of cost,
without any FSI/ TDR and free of all encumbrances for sale by Authority for
residential, commercial or industrial use depending upon the nature of development.
This 10% area shall be over and above recreational open space and amenity space to
be provided as per regulation. This 10% area shall front on minimum 12 m. wide
road.
f) Premium on gross area at the rate of 5% of land rate in Annual Statement of Rates
of the said land without considering the guidelines therein shall be paid to the
Authority.
10.4.4 (1)The following regulation shall be applicable only for the reference of Regulation No. 25.6
(xxxxiii) mentioned in the notification of sanctioning the Development Plan of Nagpur
Metropolitan Region Development Authority.
(1)
Inserted Vide Addendum No.CR 236/18 (Part-1), dt. 23th June, 2021.
(#)
Clarification issued vide letter No. CR 67/2022, dt. 6th September, 2022.
(1) Development permission around the periphery of Gaothan boundary -
Development permission around the periphery of Gaothan boundary shall be allowed as per the
Regulation mentioned as below. This regulation shall be applicable only for the Rural centre and
rural area (excluding nine urban centre area). Regulation for residential zone and other
regulation shall be applicable.
The peripheral residential area shown along the Gaothan village is deleted and land thereunder
included in Agriculture Zone. The development along the periphery of the Gaothan shall be
allowed subject to following:
a) In the villages in Rural area / Rural Centre excluding the area under nine urban centres,
Residential Development or development allowed in Residential Zone, may be permitted
within the periphery of Gaothan boundary as per the criteria given below. The regulations
in respect of residential zone specified in these UDCPR shall be applicable.
Sr. No. Category of Village (Populations as Development allowed from
per latest census) Gaothan boundary
1 Up to 5000 750 M
2 Above 5000 1000 M
Such development may be permitted on payment of premium of the total area of land. Such
premium shall be calculated considering 15 % rate of the said land as prescribed in the Annual
Statement of Rates of the year granting such developments. Such premium shall be deposited in
the concerned Authority.
Provided that, where more than 50% of area of the Survey Number/ Gat Number is covered
within the above peripheral distance then the remaining whole of such Survey number/Gat
number within one ownership shall be considered for development on payment of premium as
above.
Provided further that, the premium charges shall be recovered at the time of tentative approval
of the Development permission. Where tentative development permission is already granted
before publication of this Development Plan and final approval is yet to be granted, then in such
cases premium charges shall not be recovered at the time of final approval.
Provided further that, such payment of premium shall not be applicable in cases where
development permission is already granted or layout is already approved by the authority before
publication of Development Plan. Such premium shall also be not applicable for revision of
such already approved permissions.
However, such development should not be permitted on lands which deserve preservation or
protection from Environmental considerations viz. Hills and Hill tops and within the required
Buffer Zone / prohibited Zone from river, lakes and reservoirs of minor and major project of
water resource department.
10.5 NASHIK MUNICIPAL CORPORATION
10.5.1 Applicability of Regulations for some areas.
i) The special Regulations framed by the Arbitrator for some final plots in TP Scheme No.1
(First Varied) shall remain in force.
(2) (--)
(1)
Inserted Vide Addendum No.CR 236/18 (Part-1), dt. 23th June, 2021.
(2)
Sr. No (ii) deleted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
10.5.2 Development of Cycle Track Along River and Nallah
A cycle track shall be developed in green belt areas earmarked on Development Plan along the
rivers. Also, cycle track proposal is shown on canal land in the Development Plan.
A distance of 6 m. from the edge of minor water course (nallah) is to be left as marginal distance
for construction of any building. A 3 m. strip of land from the edge of such water course out of
this 6 m. distance to be left shall be available for use as cycle track for general public. The
compound wall shall be constructed excluding this distance of 3 m. strip for cycle track. The
owner shall be entitled for FSI of this strip of land for cycle track, in-situ. This 3 m. wide strip
shall be handed over to Municipal Corporation for which, owner shall be entitled for TDR or in-
situ FSI equivalent to 35% of the area of 3 m. wide strip. This regulation shall be applicable for
development of land along Nallahs specified in Plan-A annexed with this UDCPR. Where
development is already taken place and it is not possible to make provision for such 3 m. wide
cycle track, then Municipal Commissioner shall be empowered to decide not to apply this
regulation for particular stretch of nallah. In such cases, normal marginal distances under these
regulations shall apply.
10.5.3 Set back and marginal distances for 36 m. wide D.P. road passing through village
Gangapur and Ambad.
Notwithstanding anything contained in Regulation No. 6.2.1, following set back and marginal
distance shall be applicable for road mentioned below.
Description Min Min Min set Min. Min. Remarks
of the road Plot width back from side rear
Size in of plot road side margins margins
Sq.m. in in meters in in
meters meters meters
36 m. wide 300 12 3.00 2.00 2.00 Margins for
D.P. road buildings G+2 or
(for
from stilt + 3 structure.
commercial
Gangapur Higher height
use also)
S.No. 12 to permissible subject
Ambad to marginal
S.No.199 distances in
Regulation No.6.2.3.
10.6 VASAI VIRAR CITY MUNICIPAL CORPORATION
Following regulations shall be applicable for the low intensity development areas in the Vasai
Virar City Municipal Corporation.
The basic and total permissible FSI with DR/TDR on the plot shall be as under :-
Table No. 10 A
Sr. Land use Zone Base Additional Admissible Maximum
No. FSI FSI on TDR including permissibl
payment of Road widening e FSI
premium FSI if any
1 Low Density Residential Zone 0.3 0.2 -- 0.5
(1)(--)
(1)
Deleted vide Notificatio27n No.CR 121/21, dt. 27/10/2021.
10.7 MIRA BHAYANDAR MUNICIPAL CORPORATION -
10.7.1 Uses permissible in Agriculture Zone.
The lands along 45m., 30 m. wide roads upto a depth of 30 m. may be developed for residential
purpose on condition that the owner should provide infrastructural facilities such as septic tank,
drainage, water supply etc. at his own cost.
10.7.2 Manori-Gorai-Uttan Notified Area
Special Development Control Regulations sanctioned for the Manori-Gorai-Uttan Notified Area
as amended from time to time shall be applicable for the development/ redevelopment in the
said notified area being a special Tourism Development Plan sanctioned for this notified area.
10.8 ULHASNAGAR CITY MUNICIPAL CORPORATION
Regulations of unauthorised development in Ulhasnagar City Municipal Corporation shall be
governed by the Regularisation of Unauthorised Developments in the City of Ulhasnagar Act,
2006.
10.9 KOLHAPUR MUNICIPAL CORPORATION
10.9.1 Open spaces, area, FSI and height limitations for characteristic specified areas in Kolhapur.
For characteristic specified areas in Kolhapur, listed herein below, shall have the open spaces
and regulations for FSI and height limitations as given in table No. 10 B. below :-
TABLE NO - 10 B.
Sr. Particulars of Minimum size of Marginal distance to be observed Permissible
No. Areas plot Max.
Front Rear Side
built-up area
1 2 3 4 5 6 7
1 Rajarampuri 40 x 78 = 3120 Sq.ft. 10.0 2.0 2.6 -
almost all (12.16 m. x 23.77 m.) (3.05 m.) (0.60 m.) (0.76 m.)
plots are of 40 294 Sq.m.
x 78 except
corner plots of
80 x 78
2 Shahupuri 30 x75 = 2250 Sq.ft. 1.0 1.0 1.06 -
Commercial ( 9.12 m. x 22.86 m.) (0.305m) (0.305m)
lane 30 x 75
(9.12 m. x
22.86 m.) or
40 x 75 (12.16
m. x 22.86 m.)
Part of old
cantonment
(new
Shahupuri)
Shown as
ABCDE on
Development
Plan.
Shahu Road 40 x 75 = 3000 Sq.ft. 1.0 1.0 2.6 -
(0.305m) (0.305m)
(12.216m. x 22.86 m)
Other lanes 40 x80 = 3200 Sq.ft. 1.0 1.0 2.6 -
(12.16 m. x (0.305m) (0.305m)
( 0.305 m.)
24.30 m.)
3 Laxmipuri 80 x160 = 12800 20.0 5.0 5.0 -
Sq.ft. ( 24.3m (6.00m) (1.52 m)
(1.52 m)
x48.64m)
50 x100 = 5000 10.0 2.6 2.6 -
Sq.ft.( 15.2 m x (3.05m) (0.76 m) (0.76 m)
30.48m)
40 x80 = 3200 Sq.ft. 5.0 2.6 2.6
(12.16m x 24.3m) (1.52m) (0.76 m) (0.76 m)
4 Subhash road 40 x100 = 4000 Sq.ft. 10.0 3.0 5.0 -
(South side ( 12.16 m x 30.4 m) (3.05m) (0.91 m) (1.52 m)
Uma Talkies
Gokhale Upto 3000 Sq.ft. 10.0 3.0 5.0 -
College (3.05m) (0.91m) (1.52m)
5 Balbag 80 x 120 = 9600 15.0 10.8 5.0 -
Vashant Sq.ft. ( 24.32 m x (4.56 m ) (3.04 m) (1.52 m)
36.48m)
6 Muskuti 40 x 80 = 3200 Sq.ft. 5.0 2.6 2.6 -
Talao ( 12.16 m x 24.32 m ) (1.52m) (0.76 m) (0.76 m)
7 Old 80 x 120 = 9600 2.6 2.6 (0.76 2.6 -
cantonment Sq.ft. ( 24.32 m x (0.76m) m) (0.76 m)
(New 36.48m)
Shahupuri)
Remaining
part area
excluding in
Sr. No. 2
40 x 80 = 3200 Sq.ft. 2.6 2.6 2.6
( 12.16 m x 24.32 m ) (0.76m) (0.76m) (0.76m)
8 Patankar 80 x 120 = 9600 - - - -
Colony Sq.ft. ( 24.32 m x
36.48m)
Main Road 10.0 3.0 5.0 -
(3.05m) (0.91m) (1.52m)
Other Roads 5.0 2.6 2.6 -
(1.52m) (0.76 m) (0.76 m)
9 Rajarampur 40 x 80 = 3200 Sq.ft. 10.0 3.0 5.0 -
New vasahat ( 12.16 m x 24.32 m ) (3.05m) (0.91m) (1.52m)
East side of
Tararani
vidyapeeth
10 Petala New 40 x100 = 4000 Sq.ft. 5.0 3.0 5.0 -
Mahadwar ( 12.16 m x 30.4 m) ( 1.52m) ( 0.91m) ( 1.52m)
Road Other plots interior
roads.
11 Tarabai Park 5000 Sq.ft. and above 15.0 10.0 10.0 -
( 460 Sq.m.) (4.56 m ) (3.05) (3.05m)
7.6
3000 Sq.ft. to 5000 15.0 10.0 -
Sq.ft. ( 278.5 Sq.m. to (4.56 m ) (3.05) (2.25 m)
460 Sq.m.)
12 Shahaji Nagar 5000 Sq.ft. ( 460 15.0 10.0 10.0 -
Sq.m.) (4.56 m ) (3.05) (3.05m)
13 Sykes 80 x 120 = 9600 15.0 10.0 10.0 -
Extension Sq.ft. ( 24.32 m x (4.56 m ) (3.05) (3.05m)
36.40m)
CTS no. 60 x 70 = 3200 Sq.ft. 10.0 5.0 5.0 -
1143, E ( 18.29 m x 21.33 m ) (3.05m) (1.52m) (1.52m)
CTS no. 40 x 80 = 3200 Sq.ft. 5.0 2.6 2.6 -
1141, E ( 12.16 m x 24.32 m ) (1.52m) (0.76 m) (0.76 m)
14 Old Gavat 40 x 80 = 3200 Sq.ft. 10.0 2.6 2.6 -
Mandai ( 12.16 m x 24.32 m )
( 3.04m) ( 0.76 m) ( 0.76 m)
opposite and other Plots.
Jijamata Girls
High School
15 Subhash 40 x60 = 2400 Sq.ft. 5.0 2.6 2.6 -
Nagar (12.16 m x 10.24m) ( 1.52m) ( 0.76 m) ( 0.76 m)
16 Jawahar Nagar 40 x60 =2400 Sq.ft. 10.0 5.0 5.0 -
(12.16 m x 10.24m) ( 3.05m) ( 1.52m) ( 1.52m)
17 Line Bazar 40 x90= 3600 Sq.ft. 10.0 2.6 2.6 -
near Masjid (12.16 m x 27.42m)) ( 3.05m) ( 0.60 m) ( 0.76 m)
18 Shivaji Udyam 80 x 120 = 9600 20.0 3.6 2.6 -
Nagar ( Sq.ft. ( 24.32 m x (6.10 m) (1.064m) (0.76m)
Industrial use 36.48m)
only permitted
except to
residential use
already in use)
40 x 80 = 3200 Sq.ft. 5.0 2.6 2.6 -
( 12.16 m x 24.32 m ) (1.52m) ( 0.76 m) ( 0.76 m)
On Rajaram Road 80 5.0 3.6 5.0 -
x80 = 6400 Sq.ft. (1.064m)
( 1.52m) ( 1.52m)
( 24.32 m x 24.32m)
40 x 80 = 3200 Sq.ft. 5.0 3.6 5.0 -
( 12.16 m x 24.32 m )
( 1.52 m) ( .064m) ( 1.52m)
CTS No. 1325 40 x 80 = 3200 Sq.ft. 5.0( 2.6 2.6 -
( 12.16 m x 24.32 m ) 1.52m)
( 0.76 m) ( 0.76 m)
CTS No. 20.0 5.0 5.0 -
1243/2 to (6.10 m) ( 1.52m) ( 1.52m)
1243/4 for
foundry use.
Power Nagar,
Udyam nagar
extension
19 Dhor Vasahant 80x 160 = 12800 15.0 10.0 5.0 -
Sq.ft. ( 24.32 m x
( 4.56 m) ( 3.05 m) ( 1.52 m)
48.64m)
20 Town Kolhapur No. 1 - - - -
Planning Special
Scheme
For final Plots Upto 2 Gunthas ( less 5.0 5.0 2.06 50%
than 2 area) ( 1.52 m) ( 1.52 m) (0.76m)
For final Plot 2 Gunthas to 5 10.0 5.0 5.0 50%
gunthas ( 2 Ares to 5 ( 3.05m) ( 1.52m) ( 1.52m)
areas)
For final Plots 5 gunthas (5 Ares) 15.0 15.0 10.0 33%
( 4.5 m ) (4.56 m ) ( 3.05 m)
21 Town Planning Scheme Kolhapur No. II Special Regulations.
B) Excepting 15.0 15.0 5.0 33%
above further (4.56 m)
(4.56 m) ( 1.52m)
final plots
22 Two planning
Scheme
Kolhapur No.
III Special
Regulations.
A. Final plot 15.0 15.0 10.0 33%
about 5000 (4.56 m) (4.56 m)
( 1.56m)
Sq.ft. (460
Sq.m.)
B. Final plot 10.0 ( 10.0 10.0 33%
No. 15 and 19 3.04 m)
( 3.04 m) ( 3.04 m)
23 Mahatma 40 x110 = 4400 Sq.ft. 10.0 2.6 2.06 -
Phulewadi ( 12.016 m x 33.53m) (0.76m)
( 3.05 m) (0.76 m)
Housing
society
40 x60 = 2400 Sq.ft. 10.0 2.6 2.6 -
( 12.16 m x 18.29 m) ( 3.05 m) ( 0.76 m) ( 0.76 m)
24 Sambhaji 40 x 80 = 3200 Sq.ft. 5.0 2.0 2.6 -
Nagar ( 12.16 m x 24.32 m )
( 1.52m) ( 0.60 m) ( 0.76 m)
40 x60 = 2400 Sq.ft. 5.0 2.0 2.6 -
( 12.16 m x 18.29 m) ( 1.52 m) ( 0.60 m) ( 0.76 m)
25 Sagar Mal. 50 x 85 = 4250 Sq.ft. 10.0 2.6 2.6 -
Behind
( 15.20m x 25.900m) ( 3.05 m) ( 0.76 m) ( 0.76 m)
Maharashtra
Housing
Board colony.
(Shastri
Nagar)
26 Khasbag Road As per 1.0 1.6 -
from CTS No. gaothan (0.305m) (0.76m)
2557 to 2533 regulation
27 Sakoli Vasahat As per 1.0 1.6 -
to the South gaothan (0.305m) (0.457m)
West of regulation
Rankala S.T.
Stand
28 Timber 100x150 - 15000 15.0 15.0 15.0 (4.56 -
Market Sq.ft. ( 30.48 m x (4.56 m) (4.56 m) m)
45.72m)
29 Golibar 40 x 40 = 1600 Sq.ft. 2.6 2.6 2.6 -
Vasahat K
( 12.16 m x 12.16m ) ( 0.76 m) ( 0.76 m) ( 0.76 m)
Bavada
30 Patharvat 30 x 50 = 1500 Sq.ft. 5.0 2.6 2.6 -
Vasahat Near
( 9.14 m x 15.24 m ) ( 1.52m) ( 0.76 m) ( 0.76 m)
Daulat Nagar
31 Old Vasahats Gaothan Regulation - - - -
would be applicable
a) Dombar Wada
b) Takala portion
on Koti-tirth
32 Sotewala 5.0 2.0 2.6 -
Vasahat
( 1.52m) ( 0.60 m) ( 0.76 m)
33 Nagala Area 5000 Sq.ft. and above 15.0 10.0 10.0 33%
of Tarbai Park ( 460 Sq.m.& above) (4.56 m)
( 3.05 m) ( 3.05 m)
3000 Sq.ft. to 5000 15.0 10.0 7.6 33%
Sq.ft. (278.5 Sq.m. to (4.56 m)
( 3.05 m) (2.25 m)
460 Sq.m.)
34 Hind co- 65 x 80 = 52000 10.0 - 7.0 -
Operative Sq.ft. ( 19.81 m x (3.05 m)
(2.135m)
Housing 24.36 m )
Society
(Ruikar
Colony)
60 x 90 = 5400 Sq.ft. 15.0 5.0 7.0 -
(4.56 m) (1.52 m) (2.135m)
( 18.91m x 27.42m )
35 Dinanath i) 1500 to below 2000 10.0 ( 5.0 5.0
1/2
Mangeshkar Sq.ft. (139.35 Sq.m. 3.05 m)
(1.52 m) (1.52 m)
Nagar - site to 185.80 Sq.m.)
No. 272 & 273
ii) 2000 to below 10.0 10.0 5.0
1/2
3000 Sq.ft. (185.0
( 3.05 m) ( 1.52 m) ( 1.52 m)
Sq.m. to 278.7 Sq.ft.)
iii) 3000 to below 15.0 10.0 7.6
1/2
5000 Sq.ft. ( 278.7 (4.56 m)
( 3.05 m) (2.25 m)
Sq.m. to 464.5 Sq.m.)
36 Sagarmal do do do do do
( S.No. 1330)
E Ward, site
No. 338)
37 R.S. No. 690 400 Sq.ft.( 37016 Gaothan - - -
site No. 365 Sq.m.) Regulatio
n shall be
applied
2.0 2.6
400 to 784 Sq.ft. 5.0
(0.60m) (0.76m)
( 37016 to 67.03 (1.52m)
Sq.m.)
38 Site No. 87 AS mentioned in AS - - -
( Housing the sr.no.l35 mentione
Dishoused) d in
sr.no.l35
39 R.S. No 711 500 to 1000 Sq.ft. 5.0 - 3.0 -
K, Karveer ( 46.45 to 92.90 ( 1.52m) ( 0.9 m )
sq.mt.) on one side
2.6
(Common
distance
( 0.76m)
40 Remanmala 1800 to 2000 Sq.ft. 5.0 2.6 2.6
1/2
Zopadpatti
( 1167.22 to 185.8 (1.52 m) ( 0.76 m) ( 0.76 m)
Sq.m.)
41 Site No. 60 50 x 30 = 1500 Sq.ft. 5.0 2.6 2.6
1/2
(15.24 m x 9.14 m) (1.52 m) (0.76 m) ( 0.76 m)
42 Daulat Nagar 1500 Sq.ft. 5.0 2.6 2.6
1/2
( 139.35m) (1.52 m) (0.76 m) ( 0.76 m)
Note 1 - Maximum permissible Basic FSI for Sr. No. 1 to 3 and 26, 27 and 31 shall be 1.5 for
residential use and 2.0 for residential cum-Commercial use and for remaining areas, it shall
be 1.1 and mix non-residential use to be allowed without any restriction of percentage.
Note 2 - The properties fronting on " Mahadwar to Mahadwar Chowk Road " shall be given
building permission with a front set back of only 0.5 m.
Note 3 - The Maximum permissible Basic FSI, permissible TDR loading and additional FSI
on payment of premium shall be as allowed as per these regulations.
Note 4 - Height of building
i) Height of building to be constructed on Kiranotsav Marg of Mahalaxmi
Temple shall be determined by the Municipal Commissioner.
ii) For Sr. No. 1, 2 & 3 - upto 21 m. height with marginal distances as per
column No. 4, 5 & 6 of table above.
Above 21 m. height - it shall be as per Regulation No. (1) 6.1.1(iii), (vi) or
Regulation No.6.2.3, as the case may be.
iii) For Sr. No. 4 to 42 upto 15 m. as per column No 4, 5 & 6 of table above.
For height above 15 m., 1.0 m. set-back for every 3 m. height on all sides
except front for open plot. For the existing structures and ongoing projects
only front and rear set-back to be kept in addition to the marginal open spaces
as per column No. 4, 5 & 6 of table above. This may be allowed in form of
step margin. Side margin as mentioned in column No. 6 of table above, may
be continued upto 21 m. height.
Above 21 m. height - it shall be as per Regulation No. (1) 6.1.1(iii), (vi) or
Regulation No.6.2.3, as the case may be.
Note - 5 Other provisions excluding above, shall be as per UDCPR.
Note - 6 For parking spaces in basement and upper floor at least one vehicular ramp of 3.00m.
width in side and rear margin for 4 wheeler (2)and for 2 wheeler or one vehicular
ramp of 2 m. width for 2 wheeler shall be provided for plot area upto 1000 Sq.m.
(2)or the owner may provide minimum 2 Car lifts instead of Ramp.
10.9.2 Height of building on Kiranotsav Marg other than specified area.
The height of building to be constructed along Kiranotsav Marg of Mahalaxmi Temple shall be
determined by the Municipal Commissioner.
10.10 NAVI MUMBAI MUNICIPAL CORPORATION
10.10.1 Basic FSI Permissible for Certain Categories of Plots.
Business or Mercantile use wholly or in combination with the residential use in any other zone
mentioned in Regulation, other than Regional Park Zone and No Development Zone, shall be as
below.
Provided that, in case of combination, Business or mercantile use shall not be less than 10% of
the admissible FSI. Provided further that the area of all such plots taken together in the zone
from Node shall not exceed 15% of the area of the relevant zone from the Node.
a. For plots of area below 1000 Sq.m. Basic FSI = 1.00
b. For plots of area 1000 Sq.m. and above
& fronting on minimum 15 m. wide road Basic FSI = 1.50
(1)
Substituted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
(2)
Substituted / Inserted Vide Corrigendum / Addendum No.CR 79/2021, dt. 02nd December 2021.
Note :
1) The benefit of the regulation mentioned at (a) above may be extended to plots of land
leased out or agreed to be leased out by CIDCO earlier with different (lower) FSI, in
Zones other than predominantly Commercial Zone, provided further that all other
UDCPR provisions including parking are fully complied with.
2) All plots leased by CIDCO with FSI 1.50 and fronting on roads less than 15 m. if any,
prior to the sanction of this UDCPR shall be exempted from the 15 m. road with criteria.
If the intended development is within the scheme for allotment of land to the project
affected land holders in the defined area contiguous to the villages or within the scheme
of allotment of 12.5% / 22.5% land to the project affected land holders, 15% of such FSI
may be utilized for commercial area and FSI permissible shall be 1.50. (1) In such case,
the clear marginal open spaces within the plot required to be provided for the purposes
of deriving light and ventilation, shall be as follows :-
Area of plot fronting Max Min. Marginal Open Spaces
Category road (in m.) permissible (in m.)
height of
buildings Front Side Side-2 Rear
Row houses a 40 m2 to less than 13 m 1.5 0.0 0.0 2.2.5
with or 150 m2
without
b 150 m2 to less than 13 m 3.0 0.0 0.0 3.0
common
150 m2
walls
Semi- a 150 m2 to less than 13 m 1.5 2.25 0.0 2.25
detached 150 m2
building
b 150 m2 to less than 13 m 3.0 1.5 0.0 3.0
300 m2
c More than 300 m2 13 m 3.0 3.0 0.0 3.0
to less than 450 m2
Detached a 450 m2 to less than 13 m 3.0 3.0 3.0 3.0
building 1000 m2
b 1000 m2 and above As per regulation No. 6.2 and 6.3 of these
regulation.
(#)3) In case of plot where basic FSI is 1.5 the maximum building potential of plot including in-
situ FSI as mentioned in table 6 G may be allowed to be exceeded by further 0.5.
10.10.2 Reconstruction / Redevelopment of Building in CIDCO / NMMC Areas
Regulation for reconstruction / redevelopment schemes undertaken by CIDCO/Owner‘s
Association / Co-operative Housing Society (CHS) in respect of the authorized buildings
previously constructed by CIDCO but subsequently destroyed by natural calamities or
accidental fires or which have collapsed by aging or are demolished or being demolished under
a lawful order of the Municipal Commissioner etc.:-
Reconstruction / Redevelopment, in whole or in part of a building, previously constructed by
CIDCO (not being a building wholly occupied by warehousing / Industrial user and also not
being an individually owned structures, which has ceased to exist for the reasons mentioned
above) or a building constructed by CIDCO which has been declared dilapidated by the
(1)
Inserted vide Notification u/s 37 (1AA)(c) No. CR 236/18 (Part 6) dt. 12th October, 2022
(#) Clarification issued vide Letter No. CR 42/21, dt. 14th June, 2021 &Order No. CR 236/18 (Part 2) dt. 12th October, 2022.
Commissioner NMMC or a buildings constructed by CIDCO which is above 30 years of age,
irrespective of its status of dilapidation, (hereinafter collectively referred to as "dangerous /
dilapidated building") shall be permissible in accordance with the following Regulations.
Regulation for Reconstruction / Redevelopment :-
1. For redevelopment of building or buildings in the housing schemes of CIDCO, containing
houses or tenements for (i) EWS / LIG and / or (ii) MIG and/or (iii) HIG, the total
permissible FSI shall as specified in Table below or Rehab + Incentive FSI as per clause
2(A) & (B), whichever is more and shall be based on gross plot area:-
Table No -10 C
Sr. No. Category Permissible FSI
i) Plot area of 1000 sq.mt. or more and having 3.00
access road of minimum 15 m width.
ii) Plots area of 1000 sq.mt. or more and having 2.00
access road of minimum 9m. width
iii) All other plots having access road below 9m 1.80 or Authorisedly consumed
width. FSI + 50% Incentive whichever
is less
If the entitlement of FSI as above is less than maximum building potential mentioned in
column 6 or 9 of Table 6-G of Regulation No.6.3, then difference of FSI entitlement shall be
availed by payment of premium. Moreover, the maximum building potential mentioned in
Table No.6-G shall be allowed considering the road width one step below subject to road
width of minimum 12 m.
e.g. for the roads as mentioned at Sr.No.3 in Table No.6-G, the maximum building potential
shall be considered as given at Sr.No.4.
Identification of dangerous / dilapidated buildings shall be done by a Committee Under the
Chairmanship of the Municipal Commissioner, NMMC, comprising Superintendent
Engineer, Public Works Department, Thane; Joint Director, Town Planning, Konkan
Division; City Engineer, NMMC; Chief Engineer, CIDCO; Chief Planner, CIDCO and such
other members as may be appointed by the Municipal Commissioner, NMMC, having
regard to their academic qualifications, technical competence and previous experience in the
field of Structural Engineering.
2. Where redevelopment of any dangerous / dilapidated buildings(s) in a Housing Scheme of
CIDCO constructed building is undertaken by the Co-op Housing Society or the occupiers of
such building(s) or by the lessees of CIDCO, the Rehabilitation area Entitlement, Incentive
FSI and sharing of balance FSI shall be as follows:-
A) Rehabilitation Area Entitlement :
i) Under redevelopment of any dangerous / dilapidated building(s) in a
Housing Scheme of CIDCO, the entitlement of rehabilitation are for an existing
residential tenement shall be equal to sum total of-
(a) a basic entitlement equivalent to the carpet area of the existing
tenement plus 35% thereof, subject to a minimum carpet area of 300 Sq.ft.
and
(b) an additional entitlement, governed by the size of the plot under
redevelopment, in accordance with the Table below :-
Table No - 10 D
Area of the Plot under Additional Entitlement (As % of the
Redevelopment Carpet Area of the Existing Tenement)
Upto 4000 Sq.m. Nil
Above 4000 Sq.m. to 2 hect 10%
Above 2 hect to 5 hect 15%
Above 5 hect to 10 hect 20%
Explanation: The plot under redevelopment means the total area of the land on which
redevelopment of dangerous / dilapidated building (s) is to be undertaken.
Provided that the maximum entitlement of rehabilitation area shall in no case exceed the
maximum limit of carpet area prescribed for MIG category by the Govt., as applicable
on the date of approval of the redevelopment project.
Provided further that the entitlement of rehabilitation area, as admissible under this
regulation, shall be exclusive of the area of balcony.
ii) Under redevelopment of any dangerous / dilapidated building(s) in a
Housing Scheme of CIDCO, the entitlement of rehabilitation area of any
existing authorized commercial unit / amenity unit in the Residential Housing
Scheme shall be equal to the carpet area of the existing unit plus 20% thereof.
B) Incentive FSI : Incentive FSI admissible against the FSI required for rehabilitation,
as calculated above, shall be based on the ratio (hereinafter referred to as Basic
Ratio) of Land Rate )LR) in Rs/Sq.m. of the plot under redevelopment as per the
Annual Schedule of Rates (ASR) and Rate of Construction (RC)* in Rs/Sq.m.
applicable to the area as per the ASR and shall be as given in the Table below :-
Table No - 10 E
Basic Ration (LR/RC) Incentive (As % of Admissible Rehabilitation Area)
Above 3.00 70%
Above 2.00 and upto 3.00 80%
Above 1.00 and upto 2.00 90%
Upto 1.00 100%
Explanation :- *RC is the rate of construction in respect of R.C.C. Construction, as published
by the Chief Controlling Revenue Authority & Inspector General of Registration, Maharashtra
State in the Annual Schedule of Rates.
Provided that the above incentive will be subject to the availability of the FSI on the Plot under
redevelopment and its distribution by NMMC, with prior approval of CIDCO.
Provided further that in case there are more than one land rate applicable to different parts of the
plot under redevelopment, a weighted average of all the applicable rates shall be taken for
calculating the Average Land Rates and the Basic Ratio.
Provided further that the Land Rate (LR) and the Rate of Construction (RC) for calculation of
the Basic Ration shall be taken for the year in which the redevelopment project is approved by
the authority.
C) Sharing of the Balance FSI :
The FSI remaining in balance after providing for the rehabilitation and the incentive
components, calculated as per (A) and (B) above respectively, shall be shared between
the existing or proposed Co-operative Housing Society / Apartment Ownership
Association and CIDCO, in the form of built-up area, as given in Table below and the
share of CIDCO shall be handed over to CIDCO free of cost.
Table No - 10 F
Basic Ratio (LR/RC) Sharing of Balance FSI
Society / Association Share CIDCO Share
Above 3.00 30% 70%
Above 2.00 and upto 3.00 40% 60%
Above 1.00 and upto 2.00 50% 50%
Upto 1.00 60% 40%
Provided that building or buildings under redevelopment in the NMMC area, upto 20% of the
CIDCO‘s share in the form of tenement shall be handed over free of cost to the NMMC.
NMMC require the same for rehabilitation of the project affected persons.
2.1 Where redevelopment of dangerous / dilapidated building(s) in a Housing Scheme of
CIDCO is undertaken by CIDCO directly or jointly by CIDCO along with the Co-
operative Housing Society / Association or the occupiers of such building(s) or by the
lessees of CIDCO, the Rehabilitation Area Entitlement, incentive FSI and sharing of
balance FSI shall be as follows:
A) Rehabilitation Area Entitlement :
The Rehabilitation Area Entitlement shall be increased by 15% of the existing
carpet area, over and above the Rehabilitation Area Entitlement calculated in (A)
of Clause 2 above, subject to the maximum of the size of MIG, prescribed by the
Government in the Housing Department.
B) Incentive FSI : Incentive FSI shall be the same as in (B) of Clause 2.
C) Sharing of the balance FSI : There shall be no sharing of the balance FSI,
which shall be entirely available to CIDCO for implementing Affordable
Housing Project.
3. Other requirement / Criteria :
i. For the purpose of calculating the FSI, the entire area of the layout including widening
of existing roads and internal roads but excluding the land earmarked for public
amenities shall be considered. Sub-division as well as amalgamation of plots shall be
permissible. Amalgamation of more than one Apartment Owners‘ Association / Co. op.
Hsg. Society (CHS) / Residents‘ Association shall be permissible and after such
amalgamation, the amalgamated plot should be in the name of the applicant CHS with
legal ownership title, without considering the provision made in the Regulation of the
DCR. However consent of at least 70% leaseholders / occupants who intend to
amalgamate such condominium shall be necessary.
ii. In a condominium/plot area, widening of existing roads as per the regular line of street
prescribed by the Commissioner, NMMC or widening of road providing vehicular
access to the condominium plot to bring it to the minimum right of way as prescribed in
Table No. 10 C, shall be permissible for reconstruction / redevelopment, after handing
over required stretch of land under road to NMMC, free of cost, duly developed with
storm water drains and footpath, if any, to the satisfaction of the Municipal
Commissioner.
iii. In case where there are a number of dangerous / dilapidated buildings on a plot, in such
cases, equivalent Land component of such buildings shall be worked out and incentive
F.S.I. shall be based on such land component.
iv. The normal permissible tenement density per net hectare may be allowed to be
exceeded in multiple of F.S.I. permissible.
v. The existing residential premises (other than R+C premises) shall be permitted to be
redeveloped for residential user only. No change of use from Residential to Residential
cum Commercial shall be permitted. However, in such premises, if area of such plot is
more than 1000 Sq.m. and the same is fronting on a road having width of 20 mtr and
above then it shall be permissible to construct convenience shopping to the extent of 5%
of the plot area and if the plot area is more than1000 sq.mr and the plot is fronting on a
road having width of 30 mtrs and above then this limit for convenience shopping will be
upto 10%.
vi. In a condominium/plot area, It shall be mandatory to keep minimum 10% or 15%, as
the case may be, compulsory recreational open space on ground clearly open to sky over
and above podium garden, in the proposed redevelopment project in respect of land area
between 2500 sq.mt. to 4000 sq.mt. or more than 4000 sq.mt., respectively.
vii. 5% of the Plot area under reconstruction / redevelopment project shall be surrendered to
the Municipal Corporation, free of cost, towards essential amenity area, in case the plot
area is more than 2500 sq.mt. The FSI of such amenity area shall be permissible on the
balance plot area and the entire area of such amenity space will be considered for
computation of FSI, without deducting this area from the gross plot area. However, 1.0
FSI out of amenity space FSI will be deducted from the total permissible FSI.
Alternatively carpet area equivalent to 5% of the area of the plot Under redevelopment
can be constructed within the Scheme, providing Separate access, and handed over to
NMMC free of cost as Social amenity.
viii. The Layout of entire condominium / residential / Residential cum commercial premises,
duly signed by the Apartment owners‘ Association/CHS shall be submitted at the time
of Commencement Certificate to ascertain the feasibility of the entire condominium for
redevelopment, so that in future, proper redevelopment of other buildings in the
condominium/residential premises is smoothly feasible. However, such redevelopment
can be undertaken in a phased manner in respect of one or two buildings likewise as per
the approved layout of the entire condominium/residential premises. In case of such
partial redevelopment, the infrastructure charges shall also be deposited in proportion to
the area under such partial redevelopment.
ix. For the purpose of deciding the authenticity of the age of the structure, if the approval
plans of such existing structure are not available, the Municipal Commissioner shall
consider other evidence such as Assessment Record, or city survey record or sanad.
x. In any Redevelopment project where the existing or proposed Co-operative Housing
Society/Apartment Owners‘ Association/Developer appointed by the concerned
Society/Association has obtained No Objection Certificate from the CIDCO, thereby
securing additional balance FSI with the consent of 70% of its members and where such
NOC holder has made provision for alternative accommodation in the proposed
building (including transit accommodation), then it shall be obligatory for all the
occupiers / members to participate in the Redevelopment Scheme and vacate the
existing tenements for the purpose of redevelopment. However, in case of Apartment
owners‘ Association, the Consent as per the concerned Act will be required.
xi. For redevelopment of any dangerous / dilapidated buildings in any Housing Scheme of
CIDCO under clause 2.1 hereinabove, by CIDCO, the consent of the Cooperative
Housing Society in the form of a valid Resolution as per the Co-operative Societies Act,
1960 will be sufficient. Similarly in case of Apartment Owners‘ Association, the
consent as per the concerned Act will be required.
xii. For providing the requisite infrastructure for the increased population, an infrastructure
charge at the rate of 10% of the Land Rate as per the ASR of the year of approval of the
redevelopment project shall be levied and charged by the NMMC for the extra FSI
granted for the redevelopment project, over and above the Basic Zonal FSI.
xiii. A corpus fund, as may be decided by Municipal Commissioner, shall be created by the
Developer which shall remain with the concerned Co-operative Housing Society /
Apartment Owners‘ Association for the maintenance of the new buildings under the
Rehabilitation Component.
xiv. For the purpose of this Regulation, the carpet areas for EWS, LIG or MIG tenements
shall be as determined by the Government in the Housing Department from time to
time.
XV. Any redevelopment proposal where NMMC has already issued Commencement
Certificate (C.C.) prior to the date of coming into force of this Modification (hereinafter
referred to as "the appointed date") and which is valid as on the appointed date, shall be
allowed to convert to redevelopment projects under this Regulation, provided it satisfies
all the requirements specified in this Regulation.
10.10.3 Road width of 11 m.
The road width of 11 m. in Navi Mumbai Municipal Corporation area shall be treated at par
width of 12 m. for all purposes including permissible uses mentioned in this UDCPR.
10.10.4 Allowance of premium FSI in lieu of TDR
In addition to the quantum of premium FSI mentioned in Table 6A of Regulation No.6.1.1 and
Table 6G of Regulation No.6.3, the additional premium FSI to the extent of TDR mentioned in
the said table shall be allowed till the generation of TDR in Navi Mumbai Municipal
Corporation area (1) and CIDCO as a Planning Authority by virtue of NTDA.
10.10.5 Provision of Amenity Space.
The Regulation No.3.5 shall not be applicable to CIDCO area.
Provision of Recreational Open Space
10.10.6
The recreational open space required to be provided in the lands allotted outside the Action area
shall be as per the relevant clause of the Agreement to lease or as per these regulations
(UDCPR), whichever is more.
The Action area means area for which the CIDCO intends to prepare a detailed layout plan with
special development control regulations.
(1)
Inserted vide Notification u/s 37 (1AA)(c) No. CR 236/18 (Part 6) dt. 12th October, 2022
10.11 NATIONAL PARK AND TUNGARESHWAR ECO-SENSITIVE ZONE -
10.11.1 Development around National Park and Tungareshwar Eco-sensitive Zone
The restrictions imposed by Ministry of Environment, Forests and Climate Change for the Eco-
sensitive Zone declared around Sanjay Gandhi National Park and Tungareshwar Eco-sensitive
Zone shall be applicable as amended from time to time in addition to these Regulations.
10.12 MAHARASHTRA AIRPORT DEVELOPMENT COMPANY NOTIFIED AREA.
10.12.1 In the areas notified for Maharashtra Airport Development Company as Planning Authority /
Special Planning Authority, the following additional regulation shall be applicable.
The basic FSI permissible for development in Airport and allied activities / services, Special
Economic Zone, Mix Use Zone, Public-Semi-Public Zone shall be 1.50.
10.13 BHIWANDI SURROUNDING NOTIFIED AREA
10.13.1 REGULATIONS FOR AFFORDABLE HOUSING SCHEME:
In order to promote construction of affordable housing stock on private lands, the Planning
Authority may permit implementation of Affordable Housing Scheme in accordance with the
provisions of these Regulations. Affordable Housing Scheme (hereinafter referred to as 'the
Scheme') shall be permissible only on the lands situated within the limits of the Bhiwandi
Surrounding Notified Area in the Mumbai Metropolitan Region (MMR).
(i) Affordable Housing Scheme shall be permissible in Residential Zone / Affordable
Housing Zone shown on the Development Plan only and on plots having access from an
existing or proposed Development Plan Road having width equal to or in excess of 18
nit, or an existing road in respect of which Regular Line of Street has been declared under
the relevant provisions of Maharashtra Municipal Corporation Act, Maharashtra
Municipal Councils, Nagar Panchayats and Industrial Townships Act, 1965 for a width of
18 mt. or more, provided permissible FSI on such plots is 0.95 or more and
TDR/additional FSI on payment of premium more than 0.6 is allowable. However in case
of a proposed road, the land under the said proposed road shall be acquired before the
approval of building plans for the Affordable Housing Scheme. Affordable Housing
Scheme shall not be allowed in areas where FSI is less than 0.95 or where use of TDR is
not permissible.
(ii) Minimum plot area for the Affordable Housing Scheme shall be 4000 sq.mt. excluding
area under D.P. Roads and D.P. Reservations, if any.
(iii) The plot under the Scheme shall be independent, unencumbered and contiguous.
(iv) The Scheme shall not be permissible in congested areas, demarcated as such on the
Development Plan.
3. The Special Planning Authority for Bhiwandi Surrounding Notified Area shall be competent
to grant both location clearance and layout approval/building permission for an Affordable
Housing Scheme.
4. (i) Maximum permissible FSI (including the base FSI of 1.00) under the Scheme shall
be 3.00 on the gross plot area, including mandatory layout recreational open space and
Amenity Space. The FSI to be utilized shall be in the proportion of 1:3 for the Affordable
Housing Component and the Free Sale Housing Component on 1/4th and 3/4th part of the
land respectively. Thus Affordable Housing and Free Sale Housing shall be proposed on
the same plot of land but on two separate independently buildable pockets. For lands in
Affordable Housing Zones, the owner/ developer may be allowed to develop the land as
per the Rules of the Affordable Housing Policy with the proviso that free sale to
Affordable Housing FSI ratio will be 1.8:1 instead of 1.66 : 1 and the maximum FSI will
be 2.5. Or
the owner / developer may be allowed to develop the land as permissible in Residential
Zone as per prevailing Development Control Regulation subject to the condition that the
area of tenements to be constructed with entire potential of the land, shall be of
Affordable Housing Scheme. However if the provisions of inclusive housing stipulated in
UDCPR are applicable to this area then, it shall also be made applicable to such land.
(ii) Under Affordable Housing Scheme, upto 15 % of the total built-up area of the Affordable
Housing Component may be used for construction of shops / commercial use as per the
direction of Special Planning Authority for Bhiwandi Surrounding Notified Area and
such commercial built-up area shall be handed over to the Special Planning Authority for
Bhiwandi Surrounding Notified Area free of cost.
5. (i) An Affordable Housing Unit shall be a self-contained dwelling unit of 25 sq.mt,
carpet area, However the carpet area of a Housing Unit shall be 160 Sq.ft., where the
construction under the Rental Housing Scheme has already commenced.
(ii) The amenity space for Affordable Housing shall be 10 % of the gross plot area under the
Scheme and it shall be proportionately provided in the area earmarked for the Affordable
Housing Component and the Area kept for Free Sale Housing Component.
Provided that where the Scheme is to be implemented on a plot in Industrial Zone where
the Planning Authority has duly permitted Residential user under the relevant provisions
of the Development Control Regulations:-
no further area shall be required to be kept as amenity space under Regulation 5 (ii) for
the Scheme if the area prescribed to be kept as amenity space while permitting residential
user in Industrial zone is equal to or more than 10% of the gross plot area.
only the balance area shall be required to be kept as amenity space under Regulation 5(ii)
for the Scheme if the area of amenity space prescribed by the Planning Authority, while
permitting residential user in Industrial zone, falls short of 10%.
(iii) Notwithstanding anything contained in the relevant provisions of the Development
Control Regulations of Amenity Space in general, and also regarding permitting
Residential User in Industrial Zone, it shall be obligatory on the Developer/Owner to
develop the amenity space for users (hereinafter referred to as prescribed amenity users)
such as School, Play Ground, Garden, Health Care Facilities, Multipurpose Hall,
Auditorium, etc. with the approval of Chief Executive Officer of Special Planning
Authority, as per the specifications prescribed by the said Authority, subject to the
condition that at least 50% of such amenity space shall be kept for open users, before
seeking Occupancy Certificate for the Free Sale Housing Component of the Scheme,
failing which the land under such amenity space shall be handed over free of cost to the
Planning Authority and such land shall be developed by the Chief Executive Officer of
Special Planning Authority for the aforesaid prescribed amenity users only.
No compensation in the form of TDR shall be admissible to the Owner/Developer for
development of such prescribed amenities under this Regulation.
(iv) Irrespective of whether the Owner / Developer develops the prescribed amenity users as
per the provision of Clause (iii) above or fails to do so, the process of handing over the
land under such amenity space, along with the developed prescribed amenities, where
such prescribed amenities have been developed, shall be completed within one month
from the date of application by the Developer / Owner for seeking Occupancy Certificate
for the free sale Housing Component of the Scheme and if such handing over process is
not completed within the said period, the occupancy Certificate for the free sale Housing
Component of the Scheme shall be withheld by the Chief Executive Officer of Special
Planning Authority, till such amenity space, along with developed prescribed amenities,
where such prescribed amenities have been developed, is handed over to the Planning
Authority.
(v) Under the Affordable Housing Scheme, there shall be a welfare hall and a Balwadi at the
rate of 30 sq.mt. for every multiple or part of 200 residential units and an office for
Managers/Co-operative Housing Society at the rate of 30 sq.mt. per every multiple or
part of 500 residential units which shall be treated as a part of Affordable Housing
Component and shall not be counted towards the FSI while computing 3.00 FSI on the
site and shall be given along with layout/DP roads and shops, free of cost to the Special
Planning Authority for Bhiwandi Surrounding Notified Area. These facilities shall be
constructed at locations as suggested by the Special Planning Authority for Bhiwandi
Surrounding Notified Area and shall be transferred free of cost to it.
6. Under the Affordable Housing Scheme, Off-Site Infrastructure Charges at the rate of 5%
of the land rate as given in the Annual Statement of Rates (ASR) prepared by the Inspector
General of Registration, Maharashtra State, for the year in which Commencement Certificate is
issued, subject to a minimum of Rs. 2000 per sq.mt., shall be paid by the Developer for the built
up area, over and above the normal permissible FSI. This amount shall be paid to the Special
Planning Authority for Bhiwandi Surrounding Notified Area.
7. Release of FSI under the Scheme shall be as follows:-
FSI for Affordable Housing Component and the Free Sale Housing Component under the
Scheme shall be released in accordance with the following Table:-
Sr. Stages of Release FSI Affordable Free Sale
Housing Component*
No.
Component*
1 On Grant of Building Permission/ 3.00 1.00
Commencement Certificate up to plinth by
1.1-L-B Special Planning Authority for
Bhiwandi Surrounding Notified Area
/Planning Authority to the Affordable
Housing Project.
2 On Completion of 50% BUA of Affordable - 0.75
Component
3 On Completion of 100% BUA of Affordable - 0.75
Component
4 On handing over of 25% land and completed - 0.50
Affordable Housing Component buildings
with Occupancy Certificate
Total 3.00* 3.00*
*Explanation- The FSI of 3.00 is to be calculated on the one-fourth of plot area for Affordable
Housing Component as well as three-fourth of plot area for Free-Sale Housing Component.
8. The Affordable Housing Component under the Scheme shall be handed over alongwith the
1/4 part of the total plot of land, free of cost to the Special Planning Authority for Bhiwandi
Surrounding Notified Area.
9. (i) The affordable Housing stock created under the Scheme shall be allotted by the
Special Planning Authority for Bhiwandi Surrounding Notified Area as follows:-
Percent Allotment to Category of Rate of Allotment
age Stock
25 Special Planning Authority for Bhiwandi Ownership Free of Cost
Surrounding Notified Area for use as
PAP tenements or Staff Quarters or
Transit Accommodation,
25 Outright sale to Govt. of Maharashtra and Ownership As per Construction
its statutory bodies / Govt. undertakings rate of ASR
for use as PAP tenements or staff quarters
or Transit Accommodation.
50 Outright sale as affordable housing by Ownership Free of Cost to
MHADA subject to the general or MHADA which shall
specific directions of the Government. dispose of the same
as per its pricing
policy and by draw
of lots.
(ii) The Affordable Housing stock shall be disposed of as per the prevailing policy of
MHADA regarding pricing and disposal of its housing Stock meant for affordable
housing. Each Project approved under the Scheme Shall be brought to the notice of the
Government of Maharashtra and its statutory bodies/Government undertakings by means
of Press Advertisement and if the Government of Maharashtra or any of its statutory
bodies/Government Undertakings doesn't place firm requirement for the housing stock
earmarked for them in the Scheme before the Completion Certificate/Occupation
Certificate for the said Scheme is issued, the same shall come to the share of MHADA
for outright sale as per the Prevailing Policy of the MHADA.
10. (i) The other aspects of the Development of Affordable Housing Scheme, not specifically
dealt with hereinabove, shall be as per the relevant provisions of the Development
Control Regulations of the respective Planning Authority.
(ii) It shall also be permissible for the Developer/Owner to utilize the FSI available for Free
Sale Housing Component, fully /partly for any other user otherwise permissible as per
Development Plan and Development Control Regulations.
(iii) In case owing to genuine hardship and site conditions, relaxation in marginal open spaces
is sought by the Developer/Owner, the Chief Executive Officer of Special Planning
Authority may consider such request, using his discretionary powers under the
Development Control Regulations, subject to the condition that in no case shall the clear
marginal open space reduced below 6.m No premium shall be charged for granting such
relaxation in marginal open space in respect of Affordable Housing Component of the
Scheme.
11. No project under the Rental Housing Scheme envisaged under the said directives issued by
the Government vide orders dated 61h August 2008, 25h August 2009,49' November 2008 and
August 2008 shall be permitted after the date on which the Notice No TPS-1212/79/C R
60/12/11D,12, Dated 30th November 2013 regarding this Regulation Under section 37 (IAA) of
the Maharashtra Regional and Town Planning Act, 1066 was published in the official (herein
after referred to as 'the cut cat date')
Provided that the Rental Housing Projects in respect of which Location Clearance had been
granted by MMRDA, but Commencement Certificate has riot been issued by the concerned
planning Authority, shall he allowed to continue, as such in case such project proposals are
resubmitted to MMRDA within a period of 31) days from the date of this Notification in the
Official Gazette. All such project proposals received by MMRDA within the prescribed time
limit shall be scrutinized by MMRDA on merit and submitted for the prior approval of the State
Government for their continuance under the Rental Housing Scheme.
Provided further that the Rental Housing Projects already approved may be allowed to be
converted into Affordable Housing Projects under the provisions of this Regulation, with prior
approval of the State Government.
10.14 CIDCO AREA EXCLUDING NAINA AREA
10.14.1 The Regulations No. 10.10.1, 10.10.2, 10.10.3, (1)10.10.4, 10.10.5 and 10.10.6 shall be
applicable to CIDCO area.
10.14.2 Regulations for Land Compensation Scheme and Rehabilitation Pocket in Navi Mumbai
(i) Land Compensation Scheme and Rehabilitation Pocket: Land Compensation Scheme
means the Scheme devised by City and Industrial Development Corporation of
Maharashtra Ltd. (CIDCO) with the approval of State Government vide Government
Resolution CID1812/C.R. 274/UD10, dated 1/3/2014 and as amended from time to time
for compensating the land holders whose lands are being acquired on or after 1st March
2014, The Rehabilitation Pocket means the land identified by CIDCO for allotment under
land compensation scheme. The compensation under Scheme shall have three
components.
a) Component - I: involving allotment of 10% developed land in lieu of monetary
compensation after deduction of 30% of the eligible area for the development of
infrastructure and amenities. Maximum 15% FSI may be used for commercial use
provided that such commercial use shall be permissible as per provisions of UDCPR
b) Component - II: involving allotment of 12.5% developed land in lieu of monetary
compensation after deduction of 30% of the eligible area for the development of
infrastructure and amenities. Maximum 15% FSI may be used for commercial use
provided that such commercial use shall be permissible as per provisions of UDCPR
c) Component - III: involving allotment of developed plot to the eligible owner of the
house whose house and land under house are being acquired and resettled at another
location Maximum 15% FSI may be used for commercial use provided that such
commercial use shall be permissible as per provisions of UDCPR
(ii) Floor Space Index admissible on lands allotted under the scheme shall be as follows:
a) Component - I: Floor Space Index for the development of lands allotted under
Component - I shall be 2.5.
(1)
Inserted vide Notification u/s 37 (1AA)(c) No. CR 236/18 (Part 6) dt. 12th October, 2022
b) Component - II: Floor Space Index for the development of land allotted under
Component - II shall be 1.5.
c) Floor Space Index for the development of total land allotted under Component - I
and Component - II that is 22.5% shall be 2.0.
d) Component - III: Floor Space Index for the development of land allotted under
Component - III shall be 1.5.
e) The base FSI of the lands within Pushpak Node as described by CIDCO shall be 2.0
irrespective of the land use and the maximum permissible FSI shall be 2.5.
Provided that with the previous approval of VC & MD, CIDCO, this additional 0.5
FSI may be granted for utilization on these plots subject to payment of additional
premium as may be decided by the Corporation.
Alternatively, with the previous approval of VC & MD, CIDCO, additional FSI 0.5
in the form of DRC shall be allowed on lands within the Pushpak Node only over
and above the base FSI of 2.0. However, while granting such additional 0.5 FSI
VC & MD, CIDCO shall give priority to grant of such additional FSI in the form
of DRC.
(1)(f) The basic FSI for the lands allotted to project affected person by the JNPT in any
area, defined and made available by the JNPT under 12.5 % scheme, shall be
2.0. All the aspects of development shall be governed by these regulations.
Provided that
A Maximum FSI 2.0 shall be admissible for plots having an area equal to or in as excess of
1000 sq. mtr., however in case, the available FSI cannot be used at site due to hardship of
height restriction and for any other reasons recorded in writing in Pushpak Node, floating
of TDR shall be allowed and such TDR shall be used within Pushpak Node only with the
approval of VC & MD.
B FSI 1.5 shall be admissible for plot having area less than 1000 sq. mtr. and the balance 0.5
or 1.0 FSI, as may be applicable, shall be admissible for utilization in the form of
Development Right Certificate (DRC) as a Transferable Development Right (TDR), the
utilization of which shall be within Pushpak Node only.
(iii) Locations for utilization of DRC -
DRC in the form of TDR shall be eligible for utilization in the following locations.
a) Pushpak Node as shown on the plan with CIDCO.
(iv) Extent of Utilization of DRC :
The utilization of DRC within Pushpak node only shall be permitted is as follows:
Maximum Permissible Utilization of
Road width
TDR in addition to basic FSI under these
regulations.
Equal to or above 20.0 mtr and along the
Upto 0.5 FSI on receiving plot.
service road in Pushpak node
(1) Inserted vide Notification u/s 37 (1AA)(c) No. CR 236/18 (Part 6) dt. 12th October, 2022
(2) 10.14.3 Development of land Notified for Acquisition
i) In case of land notified for acquisition under the Land Acquisition Act 1894 or The
Right to Fair Compensation and Transparency in Land Acquisition, Rehabilitation
and Resettlement Act, 2013 and where the land has not been acquired, the CIDCO may
in its absolute discretion to grant permission for temporary development
Provided that the period of such temporary development shall not exceed 1 year and
provided further that the applicant shall undertake to remove the so executed on or
before the date specified by the CIDCO
ii) Temporary Development shall be permissible as per uses permissible in respective
zones as per UDCPR.
iii) The permission may be renewed from time to time at the discretion of the CIDCO.
iv) Security Deposit :-
a. The applicant shall deposit and keep deposited an amount as Security Deposit at
the rate of Rs. 10/- per Sq.m. of the floor area of the proposed development for
the due performance of the conditions of the permission granted under the
Commencement Certificate.
b. The amount shall be refunded, without interest; after the removal of the
development with due compliance with the conditions of the Commencement
Certificate.
c. The Security Deposit shall be forfeited either in whole or in part at the discretion
of the CIDCO, for breach of any of the provisions of these regulations and
conditions attached to the permission covered under the Commencement
Certificate.
v) The development permission may be granted at the discretion of the CIDCO with
following conditions of the Commencement Certificate.
a. The applicant shall remove all the development on land when directed by the
CIDCO.
b. The applicant shall neither be entitled for any compensation for the removal of
the development nor for any alternative land.
c. The applicant if he desires may apply in writing for renewal of the permission.
10.14 A CIDCO AREA WITHIN PANVEL MUNICIPAL CORPORATION.
10.14 A.1 The Regulations No. 10.10.1, 10.10.2 10.10.3, 10.10.5 and 10.10.6 shall be applicable to
CIDCO area within Panvel Municipal Corporation.
10.15 CERTAIN REGULATIONS CEASE TO OPERATE IN FUTURE.
The Regulation No. 10.1.1, 10.3.1, 10.3.2, 10.3.4, (1) (--), (3) (--) shall cease to operate on 1st Jan,
2022 or as decided by the Government from time to time and thereafter provisions of these
regulations shall apply.
-*-*-*-*-*-
(1)
The "10.4.1" is deleted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
(2)
Inserted /
(3)
Deleted vide Notification u/s 37 (1AA)(c) No. CR 236/18 (Part 6) dt. 12th October, 2022