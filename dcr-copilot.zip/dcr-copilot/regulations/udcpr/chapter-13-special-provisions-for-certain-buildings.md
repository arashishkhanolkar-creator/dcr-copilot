# Chapter 13: Special Provisions for Certain Buildings

CHAPTER - 13
SPECIAL PROVISIONS FOR CERTAIN BUILDINGS
13.0 GENERAL
Special provisions shall be made in respect of certain buildings as given below. However, this
provision shall stand superseded if new directions are issued by the Government.
13.1 PROVISIONS FOR BARRIER FREE ACCESS
Provisions for barrier free access in buildings for differently abled persons shall be as given
below.
13.1.1 Definitions
i) Non-ambulatory Disabilities:- Impairments that, regardless of cause or manifestation, for all
practical purposes, confine individuals to wheelchairs.
ii) Semi-ambulatory Disabilities:- Impairments that cause individuals to walk with difficulty or
insecurity, individuals using braces or crutches, amputees, arthritics, spastics, and those with
pulmonary and cardiac ills may be semi-ambulatory.
iii) Hearing Disabilities:- Deafness or hearing handicaps that might make an individual insecure
in public areas because he is unable to communicate or hear warning signals.
iv) Sight Disabilities:- Total blindness or impairments, which affect sight to the extent that the
individual, functioning in public areas, is insecure or exposed to danger.
v) Wheel Chair:- Chair used by disabled people for mobility. The standard size of wheel chair
shall be taken as 1050 mm. x 750 mm.
13.1.2 Scope
These regulations are applicable to all buildings and facilities used by the public such as
educational, institutional, assembly, commercial, business, mercantile buildings constructed on
plot having an area of more than 2000 Sq.m. It does not apply to private and public residences
13.1.3 Site development
Level of the roads, access paths and parking areas shall be described in the plan along with
specification of the materials.
1. Access Path / Walk Way:- Access path from plot entry and surface parking to building
entrance shall be minimum of 1800 mm. wide having even surface without any steps. Slope,
if any, shall not have gradient greater than 5%. Selection of floor material shall be made
suitably to attract or to guide visually impaired persons (limited to coloured floor material
whose colour and brightness is conspicuously different from that of the surrounding floor
material or the material that emits different sound to guide visually impaired persons;
hereinafter referred to as "guiding floor material". Finishes shall have a non-slip surface with a
texture traversable by a wheel chair. Curbs wherever provided should blend to a common
level.
2. Parking:- For parking of vehicles of handicapped people, the following provisions shall be
made :-
a) Surface parking for two car spaces shall be provided near entrance for the physically
handicapped persons with maximum travel distance of 30 m. from building entrance.
b) The width of parking bay shall be minimum 3.6 meter.
c) The information stating that the space is reserved for wheel chair users shall be
conspicuously displayed.
d) Guiding floor materials shall be provided or a device, which guides visually impaired
persons with audible signals, or other devices, which serves the same purpose, shall be
provided.
13.1.4 Building Requirements
The specified facilities for the buildings for differently abled persons shall be as follows:-
i) Approach to plinth level
ii) Corridor connecting the entrance / exit for the differently abled.
iii) Stair-ways
iv) Lift
v) Toilet
vi) Drinking Water.
i) Approach to plinth level :-Every building should have at least one entrance accessible to the
differently abled and shall be indicated by proper signage. This entrance shall be approached
through a ramp together with the stepped entry.
ii) Ramped Approach :- Ramp shall be finished with non-slip material to enter the building.
Minimum width of ramp shall be 1800mm. with maximum gradient 1:12. Length of ramp
shall not exceed 9 m. having 800mm. high hand rail on both sides extending 300mm. beyond
top and bottom of the ramp. Minimum gap from the adjacent wall to the hand rail shall be
50mm.
iii) Stepped Approach:-For stepped approach size of tread shall not be less than 300mm. and
maximum riser shall be 150mm. Provision of 800mm. high hand rail on both sides of the
stepped approach similar to the ramped approach.
iv) Exit/Entrance Door:- Minimum & clear opening of the entrance door shall be 900mm. and
it shall not be provided with a step that obstructs the passage of a wheel chair user.
Threshold shall not be raised more than 12mm.
v) Entrance Landing:-Entrance landing shall be provided adjacent to ramp with the minimum
dimension 1800mm. x 2000mm. The entrance landing that adjoins the top end of a slope
shall be provided with floor materials to attract the attention of visually impaired persons
(limited to coloured floor material whose colour and brightness is conspicuously different
from that of the surrounding floor material or the material that emits different sound to guide
visually impaired persons hereinafter referred to as "guiding floor material"). Finishes shall
have a non-slip surface with a texture traversable by a wheel chair. Curbs, wherever
provided, should blend to a common level.
vi) Corridor connecting the entrance / exit for the differently abled:- The corridor
connecting the entrance / exit for differently abled, leading directly outdoors to a place where
information concerning the overall use of the specified building can be provided to visually
impaired persons either by a person or by signs, shall be provided as follows:-
a) Guiding floor materials or device that emits sound to guide visually impaired persons
shall be provided.
b) The minimum width shall be 1500mm.
c) In case there is a difference of level, slope ways shall be provided with a slope of 1:12.
d) Hand rails shall be provided for ramps/slope ways.
vii) Stair-ways - One of the stair-ways - near the entrance / exit for the differently abled shall
have the following provisions:-
a) The minimum width shall be 1350 mm.
b) Height of the riser shall not be more than 150 mm. and width of the tread 300mm. The
steps shall not have abrupt (square) nosing.
c) Maximum number of risers on a flight shall be limited to 12.
d) Hand rails shall be provided on both sides and shall extend 300 mm. on the top and
bottom of each flight of steps.
viii) Lifts -Wherever lift is required as per regulations, provision of at least one lift shall be made
for the wheel chair user with the following cage dimensions of lift recommended for
passenger lift of 13 persons capacity of Bureau of Indian Standards.
Clear internal width 1100 mm.
Clear internal width 2000 mm.
Entrance door width 900 mm.
a) A hand rail not less than 600mm. long at 1000mm. above floor level shall be fixed
adjacent to the control panel.
b) The lift lobby shall be of an inside measurement of 1800 mm. x 1800 mm. or more.
c) The time of an automatically closing door should be minimum 5 seconds and the closing
speed should not exceed 0.25 m/sec.
d) The interior of the cage shall be provided with a device that audibly indicates the floor,
the cage has reached indicates that the door of the cage of entrance/exit is either open or
closed.
ix) Toilets :-One special W.C. in a set of toilets shall be provided for the use of differently abled
with essential provision of washbasin near the entrance for the handicapped.
a) The minimum size shall be 1500 mm. x 1750 mm.
b) Minimum clear opening of the door shall be 900mm. and the door shall swing out.
c) Suitable arrangement of vertical/horizontal handrails with 50 mm. clearance from wall
shall be made in the toilet.
d) The W.C. seat shall be 500mm. from the floor.
x) Drinking Water:-Suitable provision of drinking water shall be made for the differently abled
near the special toilet provided for them.
xi) Designing for Children:- In the buildings meant for the pre-dominant use of the children, it
will be necessary to suitably alter the height of the handrail and other fittings & fixtures, etc.
Explanatory notes:-
1) Guiding / Warning Floor Material:
The floor material to guide or to warn the visually impaired persons with a change of colour
or material with conspicuously different texture and easily distinguishable from the rest of the
surrounding floor materials is called guiding or warning floor material. The material with
different texture gives audible signals with sensory warning when a person moves on this
surface with walking stick. The guiding/warning floor material is meant to give the
directional effect or warn a person at critical places. This floor material shall be provided in
the following areas:-
a) The access path to the building and to the parking area.
b) The landing lobby towards the information board, reception, lifts, staircases and toilets.
c) Immediately at the beginning/end of walkway where there is a vehicular traffic.
d) At the location abruptly changing in level or beginning/end of a ramp.
e) Immediately in front of an entrance/exit and the landing.
2) Proper signage:-
Appropriate identification of specific facilities within a building for the differently abled
persons should be done with proper signals. Visually impaired persons make use of other
senses such as hearing and touch to compensate for the lack of vision, whereas visual signals
benefit those with hearing disabilities.
Signs should be designed and located so that they are easily legible by using suitable letter
size (not less than 20 mm. high). For visually impaired persons, information board in brail
should be installed on the wall at a suitable height and it should be possible to approach them
closely. To ensure safe walking, there should not be any protruding sign which creates
obstruction in walking. Public Address System may also be provided in busy public areas.
The symbols/information should be in contrasting colour and properly illuminated because
people with limited vision may be able to differentiate amongst primary colours. International
Symbol Mark for wheel chair be installed in a lift, toilet, staircase, parking areas, etc., that
have been provided for the differently abled.
13.2 INSTALLATION OF SOLAR ASSISTED WATER HEATING (SWH) SYSTEM/ ROOF
TOP PHOTOVOLTAIC (RTPV) SYSTEM
SWH or RTPV systems shall be mandatory in all types of buildings to be constructed on plot area
of more than 4000sq.m.
In order to facilitate the installation of SWH/RTPV System, the new buildings shall have the
following provisions:-
i) All such buildings where SWH/RTPV are to be installed will have open sunny roof area
available for the installation of SWH/RTPV.
ii) The roof loading adopted in the design of such building should be at least 50 kg. Per Sq.m.
for the installation of SWH / RTPV.
iii) At least 25% of the roof area shall be utilized for installation of the SWH/RTPV system.
iv) Precaution should be taken that architectural elevation treatment should not cast shadow on
terrace space. As far as possible, parapet of south, east and west sides of the terrace shall be
of railing type (above 1 feet) such that it will not cast shadow on the solar collectors and
maximum terrace space can be utilized.
v) All such new buildings installed with SWH shall have an installed hot water line from the
rooftop and insulated distribution pipelines to each of the points where hot water is required
in the building.
13.3 RAIN WATER HARVESTING
The provision for Rain Water Harvesting shall be made as under:-
a) All the layout open spaces/amenity spaces of housing societies and new constructions/
reconstruction/ additions on plots having area not less than 500 Sq.m. shall have one or more
Rain Water Harvesting structures having a minimum total capacity as detailed in Schedule.
Provided that the Authority may approve the Rain Water Harvesting structures of
specifications different from those in Schedule, subject to the minimum capacity of Rain
Water Harvesting being ensured in each case.
b) The owner/society of every building mentioned in the (a) above shall ensure that the Rain
Water Harvesting System is maintained in good condition for storage of water for non-
potable purposes or recharge of groundwater at all times.
c) The Authority may impose a levy of not exceeding Rs.1000/- per annum for every 100sq.m.
of built-up area for the failure of the owner of any building mentioned in the (a) above to
provide or to maintain Rain Water Harvesting structures as required under these regulations.
Failure to provide Rain Water Harvesting System shall deemed to be breach of the conditions
on which the development permission has been granted.
Schedule
Rain Water Harvesting in a building site includes storage or recharging the ground water by
rainwater falling on the terrace or any paved or unpaved surface within the building site. The
following systems may be adopted for harvesting the rainwater drawn from terrace and the paved
surface.
i) Open well of a minimum 1 m. diameter and 6 m. in depth into which rain water may be
channelled and allowed to filter for removing silt and floating material. The well shall be
provided with ventilating covers. The water from the open well may be used for non-potable
domestic purposes such as washing, flushing and for watering the garden etc.
ii) Rain Water Harvesting for recharge of groundwater may be done through a bore-well around
which a pit of 1 m. width may be excavated upto a depth of at least 3 m. and refilled with
stone aggregate and sand. The filtered rain water may be channelled to the refilled pit for
recharging the bore-well.
iii) An impressive surface/underground storage tank of required capacity may be constructed in
the setback or other open spaces and the rain water may be channelled to the storage tank.
The storage tank shall always be provided with ventilating covers and shall have draw-off
taps suitably placed so that rain water may be drawn off for domestic, washing, gardening
and such other purposes. The storage tank shall be provided with an overflow.
iv) The surplus rain water, after storage, may be recharged into ground through percolation pits
or trenches or combination of pits and trenches. Depending on the geomorphological and
topographical conditions, the pits may be of the size of 1.20 m. width X 1.20 m. length X 2m.
to 2.50 m. depth. The trenches can be of 0.60 m. width X 2 to 6 m. length X 1.50 to 2 m.
depth. Terrace water shall be channelled to pits or trenches. Such pits or trenches shall be
back filled with filter media comprising the following materials :-
a) 40 mm stone aggregate as bottom layer upto 50% of the depth.
b) 20 mm stone aggregate as lower middle layer upto 20% of the depth.
c) Coarse sand as upper middle layer upto 20% of the depth.
d) A thin layer of fine sand as top layer.
e) Top 10% of the pits/trenches will be empty and a splash is to be provided in this portion
in such a way that roof top water falls on the splash pad.
f) Brick masonry wall is to be constructed on the exposed surface of pits/trenches and the
cement mortar plastered. The depth of wall below ground shall be such that the wall
prevents lose soil entering into pits/ trenches. The projection of the wall above ground
shall at least be 15 cm.
g) Perforated concrete slabs shall be provided on the pits/trenches.
h) If the open space surrounding the building is not paved, the top layer up to a sufficient
depth shall be removed and refilled with coarse sand to allow percolation of rain water
into ground.
v) The terrace shall be connected to the open well/bore-well/storage tank/ recharge pit/trench by
means of HDPE / PVC pipes through filter media. A valve system shall be provided to enable
the first washing from roof or terrace catchment, as they would contain undesirable dirt. The
mouth of all pipes and opening shall be covered with mosquito (insect) proof wire net. For
the efficient discharge of rain water, there shall be at least two rain water pipes of 100 mm.
dia. for a roof area of 100 Sq.m.
vi) Rain Water Harvesting structures shall be sited as not to endanger the stability of building or
earthwork. The structure shall be designed such that no dampness is caused in any part of the
walls or foundation of the building or those of an adjacent building.
vii) The water so collected/recharged shall as far as possible be used for non-drinking and non-
cooking purpose. Provided that when the rain water in exceptional circumstances will be
utilised for drinking and/or cooking purpose, it shall be ensured that proper filter arrangement
and the separate outlet for bypassing the first rain water has been provided. Provided further
that, will be ensured that for such use, proper disinfectants and the water purification
arrangements have been made.
The structures constructed under this provision shall not be counted towards FSI
computation.
13.4 GREY WATER RECYCLING AND REUSE
Grey Water - It means waste water from bathrooms, sinks, shower and wash areas, etc.
Applicability -These Regulations shall be applicable to all Developments/ Redevelopments/part
Developments for the uses as mentioned under Regulation No. 13.4.1 to 13.4.6 shall have the
provision for treatment, recycling and reuse of Grey Water. The applicant shall along with his
application for obtaining necessary layout approval/ building permission shall submit a plan
showing the location of Grey Water Treatment Plant, furnishing details of calculations,
implementation, etc. This Plan shall accompany with the applicant‘s commitment to monitor the
system periodically from the date of occupation of the respective building.
13.4.1 For Layout Approval/Building Permission
i) In case of Residential layouts, area admeasuring 10000 Sq.m. or more, in addition to 10%
open space, prescribed in the bye- laws, a separate space for Grey Water Treatment and
Recycling Plant should be proposed in the layout. This may be proposed in amenity space
as per Regulation No. 3.5.
ii) On the layout Plan, all Drainage lines, Chambers, Plumbing lines should be marked in
different colour and submit the layout for approval to the Authority.
iii) The recycled water shall be used for gardening, car washing, toilet flushing, irrigation, etc.
and in no case for drinking, bathing, washing utensils, clothes etc.
iv) A clause must be included by the owner/ developer in the purchase agreement that the
purchaser, owner of the premises/organization or society of the purchasers shall ensure that:
a) The recycled water is tested every six months either in municipal laboratory or in the
laboratory approved by Authority or by State Government and the result of which shall
be made accessible to the competent authority/ EHO of the respective ward office.
b) Any recommendation from testing laboratory for any form of corrective measures that
are needed to be adopted shall be compiled. Copy of any such recommendation and
necessary action taken shall also be sent by the testing laboratories to the Competent
Authority/ EHO of respective Wards.
c) Maintenance of Recycling Plant should be done by the Developer or Housing Society
or Owner.
13.4.2 Group Housing/Apartment Building
In case of Group Housing scheme or a multi-storeyed building having 100 or more tenements,
Grey Water Recycling Plant as mentioned in Regulation No. 13.4.1 above, should be constructed.
In case of EWS/ LIG tenements, this shall be provided for tenements 150 or more.
13.4.3 Educational, Industrial, Commercial, Government, Semi-Government Organizations,
Hotels, Lodgings, etc.
For all above buildings having built-up area 1500 Sq.m. or more or if water consumption is 20,000
litre per day whichever is minimum, then provision for Grey Water Treatment Plant as mentioned
in Regulation No. 13.4.1 is applicable.
13.4.4 Hospitals
Those Hospitals having 40 or more beds, Grey Water Recycling Plant as mentioned in Regulation
No. 13.4.1 is applicable.
13.4.5 Vehicle Servicing Garages
All Vehicle servicing garages shall ensure that the Grey water generated through washing of
vehicles is treated and recycled back for the same use as mentioned in Regulation No.13.4.1
13.4.6 Other Hazardous uses
All other Establishments/ Buildings where chances of Waste Water generated containing harmful
chemicals, toxins are likely and where such water cannot be directly led into municipal sewers, the
concerned Competent Authority may direct the Owners, users of such Establishments, Buildings
to treat their Waste Water as per the directions laid in Regulation No. 13.4.1
13.4.7 Incentive
The Owner/Developer/Society setting up and agreeing to periodically maintain such Grey Water
Treatment and Recycling Plant entirely through their own expenditure shall be eligible for an
incentive in the form of fiscal benefits in Property Tax to the extent of 5% to Tenement
holder/Society.
13.4.8 Penalty Clause
Any person/ Owner/ Developer/ Organization/ Society violating the provisions of these bye- laws,
he shall be fined Rs.2,500/- on the day of detection and if the violation continues, then he shall be
fined Rs.100/- for every day as concrete action after written Notice from Authority.
If any person/ Owner/Developer/ Organization/ Society fails to operate as determined by the
Authorised Officer of the Authority and from the observations of test results and/or physical
verification) the Recycling plant, then he will be charged a penalty of Rs.300/- per day and
disconnection of Water connection also.
13.5 SOLID WASTE MANAGEMENT
It shall be mandatory for:-
i) Housing complexes, Commercial establishments, hostels, hospitals having aggregate built-up
area more than 4,000 Sq.m. or more.
ii) All three star or higher category hotels.
To establish a dedicated Solid waste management system to treat 100% wet waste being generated
in such buildings.
The treatment of wet waste shall be done through an organic waste composters/ vermiculture pits
or other similar technologies of suitable capacity installed through reputed vendors.
The disposal of dry waste, e-waste, hazardous waste shall be carried out through authorised
recyclers or any other system as specified by the Authority
-*-*-*-*-*-