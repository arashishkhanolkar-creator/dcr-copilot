# Chapter 6: General Building Requirements - Setback, Marginal Distance, Height and Permissible FSI

CHAPTER - 6
GENERAL BUILDING REQUIREMENTS - SETBACK, MARGINAL DISTANCE,
HEIGHT AND PERMISSIBLE FSI
6.0 GENERAL
Following regulations shall be applicable for the lands included in congested area (or core area) as
shown on the Development Plan. These regulations shall also be applicable for the gaothan areas
in Regional Plans (including the areas of Local Bodies and Special Planning Authorities where
Development Plan or Planning Proposal is not sanctioned).
However, in congested area, if the original land holding is more than 0.40 Hectare, then
regulations of non-congested area, except FSI, shall apply. FSI in such cases shall be as per the
Regulation No.6.1.1
6.1 REGULATIONS FOR CONGESTED AREA IN DEVELOPMENT PLANS / GAOTHANS
OF VILLAGE SETTLEMENTS IN METROPOLITAN REGION DEVELOPMENT
AUTHORITIES AND REGIONAL PLANS.
(Note - In Nashik Municipal Corporation, the term ‗Core Area‘ is synonymous to ‗Congested
Area‘.)
6.1.1 Residential Buildings/ Residential Buildings with mixed-use
i) Floor Space Index:-
The maximum permissible basic floor space index, FSI on payment of premium, permissible TDR
loading shall be as per the following Table No. 6A.
Note for Table No. 6 A :
1) In addition to what is mentioned in Table No. 6 A, ancillary area FSI upto the extent of
60%of the proposed FSI in the development permission (including Basic FSI, Premium FSI,
TDR but excluding the area covered in Regulation No.6.8) shall be allowed with the payment
of premium at the rate as specified below on the land rate in Annual Statement of Rates of the
said land without considering the guidelines therein. This shall be applicable to all buildings
in all zones.
Sr. No. Authority / Area Rate of Premium.
1 Pune and Thane Municipal Corporation. 15%
2 Nagpur, Nashik Municipal Corporation and Municipal 10%
Corporations in MMR (except Thane) and Metropolitan
Development Authority area (1) and CIDCO as Planning
Authority by virtue of NTDA.
3 All other Municipal Corporations. 10%
4 Municipal Councils, Nagar Panchayats and R.P. area. 10%
Provided that in case of non-residential use, the extent of ancillary area FSI shall be upto
80%.No separate calculation shall be required to be done for this ancillary area FSI. Entire
FSI in the development permission shall be calculated and shall be measured with reference
to permissible FSI, premium FSI, TDR, additional FSI including ancillary area FSI added
therein.
(1)
Inserted vide Notification u/s 37 (1AA)(c) No. CR 236/18 (Part 6), dt. 12th October 2022.
Provided further that, the above mentioned rates shall not exceed the rate of premium
mentioned in column 4 of Table 7 A under Chapter-7 where the development permission is
sought for the uses mentioned in the said table.
Provided further that, this ancillary area FSI shall be applicable to all other schemes like
TOD, PMAY, ITP, IT, MHADA, etc. except (1) Rehabilitation component in SRA. In the
result, free of FSI items in the said schemes, if any, other than mentioned in UDCPR, shall
stand deleted.
2) All notes mentioned below Table 6-G of Regulation No. 6.3 shall be applicable, mutatis-
mutandis.
3) Utilisation of ancillary area FSI is optional. It can be used fully/ partly.
4) In case of composite building of mixed users premium and ancillary area FSI shall be on
prorate basis.
Table No.6 A
Sr. Road width in Basic For all Municipal Corporations and For remaining authorities/areas
No. meter FSI (2)CIDCO as Planning Authority by
Virtue of NTDA
FSI on Maximu Maximum FSI on Maximu Maxi
payment m building payment of m mum
of permissib potential on premium permissi build
premium le TDR plot ble TDR ing
loading loading pote
ntial
on
plot
1 2 3 4 5 6 7 8 9
1 Below 9.0 m. 1.50 -- -- 1.50 -- -- 1.50
2 9.00 m. and 2.00 0.30 0.30 2.60 0.30 0.10 2.40
below 18.00 m.
3 18.00 m. and 2.00 0.30 0.50 2.80 0.30 0.20 2.50
below 30.00 m.
4 30.00 m. and 2.00 0.30 0.70 3.00 0.30 0.20 2.50
above
ii) Front Marginal Distances/Setback/ Roadside Margin/s in Congested Area
The minimum front setback from the existing or proposed road/ roads shall be as per the following
Table No. 6B.
Table No. 6B.
Sr. Road width For Residential For Residential Buildings with
No. building mixed-use
(i) For streets/lane less than 4.5 2.25m. from the centre 2.25m. + 1.50 m from the centre
m. width of the street/ lane of the street/lane
(ii) For streets 4.5m. to less NIL 1.50 m.
than 6.00 m. in width
(1)
Inserted Vide Addendum No.CR 236/18, dt. 14th January, 2021.
(2)
Inserted vide Notification u/s 37 (1AA)(c) No. CR 236/18 (Part 6), dt. 12th October 2022.
(iii) For streets 6 m. to less than 1.00 m. 2.00 m.
12 m. in width
(iv) For streets 12 m. in width 2.00 m. 2.50 m.
and above
iii) Side and Rear Marginal Distances in Congested Area
The minimum side and rear marginal distances shall be as per the following Table No. 6C.
Table No. 6C.
Plot Area Side Rear
Up to 1000 Sq.m. 0.00 0.00
Above 1000& upto 4000 Sq.m. 1.00 m. 1.00 m.
Above 4000 Sq.m. As per Regulation for non-congested area
Note:-
1) For light and ventilation, provisions about interior & exterior chowks shall apply.
2) Irrespective of the area of a plot, if the width thereof is 7m. or less, then the side margin
shall be nil.
iv) For the lanes having width less than 4.5m. abutting to any side of plot, a setback of 2.25m.
from the centre of lane shall be provided to make such lane 4.5m. wide. No projections
shall be permissible on such widened lane.
v) Excepting the FSI and its maximum loading limit & marginal distances as prescribed
above, all other regulations shall be applicable for development permission in congested
area.
vi) Height: Above setback and marginal distances shall be applicable for buildings less than
15m. in height. Marginal distances shall be increased by 1m.for buildings having height
15m. and more but less than 24m. For buildings having height 24m. and more, marginal
distances shall be as per regulations of non-congested area.
6.1.2 Other buildings like Public/ Semi-Public, Educational, Medical, Institutional, Commercial,
Mercantile, etc.
(a) Floor Space Index, - The FSI permissible for these buildings shall be as per Regulation
No.6.1.1.
(b) Marginal Distances - For these buildings marginal distances shall be 3m. on all sides
including front up to 24m. height.
Provided that for building more than 24 m. height, regulations of non-congested area shall
apply.
Provided further that, for buildings like cinema theatres, multiplex, assembly buildings,
shopping malls etc., regulations for outside congested area, except FSI, shall apply.
6.1.3 Pathway for access to internal building or interior part of the building shall not be less than 3.6 m.
in width.
6.1.4 Front setback (marginal distance) as prescribed under highway or any other rules shall be
applicable if they are over and above as prescribed in these regulations.
6.2 REGULATIONS FOR OUTSIDE CONGESTED AREA (NON-CONGESTED AREA).
6.2.1 Marginal Distances and set-back for Residential Buildings and mixed use with Height up to
15 m. or as mentioned in the Table No. 6-D.
The provisions for minimum marginal distances as given in Table No. 6-D below shall apply for
the Residential buildings, Residential with mixed uses permissible in Residential Zone and
Residential buildings permissible in other zones.
Table No.6-D
Sr. Description Min Min Min setback Min. side Min. Remarks
No of the road Plot width from road margins in rear
Size of plot side in meters meters margi
in in ns in
Sq.m. meters meters
1 2 3 4 5 6 7 8
1 Roads of 450 15 6.0in case of 3.0 3.0 Side and
width 30 m. A, B, C class Rear
and above in Municipal Margins for
local authority Corporations building
area. and 4.50 in upto 15m.
case of other height
areas. (excluding
parking
floor upto
6m. height)
2 In case of 450 15 4.5m.or as 3.0 3.0 Side and
Regional Plan specified by Rear
area. NH/SH Highway rules Margins for
whichever is building
more. upto 15m.
height
(excluding
parking
floor upto
6m. height)
3 Roads of 250 10 4.5 2.0 2.0 Side and
width 18 m. Rear
and above but Margins for
below 30 m. building
upto 10m.
height
(excluding
parking
floor upto
6m. height)
4 Roads of 200 10 3.0 1.5 1.5 Margins for
width 15 m. buildings
and above but G+2 or stilt
below 18m. +3 structure
5 Roads of 80 6 3.0 1.5 1.5 Margins for
width less (in case of buildings
than 15m. semi- G+2 or stilt
detached + 3
building, structure
only one
side
marginal
distance
shall be
permissible
6 Row Housing 30 3.5 2.25 0.0 1.5 --do--
on roads of (In case of
12m. and corner plot,
below 1.50 or
building
line of
adjoining
road
whichever
is more)
7 Row Housing 20 3.0 0.9 from 0.0 0.9 G+1 or stilt
for EWS/ pathway or (In case of + 2
LIG/ by public 2.25 from corner plot, structure
authority / road boundary 1.5 or only
private building
individual / line of
Slum adjoining
Upgradation road
etc. by public whichever
authority is more)
Notes:-
(1) The width of the road in above table shall govern the requirements in column 3 to 8.
(2) In case of Sr. No. 1 to 6 structures having higher height may be permitted subject to
marginal distance mentioned in Regulation No.6.2.3.
(3) The minimum area of plots fronting on service roads along highways shall be with
reference to the actual width of the service road.
(4) For semi-detached buildings, side margin shall be on one side only. Plots for semi-
detached buildings shall be in pairs.
(5) Row-housing plots at the junction of two roads shall be larger to maintain the setback from
both roads. Not more than 12 and not less than 3 plots shall be allowed in each block of
row housing. Each block shall be separated from the other by a 4.5 m. wide road / pathway
or 4.5m. side marginal distance within the plot or space including side marginal distance of
the plot.
(6) No garage shall be permitted in a building having stilt or basement provided for parking.
(7) Construction of ottas, railings, barricades or supporting columns for canopy or porch shall
not be allowed in minimum front marginal distances. However, steps may be permitted
within 1.2m. from the building line. Also supporting columns for canopy or porch may be
allowed within building line.
(8) In case of Regional Plan areas, ribbon development rules shall not be relaxed without
consent of the Highway Authority.
(9) In case of special building, marginal distances shall be as per regulations for such
buildings.
(10) The plot width to depth ratio shall be 1:1.5 to 1:2.5, as far as possible in plotted layout.
(11) In Public Housing Schemes for E.W.S. undertaken by government or semi-government
organizations, marginal distances shall be as per the respective schemes and rules.
(12) The front setback set-out in already approved and partially developed layouts/ schemes,
may be retained as per original approval, so as to maintain the building line.
(13) The pattern of development like semi-detached, row housing etc. in already approved
layout shall be as per said approved layout.
(14) Where commencement certificate is granted prior to publication of draft development plan
or sanction of Development Plan and the plot gets affected by new road / road widening,
proposed in the development plan, the front margin shall stand relaxed to that extent.
(15) In case of redevelopment proposal affected by line of street up to 9 m. width under
Municipal Council or Municipal Corporation Act or development plan road of up to 9 m.
width, the front margin shall stand relaxed to the extent of land affected by such proposal
(1) subject to minimum setback of 1.0 m. for roads having width 12.0 m. or less and 2.0 m.
for roads having width more than 12.0 m., from the final line of the street.
(16) Subsidiary structure such as garage (limited to one), outhouse and independent sanitary
block may be permitted only in plots having area 250sq.m.or more.
(17) Rear or side marginal distances for development along nallah or watercourses shall be
subject to Regulation regarding "Sites Not Eligible for Construction of Building" and
"Construction Within Flood Line".(Chapter 3)
(18) The plots which are substandard in area shall be developed as per marginal distances
mentioned in the above table with reference to road width.
(19) In case of plots having approach by dead-end road, (point access) front margin shall be
limited to width of point access.
(2) (20) Building Line along classified roads as mentioned in regulation no.3.1.6 shall be applicable
for residential buildings defined in Regulation No.1.3.93 (i) and Control Line along
classified roads shall be applicable for other uses or for commercial uses as mentioned in
regulation no.3.1.6 or for mixed use buildings where non-residential uses are proposed at
least 50 % or more of total proposed built-up area.
(1) Inserted Vide Corrigendum / Addendum No.CR 79/2021, dt. 02nd December 2021.
(2)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
6.2.2 Other Buildings
The Provision in respect of minimum road width, minimum marginal distances etc., as given in
Table No.6E below shall apply for different categories of other buildings.
Table No.6 E
Sr. Type of building Minimum Minimum Other stipulations
No road width marginal
required distances
1 2 3 4 5
1 Medical buildings
a) Hospital, 9 m. in case Margins as NIL
Maternity Homes, of A, B, C per Table
Health Club, Clinics class No. 6 D
etc. buildings not Municipal subject to
being special Corporation, side
buildings Metropolitan marginal
Authority distance of
Area and 7.5 minimum
m. in case of 3m.
other areas.
b) Hospital, Road width as 6 m. on all Height of building subject to provisions of
Maternity Homes, required for sides Maharashtra Fire Prevention and Life
Health Club etc. Special Safety Measures Act 2006.
buildings under Buildings.
category of special
(Regulation
building.
No.3.3.9)
2. Educational buildings
a) Pre-primary On any road. Margins as Other requirements shall be as mentioned
School per Table in the Table No.7A of Regulation No. 7.1.
No. 6 D
Height of building subject to provisions of
b) Primary School 6 m. --do-- Maharashtra Fire Prevention and Life
not being special Safety Measures Act 2006.
building.
c) Other 9 m. 3 m. on all
Educational sides
Buildings not being
special building.
d) Any building of Road width as 6 m. on all
category a, b, c required for sides
above being special Special
building. Buildings
3. Public-Semi Public Building
a) Public-Semi 9 m. Margins as per .--
Public Building not Table No.6D
being special subject to side
building. marginal
distance of
minimum 3 m
a) Public-Semi Road width as 6 m. on all --
Public Building required for sides
being special Special
building. Buildings
4. Cinema Theatre
Cinema Theatre/ 12 m. Front - 12m. i) In case of cities having population
Drama Theatre/ (only on one more than 2.5 lakhs as per latest
Assembly Hall/ major road). census, redevelopment of existing
Multiplex / cinema theatre on plots shall be
6m. on all
Shopping Malls allowed subject to the condition that
remaining
at least 1/3rd of the existing seats
sides
shall be retained, which shall not be
below 150 seats and may be
developed in combination with user
permissible in R2 zone.
ii) For redevelopment of existing theatre,
marginal distances including front
margin as per these regulations shall
not be insisted. Redevelopment shall
be allowed as per existing set back
distances. Parking area required as
per these regulations shall not be
insisted; however existing parking
area shall be maintained.
iii) In cases where redevelopment of
existing Cinema Theatre is carried
out on the same place with the
capacity more than existing capacity
in the form of single or multiscreen
cinemas, then owner / developer shall
be allowed FSI potential mentioned
in column 6 or 9, as the case may be,
of Table No.6-G at the rate of 20%
land rate mentioned in Annual Rates
of Statement without considering
guidelines therein, for the additional
capacity.
iv) The existing Cinema Theatre shall be
allowed to be relocated and
constructed at some other place
within a distance of 5 km. In such
case, original site shall be allowed to
be developed as per uses permissible
in adjoining zone.
Construction of Cinema Theatre /
Multiplex shall conform to the
provisions of Maharashtra Cinema
(Regulations) Rules, 1966 and as
amended from time to time, except
the provisions mentioned above.
v) For redevelopment of Cinema plot
having area less than 1000 Sq.m., and
if redevelopment of existing cinema
theatre on such plot is not possible
considering the other requirements in
these regulations, the condition of
providing atleast 1/3 of the existing
seats or minimum 150 seats for
cinema theatre shall not be insisted.
In such case users permissible in
adjoining predominant zone shall be
permissible with special permission
of sanctioning authority.
5. Mangal Karyalaya
a) Mangal karyalaya Road width as 3 m. on all -
and like buildings required for sides.
not under the R-2 zone.
category of special
building.
b) Mangal 12 m. 6 m. on all -
karyalaya and like sides.
buildings under the
category of special
building.
6. (#) Fuel Stations
Fuel Filling 9 m. 4.5m. on all i) In case the plot is located on any
Stations/including sides Classified road in Regional Plan area,
Petrol/ Ethanol the distance from the junction of
/LPG / CNG /etc., roads as may be specified by Indian
Road Congress/ Ministry of Road,
Public Charging
Transport and Highway, shall be
Stations for Electric
followed.
Vehicles with or
without service bays (IRC guideline 2009 and MORTH
Letter No.RW/NH-33023/19/99-
DOIII, Dated: 25.09.2003 as
amended from time to time)
ii) NOC from Chief Controller of
Explosives shall be necessary.
(#) Clarification issued vide letter No. CR 68/2021 dt., 10th May, 2021.
iii) In a plot of Fuel Filling Station, other
building or composite building for
sales office, snack bars, restaurant,
public conveniences or like activities
may be permitted.
The FSI shall not exceed 0.25 and
underground structures along with
kiosks shall not be counted
towards FSI.
7. Mercantile Buildings.
a) Mercantile/ Road width as Front 6m. i) Shops may also face on side and rear
Business/ Hotel/ required for Side & rear of a plot.
Commercial Special 6m.
ii) Minimum width and area of Shop
building under Building.
shall be as per convenience of the
the category of owner / developer.
special buildings.
b) Mercantile/ Road width as Margins as iii) In case of construction of shops /
Business/ Hotel/ required for per Table offices only on ground floor (not
Commercial R-2 zone. No. 6-D being special building) side and rear
building not under subject to marginal distance shall be as per
category of special side Table No. 6-D.
buildings marginal
distance of
minimum
3m.
c) Convenience On any road. Margins as --
shopping in R-1 per Table
zone. No. 6-D.
8. Stadium
Stadium with 12m. 6m. on all The covered portion of spectator‘s gallery
Pavilion sides shall not exceed 25%of plot area, which
shall not be counted towards FSI. Shops
below spectator‘s gallery may be permitted
which shall not be counted towards FSI. In
addition to this, ancillary office,
sportspersons accommodation, public
convenience like structures may also be
permitted which shall not consume more
than 0.10 FSI on gross plot area.
Note :
i) In case of plots fronting on National Highways, State Highways and Major District Roads in
Regional Plan area, the building line shall be as per Ribbon Development Rules or as given
in Table above, whichever is more.
ii) Side and rear marginal distances mentioned in above Table shall be subject to Regulation
No.6.2.3, whichever is more.
iii) In case of special buildings, marginal distances shall be as per regulations for special
buildings.
iv) A stadium should desirably accommodate 400 m. running track.
v) For above buildings, permissible FSI shall be as per Regulation No.6.3, unless otherwise
specified above.
vi) Point access (approach by dead end road) to a plot shall be considered for the minimum road
width requirement mentioned in above table. In such case, front margin shall be applicable
for the width of point access road.
vi) The provisions about Cinema Theatre in column 5 of Table No. 6 E shall be applicable to
Cinema Theatres in congested area also.
6.2.3 Marginal distances for buildings of heights more than mentioned in Table No.6-D of
Regulation No.6.2.1
(#) (a) Front Margin - Front margin shall be as given in Table No. 6-Dshall be applicable to a
building irrespective of its height.
Provided that, in the case of group housing schemes where building abuts on internal road,
the minimum 3m. set back from internal road or distance between two buildings, whichever
is more, shall be provided. For Development/ Regional Plan roads or classified roads or
through roads, passing through Group Housing Schemes, the setback as prescribed in these
regulations shall be provided.
(#) (b) Side or rear marginal distance - Side or rear marginal distance in relation to the height
of the building for light and ventilation shall be as below: -
The marginal distance on all sides shall be as per Table No.6D/ Table No.6E for building
height or floors mentioned there in. For height more than stipulated in Table No.6D/ Table
No.6E, the marginal distance on all sides, except the front side of a building, shall be
minimum H/5 (Where H = Height of the building above ground level).
Provided that, such marginal distance shall be subject to a maximum of 12m. from the plot
boundary and distance between two buildings shall be
(1)
as per Regulation No.6.2.4.
Provided further that, in case of redevelopment of building which has ceased to exist in
consequence of accidental fire / natural collapse / demolition for the reason of the same
having been declared dangerous or dilapidated or unsafe by or under a lawful order of the
authority or building having an age of more than 30 years, such marginal distance may be
allowed upto 6 m. for height of building upto 45 m. For redevelopment of smaller plots
having area less than 1000 sq.mt., one of the side margin / rear margin of 6 m may be relaxed
subject to Fire NOC in case of bonafide hardship.
Provided further that, such marginal distance from recreational open space shall be 3 m. in
case of non-special buildings and 6 m. in case of special buildings, irrespective of its height.
Provided further that, the building height for the purposes of this regulation and for
calculating the marginal distances shall be exclusive of height of parking floors upto 6m.
Provided further that, where rooms do not derive light and ventilation from the exterior open
space, i.e. dead walls, such marginal distance may be reduced
(1)
to 6.0 m. in case of special
building and 3.0 m. in case of other buildings.
Provided further that the plot / land of the owner falls within the jurisdiction of more than one
authority, then continuous building (without leaving margin on the boundary of the
authorities) may be allowed with the consent of the other Authorities.
(1) Substituted Vide Corrigendum / Addendum No.CR 79/2021, dt. 02nd December 2021.
(#) Clarification issued vide Order No. CR 236/18 (Part 2), dt., 23rd December, 2021.
(c) Provision for Step Margin: - Step margins may be allowed to be provided on upper floors to
achieve required side or rear marginal distances as mentioned in these regulations subject to
minimum marginal distance of 6 m. on ground level in case of special building.
This provision shall also be applicable to congested area.
6.2.4 In the cases of layouts of two or more buildings in a plot for any uses: -
Distance between two buildings: - The distance between two buildings shall be the side/ rear
marginal distance required for the taller building between the two adjoining buildings.
Provided that, the pathway/ internal road may be allowed to be proposed in such marginal
distance.
6.2.5
In case of group housing scheme where building abuts on internal road, the minimum 3 m. set
back from internal road or distance between two buildings whichever is more shall be provided.
For Development plan road /Regional plan road or classified road or through road, passing
through Group Housing Scheme, normal setback as prescribed in the regulations shall be
provided.
6.2.6 Buildings Abutting Two or More Streets
When a Building abuts two or more streets, the setbacks from the streets shall be such as if the
building is fronting on each of such streets.
6.3
PERMISSIBLE FSI
Permissible basic FSI, additional FSI on payment of premium, Permissible TDR Loading on a plot
in non-congested area for Residential and Residential with mixed uses and other buildings in
developable zones like residential, commercial, public-semi-public etc. shall be as given in Table
6 G below : -
Table 6 G
Sr. Road width in meters Basic For all Municipal Corporations (2) CIDCO as For remaining authorities/areas
No. FSI Planning Authority by Virtue of NTDA
FSI on Maximum Maximum building FSI on Maximum Maximum building
payment of permissible potential on plot payment of permissible potential on plot
premium TDR loading including in-situ FSI premium TDR loading including in-situ FSI
1 2 3 4 5 6 7 8 9
1 Below 9 m. 1.10 -- -- 1.10 -- -- 1.10
2 9 m. and above but below 12 m. 1.10 0.50 0.40 2.00 0.30 0.30 1.70
3 12 m. and above but below 15 m. 1.10 0.50 0.65 2.25 0.30 0.60 2.00
4 15 m. and above but below 24 m. 1.10 0.50 0.90 2.50 0.30 0.70 2.10
5 24 and above but below 30 m. 1.10 0.50 1.15 2.75 0.30 0.90 2.30
6 30 and above 1.10 0.50 1.40 3.00 0.30 1.10 2.50
Note -
i) In addition to above, ancillary area FSI up to the extent of 60% of the proposed FSI in the development permission (including Basic FSI, Premium
FSI, TDR but excluding the area covered in Regulation No.6.8) shall be allowed with the payment of premium as specified in Regulation No.
6.1.1.This shall be applicable to all buildings in all zones.
Provided that in case of non-residential use, the extent of ancillary area FSI shall be upto 80%. No separate calculation shall be required to be done
for this ancillary area FSI. Entire FSI in the development permission shall be calculated and shall be measured with reference to permissible FSI,
premium FSI, TDR, additional FSI including ancillary area FSI added therein.
Provided further that, this ancillary area FSI shall be applicable to all other schemes like TOD, PMAY, ITP, IT, MHADA, etc. except
(1) Rehabilitation component in SRA. In the result, free of FSI items in the said schemes, if any, other than mentioned in UDCPR, shall stand
deleted.
ii) The column of TDR shall not be applicable for the area, where there is no Planning Authority and accordingly, values in subsequent column shall
stand modified.
(1)
Substituted Vide Addendum No.CR 236/18, dt. 14th January, 2021.
(2)
Inserted vide Notification u/s 37 (1AA)(c) No. CR 236/18 (Part 6), dt. 12th October 2022.
iii) The maximum permissible limits of FSI specified in the Table above, may be allowed to be exceeded in cases mentioned in Chapter - 7, where
higher FSI is permissible over and above the limit specified in above table.
iv) Maximum permissible building potential on plot mentioned under column No.6 or 9 shall be exclusive of FSI allowed for Inclusive Housing as per
Regulation No.3.8. There is no priority fixed to utilise premium FSI or TDR as mentioned in Column No.4, 5 and 7, 8. (1) However the Authority,
considering the local situation, may allow utilisation of premium FSI and TDR, in equal proportion of permissible premium FSI and TDR
mentioned in column No.4, 5 and 7, 8. (e.g. if out of premium FSI mentioned in column No.4 & 7, 40% is proposed to be utilised then out of TDR
mentioned in column No.5 & 8, 40% TDR shall also be utilised.) In such cases the Authority shall issue written, well-reasoned speaking orders to
that effect. Other conditions of TDR utilisation shall be applicable as per the TDR Regulations No 11.2. In respect of service road, shown on
development plan or in approved layout, or plots facing on major road, however deriving access from other roads, the width of highway or major
road shall be considered for entitlement of building potential as per column 6 or 9 of above table, as the case may be.
v) Out of quantum of TDR mentioned in Column No. 5 or 8 minimum 30% and subject to maximum 50% of TDR shall be utilised out of the TDR
generated from Slum Rehabilitation Scheme (Slum TDR) / (2) Urban Renewal TDR / TDR generated from the area of notified URP as per
Regulation No. 14.8.8 (iv) (c) (i) / Amenity construction TDR (till generation of URT). If such TDR is not available then other TDR may be used.
vi) The restrictions of road width mentioned above shall not be applicable in cases where, the permissible FSI is more than the basic FSI in various
schemes such as slum rehabilitation scheme, redevelopment of dangerous buildings, cluster development for congested (core) area, redevelopment
of MHADA buildings, TOD etc. in such scheme, regulations of respective scheme shall be applicable. )3( However, for special buildings as
mentioned in Regulation No.1.3(93)(xiv), provisions mentioned in Regulation No.3.3.9 shall be applicable.
vii) The maximum limits of FSI prescribed above shall be applicable to (a) fresh permission (viz., green-field development (i.e. building on a vacant
plot of land) and brown-field development (i.e., cases of addition to existing building where a permissible FSI has not been exhausted.) and also to
(b) an existing building which has not been granted full occupation certificate. The cases of existing buildings shall be subject to production of
stability certificate from structural engineer.
viii) Premium - Rate of premium for the premium F.S.I., as mentioned in Column No. 4 and 7 above shall be 35% of the rate of the said land
mentioned in Annual Statement of Rates without considering the guidelines therein. Apportionment of such amount between Authority and
Government shall be as decided by Government from time to time. The premium of the Government, if to be paid, shall be deposited by the
Authority in the specified head of account of the Government. In the area of Regional Plans, entire premium shall be paid to the Government
through the District offices of Town Planning and Valuation Department.
(1)
Inserted Vide Addendum No.CR 236/18 (Part 1), dt. 8th October, 2021.
(2)
Inserted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
(3)
Inserted Vide Notification No.CR 236/18 (Part-3), dt. 02nd December 2021.
ix) Basic FSI (1) and premium FSI for unauthorisedly subdivided plots having area up to 0.4 ha. shall be (1) 75% of the quantum mentioned in column
No. 3, 4 & 7 and the TDR shall be to the extent of 50% of the quantum mentioned in column No.5 & 8 This provision shall be subject to
provisions in Regulation No.3.4.1 (i) (a) and (c) wherein plot shall be entitled for full potential.
x) The utilisation of TDR mentioned in above table would be available to an existing road width of 9 m. and above so marked under relevant Act.
xi) For plots regularised under Maharashtra Gunthewari Development (Regularisation, Upgradation and Control) Act 2001, these regulations shall
apply and allowance of TDR in column No. 5 and8 shall be to the extent of 50%. This shall also be applicable for cases mentioned in Regulation
No.3.4.1 (i)(b).
xii) (#)In case plots having approach by dead end road, (point access) the potential of plot mentioned in above table shall be permissible if length of
such access road does not exceed 100 m.
xiii) If the strip of land / plot adjacent to road is surrendered by the owner to the authority for road widening, then benefit of widened road in terms of
building potential, permissible height shall be granted subject to condition that such road widening shall result in widening of road from junction
of roads (or origin of road) to junction of roads (or T junction).
xiv) (#)Entire area of plot may be considered for calculating the potential of plot in respect of premium FSI + TDR, but not the basic FSI. Basic FSI shall
be calculated on area of the plot remaining with the owner after deducting area under D.P. road / (1) road widening / reservations and amenity
space. This shall be applicable in cases where reservation area or amenity space is handed over to the authority.
xv) If (2) any road of width less than 9.0 m. is proposed to be widened to 9 m. by the Authority under the provisions of the Municipal Corporation or
Municipal Council Act, by prescribing line of street (2) considering 4.5 m. from centre line of the existing road and owner of the plot hands over
such affected strip along such road to the authority, then he may be entitled for FSI and potential applicable to 9 m. road. (2) This shall be
applicable to roads in congested area also.
(1)
Inserted / Substituted vide Corrigendum / Addendum No. CR 121/21, dt. 02nd December, 2021.
(2)
Inserted / Substituted Vide Corrigendum / Addendum No.CR 79/2021, dt. 02nd December 2021.
(#) Clarification issued vide Order No.CR-236/18 (Part -2) dt.23rd December, 2021.
(#) Clarification issued vide Letter No.CR-236/18 (Part -2) dt.17th September, 2021.
6.4 INDUSTRIAL BUILDINGS
Minimum plot area, front, side and rear margins, Permissible FSI, Additional FSI with payment of
premium for industrial buildings in industrial zone shall be as per Table No. 6 H given below: -
Table No 6 H
Min. FSI on Min.
Basic Min. Side &
Sr. road Payment of Front
Plot Size in Sq.m. Permissible Rear Margins
No. width premium Margin
FSI in m.
(m.) in m.
1 2 3 4 5 6 7
1 9 Up to 300 1.00 0.40 3.00 2.25
2 9 Above 300 and upto 500 1.00 0.40 3.00 3.00
9 Above 500 and upto 1000 1.00 0.40 4.5 3.00
not being Special Building.
12 Above 1000 and not being 1.00 0.40 4.5 4.50
special building.
12 Above 500 and being 1.00 0.40 6.0 6.00
special building.
Notes: -
(i) In addition to above, ancillary area FSI up to the extent of 80%of the proposed FSI in the
development permission (including Basic FSI, Premium FSI but excluding the area covered
in Regulation No.6.8) shall be allowed with the payment of premium as specified in
Regulation No. 6.1.1.The notes mentioned below Table No.6-G of Regulation No. 6.3, which
are relevant in respect of industrial use, shall be applicable.
(ii) In case of Regional Plan areas, the plots fronting on National Highway, State Highway and
Major District Roads, the building line/ control line shall be as per Ribbon Development
Rules or as given in Table above, whichever is more.
(iii) Maximum floor height shall be 4.5 m. for industrial buildings. However, greater heights
maybe permitted as per the requirement.
(iv) Buffer zone - For construction of industrial building, a 23 m. wide buffer zone shall be kept
from residential or incompatible zone, wherever necessary. Such buffer zone may form part
of sizable required recreational open space. Roads and marginal distance may also be treated
as a part of Buffer Zone. However, area of such buffer zone, falling within the plot, shall be
counted in gross area for computation of FSI. Where green belt is shown in Development
Plan between residential and industrial zone, area of such green belt may be counted in gross
area for calculation of FSI, if land under such green belt is owned by the applicant.
Provided that, if the land under industrial zone is utilized entirely for non-polluting
industries, IT/ ITES or like purposes, then such buffer zone / open space shall not be
necessary.
6.5 FSI OF GREEN BELT
(1) Basic FSI alongwith full potential of premium FSI and TDR of the green belt zone shown on
the Development Plan / Regional Plan may be allowed on remaining land of the owner by
(1)
Inserted vide Corrigendum / Addendum CR 121/21, dt. 02nd December, 2021.
counting area of green belt in gross area of plot subject to condition that the area shall always be
under tree cover. The owner shall plant trees in this area with proper planning at the rate of
minimum 100 trees per hectare that should have survived for at least one year prior to issuance of
occupation certificate.
6.6 CALCULATION OF BUILTUP AREA FOR THE PURPOSES OF FSI.
Outer periphery of the construction floor wise (P-line) including everything but excluding ducts,
voids, and items in Regulation No. 6.8,shall be calculated for the purpose of computation of FSI.
The open balcony, double height terraces and cupboard shall also be included in P-line of
respective floor, irrespective of its use / function. If part of the stilt, podium or basement is
proposed for habitation purpose or for the construction which is counted in FSI, then such
construction shall also be measured in P-line in that respective floor.
6.7 PERMISSIBLE PROJECTIONS IN MARGINAL OPEN SPACES/ DISTANCES
The following projections shall be permissible in marginal open spaces:-
(a) Projections into Marginal Open Spaces:- Every open space provided either interior or
exterior shall be kept free from any erection thereon and shall be open to the sky and no
cornice, chajja, roof or weather shade more than 0.75 m. wide shall overhang or project over
the said marginal open spaces so as to reduce the width to less than the minimum required.
However, sloping/ horizontal chajja provided over balcony/ gallery etc. may be permitted up
to balcony projections at horizontal level.
(b) Balconies - as specified in Regulation No 9.14
(c) Ledge for Air conditioning unit as specified in Regulation No 9.5.
(d) A canopy or porch not exceeding 5m. in length and 2.5m. in width in the form of
cantilever and unenclosed over the main and subsidiary entrances providing a minimum
clear height of 2.4m. below the beam bottom of canopy. The canopy shall not have access
from upper floors (above floors), for using as sitting out place. There shall be a minimum
clearance of 1.5 m. between the plot boundaries and canopy.
Provided that more than one canopy may be permitted in the case of special buildings as per
requirement.
(e) A projection of maximum 30cm. on roof top terrace level may be allowed throughout the
periphery of the building. In case of pitched roof projection of maximum 45cm. at rooftop
level throughout periphery of the building shall be allowed.
(f) Accessory buildings: - The following accessory buildings may be permitted in the marginal
open spaces: -
i) In an existing building where toilet is not provided, a single storeyed toilet subject to a
maximum area of 4.0sq.m.in the rear or side open space and at a distance of 7.5m.
from the road line or the front boundary and 1.5m. from other boundaries may be
permissible. The Authority may reduce 1.5m. margin in exceptional cases to avoid
hardship.
ii) Parking lock-up garage not exceeding 2.4m. in height shall be permissible in the rear
corner of an independent bungalow plot. Parking lock up garage when attached to main
building shall be 7.5m. away from the road line and shall be of such construction
capable of giving fire resistance of 2 hours. The area of sanitary block and parking lock
up garage shall be taken into account for the calculation of FSI.
iii) Underground Suction tanks, soak pits, wet and dry garbage separately with collection
chambers, space required for fire hydrants, electrical and water-fittings, underground
water tanks, dustbins etc.
iv) One watchman's cabin/ booth not more than 6sq.m.in built up area having minimum
width or diameter of 1.80m. Cabin / booth may be allowed at every entrance and / or
exit.
Note :- When a building abuts three or more roads, the above mentioned uses, except (iv),
shall be permissible in front setback facing a smaller road of less importance from
traffic point of view.
(g) Ramp for basement in side and rear marginal distances subject to provisions under
Regulation No. 9.12.
(h) Fire escape staircase of single flight not less than 1.2m. width excluding the marginal
distance required for special building.
(i) Staircase mid-landing of 1.2m width with clear minimum headroom of 2.1m. below the
mid-landing. However, clear distance from edge of landing to the plot boundary shall not
be less than 1.8m.in case of non-special building and 6 m. in case of special building.
(j) Architectural projections - Architectural projections as specified in Regulations No. 9.30.
(k) Construction of ottas, railings, barricades or supporting columns for canopy or porch shall
not be permitted within the minimum required front marginal distances. However, steps or
steps along with otta may be permitted to project upto 1.2m. from the building line.
(l) Cupboard as specified in regulation No.9.6.
6.8 EXCLUSION OF STRUCTURES/ PROJECTIONS FOR FSI CALCULATION
i) Exclusion of Structures / Projections for FSI Calculation Structures/ Projections/features/
ornamental projection of glass façade permitted in marginal open spaces as mentioned in
Regulation No. 6.7 (a),(c),(d),(e),(f)(iii),(g),(1)(--),(j),(k).
ii) Stilt/ Multi-storeyed floors/ podium/ basement, if used (2) exclusively for parking including
passages (2) and staircase, Lift Duct / Lobby therein and basement used for users mentioned
in regulation 9.11.1 (i) to (iii).
iii) Areas covered by Porches, Canopies, lofts, ledge or tand, shelves, Air Conditioning Plant
Rooms, Lift Well, Lift-Machine Room and Service Floor of height not exceeding 1.8 m.
height (2) or as permissible as per Regulation No. 9.33 below the beam, for hospitals,
shopping malls, plazas and Star category hotels (rating with three stars and above) and like
buildings, other buildings above 15 m. in height.
iv) Area of structures for water, grey water, wet-waste or an effluent treatment plant, rain
water harvesting Pump rooms, (1) (--) electric cabin of sub-stations / of generator set area,
electric meter rooms as per requirements, Refuge chutes/ garbage chutes /garbage shafts
for wet and dry garbage separately with collection chambers.
v) Rockery, Well and well structures, Plant Nursery, Water Pool, platform around a tree,
Fountain, bench, Chabutara with open top and unenclosed sides, Ramps, Compound wall,
Gate, slide/ swing, Steps outside the buildings, Domestic working place (open to sky),
Overhead water tank on top of the building, Refuge area for high rise buildings as specified
in Regulation No. 9.29.6
(1)
The words (i) & ‗maximum 10 Sq.m.‘ deleted vide Corrigendum / Addendum CR 121/21, dt. 02nd December, 2021.
(2)
Inserted vide Corrigendum / Addendum CR 121/21, dt. 02nd December, 2021.
vi) Telecommunication tower, antenna and allied activities.
vii) Atrium may be allowed in any type of building. Such atrium may be allowed to be
enclosed on top by transparent or opaque sheet.
viii) Open to sky terraces, top of podium, open to sky swimming pool on the top terrace and top
of podium with plant room.
ix) Structures permissible in recreational open space as per Regulation No.3.4.7.
6.9 INTERIOR & EXTERIOR CHOWK
(a) Interior chowk : Wherever habitable rooms or kitchen derive ventilation from inner
chowk or interior open space, the minimum size of such interior open space shall not be
less than 3 m. x 3 m. (1) Further such interior chowk shall have an area of not less than the
square of one sixth of the height of the highest wall abutting the chowk considered from
the lowest point of the chowk, at all levels.
(b) Exterior chowk: The minimum width of the exterior chowk for the purpose of light and
ventilation shall not be less than 2.4m. and the depth shall not exceed 2 times the width, for
buildings up to 17 m. height and for height more than 17 m., the exterior open space shall
not be less than H/7m. x H/7m.where H= Height of highest wall of the Chowk from ground
level. If the width of the exterior chowk is less than 2.4m., it shall be treated as a notch and
shall not be considered for deriving ventilation.
(c) Where only water closet, bathroom, combined bathroom and water closet are abutting on
the interior open space, the size of the interior open space shall be in line with the
provision for ventilation shaft as given in Regulation No.9.20.2.
Provided that, for (a) and (b) above maximum distance shall be subject to 16 m. If the owner
wishes to provide chowk size more than what is prescribed above, it shall be allowed.
6.10 HEIGHT OF BUILDING
This regulation shall be applicable for buildings to be constructed in all land use zones, unless and
otherwise specified in the respective regulation.
6.10.1 (i) Height of building shall be allowed to the extent mentioned below subject to approval of
Chief Fire Officer of the Authority or Director of Fire services, if required, under these
regulations.
Sr. Authority / Area Permissible height (m.)
No. excluding parking floor upto
6m. height
1. For Pune, Pimpri-Chinchwad, Nagpur, Nashik, Permissible height as per
Municipal Corporations in MMR and Metropolitan approval from Fire Department.
Authorities area (2) and Area Development
Authorities, Special Planning Authorities (3) CIDCO as
Planning Authority by Virtue of NTDA within these areas.
2. For remaining Municipal Corporations area (2) and 70
Area Development Authorities, Special Planning
Authorities within these areas.
(1) Inserted Vide Corrigendum / Addendum No.CR 79/2021, dt. 02nd December 2021.
(2)
Inserted vide Corrigendum / Addendum CR 121/21, dt. 02nd December, 2021.
(3)
Inserted vide Notification u/s 37 (1AA)(c) No. CR 236/18 (Part 3), dt. 12th October 2022.
3. For All Municipal Councils, Nagar 50
Panchayats, Non Municipal Council D.P.
and Regional Plan areas.
Provided that higher height may be allowed in case of Integrated Township Project where fire
station and fire-fighting facilities are to be constructed/provided. Also, if such facilities are
available in nearby area of the project, then buildings of higher heights may be allowed in
such project. However, necessary certificate to that effect and NOC shall be produced from
Director of Fire Services.
(ii) The building height upto 24 m. shall be allowed on roads less than 12 m. For a building
having height more than 24 m., the minimum road width shall be 12m.
(iii) For building in the vicinity of aerodromes, the maximum height of buildings shall be subject
to parameters framed by the Civil Aviation Authorities or the development permission shall
be considered only after applicant produces NOC from Airport Authority.
(iv) (a) In addition to (iii), for Industrial Chimneys in the vicinity of aerodromes, it shall be of
such height and character as prescribed by Civil Aviation Authorities and all Industrial
Chimneys shall be of such character as prescribed by the Chief Inspector of Steam
Boilers and Smoke Nuisance, and
(b) Buildings intended for hazardous godowns for storage of inflammable materials and
storage of explosives shall be single storied structures only.
(v) The buildings of height more than 70 m., shall be allowed subject to fulfilment of the
requirements mentioned in Regulation No.6.12.
6.11 HEIGHT EXEMPTIONS
The appurtenant structures such as roof tanks and their supports, two toilets on terrace not
exceeding 8sq.m. built-up area and height upto 3 m. in case of residential building, ventilating, air-
conditioning structures, lift rooms and similar service equipment, stair cover, chimneys and
parapet walls and architectural features not exceeding height allowed in these regulations, and
Solar panels not exceeding 1.8 m. in height shall not be included in computation of height of
building.
6.12 REQUIREMENTS IN CASE OF BUILDING MORE THAN 70 M. HEIGHT
It is mandatory for all the high rise buildings to comply with the requirements of Structural Design
and Stability, Geo-technical and other aspects and Fire Safety norms as per provisions of UDCPR,
Maharashtra Fire (Prevention and life Safety Measures) Act, 2006 and National Building Code of
India, amended from time to time, for the aspects not covered in UDCPR. The certificates from
structural and geo-technical engineers about the fulfilment of necessary requirements shall be
attached with the application. The responsibility of structural and other stability and safety of such
high-rise buildings shall lie with owner/ developer and concerned expert, consultant, executants
appointed by owner/developer.
6.13 FSI OF LANDS AFFECTED BY HEMRL OR OTHER RESTRICTIONS
The lands which are affected by the restrictions of High Energy Material Research Laboratory or
provisions of other Central or State Government Acts, forms the part of the entire land, then FSI
of such affected land may be allowed to be utilised on the remaining contiguous land. However,
sub-division of such land shall not be allowed.
6.14 PROVISION OF RECREATIONAL FLOOR
In case of residential building having height more than 30 m., recreational floor may be allowed
subject to following-
i) the height of such floor shall be upto 4.5 m. and shall be open on all sides,
ii) such floor shall be used for recreational purpose/activities including construction of
swimming pool and shall be in addition to the recreational open space required as per
UDCPR,
iii) one such floor may be allowed at every 50 m. height, however, first floor may be allowed
after 30 m. height,
iv) such floor shall not be counted in FSI, however, ancillary constructions like changing room,
wash room, etc. shall be computed in FSI.
-*-*-*-*-*-