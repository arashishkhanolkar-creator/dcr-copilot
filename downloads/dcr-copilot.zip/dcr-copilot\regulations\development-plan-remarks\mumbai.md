# Mumbai — Development Plan (DP) Remarks

Researched from public sources (MCGM's DP Remarks portal and help pages, Landeed's
explainer, MMRDA's Zone Certificate/DP Remark service page) in September 2026.
This is process/concept knowledge, **not** a substitute for an actual plot's remark —
no plot-level GIS data is bundled with this skill (see "How to get one" below).

## What a DP Remark is, and why it comes before every other question

A DP Remark is an official extract from MCGM's Chief Engineer (Development Plan)
department stating how one specific plot appears in the Development Plan currently
in force — DP-2034, sanctioned by Government notification dated 8 May 2018 (the
same source `regulations/dcpr-2034/` was built from). It typically states:

- The plot's CTS/CS number (and Final Plot number, where the area has one)
- Its DP-2034 zoning (Residential, Commercial, Industrial, Natural Area, No
  Development Zone, etc. — see `regulations/dcpr-2034/part-vii-land-use-classification-and-uses-permitted.md`
  for the full classification and what's permitted in each)
- Any reservation shown on the DP over that land — Recreation Ground, Playground,
  Garden, Public/Semi-Public purpose, road-widening line, etc. (see
  `part-iii-land-uses-and-manner-of-development.md` for what a reservation means
  for buildable rights and the acquisition process, and `part-vi-additional-floor-space-index.md`
  for TDR/FSI compensation when reserved land is surrendered)
- The DCPR-2034 provisions that then apply to that zone

**This determines whether and what can be built at all — DCPR-2034's FSI, setback,
and parking tables (which this skill otherwise answers from) determine how much,
once the zone is known.** A plot under full or partial DP reservation can have
severely reduced or zero private buildable rights regardless of what the FSI table
alone would suggest. For any real feasibility question (as opposed to a pure
"what does the regulation say" lookup), establish the DP Remark first, not last.

## How to actually get one — this skill cannot look up a specific plot

No plot-level DP/GIS records are bundled here, and none are fetchable live by this
skill. If the user needs their own plot's remark, direct them to:

- **dpremarks.mcgm.gov.in/dp2034/** — MCGM's own DP Remarks portal. A paid online
  service; remarks are generated from MCGM's GIS system (online generation began
  April 2023). Needs the plot's CTS/CS number and Division/Ward.
- Alternatively, apply in person/in writing to MCGM's Chief Engineer (Development
  Plan) department — needed for RTI or legal-proceeding purposes where a portal
  printout isn't sufficient.
- **MMRDA's "Zone Certificate / DP Remark"** service is a related but distinct
  certificate used specifically for MMRDA clearances — don't conflate it with
  MCGM's own DP Remark if the project needs an MMRDA NOC.

Two caveats worth passing on, since they affect how much weight to put on any
remark the user already has:

1. MCGM generates the remark against the CS/CTS boundary **on record with MCGM**.
   Where that differs from the City Survey Office's own boundary records, the City
   Survey Office's records govern — a remark isn't the final word on boundary
   disputes.
2. DP-2034 has an ongoing modification/correction process even after the 2018
   sanction (reservations get shifted or lifted, road lines get corrected). Treat
   any DP Remark as time-stamped to when it was pulled, not permanent — a remark
   from a few years ago should be re-verified for anything reservation-sensitive.

## What to ask the user

When a Mumbai feasibility question comes in, ask (once, conversationally — not as
a checklist item) whether they already know the plot's DP zoning/reservation
status or have a DP Remark for it. If not, say plainly that this needs confirming
via the portal above before any FSI/setback/land-use answer can be treated as
final — reservation status overrides everything else this skill can otherwise
compute from the bundled DCPR-2034 text.
