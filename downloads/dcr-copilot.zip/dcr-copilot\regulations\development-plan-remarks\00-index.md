# Development Plan (DP) Remarks — Reference Index

Source: researched from public sources (MCGM's DP Remarks portal/help pages,
Landeed, MMRDA, CIDCO, Citizen Matters, Free Press Journal, OpenCity) in
September 2026 — process and jurisdiction knowledge, not a plot-level GIS
database. See each file's own header for exact sourcing and currency caveats.

> NOTE: this folder answers "what is a DP Remark / which authority and Development
> Plan govern this plot / how do I actually check" — it does not and cannot give
> any specific plot's zoning or reservation. For the DCR-type building rules
> (FSI, setbacks, parking) once the applicable zone/authority is known, use
> `regulations/dcpr-2034/` (Mumbai) or `regulations/udcpr/` (Navi Mumbai and the
> rest of Maharashtra) as normal.

## Files

- **Mumbai** -> `mumbai.md` (4051 chars) — what a DP Remark is, why it comes
  before FSI/setback questions, how to get one (dpremarks.mcgm.gov.in), caveats
  on boundary records and DP modifications since the 2018 sanction.
- **Navi Mumbai** -> `navi-mumbai.md` (4707 chars) — why "Navi Mumbai" spans
  multiple planning authorities (CIDCO / NMMC / MIDC / NAINA), the 1979-80
  original DP vs NMMC's 2018-2038 draft DP (still provisional as of the last
  verifiable status), and how to check a specific plot.

## When to use this folder

Any question that's really a **feasibility** question (can I build X here, at
all) rather than a pure regulation lookup (what does the FSI table say) should
route through here first for Mumbai or Navi Mumbai locations — a DP reservation
or the wrong planning authority overrides whatever DCPR-2034/UDCPR alone would
suggest. See `SKILL.md`'s "Step 0" for how this fits into the regulation-set
routing.
