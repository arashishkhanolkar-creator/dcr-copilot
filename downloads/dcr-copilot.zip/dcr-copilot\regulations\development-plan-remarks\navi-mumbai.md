# Navi Mumbai — Development Plan & Planning Authority

Researched from public sources (CIDCO's own pages, Citizen Matters reporting on the
NMMC draft DP, Free Press Journal coverage of the DP hearings, OpenCity's dataset
listing) in September 2026. Treat the sanction-status details below as the last
verifiable public update, not a live check — confirm current status with NMMC/CIDCO
before relying on it for anything reservation-sensitive.

## The one thing to establish before anything else: which authority actually governs this plot

"Navi Mumbai" is not one single planning jurisdiction, and this trips people up
constantly. Depending on where the plot sits, the *actual* planning authority —
and therefore which Development Plan and which DCR apply — can be:

- **CIDCO** — the original planner and, for much of Navi Mumbai (CIDCO-leased
  plots, and areas not yet handed over to the municipal corporation), still the
  Special Planning Authority. CIDCO's own Development Control Regulations apply
  on CIDCO land, not UDCPR by default.
- **NMMC** (Navi Mumbai Municipal Corporation) — the municipal corporation
  covering the handed-over, developed parts of Navi Mumbai. UDCPR Chapter 10,
  Section 10.10 (`regulations/udcpr/chapter-10-city-specific-regulations.md`)
  is where this skill's NMMC/CIDCO-area building regulations (FSI, redevelopment,
  TDR) live — use that for FSI/setback/redevelopment questions once NMMC
  jurisdiction is confirmed.
- **MIDC** — industrial areas within Navi Mumbai's footprint fall under MIDC's
  own planning control, separate from both of the above.
- **CIDCO as Special Planning Authority for NAINA** — the Navi Mumbai Airport
  Influence Notified Area, a large area around the airport that CIDCO plans
  separately under its own sanctioned Development Plan (sanctioned 16 Sept 2019),
  distinct from both "old" Navi Mumbai and from NMMC's own DP.

**Ask which of these applies before answering a Navi Mumbai question** if it isn't
already obvious from context (e.g. "is this on CIDCO-leased land, within NMMC's
corporation limits, an industrial MIDC plot, or in the NAINA area?") — the
regulation set and DP genuinely differ between them, the same way DCPR-2034 vs
UDCPR differ for Mumbai vs the rest of the state.

## Development Plan status (verify before relying on this)

- The **original Navi Mumbai Development Plan** was sanctioned by the State
  Government in 1979-80 (effective 1 March 1980) — a structural plan prepared by
  CIDCO under the MRTP Act, covering the originally-planned 14 nodes (Airoli,
  Ghansoli, Kopar Khairane, Vashi, Sanpada, Nerul, CBD Belapur, Kharghar, Kamothe,
  Kalamboli, New Panvel, Ulwe, Dronagiri, Pushpak). This set the broad zones
  still in force where CIDCO remains the authority: Residential, Commercial,
  Institutional, Industrial, Regional Park, No Development, and similar.
- **NMMC published its own draft Development Plan for 2018-2038 in August 2022**
  — the first DP prepared by NMMC itself rather than CIDCO. It went through
  objections/suggestions (80+20 days, closing 31 Oct 2022; over 15,000 objections
  received) and public hearings (14 March – 28 March 2023), after which it was to
  be forwarded to the State Government for final sanction. **The last publicly
  verifiable status found is "sent for state sanction after the March 2023
  hearings" — treat this draft DP's reservations and zoning as provisional, not
  final, until NMMC/the State Government confirms sanction.** A draft DP's
  reservations can still change before it's sanctioned.
- The draft 2018-2038 DP's proposed reservations include a **Slum Improvement
  Zone** (~0.98 sq km, ~0.9% of city land) among other civic-amenity reservations
  — reporting at the time noted this significantly under-represents Navi Mumbai's
  actual informal-settlement footprint, so don't assume "not shown as a slum
  reservation on the DP" means a site has no occupation/rehabilitation
  complications on the ground.

## How to actually check a specific plot

This skill has no bundled or live GIS access for Navi Mumbai plot records. Direct
the user to:

- **CIDCO** directly, for CIDCO-leased plots or anything in NAINA — CIDCO
  administers its own plot records and DP.
- **NMMC's Town Planning / Development Plan department**, for plots within
  NMMC's corporation limits.
- If it's unclear which authority applies, that itself is worth confirming first
  (via either office, or the plot's lease/ownership documents) — see above.

Once the authority and applicable zone are confirmed, come back to UDCPR Section
10.10 for the FSI, redevelopment, and TDR rules this skill can actually compute
from bundled text.
